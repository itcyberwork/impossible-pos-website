======================================================================
IMPOSSIBLE POS - HARDWARE STATIONS SETUP
======================================================================

Double-click "Impossible_POS_Hardware_Setup.exe" to configure this computer
as any station:
  - Kitchen Display (KDS Grill)
  - Kitchen Display (Bakery & Prep)
  - Bar Display (Cocktails & Beverages KDS)
  - Runner Hub (Expediter)
  - Customer Lobby TV
  - Hostess Hub
  - Secondary Cashier Register

The utility automatically finds your Impossible POS Central Server,
creates a desktop shortcut with the official station icon, and opens
in kiosk mode.
======================================================================
