======================================================================
IMPOSSIBLE POS - HARDWARE STATIONS SETUP
======================================================================

ENGLISH INSTRUCTIONS:
1. Right-click this folder or ZIP and choose "Extract All".
2. Double-click "Impossible_POS_Hardware_Setup.exe".
3. If Windows displays "Windows protected your PC":
   Click "More info" -> Click "Run anyway".
4. Select your station (Kitchen KDS, Bar KDS, Lobby TV, Hostess, Kiosk).
5. The station shortcut will automatically be created on your desktop.

----------------------------------------------------------------------
INSTRUCCIONES EN ESPANOL:
1. Haz clic derecho en esta carpeta o ZIP y elige "Extraer todo".
2. Haz doble clic en "Impossible_POS_Hardware_Setup.exe".
3. Si Windows muestra "Windows protegio su PC":
   Haz clic en "Mas informacion" -> Haz clic en "Ejecutar de todas formas".
4. Selecciona tu estacion (Cocina KDS, Bar KDS, TV de Pedidos, Hostess, Kiosco).
5. El acceso directo se creara automaticamente en tu escritorio.
======================================================================
