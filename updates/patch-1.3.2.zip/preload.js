const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('electron-minimize'),
  restore: () => ipcRenderer.send('electron-restore'),
  shutdown: () => ipcRenderer.send('system-shutdown'),
  restart: () => ipcRenderer.send('system-restart'),
  printCakeSilent: (orderId) => ipcRenderer.send('print-cake-silent', { orderId }),
  printInvoiceSilent: (orderId) => ipcRenderer.send('print-invoice-silent', { orderId }),
  getPrimaryScreenSourceId: () => ipcRenderer.invoke('get-primary-screen-source-id')
});
