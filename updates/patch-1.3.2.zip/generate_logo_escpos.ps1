param(
    [string]$ImagePath,
    [string]$OutputPath,
    [int]$MaxWidth = 384
)

Add-Type -AssemblyName System.Drawing

if (-not (Test-Path $ImagePath)) {
    Write-Error "Image file does not exist: $ImagePath"
    exit 1
}

try {
    # Load image without locking the file
    $bytes = [System.IO.File]::ReadAllBytes($ImagePath)
    $ms = New-Object System.IO.MemoryStream(,$bytes)
    $orig = [System.Drawing.Bitmap]::FromStream($ms)

    [int]$targetWidth = $MaxWidth
    if ($orig.Width -lt $targetWidth) {
        $targetWidth = [int]([Math]::Floor($orig.Width / 8) * 8)
        if ($targetWidth -lt 8) { $targetWidth = 8 }
    } else {
        $targetWidth = [int]([Math]::Floor($targetWidth / 8) * 8)
    }

    $ratio = [double]$targetWidth / [double]$orig.Width
    [int]$targetHeight = [int][Math]::Round($orig.Height * $ratio)
    if ($targetHeight -lt 1) { $targetHeight = 1 }

    $resized = New-Object System.Drawing.Bitmap([int]$targetWidth, [int]$targetHeight)
    $g = [System.Drawing.Graphics]::FromImage($resized)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.Clear([System.Drawing.Color]::White)
    $g.DrawImage($orig, 0, 0, $targetWidth, $targetHeight)
    $g.Dispose()
    $orig.Dispose()
    $ms.Dispose()

    [int]$widthBytes = [int]($targetWidth / 8)
    $xL = [byte]($widthBytes -band 0xFF)
    $xH = [byte](($widthBytes -shr 8) -band 0xFF)
    $yL = [byte]($targetHeight -band 0xFF)
    $yH = [byte](($targetHeight -shr 8) -band 0xFF)

    $byteList = New-Object System.Collections.Generic.List[byte]

    # ESC @: Initialize printer (ensure default mode)
    $byteList.Add([byte]0x1B)
    $byteList.Add([byte]0x40)

    # ESC a 1 (center alignment)
    $byteList.Add([byte]0x1B)
    $byteList.Add([byte]0x61)
    $byteList.Add([byte]0x01)

    # GS v 0 0 xL xH yL yH (Standard ESC/POS raster bit image)
    $byteList.Add([byte]0x1D)
    $byteList.Add([byte]0x76)
    $byteList.Add([byte]0x30)
    $byteList.Add([byte]0x00)
    $byteList.Add($xL)
    $byteList.Add($xH)
    $byteList.Add($yL)
    $byteList.Add($yH)

    for ($y = 0; $y -lt $targetHeight; $y++) {
        for ($xb = 0; $xb -lt $widthBytes; $xb++) {
            $b = 0
            for ($bit = 0; $bit -lt 8; $bit++) {
                $x = ($xb * 8) + $bit
                $pixel = $resized.GetPixel($x, $y)
                # If pixel is opaque and dark, set bit to 1 (black)
                $lum = ($pixel.R * 0.299) + ($pixel.G * 0.587) + ($pixel.B * 0.114)
                $isBlack = ($pixel.A -gt 80) -and ($lum -lt 190)
                if ($isBlack) {
                    $b = $b -bor (1 -shl (7 - $bit))
                }
            }
            $byteList.Add([byte]$b)
        }
    }
    $resized.Dispose()

    # Reset alignment to left ESC a 0 and line feed
    $byteList.Add([byte]0x1B)
    $byteList.Add([byte]0x61)
    $byteList.Add([byte]0x00)
    $byteList.Add([byte]0x0D)
    $byteList.Add([byte]0x0A)

    [System.IO.File]::WriteAllBytes($OutputPath, $byteList.ToArray())
    Write-Host "SUCCESS: Generated ESC/POS raster image ($targetWidth x $targetHeight, $($byteList.Count) bytes)"
} catch {
    Write-Error $_.Exception.Message
    exit 2
}
