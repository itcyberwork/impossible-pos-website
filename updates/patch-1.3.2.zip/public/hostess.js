// --- HOSTESS HUB BUSINESS LOGIC WITH WAITLIST INTEGRATION ---

let ws = null;
let currentReservations = [];
let waitlistItems = [];
let configuredTables = [];
let activeOrders = [];
let seatingReservationId = null; // Stored reservation ID or waitlist ID when Seating Mode is active
let selectedLang = 'es'; // default
let activeTab = 'reservations'; // 'reservations' or 'waitlist'

// Audio chime using Web Audio API (completely offline-friendly)
function playNewResChime() {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const playNote = (freq, startTime, duration) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime);
      gain.gain.setValueAtTime(0.3, startTime);
      gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration);
      osc.start(startTime);
      osc.stop(startTime + duration);
    };
    const now = audioCtx.currentTime;
    playNote(523.25, now, 0.3); // C5
    playNote(659.25, now + 0.15, 0.4); // E5
  } catch (err) {
    console.error("Audio Context failed:", err);
  }
}

// Websocket setup for real-time reactivity
function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}`;
  
  ws = new WebSocket(wsUrl);
  
  ws.onopen = () => {
    console.log("WebSocket connected to Server successfully!");
  };
  
  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      console.log("WS received event:", data.type);
      
      if (data.type === 'RESERVATIONS_UPDATED' || data.type === 'NEW_RESERVATION') {
        fetchReservations();
        if (data.type === 'NEW_RESERVATION') {
          playNewResChime();
          showNotificationPopup(data.reservation);
        }
      }
      
      if (data.type === 'WAITLIST_UPDATED') {
        fetchWaitlist();
      }
      
      if (data.type === 'TABLES_UPDATED') {
        fetchTables();
      }
      
      if (data.type === 'NEW_ORDER' || data.type === 'ORDER_UPDATED' || data.type === 'TABLES_UPDATED') {
        fetchActiveOrders();
      }
    } catch (e) {
      console.error("WebSocket message parsing error:", e);
    }
  };
  
  ws.onclose = () => {
    console.log("WebSocket closed. Reconnecting in 5s...");
    setTimeout(connectWebSocket, 5000);
  };
}

// Fetch configured tables from server
async function fetchTables() {
  try {
    const res = await fetch(`${SERVER_URL}/api/tables`);
    if (res.ok) {
      configuredTables = await res.json();
      populateTableDropdown();
      renderFloorMap();
    }
  } catch (err) {
    console.error("Error fetching tables layout:", err);
  }
}

// Fetch active orders to dynamically compute table occupancy
async function fetchActiveOrders() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      const all = await res.json();
      activeOrders = all.filter(o => o.paymentStatus === 'unpaid' && o.status !== 'void');
      renderFloorMap();
    }
  } catch (err) {
    console.error("Error fetching active orders:", err);
  }
}

// Fetch reservations list
async function fetchReservations() {
  try {
    const res = await fetch(`${SERVER_URL}/api/reservations`);
    if (res.ok) {
      currentReservations = await res.json();
      renderReservationsList();
      renderFloorMap();
    }
  } catch (err) {
    console.error("Error fetching reservations:", err);
  }
}

// Fetch waitlist list
async function fetchWaitlist() {
  try {
    const res = await fetch(`${SERVER_URL}/api/waitlist`);
    if (res.ok) {
      waitlistItems = await res.json();
      renderWaitlistList();
    }
  } catch (err) {
    console.error("Error fetching waitlist:", err);
  }
}

// Populates pre-assigned table options dropdown in Modal
function populateTableDropdown() {
  const select = document.getElementById('addResTableSelect');
  if (!select) return;
  select.innerHTML = '<option value="">Ninguna / None</option>';
  configuredTables.forEach(t => {
    const opt = document.createElement('option');
    opt.value = t.name;
    opt.innerText = `${t.name} (${t.shape})`;
    select.appendChild(opt);
  });
}

// Shows online reservation arriving popup
function showNotificationPopup(resObj) {
  const toast = document.createElement('div');
  toast.style.position = 'fixed';
  toast.style.bottom = '20px';
  toast.style.right = '20px';
  toast.style.background = 'rgba(26,26,30,0.95)';
  toast.style.border = '2px solid var(--accent-color)';
  toast.style.boxShadow = '0 10px 30px rgba(0,0,0,0.8)';
  toast.style.borderRadius = '10px';
  toast.style.padding = '15px';
  toast.style.color = '#fff';
  toast.style.zIndex = '99999';
  toast.style.minWidth = '300px';
  toast.style.animation = 'slideIn 0.3s ease';

  toast.innerHTML = `
    <div style="font-weight:bold; color: var(--accent-color); font-size: 13px; margin-bottom: 5px;">⚡ NUEVA RESERVA ONLINE / NEW ONLINE BOOKING</div>
    <div style="font-size: 12px; margin-bottom: 8px;"><strong>${resObj.customerName}</strong> (${resObj.pax} pax)</div>
    <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 10px;">Hora: ${new Date(resObj.dateTime).toLocaleString()}</div>
    <div style="text-align: right;">
      <button onclick="this.parentElement.parentElement.remove()" style="padding: 4px 10px; font-size: 10px; background: var(--accent-color); border:none; border-radius:4px; font-weight:bold; cursor:pointer;">Entendido / Dismiss</button>
    </div>
  `;

  document.body.appendChild(toast);
}

// Render dynamic Floor Map on canvas
function renderFloorMap() {
  const canvas = document.getElementById('hostessTableCanvas');
  if (!canvas) return;
  canvas.innerHTML = '';

  if (configuredTables.length === 0) {
    canvas.innerHTML = `<div style="text-align: center; color: var(--text-secondary); margin-top: 150px; font-size: 13px;">No hay mesas configuradas. Configúrelas en Caja Admin -> Table Layout.</div>`;
    return;
  }

  // Pre-assigned maps for reservations of today
  const filterDateInput = document.getElementById('resFilterDate').value;
  const preAssignedMap = {};
  currentReservations.forEach(r => {
    if (r.status === 'confirmed' && r.tableNum) {
      const resDate = r.dateTime.split('T')[0];
      if (resDate === filterDateInput) {
        preAssignedMap[r.tableNum] = r;
      }
    }
  });

  configuredTables.forEach(t => {
    const el = document.createElement('div');
    el.style.position = 'absolute';
    el.style.left = t.x + '%';
    el.style.top = t.y + '%';
    el.style.cursor = 'pointer';
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.alignItems = 'center';
    el.style.justifyContent = 'center';
    el.style.userSelect = 'none';
    el.style.color = '#fff';
    el.style.zIndex = '10';

    // Shape settings
    let width = '75px';
    let height = '75px';
    let borderRadius = '10px';
    
    if (t.shape === 'circle') {
      borderRadius = '50%';
    } else if (t.shape === 'rectangle') {
      width = '115px';
      height = '65px';
    } else if (t.shape === 'half-moon') {
      width = '105px';
      height = '55px';
      borderRadius = '105px 105px 0 0';
    } else if (t.shape === 'long-bar') {
      width = '165px';
      height = '45px';
      borderRadius = '6px';
    } else if (t.shape === 'stool') {
      width = '45px';
      height = '45px';
      borderRadius = '50%';
    }

    el.style.width = width;
    el.style.height = height;
    el.style.borderRadius = borderRadius;

    // Check if table is occupied
    const isOccupied = activeOrders.some(o => o.tableNumber === t.name || o.tableNumber === t.id);
    const preAssigned = preAssignedMap[t.name] || preAssignedMap[t.id];

    // Background & border themes
    el.style.border = '2px solid rgba(255,255,255,0.15)';
    el.style.background = 'rgba(255,255,255,0.03)';
    
    if (isOccupied) {
      el.style.border = '2px solid #0a84ff';
      el.style.background = 'rgba(10, 132, 255, 0.15)';
      el.style.boxShadow = '0 0 10px rgba(10, 132, 255, 0.4)';
    } else if (preAssigned) {
      el.style.border = '2px dashed var(--warning-color)';
      el.style.background = 'rgba(255, 214, 10, 0.1)';
    }

    // Seating Mode active classes
    if (seatingReservationId && !isOccupied) {
      el.classList.add('seating-target');
      el.style.animation = 'pulseGlow 1.5s infinite alternate';
    }

    // Label content inside table
    el.innerHTML = `
      <div style="font-weight: bold; font-size: 13px;">${t.name}</div>
      <div style="font-size: 9px; color: var(--text-secondary);">${isOccupied ? 'Ocupada' : (preAssigned ? 'Reservada' : 'Libre')}</div>
    `;

    // Click handler for table
    el.onclick = () => {
      if (seatingReservationId) {
        if (isOccupied) {
          alert(selectedLang === 'es' ? 'La mesa está ocupada' : 'Table is already occupied!');
          return;
        }
        assignTableAndSeat(seatingReservationId, t.name);
      } else {
        if (isOccupied) {
          const matchOrder = activeOrders.find(o => o.tableNumber === t.name || o.tableNumber === t.id);
          alert((selectedLang === 'es' ? 'Mesa ocupada por comanda de: ' : 'Occupied by: ') + (matchOrder.clientName || 'Cliente Anónimo') + ` (${matchOrder.guestCount} pax)`);
        } else {
          alert((selectedLang === 'es' ? 'Mesa libre: ' : 'Available Table: ') + t.name);
        }
      }
    };

    canvas.appendChild(el);
  });
}

// Seat a reservation or waitlist entry at a specific table
async function assignTableAndSeat(idVal, tableNum) {
  try {
    if (String(idVal).startsWith('wl_')) {
      // It's a Waitlist guest!
      const entry = waitlistItems.find(w => w.id === idVal);
      if (entry) {
        const newOrder = {
          status: 'pendiente',
          paymentStatus: 'unpaid',
          cashierName: 'Hostess Hub',
          clientName: entry.name,
          clientPhone: entry.phone,
          deliveryType: 'comer',
          tableNumber: tableNum,
          guestCount: entry.partySize || 1,
          activeSeat: '1',
          items: [],
          subtotal: 0,
          tax: 0,
          total: 0,
          cardTip: 0,
          notes: 'Seated from waitlist'
        };

        const orderRes = await fetch(`${SERVER_URL}/api/orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newOrder)
        });

        if (orderRes.ok) {
          await fetch(`${SERVER_URL}/api/waitlist/remove`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: idVal })
          });
          
          cancelSeatingMode();
          fetchWaitlist();
          fetchActiveOrders();
        }
      }
    } else {
      // It's a standard booking reservation
      const assignRes = await fetch(`${SERVER_URL}/api/reservations/${idVal}/assign-table`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableNum })
      });

      if (assignRes.ok) {
        const statusRes = await fetch(`${SERVER_URL}/api/reservations/${idVal}/status`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'seated' })
        });

        if (statusRes.ok) {
          cancelSeatingMode();
          fetchReservations();
          fetchActiveOrders();
        }
      }
    }
  } catch (err) {
    console.error("Error Seating customer:", err);
  }
}

// Render Reservations list panel
function renderReservationsList() {
  const list = document.getElementById('hostessResList');
  if (!list) return;
  list.innerHTML = '';

  const filterDateVal = document.getElementById('resFilterDate').value;
  const filtered = currentReservations.filter(r => r.dateTime.split('T')[0] === filterDateVal);

  if (filtered.length === 0) {
    list.innerHTML = `<div style="text-align: center; color: var(--text-secondary); margin-top: 50px; font-size: 12px;">No hay reservaciones para esta fecha. / No bookings for this date.</div>`;
    return;
  }

  filtered.forEach(r => {
    const card = document.createElement('div');
    card.className = `res-card ${r.status}`;

    const dateObj = new Date(r.dateTime);
    const timeStr = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let statusLabel = r.status.toUpperCase();
    if (selectedLang === 'es') {
      const labelMap = { 'pending': 'PENDIENTE', 'confirmed': 'CONFIRMADA', 'seated': 'SENTADO', 'cancelled': 'CANCELADA' };
      statusLabel = labelMap[r.status] || r.status;
    }

    let actionButtons = '';
    if (r.status === 'pending') {
      actionButtons = `
        <button class="btn-action confirm" onclick="updateStatus('${r.id}', 'confirmed')">Confirmar</button>
        <button class="btn-action cancel" onclick="updateStatus('${r.id}', 'cancelled')">Cancelar</button>
      `;
    } else if (r.status === 'confirmed') {
      actionButtons = `
        <button class="btn-action seat" onclick="startSeatingMode('${r.id}', '${r.customerName}', '${r.tableNum}')">Sentar / Seat</button>
        <button class="btn-action cancel" onclick="updateStatus('${r.id}', 'cancelled')">Cancelar</button>
      `;
    }

    card.innerHTML = `
      <div class="res-meta">
        <span class="res-name">${r.customerName}</span>
        <span class="res-pax">${r.pax} Pax</span>
      </div>
      <div style="font-size: 11px; color: var(--text-secondary); display: flex; justify-content: space-between;">
        <span>📞 ${r.customerPhone}</span>
        <span>Mesa: <strong>${r.tableNum || 'N/A'}</strong></span>
      </div>
      <div class="res-meta" style="margin-top: 4px;">
        <span class="res-time">⏰ ${timeStr} (${statusLabel})</span>
        <span style="font-size: 9px; padding: 2px 5px; border-radius: 3px; background: rgba(255,255,255,0.05);">${r.source === 'online' ? 'ONLINE' : 'LOCAL'}</span>
      </div>
      <div class="res-actions">
        ${actionButtons}
      </div>
    `;

    list.appendChild(card);
  });
}

// Render Waitlist panel
function renderWaitlistList() {
  const list = document.getElementById('hostessWaitlist');
  if (!list) return;
  list.innerHTML = '';

  if (waitlistItems.length === 0) {
    list.innerHTML = `<div style="text-align: center; color: var(--text-secondary); margin-top: 50px; font-size: 12px;">Lista de espera vacía. / Waitlist is empty.</div>`;
    return;
  }

  waitlistItems.forEach((item, index) => {
    const card = document.createElement('div');
    card.className = `res-card pending`;
    
    const countLabel = selectedLang === 'es' ? 'Personas' : 'Pax';
    const placeInQueue = index + 1;

    card.innerHTML = `
      <div class="res-meta">
        <span class="res-name"><span style="background-color: var(--accent-color); color:#000; display:inline-block; border-radius:50%; font-size:10px; width:16px; height:16px; text-align:center; line-height:16px; font-weight:bold; margin-right:4px;">${placeInQueue}</span> ${item.name}</span>
        <span class="res-pax">${item.partySize || 1} ${countLabel}</span>
      </div>
      <div style="font-size: 11px; color: var(--text-secondary); display: flex; justify-content: space-between; align-items: center;">
        <span>📞 ${item.phone}</span>
        <span style="font-size:10px;">⏰ ${new Date(item.dateAdded).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
      </div>
      <div class="res-actions" style="margin-top: 6px;">
        <button class="btn-action confirm" onclick="callWaitlistGuest('${item.id}')">🔔 Llamar / Call</button>
        <button class="btn-action seat" onclick="startSeatingMode('${item.id}', '${item.name}', 'N/A')">✓ Sentar / Seat</button>
        <button class="btn-action cancel" onclick="removeWaitlistGuest('${item.id}')">✕</button>
      </div>
    `;

    list.appendChild(card);
  });
}

// Trigger Twilio SMS and Lobby TV overlay for waitlist clients
async function callWaitlistGuest(id) {
  try {
    const res = await fetch(`${SERVER_URL}/api/waitlist/call`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (res.ok) {
      alert(selectedLang === 'es' ? 'Mensaje enviado y cliente llamado en TV!' : 'Customer notified via SMS & Lobby TV!');
    }
  } catch (err) {
    console.error(err);
  }
}

// Remove from waitlist
async function removeWaitlistGuest(id) {
  if (!confirm(selectedLang === 'es' ? '¿Quitar de la lista de espera?' : 'Remove from waitlist?')) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/waitlist/remove`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (res.ok) {
      fetchWaitlist();
    }
  } catch (err) {
    console.error(err);
  }
}

// Update Status from UI click
async function updateStatus(id, status) {
  try {
    const res = await fetch(`${SERVER_URL}/api/reservations/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) {
      fetchReservations();
    }
  } catch (err) {
    console.error("Error updating reservation status:", err);
  }
}

// Start interactive seating mode
function startSeatingMode(id, name, preAssignedTable) {
  seatingReservationId = id;
  document.getElementById('seatingCustomerName').innerText = name;
  document.getElementById('seatingPreAssignedTable').innerText = preAssignedTable || 'N/A';
  document.getElementById('seatingActiveBanner').style.display = 'block';
  renderFloorMap();
}

// Cancel Seating mode
function cancelSeatingMode() {
  seatingReservationId = null;
  document.getElementById('seatingActiveBanner').style.display = 'none';
  renderFloorMap();
}

// Save Local Reservation
async function saveReservation() {
  const name = document.getElementById('addResName').value.trim();
  const phone = document.getElementById('addResPhone').value.trim();
  const dateTime = document.getElementById('addResDateTime').value;
  const pax = document.getElementById('addResPax').value;
  const tableNum = document.getElementById('addResTableSelect').value;

  if (!name || !phone || !dateTime) {
    alert(selectedLang === 'es' ? 'Faltan campos requeridos (*)' : 'Missing required fields (*)');
    return;
  }

  try {
    const res = await fetch(`${SERVER_URL}/api/reservations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerName: name,
        customerPhone: phone,
        dateTime,
        pax,
        tableNum
      })
    });

    if (res.ok) {
      closeAddReservationModal();
      fetchReservations();
    } else {
      alert("Error saving reservation.");
    }
  } catch (err) {
    console.error(err);
  }
}

// Save Waitlist Guest from Modal
async function saveWaitlistGuest() {
  const name = document.getElementById('addWlName').value.trim();
  const phone = document.getElementById('addWlPhone').value.trim();
  const partySize = document.getElementById('addWlPax').value;

  if (!name || !phone) {
    alert(selectedLang === 'es' ? 'Faltan campos requeridos (*)' : 'Missing required fields (*)');
    return;
  }

  try {
    const res = await fetch(`${SERVER_URL}/api/waitlist/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name,
        phone,
        partySize
      })
    });

    if (res.ok) {
      closeAddWaitlistModal();
      fetchWaitlist();
    } else {
      alert("Error adding waitlist entry.");
    }
  } catch (err) {
    console.error(err);
  }
}

// Open/Close modals
function openAddReservationModal() {
  const now = new Date();
  const localIso = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  document.getElementById('addResDateTime').value = localIso;
  document.getElementById('addResName').value = '';
  document.getElementById('addResPhone').value = '';
  document.getElementById('addResPax').value = '2';
  document.getElementById('addResTableSelect').value = '';
  document.getElementById('modalAddReservation').style.display = 'flex';
}

function closeAddReservationModal() {
  document.getElementById('modalAddReservation').style.display = 'none';
}

function openAddWaitlistModal() {
  document.getElementById('addWlName').value = '';
  document.getElementById('addWlPhone').value = '';
  document.getElementById('addWlPax').value = '2';
  document.getElementById('modalAddWaitlist').style.display = 'flex';
}

function closeAddWaitlistModal() {
  document.getElementById('modalAddWaitlist').style.display = 'none';
}

// Tab switches
function switchTab(tabName) {
  activeTab = tabName;
  const resBtn = document.getElementById('tabReservationsBtn');
  const wlBtn = document.getElementById('tabWaitlistBtn');
  const resList = document.getElementById('hostessResList');
  const wlList = document.getElementById('hostessWaitlist');
  const dateWrapper = document.getElementById('dateFilterWrapper');

  if (tabName === 'reservations') {
    resBtn.style.background = 'var(--accent-color)';
    resBtn.style.color = '#000';
    wlBtn.style.background = 'rgba(255,255,255,0.05)';
    wlBtn.style.color = '#fff';
    resList.style.display = 'flex';
    wlList.style.display = 'none';
    dateWrapper.style.opacity = '1';
    dateWrapper.style.pointerEvents = 'auto';
  } else {
    wlBtn.style.background = 'var(--accent-color)';
    wlBtn.style.color = '#000';
    resBtn.style.background = 'rgba(255,255,255,0.05)';
    resBtn.style.color = '#fff';
    resList.style.display = 'none';
    wlList.style.display = 'flex';
    dateWrapper.style.opacity = '0';
    dateWrapper.style.pointerEvents = 'none';
  }
}

// Set up UI Event listeners on window load
window.addEventListener('DOMContentLoaded', () => {
  const todayStr = new Date().toISOString().split('T')[0];
  document.getElementById('resFilterDate').value = todayStr;

  // Bind Buttons
  document.getElementById('btnNewReservation').onclick = openAddReservationModal;
  document.getElementById('btnCancelAddRes').onclick = closeAddReservationModal;
  document.getElementById('btnSaveAddRes').onclick = saveReservation;

  document.getElementById('btnNewWaitlist').onclick = openAddWaitlistModal;
  document.getElementById('btnCancelAddWl').onclick = closeAddWaitlistModal;
  document.getElementById('btnSaveAddWl').onclick = saveWaitlistGuest;

  document.getElementById('tabReservationsBtn').onclick = () => switchTab('reservations');
  document.getElementById('tabWaitlistBtn').onclick = () => switchTab('waitlist');

  document.getElementById('resFilterDate').onchange = () => {
    fetchReservations();
    renderFloorMap();
  };

  // Language Toggle
  document.getElementById('btnLanguageToggle').onclick = () => {
    selectedLang = selectedLang === 'es' ? 'en' : 'es';
    document.getElementById('btnLanguageToggle').innerText = selectedLang === 'es' ? 'ES/EN' : 'EN/ES';
    renderReservationsList();
    renderWaitlistList();
  };

  // Init Data fetches
  fetchTables();
  fetchActiveOrders();
  fetchReservations();
  fetchWaitlist();

  // Start WS listen
  connectWebSocket();
});

// CSS Injection for Seating Mode Pulsing glow
const style = document.createElement('style');
style.innerHTML = `
  @keyframes pulseGlow {
    from {
      box-shadow: 0 0 5px rgba(255, 159, 10, 0.2);
      border-color: rgba(255, 159, 10, 0.4);
    }
    to {
      box-shadow: 0 0 15px rgba(255, 159, 10, 0.8);
      border-color: var(--accent-color);
    }
  }
  @keyframes slideIn {
    from { transform: translateY(50px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }
`;
document.head.appendChild(style);
