const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let activeWebSocket = null;
let currentLanguage = 'en';

document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  initClock();
  initWebSocket();
  loadOrders();
  setupFullscreen();
  
  // Inicializar QR y lista de espera
  initWaitlistQR();
  loadWaitlist();
  
  // Revisar pasteles programados cada 30 segundos (el buffer de 10 minutos)
  setInterval(checkScheduledOrders, 30000);
});

async function loadSettings() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      const settings = await res.json();
      currentLanguage = settings.langLobby || settings.language || 'en';
      const logoEl = document.getElementById('lobbyLogoText') || document.querySelector('.lobby-logo');
      if (logoEl && settings.businessName) {
        logoEl.innerText = settings.businessName;
      }
      applyStaticTranslations();
    }
  } catch (e) {
    console.error("Error loading settings in Lobby:", e);
  }
}

function applyStaticTranslations() {
  const isEs = currentLanguage === 'es';
  
  document.title = isEs ? "Impossible POS™ - Sala de Espera" : "Impossible POS™ - Lobby Display";
  
  const titleText = document.querySelector('.lobby-header div[style*="font-size: 22px"]');
  if (titleText) {
    titleText.innerText = isEs ? 'ENTREGAS DEL DÍA' : "TODAY'S DELIVERIES";
  }
  
  const prepHeader = document.querySelector('.board-column-header.preparing');
  if (prepHeader) prepHeader.innerText = isEs ? 'En Proceso' : 'Preparing';
  
  const readyHeader = document.querySelector('.board-column-header.ready');
  if (readyHeader) readyHeader.innerText = isEs ? 'Listo para Recoger' : 'Ready for Pickup';
  
  const fsBtn = document.getElementById('btnToggleFullscreen');
  if (fsBtn) {
    fsBtn.innerText = isEs ? 'Pantalla Completa (F11)' : 'Fullscreen (F11)';
  }
}

// Reloj digital en la esquina
function initClock() {
  const clockEl = document.getElementById('lblClock');
  setInterval(() => {
    const now = new Date();
    clockEl.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }, 1000);
}

// Conectar WebSockets para actualizar instantáneamente
function initWebSocket() {
  activeWebSocket = new WebSocket(WS_URL);
  
  activeWebSocket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'NEW_ORDER' || data.type === 'ORDER_UPDATED') {
      loadOrders();
      if (data.type === 'ORDER_UPDATED' && data.order.status === 'listo') {
        playChime(); // Timbre cuando un pedido está listo
      }
    } else if (data.type === 'WAITLIST_UPDATED') {
      renderWaitlist(data.waitlist);
    } else if (data.type === 'WAITLIST_CALL') {
      const overlay = document.getElementById('lobbyCallOverlay');
      const overlayName = document.getElementById('lblOverlayCallName');
      if (overlay && overlayName) {
        overlayName.innerText = data.name;
        overlay.style.display = 'flex';
        playChime();
        setTimeout(() => {
          overlay.style.display = 'none';
        }, 6000);
      }
    }
  };

  activeWebSocket.onclose = () => {
    setTimeout(initWebSocket, 5000);
  };
}

// Cargar órdenes del servidor
async function loadOrders() {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    orders = await response.json();
    renderBoard();
  } catch (error) {
    console.error('Error cargando datos para TV:', error);
  }
}

// Renderizar columnas de la televisión
function renderBoard() {
  const listPreparing = document.getElementById('listPreparing');
  const listReady = document.getElementById('listReady');
  
  listPreparing.innerHTML = '';
  listReady.innerHTML = '';

  const now = new Date();

  orders.forEach(order => {
    const isCake = order.items.some(i => i.isCustomCake);
    
    // Si la orden está entregada, no mostrar
    if (order.status === 'entregado') return;

    // --- REGLAS DE COLUMNA 1: EN PROCESO ---
    // Se muestra si:
    // A) El estatus ya es activamente "en_preparacion" o "en_decoracion"
    // B) Es una orden normal no-pastel "pendiente" (ej. tacos, sodas que se hacen al momento)
    // C) Es un pastel "pendiente" cuya hora de recogida está dentro del buffer de 10 minutos (o ya pasó)
    let shouldShowInPrep = false;

    if (order.status === 'en_preparacion' || order.status === 'en_decoracion') {
      shouldShowInPrep = true;
    } else if (order.status === 'pendiente') {
      if (!isCake) {
        shouldShowInPrep = true; // Orden normal se procesa al momento
      } else {
        // Validar regla de los 10 minutos para pasteles
        const cakeItem = order.items.find(i => i.isCustomCake);
        const pickupDateStr = cakeItem.details.pickupDate; // AAAA-MM-DD
        const pickupTimeStr = cakeItem.details.pickupTime; // HH:MM
        
        const pickupDateTime = new Date(`${pickupDateStr}T${pickupTimeStr}`);
        const diffMs = pickupDateTime.getTime() - now.getTime();
        const diffMins = diffMs / 60000;

        // Mostrar si faltan 10 minutos o menos, o si la hora ya pasó y el cliente está retrasado
        if (diffMins <= 10) {
          shouldShowInPrep = true;
        }
      }
    }

    if (shouldShowInPrep) {
      const card = document.createElement('div');
      card.className = 'lobby-order-card';
      
      const isEs = currentLanguage === 'es';
      const clientName = isCake ? order.items[0].details.clientName : (isEs ? 'Cliente' : 'Customer');
      const orderNum = order.id.substring(2, 8).toUpperCase();

      card.innerHTML = `
        <span class="lobby-order-num">#${orderNum}</span>
        <span class="lobby-order-name">${clientName}</span>
      `;
      listPreparing.appendChild(card);
    }

    // --- REGLAS DE COLUMNA 2: LISTO PARA RECOGER ---
    if (order.status === 'listo') {
      const card = document.createElement('div');
      card.className = 'lobby-order-card ready';
      
      const isEs = currentLanguage === 'es';
      const clientName = isCake ? order.items[0].details.clientName : (isEs ? 'Cliente' : 'Customer');
      const orderNum = order.id.substring(2, 8).toUpperCase();

      card.innerHTML = `
        <span class="lobby-order-num">#${orderNum}</span>
        <span class="lobby-order-name" style="color: var(--success-color);">${clientName}</span>
      `;
      listReady.appendChild(card);
    }
  });
}

// Reloj interno de sondeo para refrescar si hay pedidos futuros listos para entrar al buffer
function checkScheduledOrders() {
  loadOrders();
}

// Botón para pantalla completa táctil (Modo Kiosco nativo)
function setupFullscreen() {
  const btn = document.getElementById('btnToggleFullscreen');
  btn.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((err) => {
        console.error(`Error al activar pantalla completa: ${err.message}`);
      });
      btn.innerText = "Salir de Pantalla Completa";
    } else {
      document.exitFullscreen();
      btn.innerText = "Pantalla Completa (F11)";
    }
  });
}

// Sonido de timbre (chime) cuando una comanda está lista
function playChime() {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    
    // Tocar un acorde arpegiado agradable (Do - Mi - Sol)
    const playNote = (freq, delay, duration) => {
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioContext.currentTime + delay);
      
      gain.gain.setValueAtTime(0, audioContext.currentTime + delay);
      gain.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + delay + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + delay + duration);
      
      osc.connect(gain);
      gain.connect(audioContext.destination);
      
      osc.start(audioContext.currentTime + delay);
      osc.stop(audioContext.currentTime + delay + duration);
    };

    playNote(523.25, 0, 0.5);   // Do5
    playNote(659.25, 0.15, 0.5); // Mi5
    playNote(783.99, 0.3, 0.8);  // Sol5
  } catch (e) {
    console.log("Audio bloqueado por el navegador");
  }
}

async function initWaitlistQR() {
  const qrContainer = document.getElementById('waitlistQRContainer');
  if (!qrContainer) return;
  qrContainer.innerHTML = 'QR...';
  
  // 1. Fetch settings to render Wi-Fi QR if configured
  try {
    const settingsRes = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (settingsRes.ok) {
      const settings = await settingsRes.json();
      if (settings.wifiSSID && settings.wifiSSID.trim() !== '') {
        const wifiWrapper = document.getElementById('wifiQRWrapper');
        const wifiContainer = document.getElementById('wifiQRContainer');
        if (wifiWrapper && wifiContainer) {
          wifiContainer.innerHTML = '';
          const ssid = settings.wifiSSID.trim();
          const pass = (settings.wifiPassword || '').trim();
          // WIFI format: WIFI:S:SSID;T:WPA;P:PASSWORD;;
          const wifiText = `WIFI:S:${ssid};T:WPA;P:${pass};;`;
          
          new QRCode(wifiContainer, {
            text: wifiText,
            width: 80,
            height: 80,
            colorDark : "#000000",
            colorLight : "#ffffff"
          });
          wifiWrapper.style.display = 'flex';
        }
      }
    }
  } catch(e) {
    console.warn("Could not load Wi-Fi configuration settings in Lobby:", e);
  }

  // 2. Fetch public/local URL for Waitlist QR
  let targetUrl = `${window.location.origin}/waitlist.html`; // fallback local
  try {
    const response = await fetch(`${SERVER_URL}/api/tunnel-url`);
    if (response.ok) {
      const data = await response.json();
      if (data.url) {
        const baseUrl = data.url.endsWith('/') ? data.url.slice(0, -1) : data.url;
        targetUrl = `${baseUrl}/waitlist.html`;
      }
    }
  } catch(e) {
    console.warn("Could not fetch tunnel url in waitlist lobby", e);
  }
  
  try {
    qrContainer.innerHTML = '';
    new QRCode(qrContainer, {
      text: targetUrl,
      width: 80,
      height: 80,
      colorDark : "#000000",
      colorLight : "#ffffff"
    });
  } catch(err) {
    console.error(err);
  }

  // 3. Fetch public/local URL for Car Self-Ordering QR
  let carOrderUrl = `${window.location.origin}/ordena.html`;
  try {
    const response = await fetch(`${SERVER_URL}/api/tunnel-url`);
    if (response.ok) {
      const data = await response.json();
      if (data.url) {
        const baseUrl = data.url.endsWith('/') ? data.url.slice(0, -1) : data.url;
        carOrderUrl = `${baseUrl}/ordena.html`;
      }
    }
  } catch(e) {
    console.warn("Could not fetch tunnel url for car self-ordering", e);
  }

  // Draw if settings enableCarSelfOrdering !== false
  try {
    const settingsRes = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (settingsRes.ok) {
      const settings = await settingsRes.json();
      if (settings.enableCarSelfOrdering !== false) {
        const carWrapper = document.getElementById('carOrderQRWrapper');
        const carContainer = document.getElementById('carOrderQRContainer');
        if (carWrapper && carContainer) {
          carContainer.innerHTML = '';
          new QRCode(carContainer, {
            text: carOrderUrl,
            width: 80,
            height: 80,
            colorDark : "#000000",
            colorLight : "#ffffff"
          });
          carWrapper.style.display = 'flex';
        }
      }
    }
  } catch(e) {
    console.warn("Could not draw car order QR:", e);
  }
}

async function loadWaitlist() {
  try {
    const res = await fetch(`${SERVER_URL}/api/waitlist`);
    if (res.ok) {
      const list = await res.json();
      renderWaitlist(list);
    }
  } catch (e) {
    console.error("Error loading waitlist in Lobby:", e);
  }
}

function renderWaitlist(list) {
  const container = document.getElementById('lobbyWaitlistContainer');
  if (!container) return;
  container.innerHTML = '';
  
  if (!list || list.length === 0) {
    const isEs = currentLanguage === 'es';
    container.innerHTML = `<span style="color: var(--text-secondary); font-size: 12px;">${isEs ? 'Sin personas en espera' : 'No customers waiting'}</span>`;
    return;
  }
  
  list.forEach((item, index) => {
    const el = document.createElement('div');
    el.style.backgroundColor = '#14141a';
    el.style.border = '1px solid var(--border-color)';
    el.style.borderRadius = '8px';
    el.style.padding = '8px 12px';
    el.style.display = 'flex';
    el.style.alignItems = 'center';
    el.style.gap = '8px';
    el.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
    el.style.flexShrink = '0';
    el.innerHTML = `
      <span style="background-color: var(--accent-color); color: #000; font-weight: 900; border-radius: 50%; font-size: 11px; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center;">${index + 1}</span>
      <span style="font-weight: 600; font-size: 13px; color: #fff;">${item.name} <span style="color: var(--text-secondary); font-size: 11px;">(${item.partySize || 1} pax)</span></span>
    `;
    container.appendChild(el);
  });
}
