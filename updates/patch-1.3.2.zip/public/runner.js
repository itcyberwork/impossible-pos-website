const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let activeWebSocket = null;
let currentLanguage = 'en';
let currentPage = 0;

function isMeatModifier(name) {
  const n = name.toLowerCase().trim();
  const meats = ['asada', 'pollo', 'pastor', 'tripa', 'barbacoa', 'carnitas', 'lengua', 'chorizo', 'camaron', 'camarón', 'pescado', 'cabeza', 'barbacoa', 'chicharron', 'charrada', 'carne'];
  return meats.some(meat => n.includes(meat));
}

function getSortedFormattedModifiers(modifiers, isDarkBackground) {
  if (!modifiers || modifiers.length === 0) return '';
  
  // Sort by color: red (meat) first, then green (veg), then yellow (dressing), then default
  const colorOrder = { 'red': 1, 'green': 2, 'yellow': 3, 'default': 4 };
  const sorted = [...modifiers].sort((a, b) => {
    const cA = a.color || (isMeatModifier(a.name) ? 'red' : 'default');
    const cB = b.color || (isMeatModifier(b.name) ? 'red' : 'default');
    return (colorOrder[cA] || 5) - (colorOrder[cB] || 5);
  });
  
  const themeColors = {
    'red': isDarkBackground ? '#ff4d4f' : '#d9381e',
    'green': isDarkBackground ? '#52c41a' : '#388e3c',
    'yellow': isDarkBackground ? '#fadb14' : '#fbc02d',
    'default': isDarkBackground ? '#ffffff' : '#000000'
  };
  
  return sorted.map(m => {
    let c = m.color;
    // Fallback for old orders without color field
    if (!c) {
      c = isMeatModifier(m.name) ? 'red' : 'default';
    }
    const hexColor = themeColors[c] || themeColors['default'];
    return `<div style="color: ${hexColor}; font-weight: bold; font-size: 12px; margin-top: 1px; padding-left: 6px;">${m.name.toUpperCase()}</div>`;
  }).join('');
}

document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  initWebSocket();
  loadOrders();
  setupEventListeners();
});

async function loadSettings() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      const settings = await res.json();
      currentLanguage = settings.langRunner || settings.language || 'en';
      const logoEl = document.getElementById('runnerLogoText');
      if (logoEl && settings.businessName) {
        logoEl.innerText = settings.businessName;
      }
      applyStaticTranslations();
    }
  } catch (e) {
    console.error("Error loading settings in Runner:", e);
  }
}

function applyStaticTranslations() {
  const isEs = currentLanguage === 'es';
  
  document.title = isEs ? "Impossible POS™ - Pantalla de Despacho (Runner)" : "Impossible POS™ - Dispatch Screen (Runner)";
  
  const badge = document.querySelector('.logo-section .station-badge');
  if (badge) badge.innerText = isEs ? 'Pantalla de Despacho (Runner)' : 'Dispatch Screen (Runner)';
  
  const monitoringBadge = document.querySelector('.header-actions .station-badge');
  if (monitoringBadge) monitoringBadge.innerText = isEs ? 'Monitoreo de Entregas' : 'Delivery Monitoring';
}

// Inicializar WebSockets para tiempo real
function initWebSocket() {
  activeWebSocket = new WebSocket(WS_URL);
  
  activeWebSocket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    // Si hay un pedido nuevo o cambio de estado, refrescar
    if (data.type === 'NEW_ORDER' || data.type === 'ORDER_UPDATED') {
      loadOrders();
    }
  };

  activeWebSocket.onclose = () => {
    setTimeout(initWebSocket, 5000);
  };
}

// Cargar órdenes del servidor
async function loadOrders() {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    orders = await response.json();
    renderRunner();
  } catch (error) {
    const isEs = currentLanguage === 'es';
    showToast(isEs ? 'Error cargando despacho' : 'Error loading dispatch', 'error');
  }
}

// Renderizar pantalla de despacho
function renderRunner() {
  const container = document.getElementById('runnerContainer');
  container.innerHTML = '';

  const isEs = currentLanguage === 'es';

  // Filtrar órdenes: listo (terminadas) o pendiente (cocinándose)
  const activeOrders = orders.filter(o => o.status === 'listo' || o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion');

  if (activeOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">${isEs ? 'No hay pedidos activos' : 'No active orders'}</div>`;
    return;
  }

  // Ordenar priorizando:
  // 1. Drive-Through
  // 2. Estado "listo" antes de "pendiente"
  // 3. Orden cronológico de las demás órdenes
  activeOrders.sort((a, b) => {
    const aType = a.deliveryType || a.type || 'llevar';
    const bType = b.deliveryType || b.type || 'llevar';
    if (aType === 'drive-thru' && bType !== 'drive-thru') return -1;
    if (aType !== 'drive-thru' && bType === 'drive-thru') return 1;
    
    if (a.status === 'listo' && b.status !== 'listo') return -1;
    if (a.status !== 'listo' && b.status === 'listo') return 1;
    
    return new Date(b.dateCreated) - new Date(a.dateCreated);
  });

  // CALCULAR PAGINACIÓN (10 por página)
  const totalOrdersCount = activeOrders.length;
  const maxPage = Math.max(0, Math.ceil(totalOrdersCount / 10) - 1);
  if (currentPage > maxPage) {
    currentPage = maxPage;
  }
  
  const startIndex = currentPage * 10;
  const endIndex = startIndex + 10;
  const pageOrders = activeOrders.slice(startIndex, endIndex);

  // Actualizar indicador de páginas
  const lblPageIndicator = document.getElementById('lblRunnerPageIndicator');
  if (lblPageIndicator) {
    lblPageIndicator.innerText = `Page ${currentPage + 1} of ${maxPage + 1}`;
  }

  const readyOrders = activeOrders.filter(o => o.status === 'listo');

  pageOrders.forEach((order, index) => {
    const orderType = order.deliveryType || order.type || 'llevar';
    const card = document.createElement('div');
    card.className = `runner-card ${orderType === 'drive-thru' ? 'drive-thru' : ''}`;
    
    // Asignar número del 1 al 10 en la esquina izquierda de arriba a cada comanda
    let bumpBadge = '';
    if (index < 10) {
      bumpBadge = `<div class="bump-badge">${index + 1}</div>`;
      card.setAttribute('data-bump-key', index + 1);
    }

    let itemsHtml = '';
    let isCake = false;
    let cakeClientName = '';

    order.items.forEach(item => {
      const isItemToGo = item.isToGo || item.name.includes('(To Go)') || item.name.includes('(to go)');
      const itemStyle = `font-size: 13px; font-weight: bold; color: #fff;`;

      let specs = '';
      if (item.selectedModifiers && item.selectedModifiers.length > 0) {
        specs = `<div style="margin-top: 2px; display: block; width: 100%;">
          ${getSortedFormattedModifiers(item.selectedModifiers, true)}
        </div>`;
      }

      const seatMatch = item.name.match(/\(Cliente (\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
      const clientBadge = seatMatch 
        ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">C${seatMatch[1]}</span>` 
        : '';
      const cleanName = item.name.replace(/\(Cliente \d+\)/i, '').replace(/\(Seat \d+\)/i, '').replace(/\(to go\)/i, '').trim();

      itemsHtml += `
        <div class="runner-item" style="display: flex; align-items: center; flex-wrap: wrap; padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.05); width: 100%;">
          ${clientBadge}
          <span style="${itemStyle}">${item.quantity} ${cleanName}${isItemToGo ? ' <span style="color: #ff453a; font-weight: 900; margin-left: 6px;">TO GO</span>' : ''}</span>
          ${specs}
        </div>
      `;
      if (item.isCustomCake) {
        isCake = true;
        cakeClientName = item.details.clientName;
      }
    });

    const clientName = order.clientName || cakeClientName;
    const clientPhone = order.clientPhone || '';

    // Definir estilo del badge de entrega
    let typeClass = 'to-go';
    let typeText = 'To Go';
    if (orderType === 'drive-thru') {
      typeClass = 'drive-thru';
      typeText = 'DRIVE-THRU';
    } else if (orderType === 'comer') {
      typeClass = 'to-go';
      typeText = order.tableNumber ? (isEs ? `MESA ${order.tableNumber}` : `TABLE ${order.tableNumber}`) : (isEs ? 'MESA' : 'TABLE');
    } else if (orderType === 'walkin') {
      typeClass = 'to-go';
      typeText = isEs ? 'Caja / Mostrador' : 'Walk-In';
    } else if (orderType === 'pickup') {
      typeClass = 'to-go';
      typeText = isEs ? 'Recoger' : 'Pickup';
    } else if (orderType === 'delivery') {
      typeClass = 'to-go';
      typeText = isEs ? 'Domicilio' : 'Delivery';
    } else if (orderType === 'llevar') {
      typeClass = 'to-go';
      typeText = isEs ? 'Para Llevar' : 'To Go';
    }

    // Ubicación física (si es pastel)
    let locationHtml = '';
    if (isCake && order.shelfLocation) {
      let displayLoc = order.shelfLocation;
      if (isEs) {
        displayLoc = displayLoc.replace('Fridge', 'Refrigerador').replace('Shelf', 'Anaquel');
      } else {
        displayLoc = displayLoc.replace('Refrigerador', 'Fridge').replace('Anaquel', 'Shelf');
      }
      locationHtml = `
        <div class="runner-location-box">
          <span>${isEs ? 'Ubicación' : 'Location'}:</span>
          <span>${displayLoc}</span>
        </div>
      `;
    }

    // Estatus de la orden en cocina
    let statusBadge = '';
    const isPreparing = order.status === 'pendiente';
    if (isPreparing) {
      statusBadge = `<span class="runner-card-status preparing">${isEs ? 'Cocinándose' : 'Preparing'}</span>`;
    } else {
      statusBadge = `<span class="runner-card-status ready">${isEs ? '¡Listo!' : 'Ready'}</span>`;
    }

    // Botón de entrega condicionado con opción de imprimir etiqueta
    const deliverButtonHtml = isPreparing
      ? `<button class="btn-deliver disabled" disabled>${isEs ? 'Cocinándose' : 'Cooking...'}</button>`
      : `
        <div style="display: flex; gap: 8px; width: 100%;">
          <button class="btn-deliver" style="flex: 1;" onclick="deliverOrder('${order.id}')">${isEs ? 'Entregar' : 'Deliver'}</button>
          <button class="btn-deliver" style="flex: 1; background-color: #007aff; color: #fff;" onclick="openRunnerLabelModal('${order.id}')">${isEs ? 'Print' : 'Print'}</button>
        </div>
      `;

    const isPayAtPickup = order.paymentStatus === 'unpaid' && (order.type === 'pickup' || order.type === 'llevar' || order.type === 'delivery');
    const unpaidWarningHtml = isPayAtPickup
      ? `<div style="color: #ff453a; font-weight: bold; border: 1px solid #ff453a; background: rgba(255,69,58,0.1); padding: 6px; border-radius: 4px; margin-bottom: 6px; text-align: center; font-size: 13px;">
          ⚠️ UNPAID - PAY AT PICKUP
         </div>`
      : '';

    card.innerHTML = `
      <div class="runner-card-header">
        <div style="display: flex; align-items: center; gap: 6px;">
          ${bumpBadge}
          <span class="runner-card-num">ORD #${order.ticketNumber || order.id.substring(2, 8).toUpperCase()}</span>
        </div>
        <div style="display: flex; gap: 6px; align-items: center;">
          ${statusBadge}
          <span class="runner-card-type ${typeClass}">${typeText}</span>
        </div>
      </div>
      <div class="runner-card-body">
        ${unpaidWarningHtml}
        ${clientName ? `<div style="font-size:15px; font-weight:700; color:#fff;">${isEs ? 'Cliente' : 'Customer'}: ${clientName} ${clientPhone ? `(${clientPhone})` : ''}</div>` : ''}
        ${locationHtml}
        <div>${itemsHtml}</div>
      </div>
      <div class="runner-card-footer">
        ${deliverButtonHtml}
      </div>
    `;

    container.appendChild(card);
  });
}

// Entregar orden (cambia status a "entregado")
async function deliverOrder(orderId) {
  const isEs = currentLanguage === 'es';
  try {
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'entregado' })
    });
    
    if (response.ok) {
      showToast(isEs ? '¡Pedido entregado con éxito!' : 'Order delivered successfully!');
      loadOrders();
    }
  } catch (error) {
    showToast(isEs ? 'Error procesando la entrega' : 'Error processing delivery', 'error');
  }
}

// --- BUMP BAR TECLADO (1 al 9) Y EVENTOS DE MODAL ---
function setupEventListeners() {
  // Navegación de páginas
  const btnScrollBack = document.getElementById('btnRunnerScrollBack');
  if (btnScrollBack) {
    btnScrollBack.addEventListener('click', () => {
      if (currentPage > 0) {
        currentPage--;
        renderRunner();
      }
    });
  }

  const btnScrollNext = document.getElementById('btnRunnerScrollNext');
  if (btnScrollNext) {
    btnScrollNext.addEventListener('click', () => {
      const activeOrders = orders.filter(o => o.status === 'listo' || o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion');
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 10) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderRunner();
      }
    });
  }

  window.addEventListener('keydown', (e) => {
    const key = e.key;
    if (key === 'ArrowLeft' || key === 'PageUp') {
      if (currentPage > 0) {
        currentPage--;
        renderRunner();
      }
    } else if (key === 'ArrowRight' || key === 'PageDown') {
      const activeOrders = orders.filter(o => o.status === 'listo' || o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion');
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 10) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderRunner();
      }
    } else if (key >= '1' && key <= '9') {
      const card = document.querySelector(`.runner-card[data-bump-key="${key}"]`);
      if (card) {
        const deliverBtn = card.querySelector('.btn-deliver');
        if (deliverBtn && !deliverBtn.disabled && !deliverBtn.classList.contains('disabled')) {
          deliverBtn.click();
        }
      }
    }
  });

  // Modal Closures
  const btnClose = document.getElementById('btnCloseToGoPrintLabelModal');
  if (btnClose) {
    btnClose.addEventListener('click', () => {
      document.getElementById('modalToGoPrintLabel').style.display = 'none';
    });
  }

  const btnCancel = document.getElementById('btnCancelToGoPrintLabel');
  if (btnCancel) {
    btnCancel.addEventListener('click', () => {
      document.getElementById('modalToGoPrintLabel').style.display = 'none';
    });
  }

  // Toggle All Items
  const chkSelectAll = document.getElementById('chkSelectAllItems');
  if (chkSelectAll) {
    chkSelectAll.addEventListener('change', (e) => {
      const container = document.getElementById('togoPrintLabelItemsList');
      if (container) {
        const checkboxes = container.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(chk => {
          chk.checked = e.target.checked;
        });
      }
    });
  }

  // Confirm Print Label
  const btnConfirm = document.getElementById('btnConfirmToGoPrintLabel');
  if (btnConfirm) {
    btnConfirm.addEventListener('click', async () => {
      const orderId = document.getElementById('togoPrintLabelOrderId').value;
      const printMain = document.getElementById('chkPrintMainLabel').checked;
      const isEs = currentLanguage === 'es';
      
      const itemIndexes = [];
      const container = document.getElementById('togoPrintLabelItemsList');
      if (container) {
        const checkboxes = container.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(chk => {
          if (chk.checked) {
            itemIndexes.push(parseInt(chk.dataset.index));
          }
        });
      }

      if (!printMain && itemIndexes.length === 0) {
        showToast(isEs ? 'Selecciona al menos una etiqueta' : 'Select at least one label', 'error');
        return;
      }

      btnConfirm.disabled = true;
      const originalText = btnConfirm.innerText;
      btnConfirm.innerText = isEs ? 'Imprimiendo...' : 'Printing...';

      try {
        const res = await fetch(`${SERVER_URL}/api/printer/print-order-labels`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId, printMain, itemIndexes })
        });
        
        if (res.ok) {
          showToast(isEs ? 'Etiquetas enviadas' : 'Labels sent to printer', 'success');
          document.getElementById('modalToGoPrintLabel').style.display = 'none';
        } else {
          showToast(isEs ? 'Error al imprimir etiquetas' : 'Failed to print labels', 'error');
        }
      } catch (err) {
        showToast(isEs ? 'Error de conexión' : 'Connection error', 'error');
      } finally {
        btnConfirm.disabled = false;
        btnConfirm.innerText = originalText;
      }
    });
  }

  // Print Bag Ticket / Receipt Option
  const btnPrintReceipt = document.getElementById('btnPrintToGoReceipt');
  if (btnPrintReceipt) {
    btnPrintReceipt.addEventListener('click', async () => {
      const orderId = document.getElementById('togoPrintLabelOrderId').value;
      const isEs = currentLanguage === 'es';
      if (!orderId) return;

      btnPrintReceipt.disabled = true;
      const originalText = btnPrintReceipt.innerText;
      btnPrintReceipt.innerText = isEs ? 'Imprimiendo...' : 'Printing...';

      try {
        const res = await fetch(`${SERVER_URL}/api/printer/print-receipt/${orderId}`, {
          method: 'POST'
        });
        if (res.ok) {
          showToast(isEs ? '¡Ticket impreso con éxito!' : 'Receipt printed successfully!', 'success');
          document.getElementById('modalToGoPrintLabel').style.display = 'none';
        } else {
          showToast(isEs ? 'Error al imprimir ticket' : 'Failed to print receipt', 'error');
        }
      } catch (err) {
        showToast(isEs ? 'Error de conexión' : 'Connection error', 'error');
      } finally {
        btnPrintReceipt.disabled = false;
        btnPrintReceipt.innerText = originalText;
      }
    });
  }

  const btnViewToGoReceipt = document.getElementById('btnViewToGoReceipt');
  if (btnViewToGoReceipt) {
    btnViewToGoReceipt.addEventListener('click', () => {
      const orderId = document.getElementById('togoPrintLabelOrderId').value;
      if (orderId) {
        openWorkSheetModal(orderId);
      }
    });
  }

  const btnCloseWorkSheetModal = document.getElementById('btnCloseWorkSheetModal');
  if (btnCloseWorkSheetModal) {
    btnCloseWorkSheetModal.addEventListener('click', () => {
      document.getElementById('modalWorkSheetPreview').style.display = 'none';
    });
  }
}

window.openRunnerLabelModal = function(orderId) {
  const order = orders.find(o => o.id === orderId);
  const isEs = currentLanguage === 'es';
  if (!order) {
    showToast(isEs ? 'No se encontró el pedido' : 'Order not found', 'error');
    return;
  }

  document.getElementById('togoPrintLabelOrderId').value = orderId;
  document.getElementById('chkPrintMainLabel').checked = true;
  document.getElementById('chkSelectAllItems').checked = false;

  const listContainer = document.getElementById('togoPrintLabelItemsList');
  listContainer.innerHTML = '';

  (order.items || []).forEach((item, idx) => {
    const row = document.createElement('label');
    row.style.display = 'flex';
    row.style.alignItems = 'center';
    row.style.gap = '8px';
    row.style.padding = '6px 8px';
    row.style.backgroundColor = 'rgba(255,255,255,0.02)';
    row.style.border = '1px solid rgba(255,255,255,0.05)';
    row.style.borderRadius = '6px';
    row.style.cursor = 'pointer';
    row.style.fontSize = '12px';
    row.style.color = '#fff';

    row.innerHTML = `
      <input type="checkbox" data-index="${idx}" style="accent-color: var(--success-color); width: 16px; height: 16px;">
      <span>${item.quantity}x ${item.name}</span>
    `;
    listContainer.appendChild(row);
  });

  document.getElementById('modalToGoPrintLabel').style.display = 'flex';
};

// --- ALERTA TOAST ---
function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  toast.className = `toast ${type}`;
  toastText.innerText = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function openWorkSheetModal(orderId) {
  const order = orders.find(o => o.id === orderId);
  const isEs = currentLanguage === 'es';
  if (!order) {
    showToast(isEs ? 'No se encontró el pedido' : 'Order not found', 'error');
    return;
  }

  const modal = document.getElementById('modalWorkSheetPreview');
  const modalTitle = document.getElementById('lblWorkSheetModalTitle');
  const modalBody = document.getElementById('workSheetModalBody');

  if (!modal || !modalBody) return;

  modalTitle.innerText = isEs ? `📋 Vista Previa del Ticket #${order.ticketNumber || 'N/A'}` : `📋 Ticket Preview #${order.ticketNumber || 'N/A'}`;

  const orderType = order.deliveryType || order.type || 'llevar';
  const getTableDisplay = (o) => {
    const num = o.tableNumber;
    if (num) {
      return num.toLowerCase().includes('table') || num.toLowerCase().includes('mesa') ? num : `Table ${num}`;
    }
    return o.tableName || '';
  };
  const tableText = (orderType === 'comer') 
    ? (getTableDisplay(order) || 'TABLE N/A') 
    : 'TO GO';
  const tableStyle = (orderType === 'comer')
    ? 'font-size: 14px; font-weight: bold; color: #000;'
    : 'font-size: 14px; font-weight: bold; color: #ff3b30;';

  // Generar vista HTML estilo papel térmico
  let itemsHtml = '';
  (order.items || []).forEach(item => {
    let modsHtml = '';
    if (item.selectedModifiers && item.selectedModifiers.length > 0) {
      modsHtml = `<div style="margin-left: 12px; margin-top: 2px;">
        ${getSortedFormattedModifiers(item.selectedModifiers, false)}
      </div>`;
    }
    const isItemToGo = item.isToGo || item.name.includes('(To Go)') || item.name.includes('(to go)');
    const itemStyle = `font-size: 13px; font-weight: bold; color: #000;`;

    const seatMatch = item.name.match(/\(Cliente (\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
    const clientBadge = seatMatch 
      ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">C${seatMatch[1]}</span>` 
      : '';
    const cleanName = item.name.replace(/\(Cliente \d+\)/i, '').replace(/\(Seat \d+\)/i, '').replace(/\(to go\)/i, '').trim().toUpperCase();

    itemsHtml += `
      <div style="margin-bottom: 6px; border-bottom: 1px solid #eee; padding-bottom: 4px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="${itemStyle}">${clientBadge}${item.quantity} ${cleanName}${isItemToGo ? ' <span style="color: #ff3b30; font-weight: 950; margin-left: 6px;">TO GO</span>' : ''}</span>
          <span style="font-size: 13px; font-weight: bold; color: #000;">$${(item.price * item.quantity).toFixed(2)}</span>
        </div>
        ${modsHtml}
      </div>
    `;
  });

  const detailsHtml = `
    <div style="max-width: 420px; margin: 0 auto; padding: 10px; background-color: #fff; color: #000; font-family: 'Courier New', Courier, monospace; border: 2px dashed #000; border-radius: 4px; box-sizing: border-box; width: 100%;">
      <div style="text-align: center; font-weight: bold; font-size: 16px; margin-bottom: 10px; border-bottom: 2px dashed #000; padding-bottom: 6px;">
        IMPOSSIBLE POS
      </div>
      
      <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px dashed #000; padding-bottom: 6px; margin-bottom: 8px; font-size: 13px; line-height: 1.35; color: #000;">
        <div>
          <div><strong>FOLIO #:</strong> <span style="font-size: 14px; font-weight: bold;">#${order.ticketNumber || order.id.substring(2, 8).toUpperCase()}</span></div>
          <div><strong>TABLE:</strong> <span style="${tableStyle}; text-transform: uppercase;">${tableText}</span></div>
        </div>
        <div style="text-align: right;">
          <div><strong>TIME:</strong> ${new Date(order.dateCreated).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
          <div><strong>DATE:</strong> ${new Date(order.dateCreated).toLocaleDateString()}</div>
        </div>
      </div>

      <!-- Items List -->
      <div style="font-size: 14px; line-height: 1.4; color: #000; text-align: left;">
        ${itemsHtml}
      </div>

      <!-- Totals -->
      <div style="border-top: 2px dashed #000; padding-top: 6px; margin-top: 8px; font-size: 14px; font-weight: bold;">
        <div style="display: flex; justify-content: space-between;">
          <span>Total:</span>
          <span>$${(order.total || 0).toFixed(2)}</span>
        </div>
      </div>

      <!-- Barcode Container -->
      <div style="text-align: center; margin-top: 15px; border-top: 1px dashed #ccc; padding-top: 10px;">
        <canvas id="kdsBarcodeCanvas_modal" style="margin: 0 auto; max-width: 100%;"></canvas>
      </div>
    </div>
  `;

  modalBody.innerHTML = detailsHtml;
  modal.style.display = 'flex';

  // Draw barcode using JsBarcode CODE128
  setTimeout(() => {
    try {
      const barcodeValue = String(order.ticketNumber || order.id.replace(/\D/g, '').substring(0, 8));
      if (typeof JsBarcode !== 'undefined') {
        const canvasModal = document.getElementById('kdsBarcodeCanvas_modal');
        if (canvasModal) {
          JsBarcode(canvasModal, barcodeValue, {
            format: "CODE128",
            width: 1.8,
            height: 35,
            displayValue: true,
            fontSize: 10,
            margin: 0
          });
        }
      }
    } catch (err) {
      console.error("Barcode generation failed in runner preview:", err);
    }
  }, 50);
}
