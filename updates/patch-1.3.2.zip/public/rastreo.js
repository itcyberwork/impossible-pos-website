const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;

let currentOrder = null;
let selectedLocationName = '';

document.addEventListener('DOMContentLoaded', () => {
  setupScannerFocus();
  setupEventListeners();
});

// Mantener el input de escaneo siempre enfocado para capturar el lector USB
function setupScannerFocus() {
  const input = document.getElementById('hiddenScannerInput');
  input.focus();

  // Si hacen clic en cualquier parte de la pantalla, devolver el foco al input
  document.body.addEventListener('click', () => {
    input.focus();
  });
}

function setupEventListeners() {
  const input = document.getElementById('hiddenScannerInput');

  // Capturar escaneo del QR (al presionar Enter el lector USB envía la tecla Enter)
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const scannedId = input.value.trim();
      input.value = ''; // Limpiar de inmediato
      if (scannedId) {
        processScan(scannedId);
      }
    }
  });

  // Botón Cancelar / Volver a escaneo
  document.getElementById('btnCancelTrack').addEventListener('click', () => {
    resetToWaitingState();
  });

  // Botón: Iniciar Preparación
  document.getElementById('btnTrackPrep').addEventListener('click', () => {
    updateTrackStatus('en_preparacion');
  });

  // Botón: Iniciar Decoración
  document.getElementById('btnTrackDecor').addEventListener('click', () => {
    updateTrackStatus('en_decoracion');
  });

  // Botón: Guardar en Refrigerador (Abre modal)
  document.getElementById('btnTrackFridge').addEventListener('click', () => {
    document.getElementById('locEmployeeCode').value = '';
    document.querySelectorAll('#modalLocation .btn-option').forEach(b => b.classList.remove('selected'));
    selectedLocationName = '';
    document.getElementById('modalLocation').style.display = 'flex';
  });

  // Botón: Guardar Ubicación en Modal
  document.getElementById('btnSaveLoc').addEventListener('click', () => {
    const code = document.getElementById('locEmployeeCode').value;
    if (!code || !selectedLocationName) {
      showToast('Ingresa tu código y selecciona un anaquel', 'error');
      return;
    }

    // Validar empleados
    let employeeName = '';
    if (code === '1234') employeeName = 'Pedro Gomez';
    else if (code === '5678') employeeName = 'Jose Rodriguez';

    if (!employeeName) {
      showToast('Código de empleado inválido', 'error');
      return;
    }

    saveLocationAndComplete(selectedLocationName, employeeName);
  });

  // Cancelar ubicación
  document.getElementById('btnCancelLoc').addEventListener('click', () => {
    document.getElementById('modalLocation').style.display = 'none';
  });
  document.querySelector('#modalLocation .close-modal').addEventListener('click', () => {
    document.getElementById('modalLocation').style.display = 'none';
  });

  // Selección de refrigerador en modal
  const locBtns = document.querySelectorAll('#modalLocation .btn-option');
  locBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      locBtns.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      selectedLocationName = btn.getAttribute('data-loc');
    });
  });
}

// Procesar el ID de orden escaneado
async function processScan(orderId) {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    const orders = await response.json();
    const order = orders.find(o => o.id === orderId);

    if (!order) {
      showToast('Orden no encontrada en el sistema', 'error');
      playBeep(false);
      return;
    }

    const cakeItem = order.items.find(i => i.isCustomCake);
    if (!cakeItem) {
      showToast('Esta orden no contiene un pastel sobre pedido', 'error');
      playBeep(false);
      return;
    }

    currentOrder = order;
    playBeep(true);
    showActiveState(order, cakeItem);
  } catch (error) {
    showToast('Error conectando con el servidor local', 'error');
  }
}

// Mostrar el panel de control de la orden activa
function showActiveState(order, cakeItem) {
  document.getElementById('viewWaiting').style.display = 'none';
  document.getElementById('viewActive').style.display = 'block';

  document.getElementById('lblOrderNum').innerText = `ORDEN #${order.id.substring(2, 8).toUpperCase()}`;
  document.getElementById('lblClientName').innerText = `Cliente: ${cakeItem.details.clientName} (${cakeItem.details.clientPhone})`;
  
  // Estatus visual
  const statusEl = document.getElementById('lblStatus');
  statusEl.className = `status-badge ${order.status}`;
  statusEl.innerText = order.status.replace('_', ' ');

  // Detalles del pastel
  document.getElementById('lblOrderDetails').innerHTML = `
    <strong>Tamaño:</strong> ${cakeItem.details.size} | <strong>Sabor:</strong> ${cakeItem.details.flavor}<br>
    <strong>Relleno:</strong> ${cakeItem.details.fillings.join(', ')} | <strong>Frutas:</strong> ${cakeItem.details.fruits.join(', ')}<br>
    <strong>Notas de Decoración:</strong> ${cakeItem.details.notes || 'Ninguna'}<br>
    <strong>Ubicación Actual:</strong> <span style="color:var(--success-color); font-weight:bold;">${order.shelfLocation || 'No asignada aún'}</span>
  `;
}

// Volver al estado de espera de escaneo
function resetToWaitingState() {
  currentOrder = null;
  document.getElementById('viewActive').style.display = 'none';
  document.getElementById('viewWaiting').style.display = 'block';
  setupScannerFocus();
}

// Actualizar estatus (Preparación o Decoración)
async function updateTrackStatus(newStatus) {
  if (!currentOrder) return;

  try {
    const response = await fetch(`${SERVER_URL}/api/orders/${currentOrder.id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (response.ok) {
      showToast(`Estatus actualizado a: ${newStatus.toUpperCase()}`, 'success');
      // Refrescar datos
      processScan(currentOrder.id);
    }
  } catch (error) {
    showToast('Error actualizando estatus', 'error');
  }
}

// Completar y guardar en refrigerador
async function saveLocationAndComplete(shelfLocation, employeeName) {
  if (!currentOrder) return;

  try {
    // 1. Marcar como "listo" (terminado en cocina)
    await fetch(`${SERVER_URL}/api/orders/${currentOrder.id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'listo' })
    });

    // 2. Guardar ubicación física y quién lo guardó
    await fetch(`${SERVER_URL}/api/orders/${currentOrder.id}/location`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ shelfLocation, employeeName })
    });

    document.getElementById('modalLocation').style.display = 'none';
    showToast('Pastel registrado en el refrigerador y completado', 'success');
    resetToWaitingState();
  } catch (error) {
    showToast('Error registrando ubicación', 'error');
  }
}

// Pitidos sonoros para el escáner (Verde = Éxito, Rojo = Fallo)
function playBeep(success) {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(success ? 1000 : 300, audioContext.currentTime); // Agudo para éxito, grave para error
    gain.gain.setValueAtTime(0.3, audioContext.currentTime);
    
    osc.connect(gain);
    gain.connect(audioContext.destination);
    
    osc.start();
    osc.stop(audioContext.currentTime + (success ? 0.1 : 0.3));
  } catch (e) {
    console.log("Audio no permitido");
  }
}

// --- ALERTA TOAST ---
function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  toast.className = `toast ${type}`;
  toastText.innerText = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}
