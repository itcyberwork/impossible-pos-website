const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let currentPage = 0;
let showPastOrders = false;
let activeWebSocket = null;

document.addEventListener('DOMContentLoaded', async () => {
  const isLicensed = await checkBarKdsLicense();
  if (!isLicensed) return;

  initWebSocket();
  loadOrders();
  setupEventListeners();
});

async function checkBarKdsLicense() {
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/status`);
    if (res.ok) {
      const data = await res.json();
      if (data.barStatus === 'active' || data.barStatus === 'demo') {
        return true;
      }
    }
  } catch (e) {
    console.error("License check failed:", e);
  }
  
  // Show blocking layout
  document.body.innerHTML = `
    <div style="background-color: #0b0b0d; color: #fff; height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: sans-serif; text-align: center; padding: 20px;">
      <div style="font-size: 80px; margin-bottom: 20px;">🔒</div>
      <h1 style="color: #ff453a; margin-bottom: 10px;">Licencia Premium Requerida</h1>
      <h2 style="color: #ff453a; margin-bottom: 20px; font-weight: normal; font-size: 18px;">Premium Bar Hub License Required</h2>
      <p style="color: #8e8e93; max-width: 500px; line-height: 1.5; font-size: 14px; margin-bottom: 20px;">
        Este terminal de Bar KDS no se puede utilizar porque el módulo <strong>Premium Bar Hub</strong> no está licenciado. 
        Por favor, active una licencia válida desde la sección de Configuración de la caja registradora principal.
      </p>
      <a href="https://impossiblepos.com/buy" target="_blank" style="font-size: 14px; font-weight: bold; color: #bf5af2; text-decoration: underline; display: inline-flex; align-items: center; gap: 4px;">
        🛒 Comprar Módulo Bar Hub / Buy Bar Hub Addon
      </a>
    </div>
  `;
  return false;
}

async function loadOrders() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      orders = await res.json();
      renderKDS();
    } else {
      setTimeout(loadOrders, 2000);
    }
  } catch (err) {
    console.error("Failed to load orders:", err);
    setTimeout(loadOrders, 2000);
  }
}

function initWebSocket() {
  try {
    activeWebSocket = new WebSocket(WS_URL);
    activeWebSocket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'orders_updated' || msg.type === 'new_order') {
          loadOrders();
        }
      } catch (e) {
        console.error("WS parse error:", e);
      }
    };
    activeWebSocket.onclose = () => {
      setTimeout(initWebSocket, 5000);
    };
  } catch (e) {
    console.error("WS init error:", e);
    setTimeout(initWebSocket, 5000);
  }
}

function setupEventListeners() {
  document.getElementById('btnActiveOrders').addEventListener('click', () => {
    showPastOrders = false;
    currentPage = 0;
    renderKDS();
  });

  document.getElementById('btnPastOrders').addEventListener('click', () => {
    showPastOrders = true;
    currentPage = 0;
    renderKDS();
  });

  document.getElementById('btnKdsScrollBack').addEventListener('click', () => {
    if (currentPage > 0) {
      currentPage--;
      renderKDS();
    }
  });

  document.getElementById('btnKdsScrollNext').addEventListener('click', () => {
    const activeOrders = getFilteredOrders();
    const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
    if (currentPage < maxPage) {
      currentPage++;
      renderKDS();
    }
  });

  // Keyboard shortcut listener for Bump Bar (keys 1 to 9)
  window.addEventListener('keydown', (e) => {
    if (e.key >= '1' && e.key <= '9') {
      const index = parseInt(e.key) - 1;
      const activeOrders = getFilteredOrders();
      const pageStartIndex = currentPage * 20;
      const targetOrder = activeOrders[pageStartIndex + index];
      if (targetOrder) {
        bumpOrder(targetOrder.id);
      }
    }
  });
}

function getFilteredOrders() {
  return orders.filter(o => {
    if (o.status === 'void' || o.status === 'refunded') return false;
    
    // Filter orders containing bar drinks
    const hasDrinks = o.items && o.items.some(item => {
      const category = (item.category || '').toLowerCase();
      return category.includes('bebida') || category.includes('drink') || category.includes('bar');
    });
    if (!hasDrinks) return false;

    if (showPastOrders) {
      return o.barPrepared === true || o.status === 'completado' || o.status === 'entregado';
    } else {
      return !o.barPrepared && o.status !== 'completado' && o.status !== 'entregado';
    }
  }).sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
}

function renderKDS() {
  const container = document.getElementById('kdsContainer');
  container.innerHTML = '';

  // Toggle active styling
  const btnActive = document.getElementById('btnActiveOrders');
  const btnPast = document.getElementById('btnPastOrders');
  if (showPastOrders) {
    btnPast.style.backgroundColor = 'var(--accent-color)';
    btnPast.style.color = '#000';
    btnActive.style.backgroundColor = 'var(--bg-tertiary)';
    btnActive.style.color = '#fff';
  } else {
    btnActive.style.backgroundColor = 'var(--accent-color)';
    btnActive.style.color = '#000';
    btnPast.style.backgroundColor = 'var(--bg-tertiary)';
    btnPast.style.color = '#fff';
  }

  const activeOrders = getFilteredOrders();

  if (activeOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">No drinks in queue</div>`;
    document.getElementById('lblKdsPageIndicator').innerText = `Page 1 of 1`;
    return;
  }

  const totalCount = activeOrders.length;
  const maxPage = Math.max(0, Math.ceil(totalCount / 20) - 1);
  if (currentPage > maxPage) currentPage = maxPage;

  document.getElementById('lblKdsPageIndicator').innerText = `Page ${currentPage + 1} of ${maxPage + 1}`;

  const startIndex = currentPage * 20;
  const pageOrders = activeOrders.slice(startIndex, startIndex + 20);

  pageOrders.forEach((o, index) => {
    const card = document.createElement('div');
    card.className = `kds-card type-${(o.type || 'comer').toLowerCase()}`;
    
    // Add priority outline for orders older than 5 minutes
    const minsOld = Math.floor((Date.now() - new Date(o.dateCreated).getTime()) / 60000);
    if (minsOld >= 5 && !showPastOrders) {
      card.classList.add('priority');
    }

    const elapsedText = showPastOrders ? 'DONE' : `${minsOld}m`;
    const bumpNumber = index + 1;

    let itemsHtml = '';
    o.items.forEach(item => {
      const category = (item.category || '').toLowerCase();
      if (category.includes('bebida') || category.includes('drink') || category.includes('bar')) {
        let modText = '';
        if (item.selectedModifiers && item.selectedModifiers.length > 0) {
          modText = `<div class="kds-item-specs">(${item.selectedModifiers.map(m=>m.name).join(', ')})</div>`;
        }
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity}x</span>
            <span class="kds-item-name">${item.name}</span>
            ${modText}
          </div>
        `;
      }
    });

    card.innerHTML = `
      <span class="bump-index-badge">${bumpNumber}</span>
      <div class="kds-card-header">
        <span class="kds-card-num">#${o.ticketNumber || 'N/A'}</span>
        <span class="kds-card-time">${elapsedText}</span>
      </div>
      <div class="kds-card-body">
        <div class="kds-client-info">
          <strong>Table:</strong> ${o.tableName || 'N/A'}<br>
          <strong>Waitress:</strong> ${o.cashierName || 'N/A'}
        </div>
        <div style="margin-top: 5px;">
          ${itemsHtml}
        </div>
      </div>
      <div class="kds-card-footer">
        <button class="btn-kds bump" onclick="bumpOrder('${o.id}')">${showPastOrders ? 'Re-open' : 'Done / Bump'}</button>
      </div>
    `;

    container.appendChild(card);
  });
}

async function bumpOrder(orderId) {
  try {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    // Toggle barPrepared status
    order.barPrepared = !order.barPrepared;

    const res = await fetch(`${SERVER_URL}/api/orders/${orderId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });

    if (res.ok) {
      showToast(order.barPrepared ? "Order served / Bumped" : "Order recalled", "success");
      loadOrders();
    } else {
      showToast("Error updating order status", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error connecting to server", "error");
  }
}
window.bumpOrder = bumpOrder;

function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  
  toastText.textContent = text;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.className = toast.className.replace('show', '');
  }, 2000);
}
