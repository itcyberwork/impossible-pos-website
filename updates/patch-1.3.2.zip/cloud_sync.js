process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const http = require('http');
const https = require('https');
const database = require('./database.js');

let isOnline = false;
let lastSyncTime = null;
let isFlushing = false;

// Default production URL with local fallback
const DEFAULT_CLOUD_URL = 'https://impossible-pos-licenses.onrender.com';

function getCloudConfig() {
  const settings = database.getSettings() || {};
  const licenseKey = (settings.licenseKey || '').trim().toUpperCase();
  let cloudUrl = (settings.cloudSyncUrl || DEFAULT_CLOUD_URL).trim();
  if (cloudUrl.endsWith('/')) cloudUrl = cloudUrl.slice(0, -1);
  return { licenseKey, cloudUrl };
}

// Low-level HTTP POST request with timeout
function sendPostRequest(urlStr, data, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    try {
      const url = new URL(urlStr);
      const isHttps = url.protocol === 'https:';
      const transport = isHttps ? https : http;

      const payload = JSON.stringify(data);
      const options = {
        hostname: url.hostname,
        port: url.port || (isHttps ? 443 : 80),
        path: url.pathname + (url.search || ''),
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        },
        timeout: timeoutMs,
        rejectUnauthorized: false
      };

      const req = transport.request(options, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            try {
              resolve(JSON.parse(body));
            } catch (e) {
              resolve({ success: true, raw: body });
            }
          } else {
            reject(new Error(`HTTP_${res.statusCode}: ${body}`));
          }
        });
      });

      req.on('timeout', () => {
        req.destroy();
        reject(new Error('TIMEOUT'));
      });

      req.on('error', err => {
        reject(err);
      });

      req.write(payload);
      req.end();
    } catch (err) {
      reject(err);
    }
  });
}

// Low-level HTTP GET request with timeout and TLS bypass
function sendGetRequest(urlStr, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    try {
      const url = new URL(urlStr);
      const isHttps = url.protocol === 'https:';
      const transport = isHttps ? https : http;
      const options = {
        hostname: url.hostname,
        port: url.port || (isHttps ? 443 : 80),
        path: url.pathname + (url.search || ''),
        method: 'GET',
        timeout: timeoutMs,
        rejectUnauthorized: false
      };
      const req = transport.request(options, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          if (res.statusCode >= 200 && res.statusCode < 500) {
            resolve({ success: true, statusCode: res.statusCode });
          } else {
            reject(new Error(`HTTP_${res.statusCode}`));
          }
        });
      });
      req.on('timeout', () => { req.destroy(); reject(new Error('TIMEOUT')); });
      req.on('error', err => reject(err));
      req.end();
    } catch (err) {
      reject(err);
    }
  });
}

async function checkCloudConnectivity() {
  const { cloudUrl } = getCloudConfig();
  try {
    await sendGetRequest(`${cloudUrl}/api/updates/check?version=ping`, 4000);
    isOnline = true;
    lastSyncTime = new Date().toISOString();
  } catch (err) {
    if (err.message && err.message.startsWith('HTTP_')) {
      isOnline = true;
    } else {
      isOnline = false;
    }
  }
}

// Run initial connectivity check immediately
setTimeout(() => {
  checkCloudConnectivity().catch(() => {});
}, 1000);

function formatOrderForSync(order) {
  if (!order) return null;
  const items = Array.isArray(order.items) ? order.items : [];
  
  return {
    localOrderId: String(order.id || Date.now()),
    orderNumber: order.ticketNumber ? `#${order.ticketNumber}` : String(order.id || '#'),
    orderType: order.deliveryType || order.type || 'takeout',
    items: items.map(it => ({
      name: it.name || 'Item',
      price: Number(it.price || 0),
      quantity: Number(it.quantity || 1),
      subtotal: Number(it.subtotal || (it.price * (it.quantity || 1))),
      category: it.category || ''
    })),
    subtotal: Number(order.subtotal || 0),
    tax: Number(order.tax || 0),
    tip: Number(order.cardTip || 0),
    total: Number(order.total || 0),
    paymentMethod: order.paymentMethod || 'cash',
    cashierName: order.cashierName || 'Cashier',
    terminalId: 'T1',
    orderDate: order.datePaid || order.dateCreated || new Date().toISOString()
  };
}

// 1. Sync or Enqueue a Single Order
async function syncOrder(order) {
  const formatted = formatOrderForSync(order);
  if (!formatted) return;

  const { licenseKey, cloudUrl } = getCloudConfig();

  // If no license key yet or offline, safely queue locally
  if (!licenseKey) {
    database.enqueueCloudSync('order', formatted);
    return;
  }

  try {
    await sendPostRequest(`${cloudUrl}/api/sync/orders`, {
      licenseKey,
      orders: [formatted]
    });
    isOnline = true;
    lastSyncTime = new Date().toISOString();
    console.log(`[CLOUD SYNC] Order ${formatted.orderNumber} ($${formatted.total}) synced to cloud.`);
  } catch (err) {
    isOnline = false;
    // Enqueue locally for automatic retry
    database.enqueueCloudSync('order', formatted);
    console.log(`[CLOUD SYNC] Offline or error (${err.message}). Order queued for auto-sync.`);
  }
}

// 2. Sync Z-Report (Shift Closing)
async function syncZReport(shift) {
  if (!shift) return;

  const { licenseKey, cloudUrl } = getCloudConfig();

  const formatted = {
    zReportNumber: shift.id ? parseInt(String(shift.id).replace(/\D/g, '').slice(-4)) || 1 : 1,
    openedAt: shift.dateOpened || new Date().toISOString(),
    closedAt: shift.dateClosed || new Date().toISOString(),
    cashierName: shift.closingCashier || shift.cashierName || 'Manager',
    openingCash: Number(shift.openingCash || 0),
    totalSales: Number(shift.closingCash || shift.totalSales || 0),
    cashSales: Number(shift.cashSales || 0),
    cardSales: Number(shift.cardSales || 0),
    expectedCash: Number(shift.expectedCash || 0),
    actualCash: Number(shift.actualCash || shift.closingCash || 0),
    difference: Number(shift.difference || 0),
    orderCount: Number(shift.orderCount || 0)
  };

  if (!licenseKey) {
    database.enqueueCloudSync('z_report', formatted);
    return;
  }

  try {
    await sendPostRequest(`${cloudUrl}/api/sync/z-report`, {
      licenseKey,
      zReport: formatted
    });
    isOnline = true;
    lastSyncTime = new Date().toISOString();
    console.log(`[CLOUD SYNC] Z-Report synced to cloud.`);
  } catch (err) {
    isOnline = false;
    database.enqueueCloudSync('z_report', formatted);
    console.log(`[CLOUD SYNC] Z-Report queued for auto-sync (${err.message}).`);
  }
}

// 3. Background Queue Flusher (Worker)
async function flushPendingQueue() {
  if (isFlushing) return;
  const { licenseKey, cloudUrl } = getCloudConfig();
  if (!licenseKey) return;

  const pending = database.getPendingCloudSyncQueue(50);
  if (!pending || pending.length === 0) return;

  isFlushing = true;
  try {
    const ordersToSync = [];
    const orderQueueIds = [];
    const zReportsToSync = [];
    const zReportQueueIds = [];

    for (const row of pending) {
      try {
        const payload = JSON.parse(row.payloadJson);
        if (row.payloadType === 'order') {
          ordersToSync.push(payload);
          orderQueueIds.push(row.id);
        } else if (row.payloadType === 'z_report') {
          zReportsToSync.push(payload);
          zReportQueueIds.push(row.id);
        }
      } catch (e) {}
    }

    // Flush orders in bulk
    if (ordersToSync.length > 0) {
      await sendPostRequest(`${cloudUrl}/api/sync/orders`, {
        licenseKey,
        orders: ordersToSync
      });
      database.removeCloudSyncQueueItems(orderQueueIds);
      console.log(`[CLOUD SYNC] Flushed ${ordersToSync.length} queued orders to cloud!`);
    }

    // Flush Z-Reports
    for (let i = 0; i < zReportsToSync.length; i++) {
      await sendPostRequest(`${cloudUrl}/api/sync/z-report`, {
        licenseKey,
        zReport: zReportsToSync[i]
      });
      database.removeCloudSyncQueueItems([zReportQueueIds[i]]);
    }

    isOnline = true;
    lastSyncTime = new Date().toISOString();
  } catch (err) {
    isOnline = false;
  } finally {
    isFlushing = false;
  }
}

// Periodic queue worker & connectivity check every 25 seconds
setInterval(() => {
  flushPendingQueue().catch(() => {});
  checkCloudConnectivity().catch(() => {});
}, 25000);

// Status getter for frontend UI
function getStatus() {
  const { licenseKey } = getCloudConfig();
  const pendingCount = database.getCloudSyncQueueCount ? database.getCloudSyncQueueCount() : 0;
  return {
    isOnline,
    hasLicense: !!licenseKey,
    licenseKey: licenseKey ? (licenseKey.slice(0, 7) + '***') : null,
    pendingCount,
    lastSyncTime
  };
}

module.exports = {
  syncOrder,
  syncZReport,
  flushPendingQueue,
  checkCloudConnectivity,
  getStatus
};
