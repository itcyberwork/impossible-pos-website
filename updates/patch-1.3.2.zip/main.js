const { app, BrowserWindow } = require('electron');
const path = require('path');
const net = require('net');

let mainWindow = null;

function ensureServerRunning() {
  return new Promise((resolve) => {
    const client = new net.Socket();
    client.setTimeout(350);
    client.connect(3000, '127.0.0.1', () => {
      client.destroy();
      resolve(true);
    });
    client.on('error', () => {
      console.log('Starting Express server on port 3000...');
      try {
        require('./server.js');
      } catch (err) {
        console.error('Error starting Express server:', err);
      }
      resolve(false);
    });
    client.on('timeout', () => {
      client.destroy();
      try {
        require('./server.js');
      } catch (e) {}
      resolve(false);
    });
  });
}

function createWindow() {
  const pageArg = process.argv.find(arg => arg.includes('.html')) || 'caja_v14.html';
  const targetUrl = `http://localhost:3000/${pageArg}`;

  mainWindow = new BrowserWindow({
    title: "Impossible POS™",
    icon: path.join(__dirname, '../Shortcuts_Installer/pos.ico'),
    width: 1280,
    height: 800,
    fullscreen: true,
    kiosk: true,
    frame: false,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[RENDERER CONSOLE] [Level ${level}] ${message} (at ${sourceId}:${line})`);
  });

  function loadWithRetry(retriesLeft = 25) {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.loadURL(targetUrl).catch((err) => {
      console.log(`Waiting for POS server (${retriesLeft} retries remaining)...`);
      if (retriesLeft > 0) {
        setTimeout(() => loadWithRetry(retriesLeft - 1), 350);
      }
    });
  }

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDesc, validatedURL) => {
    console.log(`Page did-fail-load (${errorCode}: ${errorDesc}). Retrying in 500ms...`);
    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.loadURL(validatedURL);
      }
    }, 500);
  });

  mainWindow.webContents.once('did-finish-load', () => {
    console.log('POS terminal UI loaded successfully.');
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
      mainWindow.focus();
      mainWindow.setAlwaysOnTop(true);
      mainWindow.setAlwaysOnTop(false);
    }
  });

  mainWindow.webContents.session.clearCache().then(() => {
    loadWithRetry();
  }).catch(() => {
    loadWithRetry();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

const { ipcMain } = require('electron');
const { exec } = require('child_process');

ipcMain.on('electron-minimize', () => {
  if (mainWindow) {
    mainWindow.minimize();
    // Use PowerShell to find the python window titled "Biometric Bridge" and force-focus it
    exec('powershell -Command "Add-Type \'[DllImport(\\\"user32.dll\\\")] public static extern bool SetForegroundWindow(IntPtr hWnd);\' -Name Utils -Namespace Win32; $proc = Get-Process -Name python -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowTitle -like \\\"*Biometric Bridge*\\\"}; if ($proc) { [Win32.Utils]::SetForegroundWindow($proc.MainWindowHandle) }"');
  }
});

ipcMain.on('electron-restore', () => {
  if (mainWindow) {
    mainWindow.restore();
    mainWindow.focus();
  }
});

ipcMain.on('system-shutdown', () => {
  console.log('[ELECTRON] Executing ACPI System Shutdown...');
  exec('shutdown /s /t 2 /f /c "Impossible POS System Shutdown"');
});

ipcMain.on('system-restart', () => {
  console.log('[ELECTRON] Executing ACPI System Restart...');
  exec('shutdown /r /t 2 /f /c "Impossible POS System Restart"');
});

ipcMain.handle('get-primary-screen-source-id', async () => {
  const { desktopCapturer } = require('electron');
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
  if (sources.length > 0) {
    return sources[0].id;
  }
  return null;
});

const http = require('http');

function getSettingsFromServer() {
  return new Promise((resolve) => {
    http.get('http://127.0.0.1:3000/api/admin/settings', (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({});
        }
      });
    }).on('error', (e) => {
      resolve({});
    });
  });
}

function sendPrintDebugLog(msg) {
  try {
    const postData = JSON.stringify({ message: msg });
    const req = http.request({
      hostname: '127.0.0.1',
      port: 3000,
      path: '/api/print-debug',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    }, (res) => {
      res.resume();
    });
    req.on('error', (e) => {
      console.error(`Error sending print log to server: ${e.message}`);
    });
    req.write(postData);
    req.end();
  } catch (err) {
    console.error("Error in sendPrintDebugLog:", err);
  }
}

ipcMain.on('print-invoice-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-invoice-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`http://localhost:3000/invoice_template.html?orderId=${orderId}`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for invoice orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
          } else {
            targetPrinter = printers[0].name;
          }
        }
        
        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        try {
          const fs = require('fs');
          const path = require('path');
          const os = require('os');
          
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `invoice_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        printWin.close();
      }
    }, 1500); // Dar 1.5 segundos para cargar y renderizar la plantilla HTML
  });
});

ipcMain.on('print-cake-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-cake-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      backgroundThrottling: false
    }
  });
  printWin.loadURL(`http://localhost:3000/comanda_pastel.html?orderId=${orderId}&silent=true`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        sendPrintDebugLog(`Printers available in Electron: ${JSON.stringify(printers.map(p => ({ name: p.name, isDefault: p.isDefault })))}`);
        sendPrintDebugLog(`Configured reportingPrinterName: "${printerName}"`);

        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        // Robust fallback: if no reporting printer is configured, attempt to use the OS default or first available printer
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
            sendPrintDebugLog(`No reportingPrinterName configured. Falling back to default printer: "${targetPrinter}"`);
          } else {
            targetPrinter = printers[0].name;
            sendPrintDebugLog(`No default printer set. Falling back to first available printer: "${targetPrinter}"`);
          }
        }
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        sendPrintDebugLog(`Generating PDF via printToPDF...`);
        try {
          const fs = require('fs');
          const os = require('os');
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `cake_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);
          sendPrintDebugLog(`PDF generated successfully at ${tempPdfPath}. Printing via pdf-to-printer to: "${targetPrinter}"`);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          sendPrintDebugLog(`Print job sent successfully via SumatraPDF to "${targetPrinter}"`);
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          sendPrintDebugLog(`Error in printToPDF / pdf-to-printer execution: ${printErr.message}`);
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        sendPrintDebugLog(`Print error catch: ${err.message}`);
        printWin.close();
      }
    }, 1200); // Dar 1.2 segundos para cargar y renderizar la plantilla HTML
  });
});

function checkWindowsEnvironment() {
  if (process.platform !== 'win32') return;

  const { exec } = require('child_process');
  
  // Whitelist current app path and parent path
  const appPath = path.resolve(__dirname).replace(/\\/g, '\\\\');
  const parentPath = path.resolve(__dirname, '..').replace(/\\/g, '\\\\');

  // 1. Check Defender Exclusions
  exec('powershell -Command "Get-MpPreference | Select-Object -ExpandProperty ExclusionPath"', (err, stdout, stderr) => {
    if (err) {
      console.error('Error checking Defender exclusions:', err);
      return;
    }
    const exclusions = stdout || '';
    const isAppExcluded = exclusions.includes(path.resolve(__dirname)) || exclusions.includes(path.resolve(__dirname, '..'));

    if (!isAppExcluded) {
      console.log('App directory is not whitelisted in Windows Defender. Requesting exclusion...');
      const addExclusionCmd = `powershell -Command "Start-Process powershell -ArgumentList '-Command Add-MpPreference -ExclusionPath \\\"${appPath}\\\",\\\"${parentPath}\\\"' -Verb RunAs -WindowStyle Hidden"`;
      exec(addExclusionCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Defender exclusion request:', uacErr);
      });
    } else {
      console.log('Windows Defender exclusion check: OK.');
    }
  });

  // 2. Check Firewall Rule for Port 3000
  exec('powershell -Command "Get-NetFirewallRule -DisplayName \\\"Impossible POS Local Server\\\" -ErrorAction SilentlyContinue"', (err, stdout, stderr) => {
    const ruleExists = stdout && stdout.includes('Impossible POS Local Server');
    if (!ruleExists) {
      console.log('Firewall rule for Impossible POS is missing. Requesting addition...');
      const addFirewallCmd = `powershell -Command "Start-Process cmd -ArgumentList '/c netsh advfirewall firewall add rule name=\\\"Impossible POS Local Server\\\" dir=in action=allow protocol=TCP localport=3000 profile=private,domain' -Verb RunAs -WindowStyle Hidden"`;
      exec(addFirewallCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Firewall addition request:', uacErr);
      });
    } else {
      console.log('Windows Firewall rule check: OK.');
    }
  });
}

app.whenReady().then(async () => {
  await ensureServerRunning();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

