process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
console.log("Loading express...");
const express = require('express');
console.log("Express loaded");
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');
const net = require('net');
const database = require('./database');
const cloudSync = require('./cloud_sync');

const app = express();

app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  next();
});

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

function isMeatModifier(name) {
  if (!name) return false;
  const n = name.toLowerCase().trim();
  const meats = ['asada', 'pollo', 'pastor', 'tripa', 'barbacoa', 'carnitas', 'lengua', 'chorizo', 'camaron', 'camarón', 'pescado', 'cabeza', 'barbacoa', 'chicharron', 'charrada', 'carne'];
  return meats.some(meat => n.includes(meat));
}

function getSortedModifierNames(modifiers) {
  if (!modifiers || modifiers.length === 0) return '';
  const colorOrder = { 'red': 1, 'green': 2, 'yellow': 3, 'default': 4 };
  const sorted = [...modifiers].sort((a, b) => {
    const aName = typeof a === 'string' ? a : (a.name || a.optionName || '');
    const bName = typeof b === 'string' ? b : (b.name || b.optionName || '');
    const cA = (typeof a === 'object' && a.color) || (isMeatModifier(aName) ? 'red' : 'default');
    const cB = (typeof b === 'object' && b.color) || (isMeatModifier(bName) ? 'red' : 'default');
    return (colorOrder[cA] || 5) - (colorOrder[cB] || 5);
  });
  return sorted.map(m => (typeof m === 'string' ? m : (m.name || m.optionName || '')).toUpperCase()).filter(Boolean).join(', ');
}

// Generador de formato de platillos y modificadores según el tamaño seleccionado (Opción 5 Aprobada)
function formatKitchenItemsEscPos(items, fontSizeOption) {
  if (!items || items.length === 0) return '';
  let out = '';
  const size = String(fontSizeOption || '5');

  items.forEach(item => {
    const qty = item.quantity || 1;
    const name = (item.name || '').toUpperCase();
    const qtyName = `${qty}x ${name}`;

    const itemMods = item.selectedModifiers || item.modifiers || [];

    if (size === '1') {
      // 1. Compacto (1x1 Normal)
      out += '\x1d\x21\x00' + qtyName + '\r\n';
      if (itemMods && itemMods.length > 0) {
        out += '   ' + getSortedModifierNames(itemMods) + '\r\n';
      }
    } else if (size === '2') {
      // 2. Alto Doble (1x2)
      out += '\x1d\x21\x01' + qtyName + '\r\n';
      out += '\x1d\x21\x00';
      if (itemMods && itemMods.length > 0) {
        out += '   ' + getSortedModifierNames(itemMods) + '\r\n';
      }
    } else if (size === '3') {
      // 3. Ancho Doble (2x1)
      out += '\x1d\x21\x10' + qtyName + '\r\n';
      out += '\x1d\x21\x00';
      if (itemMods && itemMods.length > 0) {
        out += '   ' + getSortedModifierNames(itemMods) + '\r\n';
      }
    } else if (size === '4') {
      // 4. Grande Estándar (2x2)
      out += '\x1d\x21\x11' + qtyName + '\r\n';
      out += '\x1d\x21\x00';
      if (itemMods && itemMods.length > 0) {
        out += '   ' + getSortedModifierNames(itemMods) + '\r\n';
      }
    } else {
      // 5. Opción 5 (Aprobada): 2x2 Grande con Negrita, espacio entre platillo y modificadores, sin encabezado
      // Platillo en 2x2 grande y negrita
      out += '\x1d\x21\x11\x1b\x45\x01' + qtyName + '\r\n';
      // Reset a tamaño normal sin negrita para modificadores
      out += '\x1d\x21\x00\x1b\x45\x00';

      if (itemMods && itemMods.length > 0) {
        if (Array.isArray(itemMods)) {
          itemMods.forEach(mod => {
            const mName = typeof mod === 'string' ? mod : (mod.name || mod.optionName || '');
            if (mName) {
              out += `   - ${mName.toUpperCase()}\r\n`;
            }
          });
        } else {
          out += `   - ${getSortedModifierNames(itemMods)}\r\n`;
        }
      }
      // Espacio limpio entre platillos
      out += '\r\n';
    }
  });

  // Asegurar reseteo de formato ESC/POS al finalizar
  out += '\x1d\x21\x00\x1b\x45\x00';
  return out;
}

// Generador del encabezado de comanda de cocina limpio (sin "Cliente:", sin fecha larga, con hora, tipo/destino y nombre en fuente B 1x2 destacada)
function formatKitchenTicketHeader(order, lang, stationTitle) {
  if (!lang) {
    const settings = database.getSettings();
    lang = settings.langKitchenTicket || settings.language || 'en';
  }
  const isEs = (lang === 'es');
  const ticketNum = order.ticketNumber || (order.id ? String(order.id).replace(/\D/g, '').substring(0, 8) : 'N/A');
  
  // Clean Time: Default English US format (e.g., 09:45 AM)
  const dateObj = new Date(order.dateCreated || Date.now());
  const timeStr = dateObj.toLocaleTimeString(isEs ? 'es-MX' : 'en-US', { hour: '2-digit', minute: '2-digit' });
  
  // Order Type and Service Badge (DEFAULT TO ENGLISH)
  const rawType = String(order.deliveryType || order.type || 'llevar').toLowerCase();
  let typeBadge = '';
  
  const tableInfo = (order.tableName !== undefined && order.tableName !== null && order.tableName !== '') 
    ? order.tableName 
    : ((order.table !== undefined && order.table !== null && order.table !== '') ? order.table : (order.tableNumber || ''));

  if (rawType === 'comer' || rawType === 'dine-in') {
    typeBadge = tableInfo ? (isEs ? `DINE IN - MESA ${tableInfo}` : `DINE IN - TABLE ${tableInfo}`) : 'DINE IN';
  } else if (rawType === 'drive-thru' || rawType === 'car' || rawType === 'carside') {
    let carInfo = order.car || order.vehicle || order.carDescription || '';
    if (!carInfo && order.notes) {
      const match = order.notes.match(/\[(?:CAR|VEHICLE|Auto-Pedido|🚗 Auto-Pedido):\s*([^\]]+)\]/i);
      if (match) carInfo = match[1].trim();
    }
    typeBadge = carInfo ? `CAR ORDER - ${carInfo.toUpperCase()}` : 'CAR ORDER';
  } else if (rawType === 'llevar' || rawType === 'walkin' || rawType === 'walk-in') {
    typeBadge = 'TO GO';
  } else if (rawType === 'pickup') {
    typeBadge = 'PICKUP';
  } else {
    const plat = (order.deliveryPlatform || '').toLowerCase();
    if (plat.includes('door') || (order.notes && order.notes.includes('[DoorDash]')) || rawType === 'doordash') {
      typeBadge = 'DOORDASH';
    } else if (plat.includes('uber') || (order.notes && order.notes.includes('[Uber Eats]')) || rawType === 'ubereats' || rawType === 'uber') {
      typeBadge = 'UBER EATS';
    } else if (plat.includes('grub') || (order.notes && order.notes.includes('[Grubhub]')) || rawType === 'grubhub') {
      typeBadge = 'GRUBHUB';
    } else if (plat.includes('online') || plat.includes('web') || (order.notes && order.notes.includes('[Online]'))) {
      typeBadge = 'ONLINE STORE';
    } else if (rawType === 'delivery') {
      typeBadge = isEs ? 'A DOMICILIO' : 'DELIVERY';
    } else {
      typeBadge = formatOrderType(rawType, lang).toUpperCase();
    }
  }
  
  let text = '\x1b\x40'; // Init ESC/POS
  text += '==================================\r\n';
  
  // Fila: TICKET #102          09:45 AM
  const ticketLabel = `TICKET #${ticketNum}`;
  const totalWidth = 34; // Ancho estándar de columnas 80mm
  const spacesNeeded = Math.max(2, totalWidth - (ticketLabel.length + timeStr.length));
  text += `\x1b\x45\x01${ticketLabel}\x1b\x45\x00` + ' '.repeat(spacesNeeded) + timeStr + '\r\n';
  
  // Fila destacada de tipo de orden / mesa / carro
  text += `\x1b\x45\x01[ ${typeBadge} ]\x1b\x45\x00\r\n`;
  if (order.pickupCode) {
    text += `\x1b\x45\x01PICKUP CODE: ${String(order.pickupCode).toUpperCase()}\x1b\x45\x00\r\n`;
  }
  if (order.driverInfo) {
    text += `DRIVER: ${String(order.driverInfo).toUpperCase()}\r\n`;
  }

  // Estación secundaria opcional si aplica (Bar, Grill, etc.)
  if (stationTitle && String(stationTitle).trim()) {
    text += `\x1b\x45\x01${isEs ? 'ESTACION' : 'STATION'}: ${String(stationTitle).trim().toUpperCase()}\x1b\x45\x00\r\n`;
  }

  text += '==================================\r\n';
  
  // Nombre del cliente destacado en Doble Alto y Negrita para la cocina
  const rawClient = order.clientName || order.customerName || order.client || (order.tableName && isNaN(order.tableName) ? order.tableName : '') || '';
  if (rawClient && String(rawClient).trim()) {
    const cName = String(rawClient).trim().toUpperCase();
    const clientLabel = isEs ? 'CLIENTE' : 'CUSTOMER';
    text += `\x1d\x21\x01\x1b\x45\x01${clientLabel}: ${cName}\x1b\x45\x00\x1d\x21\x00\r\n`;
  }
  
  // Notas del pedido si existen (limpiando tags de carro o marcas internas)
  if (order.notes && String(order.notes).trim()) {
    const cleanNotes = String(order.notes)
      .replace(/\[(?:CAR|VEHICLE|Auto-Pedido|🚗 Auto-Pedido):\s*[^\]]+\]/gi, '')
      .replace(/\[🌐 Pedido en Línea:[^\]]+\]/gi, '')
      .replace(/Notes:\s*/gi, '')
      .trim();
    if (cleanNotes) {
      text += `\x1b\x45\x01*** ${cleanNotes.toUpperCase()} ***\x1b\x45\x00\r\n`;
    }
  }
  
  text += '----------------------------------\r\n';
  return text;
}

// Local thermal printer Auto-Healing dispatcher
function executePowerShellPrint(tempFile, requestedPrinterName, callback) {
  const { execFile, exec } = require('child_process');
  const path = require('path');

  // First check if the exact printer is installed
  const checkCmd = `powershell -ExecutionPolicy Bypass -NoProfile -Command "Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name"`;
  exec(checkCmd, (err, stdout, stderr) => {
    let printerToUse = requestedPrinterName;

    if (!err) {
      const printers = (stdout || '').split('\r\n').map(p => p.trim()).filter(Boolean);
      const exactMatch = printers.find(p => p.toLowerCase() === requestedPrinterName.toLowerCase());
      if (exactMatch) {
        printerToUse = exactMatch;
      } else {
        // Try auto-healing to find printer
        let healedPrinter = printers.find(p => p.toLowerCase().includes(requestedPrinterName.toLowerCase()));
        if (!healedPrinter) {
          const keywords = [
            'rongta', 'rp80', 'rp3', 'pos-80', 'pos80', 'pos-58', 'pos58',
            'tm-u', 'tm-t', 'epson', 'u220', 'tsp', 'sp7', 'star',
            'xprinter', 'xp-', '80mm', '58mm', 'bixolon', 'munbyn',
            'citizen', 'zjiang', 'zj-', 'receipt', 'thermal', 'pos', 'printer'
          ];
          for (const kw of keywords) {
            healedPrinter = printers.find(p => p.toLowerCase().includes(kw));
            if (healedPrinter) break;
          }
        }
        if (healedPrinter) {
          printerToUse = healedPrinter;
          console.log(`Auto-healed printer mapping: "${requestedPrinterName}" -> "${healedPrinter}"`);
        } else if (printers.length > 0) {
          printerToUse = printers[0];
        }
      }
    }

    const scriptPath = path.join(__dirname, 'print_raw.ps1');
    const args = [
      '-ExecutionPolicy', 'Bypass',
      '-NoProfile',
      '-File', scriptPath,
      '-PrinterName', printerToUse,
      '-FilePath', tempFile
    ];

    execFile('powershell.exe', args, (error, stdout, stderr) => {
      if (error) {
        console.error(`[RAW PRINT ERROR] Failed printing to "${printerToUse}":`, stderr || error.message);
        if (callback) callback(error, stdout, stderr);
      } else {
        console.log(`[RAW PRINT SUCCESS] Printed raw bytes successfully to "${printerToUse}"`);
        if (callback) callback(null, stdout, stderr);
      }
    });
  });
}

const PORT = 3000;
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

// Crear directorio de uploads si no existe
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

let isCurrentlyOnline = true; // Stores the computed network connectivity state

function formatOrderType(type, lang) {
  if (!lang) {
    const settings = database.getSettings();
    lang = settings.language || 'en';
  }
  if (lang === 'es') {
    const map = {
      'walkin': 'CAJA',
      'llevar': 'LLEVAR',
      'comer': 'MESA',
      'drive-thru': 'AUTO',
      'pickup': 'RECOGER',
      'delivery': 'DOMICILIO'
    };
    return map[String(type).toLowerCase()] || String(type).toUpperCase();
  } else {
    const map = {
      'walkin': 'WALK-IN',
      'llevar': 'TO GO',
      'comer': 'DINE IN',
      'drive-thru': 'DRIVE-THRU',
      'pickup': 'PICKUP',
      'delivery': 'DELIVERY'
    };
    return map[String(type).toLowerCase()] || String(type).toUpperCase();
  }
}

app.use(express.json({ limit: '50mb' }));

// Forzar encabezados de NO-CACHE para evitar que Edge o Chrome guarden copias viejas en caché
app.use((req, res, next) => {
  res.header('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.header('Expires', '-1');
  res.header('Pragma', 'no-cache');
  next();
});

// Block operations if recording drive is disconnected
app.use((req, res, next) => {
  if (!isDriveConnected && req.path.startsWith('/api') && !req.path.includes('/settings') && !req.path.includes('/config')) {
    return res.status(503).json({ error: 'DRIVE_DISCONNECTED', message: 'Recording drive disconnected' });
  }
  next();
});
app.use((req, res, next) => {
  const logMsg = `[${new Date().toISOString()}] ${req.method} ${req.url} - IP: ${req.ip}\n`;
  try {
    fs.appendFileSync(path.join(__dirname, 'requests.log'), logMsg);
  } catch(e) {}
  next();
});

// On-demand downloader for cloud-synced uploads
app.get('/uploads/:filename', async (req, res, next) => {
  const filename = req.params.filename;
  const filePath = path.join(UPLOADS_DIR, filename);
  
  if (fs.existsSync(filePath)) {
    return next(); // File exists, let static server handle it
  }

  if (isCurrentlyOnline) {
    const settings = database.getSettings();
    const subdomain = settings.clientSubdomain || 'sheilas';
    const domain = settings.cloudDomain || 'impossiblepos.com';
    const cloudUrl = `https://${subdomain}.${domain}/api/get-upload?filename=${filename}`;
    
    try {
      const cloudRes = await fetch(cloudUrl);
      if (cloudRes.ok) {
        const data = await cloudRes.json();
        if (data.image) {
          const base64Data = data.image.replace(/^data:image\/\w+;base64,/, "");
          const buffer = Buffer.from(base64Data, 'base64');
          fs.writeFileSync(filePath, buffer);
          console.log(`[CLOUD SYNC] Downloaded cake photo on-demand: ${filename}`);
          return res.sendFile(filePath);
        }
      }
    } catch (err) {
      console.warn(`[CLOUD SYNC] Failed to fetch image ${filename} from Vercel:`, err.message);
    }
  }
  
  res.status(404).send('Not Found');
});

app.head('/uploads/:filename', async (req, res, next) => {
  const filename = req.params.filename;
  const filePath = path.join(UPLOADS_DIR, filename);
  
  if (fs.existsSync(filePath)) {
    return res.status(200).end();
  }

  if (isCurrentlyOnline) {
    const settings = database.getSettings();
    const subdomain = settings.clientSubdomain || 'sheilas';
    const domain = settings.cloudDomain || 'impossiblepos.com';
    const cloudUrl = `https://${subdomain}.${domain}/api/get-upload?filename=${filename}`;
    
    try {
      const cloudRes = await fetch(cloudUrl);
      if (cloudRes.ok) {
        const data = await cloudRes.json();
        if (data.image) {
          const base64Data = data.image.replace(/^data:image\/\w+;base64,/, "");
          const buffer = Buffer.from(base64Data, 'base64');
          fs.writeFileSync(filePath, buffer);
          console.log(`[CLOUD SYNC] Downloaded cake photo via HEAD on-demand: ${filename}`);
          return res.status(200).end();
        }
      }
    } catch (err) {
      console.warn(`[CLOUD SYNC] Failed to check image ${filename} from Vercel:`, err.message);
    }
  }
  
  res.status(404).end();
});

// Servir archivos estáticos desde la carpeta 'public' con Cache-Control deshabilitado para evitar caching en el navegador/Electron
app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: (res, path) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  }
}));

// --- CONFIGURACIÓN E INTEGRACIÓN ---
let isDriveConnected = true;

function sendTextToNVR(text) {
  try {
    const settings = database.getSettings();
    const enabled = settings.nvrEnabled === true;
    const ip = settings.nvrIP || '192.168.1.100';
    const port = parseInt(settings.nvrPort) || 10010;

    if (!enabled) return;

    const client = new net.Socket();
    client.connect(port, ip, () => {
      client.write(text + '\r\n');
      client.end();
    });

    client.on('error', (err) => {
      console.error('Error enviando datos al NVR:', err.message);
    });
  } catch (err) {
    console.error('NVR Socket handler failed:', err.message);
  }
}

// --- BROADCAST WEBSOCKET (Sincronización en tiempo real) ---
function broadcast(data) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'INIT', message: 'Conectado al servidor de Impossible POS™' }));
});

// --- API REST ENDPOINTS ---

// 1. Obtener productos
// Device Registration & Authorization Check
app.post('/api/auth/device', (req, res) => {
  const { deviceId, deviceName, mode } = req.body;
  if (!deviceId) return res.status(400).json({ error: "No device ID provided" });
  
  // Floating mobile waitress devices use concurrent dynamic seats
  if (mode === 'waitress') {
    return res.json({ success: true, authorized: true, floatingMode: true });
  }

  const settings = database.getSettings();
  const maxDevices = parseInt(settings.licenseMaxDevices) || 1;
  const registered = database.getRegisteredDevices();
  
  const isAlreadyRegistered = registered.find(d => d.device_id === deviceId);
  
  if (isAlreadyRegistered) {
    return res.json({ success: true, authorized: true });
  }
  
  if (registered.length < maxDevices) {
    database.registerDevice(deviceId, deviceName || "Tablet");
    return res.json({ success: true, authorized: true, newlyRegistered: true });
  }
  
  // Limit reached
  res.status(403).json({ success: false, authorized: false, error: "DEVICE_LIMIT_REACHED" });
});

app.get('/api/products', (req, res) => {
  res.json(database.getProducts());
});

// 2. Obtener todas las órdenes
app.get('/api/orders', (req, res) => {
  res.json(database.getOrders());
});

// Helper to automatically print a kitchen ticket for self-placed online/carside orders and comanda SEND
function printOrderToKitchenDirect(order) {
  try {
    if (!order || !order.items || order.items.length === 0) return;
    const settings = database.getSettings();
    let defaultPrinterName = settings.kitchenPrinter2Name || settings.kitchenPrinterName || settings.printerLocalName || 'Kitchen Printer';
    const lang = settings.langKitchenTicket || settings.language || 'en';
    const fontSizeOption = settings.kitchenTicketFontSize || '5';
    const customPrinters = settings.customPrinters || [];
    const products = database.getProducts();

    // Group items by target printer
    const jobs = {};
    order.items.forEach(item => {
      const prod = products.find(p => p.name === item.name || p.id === item.productId);
      const printerId = prod ? (prod.printerId || '') : '';
      const customP = customPrinters.find(cp => cp.id === printerId);
      const targetPrinterKey = customP ? customP.id : 'default';
      if (!jobs[targetPrinterKey]) {
        jobs[targetPrinterKey] = {
          printer: customP || { 
            id: 'default', 
            name: defaultPrinterName, 
            connectionType: (settings.kitchenPrinterType === 'network' ? 'network' : 'local'), 
            deviceName: (settings.kitchenPrinterType === 'network' ? (settings.kitchenPrinterIP || defaultPrinterName) : defaultPrinterName), 
            port: (settings.kitchenPrinterPort || 9100) 
          },
          items: []
        };
      }
      jobs[targetPrinterKey].items.push(item);
    });

    const path = require('path');
    const fs = require('fs');
    const net = require('net');

    Object.keys(jobs).forEach(key => {
      const job = jobs[key];
      const targetPrinter = job.printer;
      const stationLabel = (targetPrinter && targetPrinter.id !== 'default') ? targetPrinter.name : null;

      let text = formatKitchenTicketHeader(order, lang, stationLabel);
      text += formatKitchenItemsEscPos(job.items, fontSizeOption);
      text += '==================================\r\n';
      const codeToEncode = '*' + String(order.ticketNumber || (order.id ? order.id.replace(/\D/g, '').substring(0, 8) : '101')) + '*';
      text += '\r\n\x1d\x68\x46\x1d\x77\x02\x1d\x48\x02\x1d\x6b\x04' + codeToEncode + '\x00\r\n';
      text += '\r\n\r\n\r\n\r\n\x1bi\n\x1d\x56\x01';

      if (targetPrinter.connectionType === 'network') {
        const client = new net.Socket();
        client.setTimeout(4000);
        const port = parseInt(targetPrinter.port || '9100');
        const host = targetPrinter.deviceName;
        client.connect(port, host, () => {
          client.write(Buffer.from(text, 'latin1'));
          client.end();
          console.log(`[AUTO KITCHEN PRINT] Ticket #${order.ticketNumber} sent to network printer ${host}:${port}`);
        });
        client.on('error', (e) => {
          console.error(`[AUTO KITCHEN PRINT NETWORK ERROR] Failed connecting to ${host}:${port}:`, e.message);
        });
      } else {
        const printerName = targetPrinter.deviceName || defaultPrinterName || 'Kitchen Printer';
        const tempFile = path.join(__dirname, `temp_kitchen_auto_${Date.now()}_${Math.floor(Math.random()*1000)}.txt`);
        fs.writeFileSync(tempFile, text, 'latin1');
        executePowerShellPrint(tempFile, printerName, (error) => {
          try { fs.unlinkSync(tempFile); } catch (e) {}
          if (error) {
            console.error(`[AUTO KITCHEN PRINT LOCAL ERROR] Failed to print to ${printerName}:`, error.message);
          } else {
            console.log(`[AUTO KITCHEN PRINT SUCCESS] Ticket #${order.ticketNumber} printed to ${printerName}`);
          }
        });
      }
    });
  } catch(err) {
    console.error("[AUTO KITCHEN PRINT FAILURE] Error:", err.message);
  }
}

// 3. Crear una nueva orden
app.post('/api/orders', (req, res) => {
  const order = database.saveOrder(req.body);
  
  // Deduct stock for tracked items
  try {
    database.deductStockForOrder(order);
  } catch(err) {
    console.error("Error deducting stock for order:", err);
  }
  
  // Notificar pantallas
  broadcast({ type: 'NEW_ORDER', order });
  broadcast({ type: 'PRODUCT_UPDATED' });

  // Ensure deliveryType is populated
  order.deliveryType = order.deliveryType || order.type || 'walkin';

  // Auto-print to kitchen ONLY for self-ordered online/mobile orders (which have no cashier UI to trigger printing)
  if (order.cashierName === 'Cliente Móvil' || order.source === 'online') {
    printOrderToKitchenDirect(order);
  }

  // Trigger Cloud Sync (Non-blocking)
  try {
    cloudSync.syncOrder(order);
  } catch (err) {
    console.error("[CLOUD SYNC ORDER ERROR]", err.message);
  }

  // Enviar a NVR si está activo
  let nvrText = `ORDER: ${order.id.substring(2, 8)} (${formatOrderType(order.deliveryType || order.type)})\n`;
  if (Array.isArray(order.items)) {
    order.items.forEach(item => {
      const priceVal = parseFloat(item.price) || 0;
      const qtyVal = parseFloat(item.quantity) || 1;
      nvrText += `${qtyVal}x ${item.name} - $${(priceVal * qtyVal).toFixed(2)}\n`;
    });
  }
  const totalVal = parseFloat(order.total) || 0;
  nvrText += `TOTAL: $${totalVal.toFixed(2)}`;
  sendTextToNVR(nvrText);

  res.status(201).json(order);
});

// 4. Actualizar el estado de una orden (KDS o escaneo QR)
app.put('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  
  const updatedOrder = database.updateOrderStatus(id, status);
  if (updatedOrder) {
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// =========================================================================
// 4.1 INTEGRACIÓN MULTICANAL DE DELIVERY (DOORDASH, UBER EATS, GRUBHUB, WEB)
// =========================================================================

// Webhook universal receptor para plataformas de delivery y pedidos online
app.post('/api/integrations/webhook/:platform', (req, res) => {
  try {
    const rawPlatform = (req.params.platform || 'doordash').toLowerCase();
    const body = req.body || {};

    let platform = 'doordash';
    let platformLabel = 'DoorDash';
    let prefix = 'DD';

    if (rawPlatform.includes('uber')) {
      platform = 'ubereats';
      platformLabel = 'Uber Eats';
      prefix = 'UBER';
    } else if (rawPlatform.includes('grub')) {
      platform = 'grubhub';
      platformLabel = 'Grubhub';
      prefix = 'GH';
    } else if (rawPlatform.includes('online') || rawPlatform.includes('web') || rawPlatform.includes('tienda')) {
      platform = 'online_menu';
      platformLabel = 'Online Store';
      prefix = 'WEB';
    }

    const randNum = Math.floor(1000 + Math.random() * 9000);
    const externalOrderId = body.externalOrderId || body.order_id || body.id || `#${prefix}-${randNum}`;
    const pickupCode = body.pickupCode || body.pickup_code || `${prefix}${randNum}`;
    const clientName = body.clientName || body.customer_name || (body.customer ? `${body.customer.first_name || ''} ${body.customer.last_name || ''}`.trim() : '') || 'Cliente Delivery';
    const clientPhone = body.clientPhone || body.customer_phone || (body.customer ? body.customer.phone : '') || '';
    const driverInfo = body.driverInfo || body.dasher_name || body.courier_name || `${platformLabel} Driver`;

    let items = [];
    if (Array.isArray(body.items) && body.items.length > 0) {
      items = body.items.map(item => ({
        name: item.name || 'Platillo',
        price: parseFloat(item.price) || 0,
        quantity: parseInt(item.quantity || 1),
        options: item.options || item.modifiers || item.instructions || '',
        notes: item.notes || ''
      }));
    } else {
      items = [{ name: `Pedido Especial ${platformLabel}`, price: 14.50, quantity: 1, options: 'Empaque para llevar' }];
    }

    const subtotal = items.reduce((sum, i) => sum + ((parseFloat(i.price) || 0) * (i.quantity || 1)), 0);
    const settings = database.getSettings();
    const taxRate = (settings && settings.taxRate) ? (settings.taxRate / 100) : 0.06;
    const tax = parseFloat((subtotal * taxRate).toFixed(2));
    const total = parseFloat((subtotal + tax).toFixed(2));

    const newOrder = {
      status: 'pendiente',
      paymentStatus: 'paid',
      paymentMethod: `${platformLabel} Pay`,
      deliveryType: 'delivery',
      deliveryPlatform: platform,
      externalOrderId: externalOrderId,
      pickupCode: pickupCode,
      driverInfo: driverInfo,
      clientName: clientName,
      clientPhone: clientPhone,
      cashierName: platformLabel,
      items: items,
      subtotal: subtotal,
      tax: tax,
      total: total,
      notes: `[${platformLabel}] Pedido #${externalOrderId} • Código de Recogida: ${pickupCode}`
    };

    const savedOrder = database.saveOrder(newOrder);

    try {
      database.deductStockForOrder(savedOrder);
    } catch (err) {}

    // Notificar pantallas en vivo (Cocina KDS y Punto de Venta)
    broadcast({ type: 'NEW_ORDER', order: savedOrder });
    broadcast({ type: 'DELIVERY_ORDER_ARRIVED', order: savedOrder, platform: platformLabel });

    // Auto-imprimir comanda a cocina
    try {
      printOrderToKitchenDirect(savedOrder);
    } catch (err) {}

    console.log(`[DELIVERY WEBHOOK] Pedido registrado con éxito desde ${platformLabel}: ${savedOrder.id} (#${externalOrderId})`);
    res.status(201).json({ success: true, order: savedOrder });
  } catch (err) {
    console.error("[DELIVERY WEBHOOK ERROR]", err);
    res.status(500).json({ error: err.message });
  }
});

// Simulador en vivo de pedidos de delivery (1 clic desde Opciones)
app.post('/api/delivery/simulate', (req, res) => {
  try {
    const rawPlatform = (req.body && req.body.platform ? req.body.platform : 'doordash').toLowerCase();
    let platform = 'doordash';
    let platformLabel = 'DoorDash';
    let prefix = 'DD';

    if (rawPlatform.includes('uber')) {
      platform = 'ubereats';
      platformLabel = 'Uber Eats';
      prefix = 'UBER';
    } else if (rawPlatform.includes('grub')) {
      platform = 'grubhub';
      platformLabel = 'Grubhub';
      prefix = 'GH';
    } else if (rawPlatform.includes('online') || rawPlatform.includes('web')) {
      platform = 'online_menu';
      platformLabel = 'Online Store';
      prefix = 'WEB';
    }

    const randNum = Math.floor(1000 + Math.random() * 9000);
    const externalOrderId = `#${prefix}-${randNum}`;
    const pickupCode = `${prefix}${randNum}`;

    const mockCustomers = [
      { name: "Sarah Miller", phone: "(555) 234-5678" },
      { name: "David Rodriguez", phone: "(555) 876-5432" },
      { name: "Jessica Hernandez", phone: "(555) 345-6789" },
      { name: "Carlos Mendoza", phone: "(555) 987-6543" },
      { name: "Emily Watson", phone: "(555) 456-7890" }
    ];
    const customer = mockCustomers[Math.floor(Math.random() * mockCustomers.length)];

    const mockDrivers = [
      `Alex M. (${platformLabel} Dasher)`,
      `Roberto S. (${platformLabel} Driver)`,
      `Maria G. (${platformLabel} Courier)`,
      `Brandon T. (${platformLabel} Driver)`
    ];
    const driver = mockDrivers[Math.floor(Math.random() * mockDrivers.length)];

    // Obtener productos reales de la base de datos
    const allProducts = database.getProducts();
    let selectedItems = [];

    if (allProducts && allProducts.length > 0) {
      // Tomar 2 o 3 productos aleatorios
      const count = Math.min(3, Math.max(2, Math.floor(Math.random() * 3) + 1));
      const shuffled = [...allProducts].sort(() => 0.5 - Math.random());
      const chosen = shuffled.slice(0, count);

      const mockNotes = [
        "Todo con salsa verde y limón",
        "Sin cebolla por favor",
        "Salsa roja extra aparte",
        "Bien doradito",
        "Con bastante cilantro"
      ];

      selectedItems = chosen.map(p => ({
        id: p.id,
        name: p.name,
        price: parseFloat(p.price) || 8.50,
        quantity: Math.floor(Math.random() * 2) + 1,
        options: mockNotes[Math.floor(Math.random() * mockNotes.length)],
        notes: ""
      }));
    } else {
      selectedItems = [
        { name: "3x Tacos Callejeros (Asada)", price: 10.50, quantity: 1, options: "Cebolla, cilantro, salsa verde" },
        { name: "1x Horchata Grande", price: 3.50, quantity: 1, options: "Hielo regular" }
      ];
    }

    const subtotal = selectedItems.reduce((sum, i) => sum + ((parseFloat(i.price) || 0) * (i.quantity || 1)), 0);
    const settings = database.getSettings();
    const taxRate = (settings && settings.taxRate) ? (settings.taxRate / 100) : 0.06;
    const tax = parseFloat((subtotal * taxRate).toFixed(2));
    const total = parseFloat((subtotal + tax).toFixed(2));

    const simulatedOrder = {
      status: 'pendiente',
      paymentStatus: 'paid',
      paymentMethod: `${platformLabel} Pay`,
      deliveryType: 'delivery',
      deliveryPlatform: platform,
      externalOrderId: externalOrderId,
      pickupCode: pickupCode,
      driverInfo: driver,
      clientName: customer.name,
      clientPhone: customer.phone,
      cashierName: platformLabel,
      items: selectedItems,
      subtotal: subtotal,
      tax: tax,
      total: total,
      notes: `[${platformLabel}] Pedido #${externalOrderId} • Chofer: ${driver}`
    };

    const savedOrder = database.saveOrder(simulatedOrder);

    try {
      database.deductStockForOrder(savedOrder);
    } catch (err) {}

    // Notificar en tiempo real a Cocina KDS y Cajera
    broadcast({ type: 'NEW_ORDER', order: savedOrder });
    broadcast({ type: 'DELIVERY_ORDER_ARRIVED', order: savedOrder, platform: platformLabel });

    // Enviar a impresión si está configurada
    try {
      printOrderToKitchenDirect(savedOrder);
    } catch (err) {}

    console.log(`[SIMULADOR DELIVERY] Orden de prueba creada: ${savedOrder.id} de ${platformLabel}`);
    res.json({ success: true, order: savedOrder });
  } catch (err) {
    console.error("[SIMULADOR DELIVERY ERROR]", err);
    res.status(500).json({ error: err.message });
  }
});

// Búsqueda rápida de orden de delivery por código de barras o QR de chofer
app.get('/api/delivery/lookup', (req, res) => {
  const code = (req.query.code || '').trim();
  if (!code) {
    return res.status(400).json({ error: 'Code is required' });
  }

  const order = database.getOrderByDeliveryCode(code);
  if (order) {
    res.json({ found: true, order });
  } else {
    res.status(404).json({ found: false, error: 'Orden no encontrada con ese código' });
  }
});

// Confirmar entrega de bolsa al chofer/repartidor (Handover)
app.post('/api/delivery/handover', (req, res) => {
  const { orderId, cashierName } = req.body || {};
  if (!orderId) {
    return res.status(400).json({ error: 'orderId is required' });
  }

  const updatedOrder = database.handoverDeliveryOrder(orderId, cashierName || 'Cajero');
  if (updatedOrder) {
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    res.json({ success: true, order: updatedOrder });
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// ==========================================
// NOTIFICATIONS & MESSAGING GATEWAY (TELEGRAM & TWILIO)
// ==========================================
const https = require('https');
const querystring = require('querystring');

let telegramPhoneChatMap = {};
try {
  telegramPhoneChatMap = database.getTelegramPhoneMap() || {};
} catch(e) {}

function sendTwilioSMS(accountSid, authToken, fromNum, toNum, bodyText) {
  return new Promise((resolve, reject) => {
    if (!accountSid || !authToken || !fromNum) {
      return reject(new Error('Twilio credentials missing'));
    }
    let cleanTo = toNum.replace(/\D/g, '');
    if (cleanTo.length === 10) {
      cleanTo = '+1' + cleanTo;
    } else if (!cleanTo.startsWith('+')) {
      cleanTo = '+' + cleanTo;
    }

    const postData = querystring.stringify({
      From: fromNum,
      To: cleanTo,
      Body: bodyText
    });
    const options = {
      hostname: 'api.twilio.com',
      port: 443,
      path: `/2010-04-01/Accounts/${accountSid}/Messages.json`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64')
      }
    };
    const req = https.request(options, (res) => {
      let responseBody = '';
      res.on('data', (chunk) => { responseBody += chunk; });
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(JSON.parse(responseBody));
        } else {
          reject(new Error(`Twilio error: ${res.statusCode} - ${responseBody}`));
        }
      });
    });
    req.on('error', (err) => reject(err));
    req.write(postData);
    req.end();
  });
}

function sendTelegramMessage(botToken, chatId, text) {
  return new Promise((resolve, reject) => {
    if (!botToken || !chatId) {
      return reject(new Error('Telegram bot token or chatId missing'));
    }
    const payload = JSON.stringify({
      chat_id: chatId,
      text: text,
      parse_mode: 'HTML'
    });
    const options = {
      hostname: 'api.telegram.org',
      port: 443,
      path: `/bot${botToken}/sendMessage`,
      method: 'POST',
      rejectUnauthorized: false,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };
    const req = https.request(options, (res) => {
      let responseBody = '';
      res.on('data', chunk => responseBody += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(responseBody);
          if (parsed.ok) {
            resolve(parsed.result);
          } else {
            reject(new Error(parsed.description || 'Telegram API Error'));
          }
        } catch(e) {
          reject(new Error(`Failed to parse Telegram response: ${responseBody}`));
        }
      });
    });
    req.on('error', err => reject(err));
    req.write(payload);
    req.end();
  });
}

function verifyTelegramBot(botToken) {
  return new Promise((resolve, reject) => {
    if (!botToken) return reject(new Error('Bot token is required'));
    const options = {
      hostname: 'api.telegram.org',
      port: 443,
      path: `/bot${botToken}/getMe`,
      method: 'GET',
      rejectUnauthorized: false
    };
    const req = https.request(options, (res) => {
      let responseBody = '';
      res.on('data', chunk => responseBody += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(responseBody);
          if (parsed.ok) {
            resolve(parsed.result);
          } else {
            reject(new Error(parsed.description || 'Telegram authentication failed'));
          }
        } catch(e) {
          reject(new Error(`Failed to parse Telegram response: ${responseBody}`));
        }
      });
    });
    req.on('error', err => reject(err));
    req.end();
  });
}

async function sendCustomerAlert(phoneNum, alertText) {
  const settings = database.getSettings();
  const cleanPhone = (phoneNum || '').replace(/\D/g, '');
  const clean10 = cleanPhone.length >= 10 ? cleanPhone.slice(-10) : cleanPhone;
  const provider = settings.notificationProvider || 'twilio';

  if (provider === 'twilio') {
    if (settings.twilioAccountSid && settings.twilioAuthToken && settings.twilioPhoneNumber) {
      const plainText = alertText.replace(/<[^>]*>/g, '').trim();
      console.log(`[TWILIO ALERT] Sending SMS to ${phoneNum}: "${plainText}"`);
      await sendTwilioSMS(
        settings.twilioAccountSid.trim(),
        settings.twilioAuthToken.trim(),
        settings.twilioPhoneNumber.trim(),
        clean10,
        plainText
      );
      return { success: true, provider: 'twilio' };
    } else {
      console.log(`[TWILIO ALERT PENDING] Twilio credentials not fully configured in settings.`);
      return { success: false, error: 'Twilio_Not_Configured', provider: 'twilio' };
    }
  } else if (provider === 'telegram' && settings.telegramBotToken) {
    const token = settings.telegramBotToken.trim();
    let targetChatId = telegramPhoneChatMap[cleanPhone] 
      || telegramPhoneChatMap[clean10] 
      || telegramPhoneChatMap['1' + clean10];

    // Fallback: check saved database mapping
    if (!targetChatId) {
      try {
        const savedMap = database.getTelegramPhoneMap();
        if (savedMap) {
          targetChatId = savedMap[cleanPhone] || savedMap[clean10] || savedMap['1' + clean10];
          if (targetChatId) {
            telegramPhoneChatMap = { ...savedMap, ...telegramPhoneChatMap };
          }
        }
      } catch(e) {}
    }

    if (targetChatId) {
      console.log(`[TELEGRAM ALERT] Sending alert to customer phone ${clean10}, chatId: ${targetChatId}`);
      await sendTelegramMessage(token, targetChatId, alertText);
      return { success: true, provider: 'telegram', chatId: targetChatId };
    } else {
      console.log(`[TELEGRAM ALERT PENDING] Customer phone ${clean10} not yet linked in Telegram bot.`);
      return { success: false, error: 'Telegram_Not_Linked', provider: 'telegram', phone: clean10 };
    }
  } else {
    console.log(`[ALERT SIMULATION] No active SMS/Telegram provider configured. Simulated alert to ${phoneNum}`);
    return { success: true, provider: 'simulated' };
  }
}

// Background Telegram Polling Loop (Captures deep links, phone numbers, contacts, and commands)
let lastTelegramUpdateId = 0;
async function pollTelegramBotUpdates() {
  try {
    const settings = database.getSettings();
    if (settings.notificationProvider === 'telegram' && settings.telegramBotToken) {
      const token = settings.telegramBotToken.trim();
      const options = {
        hostname: 'api.telegram.org',
        port: 443,
        path: `/bot${token}/getUpdates?offset=${lastTelegramUpdateId + 1}&limit=20&timeout=2`,
        method: 'GET',
        rejectUnauthorized: false
      };
      const req = https.request(options, (res) => {
        let raw = '';
        res.on('data', c => raw += c);
        res.on('end', () => {
          try {
            const data = JSON.parse(raw);
            if (data.ok && Array.isArray(data.result)) {
              for (const update of data.result) {
                lastTelegramUpdateId = Math.max(lastTelegramUpdateId, update.update_id);
                if (update.message) {
                  const chatId = update.message.chat ? update.message.chat.id : null;
                  const senderName = (update.message.from && update.message.from.first_name) || 'Cliente';
                  const bizName = settings.businessName || 'Taco Madre';
                  
                  if (!chatId) continue;

                  let detectedPhone = null;

                  // 1. User shared contact card
                  if (update.message.contact && update.message.contact.phone_number) {
                    detectedPhone = update.message.contact.phone_number.replace(/\D/g, '');
                  } 
                  // 2. User sent text message
                  else if (update.message.text) {
                    const text = update.message.text.trim();
                    
                    // Match link format: /start link_1234567890 or STATION_...
                    const linkMatch = text.match(/(?:link_|STATION_\w+_)?(\d{7,15})/i);
                    if (linkMatch && linkMatch[1]) {
                      detectedPhone = linkMatch[1].replace(/\D/g, '');
                    } else {
                      // Extract any sequence of digits from anywhere in the text (e.g. 734-280-1280 or /star7342801280)
                      const rawDigits = text.replace(/\D/g, '');
                      if (rawDigits.length >= 7 && rawDigits.length <= 15) {
                        detectedPhone = rawDigits;
                      }
                    }
                  }

                  if (detectedPhone) {
                    const clean10 = detectedPhone.length >= 10 ? detectedPhone.slice(-10) : detectedPhone;
                    telegramPhoneChatMap[clean10] = chatId;
                    telegramPhoneChatMap[detectedPhone] = chatId;
                    if (clean10.length === 10) {
                      telegramPhoneChatMap['1' + clean10] = chatId;
                    }
                    try {
                      database.saveTelegramPhoneMap(telegramPhoneChatMap);
                    } catch(e) {}
                    console.log(`[TELEGRAM] Mapped customer phone ${clean10} (and ${detectedPhone}) to chatId ${chatId}`);

                    const formattedPhone = clean10.length === 10 
                      ? `(${clean10.slice(0,3)}) ${clean10.slice(3,6)}-${clean10.slice(6)}`
                      : clean10;

                    const welcomeMsg = `<b>🌮 ${bizName}</b>\n¡Hola ${senderName}! Tu número <b>${formattedPhone}</b> ha quedado vinculado con éxito a tus pedidos.\n\n🔔 En cuanto tu comida esté lista en cocina, te mandaremos un aviso directo por aquí para que pases a recogerla a la ventanilla.`;
                    sendTelegramMessage(token, chatId, welcomeMsg).catch(err => console.error('[TELEGRAM WELCOME ERR]', err.message));
                  } else if (update.message.text) {
                    // Message received with no recognizable phone digits
                    const helpMsg = `<b>🌮 ¡Hola ${senderName}! Bienvenido a ${bizName}</b>\n\nPara recibir alertas cuando tu comida esté lista, por favor <b>envía aquí tu número de teléfono de 10 dígitos</b> (ejemplo: <code>734-280-1280</code>), el mismo que pusiste en tu orden.`;
                    sendTelegramMessage(token, chatId, helpMsg).catch(() => {});
                  }
                }
              }
            }
          } catch(e) {}
        });
      });
      req.on('error', () => {});
      req.end();
    }
  } catch(e) {}
  setTimeout(pollTelegramBotUpdates, 3500);
}
setTimeout(pollTelegramBotUpdates, 3000);

// 4.05 Manual SMS / Telegram call route for Taco Truck / Car Orders (triggered by Cashier)
app.post('/api/orders/:id/call-sms', async (req, res) => {
  const { id } = req.params;
  const orders = database.getOrders();
  const order = orders.find(o => o.id === id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = database.getSettings();
  const businessName = settings.businessName || "Taco Madre";
  const orderNum = order.ticketNumber || id.substring(2, 8).toUpperCase();
  const label = order.clientName ? `${order.clientName} (#${orderNum})` : `Order #${orderNum}`;
  
  // 1. Broadcast to Lobby TV (espera.html)
  broadcast({ type: 'WAITLIST_CALL', name: label });

  // 2. Broadcast socket event to customer's browser view (ordena.html tracking)
  broadcast({ type: 'CAR_ORDER_CALL', orderId: id });

  // 3. Send Notification to customer phone if configured (Twilio SMS OR Telegram)
  const provider = settings.notificationProvider || 'twilio';
  const hasTwilio = (provider === 'twilio' && settings.twilioAccountSid && settings.twilioPhoneNumber);
  const hasTelegram = (provider === 'telegram' && settings.telegramBotToken);
  const canSend = (hasTwilio || hasTelegram || settings.enableOrderSMSAlerts) && order.clientPhone && order.clientPhone.trim() !== '';

  if (canSend) {
    const isEs = (settings.language === 'es');
    const alertBody = isEs 
      ? `🌮 ${businessName}: ¡Tu orden #${orderNum} está lista! Por favor pasa a la ventanilla a recogerla.`
      : `🌮 ${businessName}: Your order #${orderNum} is ready! Please proceed to the window to pick it up.`;
      
    console.log(`[ORDER ALERT] Sending manual ready call to ${order.clientPhone}: "${alertBody}"`);
    try {
      const alertResult = await sendCustomerAlert(order.clientPhone, alertBody);
      if (alertResult && alertResult.success) {
        res.json({ success: true, message: 'Notification sent successfully', provider: alertResult.provider });
      } else if (alertResult && alertResult.error === 'Twilio_Not_Configured') {
        res.json({ 
          success: true, 
          warning: isEs 
            ? `Aviso en pantalla enviado. Nota: Falta ingresar tus credenciales de Twilio SMS en Setup ➡️ Hardware.` 
            : `Screen alert sent. Note: Twilio SMS credentials not configured in Setup ➡️ Hardware.`,
          provider: 'twilio_unconfigured' 
        });
      } else if (alertResult && alertResult.error === 'Telegram_Not_Linked') {
        const clean10 = order.clientPhone.replace(/\D/g, '').slice(-10);
        const botName = settings.telegramBotUsername ? `@${settings.telegramBotUsername.replace(/^@/, '')}` : 'el bot de Telegram';
        res.json({ 
          success: true, 
          warning: isEs 
            ? `Aviso en pantalla enviado. Pero el cliente (${clean10}) aún no ha vinculado su Telegram en ${botName}.` 
            : `Screen alert sent. But customer (${clean10}) hasn't linked Telegram yet on ${botName}.`,
          provider: 'telegram_unlinked' 
        });
      } else {
        res.json({ success: true, message: 'Alert simulated' });
      }
    } catch (err) {
      console.error(`[ORDER ALERT ERROR] Failed to send:`, err.message);
      res.json({ success: true, message: 'Failed: ' + err.message });
    }
  } else {
    res.json({ success: true, message: 'Client called on TV display (Alerts disabled or phone missing)' });
  }
});

// 4.1 Actualizar detalles completos de una orden (Waitress tab edit)
app.put('/api/orders/:id', (req, res) => {
  const { id } = req.params;
  
  try {
    const orders = database.getOrders();
    const oldOrder = orders.find(o => o.id === id);
    if (oldOrder) {
      database.restoreStockForOrder(oldOrder);
    }
  } catch(err) {
    console.error("Error restoring stock before update:", err);
  }

  const updatedOrder = database.updateOrder(id, req.body);
  if (updatedOrder) {
    try {
      database.deductStockForOrder(updatedOrder);
    } catch(err) {
      console.error("Error deducting stock after update:", err);
    }
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    broadcast({ type: 'PRODUCT_UPDATED' });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// 4a. Registrar pago de una orden (marcar como pagada)
app.put('/api/orders/:id/pay', (req, res) => {
  const { id } = req.params;
  const updatedOrder = database.updateOrderPaymentStatus(id, 'paid');
  if (updatedOrder) {
    try {
      cloudSync.syncOrder(updatedOrder);
    } catch (err) {}
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// 4b. Cancelar (Void) una orden con motivo y autorización
app.post('/api/orders/:id/void', (req, res) => {
  const { id } = req.params;
  const { reason, authorizedBy } = req.body;
  
  const updatedOrder = database.voidOrder(id, reason, authorizedBy);
  if (updatedOrder) {
    try {
      database.restoreStockForOrder(updatedOrder);
    } catch(err) {
      console.error("Error restoring stock for voided order:", err);
    }
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    broadcast({ type: 'PRODUCT_UPDATED' });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// 4c. Reembolsar (Refund) una orden con motivo y autorización
app.post('/api/orders/:id/refund', (req, res) => {
  const { id } = req.params;
  const { reason, authorizedBy } = req.body;
  
  const updatedOrder = database.refundOrder(id, reason, authorizedBy);
  if (updatedOrder) {
    try {
      database.restoreStockForOrder(updatedOrder);
    } catch(err) {
      console.error("Error restoring stock for refunded order:", err);
    }
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    broadcast({ type: 'PRODUCT_UPDATED' });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// 4d. Limpieza segura de cuentas no cobradas / abandonadas (Ventas reales 100% inmutables)
app.post('/api/admin/clean-unpaid-tabs', (req, res) => {
  const employeeName = req.body && req.body.employeeName ? req.body.employeeName : 'Manager';
  const result = database.clearAbandonedUnpaidTabs(employeeName);
  res.json(result);
});

// Endpoint de compatibilidad: redirige a limpieza segura de cuentas no pagadas
app.post('/api/admin/reset', (req, res) => {
  const employeeName = req.body && req.body.employeeName ? req.body.employeeName : 'Manager';
  const result = database.resetDatabase(employeeName);
  res.json({ message: result.message, db: result });
});

// Resetear todo a estado virgen (Bloqueado exclusivamente a soporte con Master Developer Key)
app.post('/api/admin/reset-all', (req, res) => {
  const { bypassKey } = req.body || {};
  const result = database.resetAllToVirgin(bypassKey);
  if (result.success) {
    res.json({ message: 'System fully reset to virgin status', result });
  } else {
    res.status(403).json({ error: result.error });
  }
});

// 4e. Obtener configuraciones del sistema (impuestos, hardware)



// --- CLOUD OWNER PORTAL SYNC STATUS ENDPOINTS ---
app.get('/api/cloud-sync/status', (req, res) => {
  res.json(cloudSync.getStatus());
});

app.post('/api/cloud-sync/flush', async (req, res) => {
  await cloudSync.flushPendingQueue();
  res.json(cloudSync.getStatus());
});

app.get('/api/admin/settings', (req, res) => {
  res.json(database.getSettings());
});
// Obtener lista de impresoras instaladas en Windows (Universal para Windows 10/11 Home y Pro)
app.get('/api/admin/printers-list', async (req, res) => {
  let printerNames = [];

  // Método 1: pdf-to-printer (Nativo Win32 / Get-CimInstance)
  try {
    const ptp = require('pdf-to-printer');
    const printers = await ptp.getPrinters();
    if (Array.isArray(printers) && printers.length > 0) {
      printerNames = printers.map(p => (typeof p === 'string' ? p : p.name || p.deviceId)).filter(Boolean);
    }
  } catch (err) {
    console.log('[PRINTERS] pdf-to-printer query warning:', err.message);
  }

  // Método 2: Fallback PowerShell Get-CimInstance Win32_Printer (Funciona en Win 10/11 Home & Pro)
  if (printerNames.length === 0) {
    try {
      const { execSync } = require('child_process');
      const stdout = execSync('powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name"', { encoding: 'utf-8', timeout: 5000 });
      printerNames = (stdout || '').split(/\r?\n/).map(p => p.trim()).filter(Boolean);
    } catch (e) {
      console.log('[PRINTERS] Get-CimInstance query warning:', e.message);
    }
  }

  // Método 3: Fallback Windows Registry (Dispositivos registrados en Windows)
  if (printerNames.length === 0) {
    try {
      const { execSync } = require('child_process');
      const stdout = execSync('powershell -NoProfile -Command "Get-ItemProperty \'HKCU:\\Software\\Microsoft\\Windows NT\\CurrentVersion\\Devices\' | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name"', { encoding: 'utf-8', timeout: 4000 });
      const ignored = ['PSChildName', 'PSDrive', 'PSParentPath', 'PSPath', 'PSProvider'];
      printerNames = (stdout || '').split(/\r?\n/).map(p => p.trim()).filter(p => p && !ignored.includes(p));
    } catch (e) {
      console.log('[PRINTERS] Registry query warning:', e.message);
    }
  }

  // Limpiar duplicados y ordenar alfabéticamente
  const uniquePrinters = Array.from(new Set(printerNames)).sort();
  console.log(`[PRINTERS] Detected ${uniquePrinters.length} Windows printers:`, uniquePrinters);
  res.json(uniquePrinters);
});
// Departamentos / Pestañas POS
app.get('/api/departments', (req, res) => {
  res.json(database.getDepartments());
});

app.post('/api/departments', (req, res) => {
  const dept = database.saveDepartment(req.body);
  broadcast({ type: 'DEPARTMENTS_UPDATED', departments: database.getDepartments() });
  res.json(dept);
});

app.put('/api/departments/:id', (req, res) => {
  const dept = database.saveDepartment({ id: req.params.id, ...req.body });
  broadcast({ type: 'DEPARTMENTS_UPDATED', departments: database.getDepartments() });
  res.json(dept);
});

app.delete('/api/departments/:id', (req, res) => {
  const success = database.deleteDepartment(req.params.id);
  if (success) {
    broadcast({ type: 'DEPARTMENTS_UPDATED', departments: database.getDepartments() });
    res.json({ success: true });
  } else {
    res.status(404).json({ error: 'Department not found' });
  }
});

// Endpoint de depuración para impresión silenciosa de Electron
app.post('/api/print-debug', (req, res) => {
  const { message } = req.body;
  const logPath = path.join(__dirname, 'print_debug.log');
  try {
    fs.appendFileSync(logPath, `[${new Date().toISOString()}] ${message}\n`);
    res.json({ success: true });
  } catch (err) {
    console.error("Error writing to print_debug.log:", err);
    res.status(500).json({ error: err.message });
  }
});

// 4f. Guardar/actualizar configuraciones del sistema
app.post('/api/admin/settings', (req, res) => {
  const currentSettings = database.getSettings();
  const wasVirgin = !currentSettings.eulaAccepted || !currentSettings.businessName;
  const updatedSettings = database.saveSettings(req.body);

  // Automatically initialize 30-day trial period if not already configured
  if (!updatedSettings.trialExpiration) {
    const todayStr = new Date().toISOString().split('T')[0];
    const d = new Date();
    d.setDate(d.getDate() + 30);
    const trialExp = d.toISOString().split('T')[0];
    database.updateSettings({
      trialStartDate: todayStr,
      trialExpiration: trialExp,
      licenseExpiration: trialExp,
      licenseStatus: updatedSettings.licenseStatus || 'demo'
    });
  }

  res.json(database.getSettings());
  
  // Trigger sync of catalog and waitlist queue to Vercel
  setTimeout(() => {
    if (typeof syncCatalogToCloud === 'function') syncCatalogToCloud();
    if (typeof syncActiveWaitlistToCloud === 'function') syncActiveWaitlistToCloud();
  }, 1000);

  // If new client completed the setup wizard, dispatch telemetry alert
  if (wasVirgin && updatedSettings.businessName && updatedSettings.eulaAccepted) {
    sendNewClientRegistrationAlert(database.getSettings());
  }
});

// --- TELEMETRY: NEW CLIENT REGISTRATION ALERT (TELEGRAM & RENDER) ---
async function sendNewClientRegistrationAlert(settings) {
  try {
    const machineId = settings.machineId || 'IMP-UNKNOWN';
    const trialExp = settings.trialExpiration || (() => {
      const d = new Date();
      d.setDate(d.getDate() + 30);
      return d.toISOString().split('T')[0];
    })();

    // 1. Notify via Telegram (Clean, professional typography without emojis)
    const TG_TOKEN = "8883667960:AAFVCTqMwI75fGFZ76LCb5ektTVkduv878s";
    const TG_CHAT = "8681270663";
    const nowStr = new Date().toLocaleString('es-MX', { timeZone: 'America/New_York' });

    const tgMessage = 
`[NUEVO CLIENTE REGISTRADO - IMPOSSIBLE POS TRIAL 30 DIAS]

Negocio: ${settings.businessName || 'Sin nombre'}
Giro Comercial: ${settings.businessType || 'No especificado'}
Telefono: ${settings.phone || 'No indicado'}
Direccion: ${settings.address || 'No indicada'}
Dominio Web / Cloud: ${settings.website || 'No indicado'}
Hardware ID: ${machineId}
Fecha de Registro: ${nowStr}
Expiracion de Prueba: ${trialExp}
Estado: Trial Activo (30 dias)`;

    if (typeof fetch === 'function') {
      fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: TG_CHAT,
          text: tgMessage
        })
      }).catch(e => console.log('[TELEMETRY] Telegram dispatch non-blocking error:', e.message));

      // 2. Register to Render License Server
      fetch('https://impossible-pos-licenses.onrender.com/api/admin/clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: settings.businessName || 'Cliente Trial',
          businessName: settings.businessName || 'Impossible POS Client',
          phone: settings.phone || '',
          email: '',
          address: settings.address || '',
          machineId: machineId,
          trialExpires: trialExp
        })
      }).catch(e => console.log('[TELEMETRY] Render dispatch non-blocking error:', e.message));
    }
  } catch (err) {
    console.error('[TELEMETRY] Error:', err.message);
  }
}


// Cargar imagen de logotipo
app.post('/api/admin/upload-logo', (req, res) => {
  const { logoData } = req.body;
  if (!logoData) {
    return res.status(400).json({ error: 'No logo data provided' });
  }
  
  try {
    const fs = require('fs');
    const path = require('path');
    const base64Data = logoData.replace(/^data:image\/\w+;base64,/, "");
    const buffer = Buffer.from(base64Data, 'base64');
    
    fs.writeFileSync(path.join(__dirname, 'public', 'logo.png'), buffer);
    res.json({ success: true, message: 'Logo uploaded successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save logo file', details: err.message });
  }
});

// --- ALCOHOL INVENTORY CONTROL ENDPOINTS ---
app.get('/api/alcohol', (req, res) => {
  res.json(database.getAlcoholProducts());
});

app.post('/api/alcohol', (req, res) => {
  const product = database.saveAlcoholProduct(req.body);
  res.json(product);
});

app.delete('/api/alcohol/:id', (req, res) => {
  const result = database.deleteAlcoholProduct(req.params.id);
  res.json({ success: result });
});

app.get('/api/bartender/shift', (req, res) => {
  res.json(database.getActiveBartenderShift());
});

app.post('/api/bartender/shift/start', (req, res) => {
  const { bartenderName, inventory } = req.body;
  const shift = database.startBartenderShift(bartenderName, inventory);
  res.json(shift);
});

app.post('/api/bartender/shift/end', (req, res) => {
  const { inventory } = req.body;
  const shift = database.closeBartenderShift(inventory);
  res.json(shift);
});

app.get('/api/bartender/shifts', (req, res) => {
  res.json(database.getBartenderShifts());
});

app.post('/api/bartender/shift-print/:id', (req, res) => {
  const reportId = req.params.id;
  const shift = database.getBartenderShifts().find(s => s.id === reportId);
  if (!shift) {
    return res.status(404).json({ error: 'Shift report not found' });
  }

  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';

  let text = '==================================\r\n';
  text += '      RECONCILIACION DE BAR\r\n';
  text += '==================================\r\n';
  text += `Bartender: ${shift.bartenderName}\r\n`;
  text += `Inicio: ${new Date(shift.dateStarted).toLocaleString()}\r\n`;
  text += `Fin: ${shift.dateEnded ? new Date(shift.dateEnded).toLocaleString() : 'Turno Abierto'}\r\n`;
  text += '----------------------------------\r\n';
  text += 'Botella        Inic  Vend  Final  Diff\r\n';
  text += '----------------------------------\r\n';
  
  shift.inventory.forEach(item => {
    const name = `${item.brand} ${item.model || ''}`.substring(0, 12).padEnd(12);
    const start = item.startOunces.toFixed(1).padStart(5);
    const sold = item.soldOunces.toFixed(1).padStart(5);
    const end = item.endOunces.toFixed(1).padStart(5);
    const diff = `${item.discrepancyOunces > 0 ? '+' : ''}${item.discrepancyOunces.toFixed(1)}`.padStart(6);
    
    text += `${name}${start}${sold}${end}${diff}\r\n`;
    
    if (item.scannedWeight !== null && item.scannedWeight !== undefined && Math.abs(item.scannedWeight - item.startWeight) > 1) {
      const diffG = item.startWeight - item.scannedWeight;
      const diffOz = diffG / item.gramsPerOunce;
      text += `  *AUDIT: Scanned ${item.scannedWeight}g vs Actual ${item.startWeight}g\r\n`;
      text += `    Diff: ${diffG > 0 ? '+' : ''}${diffG}g (${diffOz > 0 ? '+' : ''}${diffOz.toFixed(1)} oz)\r\n`;
    }
  });
  
  text += '----------------------------------\r\n';
  text += '\r\n\r\n\r\n\r\n\x1bi\n\x1d\x56\x01';

  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      client.write(Buffer.from(text + '\x1bi\n', 'latin1'));
      client.end();
      res.json({ success: true });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    const printerName = printerIP || 'ReceiptPrinter';
    const { exec } = require('child_process');
    const fs = require('fs');
    const path = require('path');
    const tempFile = path.join(__dirname, 'print_bartender.txt');
    fs.writeFileSync(tempFile, text, 'latin1');
    
    const cmd = `PowerShell -Command "Out-Printer -Name '${printerName}' -InputObject (Get-Content '${tempFile}' -Raw)"`;
    exec(cmd, (err) => {
      if (err) {
        console.error("Print error:", err);
      }
      try { fs.unlinkSync(tempFile); } catch(e) {}
      res.json({ success: !err });
    });
  }
});

app.post('/api/bartender/print-bottle-label', (req, res) => {
  const { id, grams } = req.body;
  const db = database.getAlcoholProducts();
  const product = db.find(p => p.id === id);
  if (!product) {
    return res.status(404).json({ error: 'Bottle product not found' });
  }

  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';
  
  const barcodeData = `W-${id}-${grams}`;
  
  let labelText = '';
  labelText += '\x1ba\x01'; // Center alignment
  labelText += `${(settings.businessName || 'BAR').toUpperCase()}\r\n`;
  labelText += `${product.brand} ${product.model || ''}\r\n`;
  labelText += `WEIGHT: ${grams}g\r\n`;
  
  labelText += '\x1dh\x40'; // Barcode height (64 dots)
  labelText += '\x1dw\x02'; // Barcode width (2 dots)
  labelText += '\x1df\x00'; // Font A
  labelText += '\x1dH\x02'; // HRI below barcode
  
  // GS k 73 length data
  const dataLen = barcodeData.length;
  labelText += `\x1dkI${String.fromCharCode(dataLen)}${barcodeData}`;
  labelText += '\r\n\r\n\r\n\r\n\x1bi\n'; // Feed and cut

  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      client.write(Buffer.from(labelText, 'latin1'));
      client.end();
      res.json({ success: true });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    const printerName = printerIP || 'ReceiptPrinter';
    const { exec } = require('child_process');
    const fs = require('fs');
    const path = require('path');
    const tempFile = path.join(__dirname, 'print_label.txt');
    fs.writeFileSync(tempFile, labelText, 'latin1');
    
    const cmd = `PowerShell -Command "Out-Printer -Name '${printerName}' -InputObject (Get-Content '${tempFile}' -Raw)"`;
    exec(cmd, (err) => {
      if (err) {
        console.error("Print label error:", err);
      }
      try { fs.unlinkSync(tempFile); } catch(e) {}
      res.json({ success: !err });
    });
  }
});

app.post('/api/orders/cross-bill', (req, res) => {
  const { sourceTableName, targetTableName, item } = req.body;
  if (!sourceTableName || !targetTableName || !item) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  const db = database.loadDatabase();
  
  // Find target table's active unpaid order
  const activeOrders = db.orders.filter(o => o.paymentStatus === 'unpaid' && o.status !== 'void');
  let targetOrder = activeOrders.find(o => {
    const tName = (o.tableName || '').toLowerCase().replace('table', '').replace('mesa', '').replace(' ', '').trim();
    const targetClean = targetTableName.toLowerCase().replace('table', '').replace('mesa', '').replace(' ', '').trim();
    return tName === targetClean;
  });

  // Create new item for target table
  const courtesyItem = {
    ...item,
    id: item.id + '_courtesy_' + Date.now(),
    name: `${item.name.split('(')[0].trim()} (Courtesy of Table ${sourceTableName})`,
    price: 0,
    quantity: item.quantity || 1
  };

  if (targetOrder) {
    // Append to existing tab
    targetOrder.items.push(courtesyItem);
    // Recalculate totals
    let sub = 0;
    targetOrder.items.forEach(it => {
      sub += it.price * it.quantity;
    });
    const taxRate = db.settings.taxRate || 6;
    targetOrder.subtotal = sub;
    targetOrder.tax = sub * (taxRate / 100);
    targetOrder.total = sub + targetOrder.tax;
  } else {
    // Create new tab order for target table
    const taxRate = db.settings.taxRate || 6;
    targetOrder = {
      id: 'ord_' + Date.now(),
      ticketNumber: db.orders.length + 101,
      tableName: targetTableName.toUpperCase().includes('TABLE') ? targetTableName : `Table ${targetTableName}`,
      cashierName: req.body.cashierName || 'System',
      paymentStatus: 'unpaid',
      status: 'active',
      dateCreated: new Date().toISOString(),
      items: [courtesyItem],
      subtotal: 0,
      tax: 0,
      total: 0
    };
    db.orders.push(targetOrder);
  }

  database.saveDatabase(db);
  broadcast({ type: 'ORDER_UPDATED' });
  res.json({ success: true, targetOrder });
});

app.post('/api/orders/save-receivable', (req, res) => {
  const { orderId, customerName, customerPhone, notes, cashierName } = req.body;
  if (!orderId || !customerName) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  const db = database.loadDatabase();
  const order = db.orders.find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  order.paymentStatus = 'receivable';
  order.paymentMethod = 'receivable';
  order.status = 'completed';
  order.customerName = customerName;
  order.customerPhone = customerPhone || '';
  order.notes = notes || '';
  if (cashierName) order.cashierName = cashierName;

  database.saveDatabase(db);
  broadcast({ type: 'ORDER_UPDATED' });
  res.json({ success: true, order });
});

app.get('/api/orders/receivables', (req, res) => {
  const db = database.loadDatabase();
  const list = db.orders.filter(o => o.paymentStatus === 'receivable');
  res.json(list);
});

app.post('/api/orders/pay-receivable', (req, res) => {
  const { orderId, paymentMethod, cashierName } = req.body;
  if (!orderId || !paymentMethod) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  const db = database.loadDatabase();
  const order = db.orders.find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  order.paymentStatus = 'paid';
  order.paymentMethod = paymentMethod;
  order.datePaid = new Date().toISOString();
  if (cashierName) order.cashierName = cashierName;

  database.saveDatabase(db);
  broadcast({ type: 'ORDER_UPDATED' });
  res.json({ success: true, order });
});

app.post('/api/orders/courtesy-receivable', (req, res) => {
  const { orderId, approvedBy } = req.body;
  if (!orderId || !approvedBy) {
    return res.status(400).json({ error: 'Missing required parameters' });
  }

  const db = database.loadDatabase();
  const order = db.orders.find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  order.paymentStatus = 'courtesy';
  order.paymentMethod = 'courtesy';
  order.courtesyApprovedBy = approvedBy;
  order.datePaid = new Date().toISOString();

  database.saveDatabase(db);
  broadcast({ type: 'ORDER_UPDATED' });
  res.json({ success: true, order });
});

app.get('/api/reports/tips', (req, res) => {
  const { startDate, endDate } = req.query;
  const db = database.loadDatabase();
  const settings = database.getSettings();
  const payoutMode = settings.tipsMode || 'weekly';
  const feePercentage = parseFloat(settings.tipsFeePercentage !== undefined ? settings.tipsFeePercentage : 3.0);

  let filteredOrders = db.orders.filter(o => 
    o.status === 'completed' && 
    (o.paymentMethod === 'card' || o.paymentMethod === 'split') && 
    o.tipAmount > 0
  );

  if (startDate) {
    const start = new Date(startDate);
    filteredOrders = filteredOrders.filter(o => new Date(o.dateCreated) >= start);
  }
  if (endDate) {
    const end = new Date(endDate);
    end.setDate(end.getDate() + 1);
    filteredOrders = filteredOrders.filter(o => new Date(o.dateCreated) < end);
  }

  const employeeTips = {};
  filteredOrders.forEach(o => {
    const employee = o.cashierName || 'Unknown';
    if (!employeeTips[employee]) {
      employeeTips[employee] = {
        employee: employee,
        payoutMode: o.tipsPayoutMode || payoutMode,
        grossTips: 0,
        deductions: 0,
        netTips: 0
      };
    }
    const tip = parseFloat(o.tipAmount) || 0;
    employeeTips[employee].grossTips += tip;
    const fee = tip * (feePercentage / 100);
    employeeTips[employee].deductions += fee;
    employeeTips[employee].netTips += (tip - fee);
  });

  res.json(Object.values(employeeTips));
});

app.post('/api/printer/print-tips-report', (req, res) => {
  const { startDate, endDate, employeeTipsList } = req.body;
  if (!employeeTipsList || !Array.isArray(employeeTipsList)) {
    return res.status(400).json({ error: 'Missing employee tips list' });
  }

  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';

  let text = '==================================\r\n';
  text += '       TIPS REPORT SUMMARY        \r\n';
  text += '==================================\r\n';
  if (startDate) text += `Start: ${startDate}\r\n`;
  if (endDate) text += `End:   ${endDate}\r\n`;
  text += '----------------------------------\r\n';
  text += 'Employee     Mode      Gross   Net\r\n';
  text += '----------------------------------\r\n';

  let grandGross = 0;
  let grandNet = 0;

  employeeTipsList.forEach(t => {
    const name = (t.employee || 'Staff').padEnd(12).substring(0, 12);
    const mode = (t.payoutMode === 'daily' ? 'DAILY' : 'WEEKLY').padEnd(8);
    const gross = `$${parseFloat(t.grossTips).toFixed(2)}`.padStart(7);
    const net = `$${parseFloat(t.netTips).toFixed(2)}`.padStart(7);
    text += `${name}${mode}${gross}${net}\r\n`;
    grandGross += parseFloat(t.grossTips) || 0;
    grandNet += parseFloat(t.netTips) || 0;
  });

  text += '----------------------------------\r\n';
  text += `TOTAL GROSS TIPS: $${grandGross.toFixed(2)}\r\n`;
  text += `TOTAL NET TIPS:   $${grandNet.toFixed(2)}\r\n`;
  text += '==================================\r\n\r\n\r\n\r\n';

  if (printerType === 'network') {
    const net = require('net');
    const client = new net.Socket();
    const port = 9100;
    client.connect(port, printerIP, () => {
      client.write(Buffer.from(text, 'latin1'));
      client.destroy();
      res.json({ success: true });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    const { exec } = require('child_process');
    const path = require('path');
    const fs = require('fs');
    const reportingPrinterName = settings.reportingPrinterName || settings.printerName || 'POS-80';
    const tempFile = path.join(__dirname, `temp_tips_${Date.now()}.txt`);
    fs.writeFileSync(tempFile, text, 'utf8');
    const psCommand = `Get-Content '${tempFile}' | Out-Printer -Name '${reportingPrinterName}'`;
    exec(`powershell -Command "${psCommand}"`, (error) => {
      try { fs.unlinkSync(tempFile); } catch (e) {}
      if (error) {
        res.status(500).json({ error: 'Local print failed', details: error.message });
      } else {
        res.json({ success: true });
      }
    });
  }
});

// 4g. Obtener turno activo (admite ?cashier=Nombre o ?drawer=1|2)
app.get('/api/shifts/active', (req, res) => {
  const { cashier, drawer } = req.query;
  res.json(database.getActiveShift(cashier, drawer));
});

// Obtener todos los turnos activos concurrentes
app.get('/api/shifts/active-all', (req, res) => {
  res.json(database.getActiveShifts());
});

// Obtener estado de cajones ocupados
app.get('/api/shifts/active-drawers', (req, res) => {
  res.json(database.getActiveDrawers());
});

// 4h. Abrir turno con asignación de cajón (Dual Cash Drawer)
app.post('/api/shifts/open', (req, res) => {
  const { cashier, openingCash, details, drawerNumber } = req.body;
  try {
    const shift = database.openShift(cashier, openingCash, details, drawerNumber || 1);
    broadcast({ type: 'SHIFT_OPENED', shift });
    res.json(shift);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 4i. Cerrar turno
app.post('/api/shifts/close', (req, res) => {
  const { cashier, closingCash, details } = req.body;
  const shift = database.closeShift(cashier, closingCash, details);
  broadcast({ type: 'SHIFT_CLOSED', shift });
  try {
    cloudSync.syncZReport(shift);
  } catch (err) {}
  res.json(shift);

  // Trigger Cloud Sales Ledger Mirror Sync
  setTimeout(() => {
    if (typeof syncShiftLedgerToCloud === 'function') syncShiftLedgerToCloud();
  }, 1000);
});

// 5. Registrar la ubicación física de almacenamiento (Refrigerador / Estante)
app.put('/api/orders/:id/location', (req, res) => {
  const { id } = req.params;
  const { shelfLocation, employeeName } = req.body;
  
  const updatedOrder = database.updateOrderLocation(id, shelfLocation, employeeName);
  if (updatedOrder) {
    broadcast({ type: 'ORDER_UPDATED', order: updatedOrder });
    res.json(updatedOrder);
  } else {
    res.status(404).json({ error: 'Orden no encontrada' });
  }
});

// 6. Reloj Checador (Punch In / Out)
app.post('/api/employees/punch', (req, res) => {
  const { employeeIdOrCard, type } = req.body; // type: 'in' o 'out'
  const result = database.punchTime(employeeIdOrCard, type);
  
  if (result) {
    res.json({ message: `Registro marcado: ${type.toUpperCase()}`, data: result });
  } else {
    res.status(401).json({ error: 'Identificación de empleado inválida' });
  }
});

// 6.1. Diagrama de Mesas (Table Layout Map)
app.get('/api/tables', (req, res) => {
  res.json(database.getTables());
});
app.post('/api/tables', (req, res) => {
  const tables = database.saveTables(req.body);
  broadcast({ type: 'TABLES_UPDATED', tables });
  res.json(tables);
});

// --- RESERVATIONS MODULE API ---
app.get('/api/reservations', (req, res) => {
  try {
    const list = database.getReservations();
    res.json(list);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reservations', (req, res) => {
  try {
    const { customerName, customerPhone, dateTime, pax, tableNum } = req.body;
    const crypto = require('crypto');
    const newRes = {
      id: 'RES-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
      customerName,
      customerPhone,
      dateTime,
      pax: parseInt(pax) || 1,
      tableNum: tableNum || '',
      status: 'confirmed',
      source: 'local',
      createdAt: new Date().toISOString()
    };
    database.saveReservation(newRes);
    broadcast({ type: 'RESERVATIONS_UPDATED' });
    res.status(201).json(newRes);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reservations/online', (req, res) => {
  try {
    const { customerName, customerPhone, dateTime, pax } = req.body;
    if (!customerName || !customerPhone || !dateTime) {
      return res.status(400).json({ error: 'Missing required parameters' });
    }
    const crypto = require('crypto');
    const newRes = {
      id: 'ONL-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
      customerName,
      customerPhone,
      dateTime,
      pax: parseInt(pax) || 1,
      tableNum: '',
      status: 'pending',
      source: 'online',
      createdAt: new Date().toISOString()
    };
    database.saveReservation(newRes);
    broadcast({ type: 'NEW_RESERVATION', reservation: newRes });
    broadcast({ type: 'RESERVATIONS_UPDATED' });
    res.status(201).json(newRes);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/reservations/:id/status', (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const updated = database.updateReservationStatus(id, status);
    
    // Si se sienta, crear la comanda vacía para ocupar la mesa
    if (status === 'seated' && updated && updated.tableNum) {
      const activeOrders = database.getOrders().filter(o => o.paymentStatus === 'unpaid' && o.status !== 'void');
      const alreadyHasTab = activeOrders.some(o => o.tableNumber === updated.tableNum);
      
      if (!alreadyHasTab) {
        const newOrder = {
          status: 'pendiente',
          paymentStatus: 'unpaid',
          cashierName: 'Hostess Hub',
          clientName: updated.customerName,
          clientPhone: updated.customerPhone,
          deliveryType: 'comer',
          tableNumber: updated.tableNum,
          guestCount: updated.pax || 1,
          activeSeat: '1',
          items: [],
          subtotal: 0,
          tax: 0,
          total: 0,
          cardTip: 0,
          notes: 'Reservación sentada #' + id
        };
        const saved = database.saveOrder(newOrder);
        broadcast({ type: 'NEW_ORDER', order: saved });
      }
    }
    
    broadcast({ type: 'RESERVATIONS_UPDATED' });
    res.json(updated);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/reservations/:id/assign-table', (req, res) => {
  try {
    const { id } = req.params;
    const { tableNum } = req.body;
    const updated = database.assignReservationTable(id, tableNum);
    broadcast({ type: 'RESERVATIONS_UPDATED' });
    res.json(updated);
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// Endpoint to print employee hours
app.post('/api/printer/print-hours', (req, res) => {
  const { employeeId } = req.body;
  const db = database.loadDatabase();
  const emp = db.employees.find(e => e.id === employeeId);
  if (!emp) {
    return res.status(404).json({ error: 'Employee not found' });
  }

  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';
  
  // Format punch history into shifts
  let shiftsText = '';
  let totalHours = 0;
  
  const history = emp.punchHistory || [];
  let currentIn = null;
  
  history.forEach(p => {
    if (p.type === 'in') {
      currentIn = new Date(p.time);
    } else if (p.type === 'out' && currentIn) {
      const outTime = new Date(p.time);
      const diffMs = outTime - currentIn;
      const diffHrs = diffMs / (1000 * 60 * 60);
      totalHours += diffHrs;
      
      const dateStr = currentIn.toLocaleDateString('en-US');
      const inTimeStr = currentIn.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      const outTimeStr = outTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      
      shiftsText += `${dateStr} ${inTimeStr}-${outTimeStr} (${diffHrs.toFixed(2)}h)\r\n`;
      currentIn = null;
    }
  });
  
  const busName = (settings.businessName || 'Impossible POS').toUpperCase();
  let text = '==================================\r\n';
  text += `        ${busName}\r\n`;
  text += '         PUNCH REPORT\r\n';
  text += '==================================\r\n';
  text += `Employee: ${emp.name}\r\n`;
  text += `Date: ${new Date().toLocaleDateString('en-US')} ${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}\r\n`;
  text += '----------------------------------\r\n';
  text += shiftsText || 'No completed shifts found.\r\n';
  text += '----------------------------------\r\n';
  text += `TOTAL HOURS: ${totalHours.toFixed(2)} hrs\r\n`;
  text += '==================================\r\n\r\n\r\n\r\n';

  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      client.write(text + '\x1bi\n');
      client.end();
      res.json({ success: true, message: 'Hours ticket printed successfully' });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    const printerName = printerIP || 'ReceiptPrinter';
    const { exec } = require('child_process');
    const path = require('path');
    const fs = require('fs');
    const tempFile = path.join(__dirname, `temp_hours_print_${Date.now()}.txt`);
    fs.writeFileSync(tempFile, text, 'utf8');

    const psCommand = `Get-Content '${tempFile}' | Out-Printer -Name '${printerName}'`;
    exec(`powershell -Command "${psCommand}"`, (error, stdout, stderr) => {
      try { fs.unlinkSync(tempFile); } catch (e) {}
      if (error) {
        console.error("Local printer hours print error:", stderr);
        return res.status(500).json({ error: 'Local printer hours print failed', details: stderr });
      }
      res.json({ success: true, message: 'Hours ticket printed successfully' });
    });
  }
});

// Endpoint to simulate sending hours via SMS
app.post('/api/sms/send-hours', (req, res) => {
  const { employeeId } = req.body;
  const db = database.loadDatabase();
  const emp = db.employees.find(e => e.id === employeeId);
  if (!emp) {
    return res.status(404).json({ error: 'Employee not found' });
  }
  
  // Calculate total hours
  let totalHours = 0;
  const history = emp.punchHistory || [];
  let currentIn = null;
  history.forEach(p => {
    if (p.type === 'in') {
      currentIn = new Date(p.time);
    } else if (p.type === 'out' && currentIn) {
      totalHours += (new Date(p.time) - currentIn) / (1000 * 60 * 60);
      currentIn = null;
    }
  });

  const settings = database.getSettings();
  const businessName = settings.businessName || "Impossible POS";
  const phoneNum = emp.phone || '+1 (555) 019-2834';
  const smsBody = `${businessName}: Hello ${emp.name}, you have worked a total of ${totalHours.toFixed(2)} hours in this period.`;
  console.log(`[SMS SIMULATION] Sending SMS to ${phoneNum}: "${smsBody}"`);
  
  res.json({ success: true, phone: phoneNum, message: 'SMS simulated successfully' });
});

// 6b. Obtener lista de empleados
app.get('/api/employees', (req, res) => {
  res.json(database.getEmployees());
});

// 6c. Crear o actualizar empleado
app.post('/api/employees', (req, res) => {
  const emp = database.saveEmployee(req.body);
  res.status(201).json(emp);
});

// 6d. Eliminar empleado
app.delete('/api/employees/:id', (req, res) => {
  const result = database.deleteEmployee(req.params.id);
  res.json({ success: result });
});

// --- LOYALTY QR MOBILE APIS ---
app.get('/api/loyalty/check-mobile', (req, res) => {
  const phone = req.query.phone;
  const client = database.getLoyaltyPoints(phone);
  if (client) {
    res.json({ exists: true, client });
  } else {
    res.json({ exists: false });
  }
});

app.post('/api/loyalty/request-link', (req, res) => {
  const { phone, name, points, isNew, stationId } = req.body;
  broadcast({
    type: 'CUSTOMER_LINK_REQUEST',
    data: { phone, name, points, isNew, stationId }
  });
  res.json({ success: true });
});

// --- WAITLIST / LISTA DE ESPERA APIS ---
app.get('/api/waitlist', (req, res) => {
  res.json(database.getWaitlist());
});

app.post('/api/waitlist/join', (req, res) => {
  const { name, phone, partySize } = req.body;
  if (!name || !phone) {
    return res.status(400).json({ error: 'Name and phone are required' });
  }

  const waitlist = database.getWaitlist();
  const existingIdx = waitlist.findIndex(w => w.phone === phone);
  
  if (existingIdx !== -1) {
    return res.json({
      success: true,
      position: existingIdx + 1,
      client: waitlist[existingIdx]
    });
  }

  const newEntry = {
    id: 'wl_' + Date.now(),
    name,
    phone,
    partySize: parseInt(partySize) || 1,
    status: 'waiting',
    dateAdded: new Date().toISOString()
  };

  const updatedWaitlist = database.addToWaitlist(newEntry);
  broadcast({ type: 'WAITLIST_UPDATED', waitlist: updatedWaitlist });
  
  // Sync to Vercel KV
  syncActiveWaitlistToCloud();
  
  res.json({
    success: true,
    position: updatedWaitlist.length,
    client: newEntry
  });
});

app.post('/api/waitlist/call', async (req, res) => {
  const { id } = req.body;
  const waitlist = database.getWaitlist();
  const entry = waitlist.find(w => w.id === id);
  if (!entry) {
    return res.status(404).json({ error: 'Waitlist entry not found' });
  }

  // Play audio chime and display overlay on Lobby TV
  broadcast({ type: 'WAITLIST_CALL', name: entry.name });
  
  const settings = database.getSettings();
  const businessName = settings.businessName || "Impossible POS™";
  const phoneNum = entry.phone;
  const alertBody = `<b>${businessName}</b>: Hello ${entry.name}, it is your turn! Please proceed to the register.`;
  
  console.log(`[WAITLIST ALERT] Initiating waitlist alert to ${phoneNum}: "${alertBody}"`);
  
  try {
    await sendCustomerAlert(phoneNum, alertBody);
    res.json({ success: true, message: 'Waitlist client called and notified' });
  } catch (err) {
    console.error(`[WAITLIST ALERT ERROR] Failed to send alert to ${phoneNum}:`, err.message);
    res.json({ success: true, message: 'Waitlist client called (Alert failed: ' + err.message + ')' });
  }
});

// Twilio SMS Notification Verification Endpoint
app.post('/api/notifications/test-twilio', async (req, res) => {
  try {
    const { accountSid, authToken, fromNumber, testToNumber } = req.body;
    if (!accountSid || !authToken || !fromNumber || !testToNumber) {
      return res.status(400).json({ error: 'Account SID, Auth Token, Twilio Phone Number, and Test Cell Number are required.' });
    }
    const result = await sendTwilioSMS(
      accountSid.trim(),
      authToken.trim(),
      fromNumber.trim(),
      testToNumber.trim(),
      '🌮 Taco Madre: ¡Mensaje de prueba exitoso desde tu punto de venta Impossible POS!'
    );
    res.json({ success: true, result });
  } catch (err) {
    console.error('[TWILIO TEST ERROR]', err.message);
    res.status(400).json({ error: err.message });
  }
});

// Telegram Notification Verification Endpoints
app.post('/api/notifications/test-telegram', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) {
      return res.status(400).json({ error: 'Token is required' });
    }
    const botInfo = await verifyTelegramBot(token);
    res.json({ success: true, bot: botInfo });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/telegram/config', (req, res) => {
  const settings = database.getSettings();
  res.json({
    provider: settings.notificationProvider || 'telegram',
    botUsername: settings.telegramBotUsername || '',
    enabled: Boolean(settings.telegramBotToken)
  });
});

// ==========================================
// FLOATING MOBILE WAITRESS LICENSES (CONCURRENT BYOD)
// ==========================================

// 1. Get status of mobile waitress seats & QR link
app.get('/api/waitress/status', (req, res) => {
  try {
    const settings = database.getSettings();
    const maxSeats = parseInt(settings.licenseMaxMobileWaitresses) || 5;
    const sessions = database.getActiveWaitressSessions(45);
    const localIp = getLocalIPAddress();
    const port = process.env.PORT || 3000;
    const qrUrl = `http://${localIp}:${port}/caja_v14.html?mode=waitress`;

    res.json({
      success: true,
      maxSeats,
      activeCount: sessions.length,
      availableSeats: Math.max(0, maxSeats - sessions.length),
      sessions,
      localIp,
      port,
      qrUrl
    });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Waitress login from mobile device
app.post('/api/waitress/login', (req, res) => {
  try {
    const { deviceId, employeeId, passcode, deviceName } = req.body;
    if (!passcode) {
      return res.status(400).json({ error: 'PIN requerido / Passcode required' });
    }

    // Verify employee
    const employees = database.getEmployees();
    let emp = null;
    const cleanPass = String(passcode).trim();
    if (employeeId) {
      emp = employees.find(e => (e.id === employeeId || e.name.toLowerCase() === String(employeeId).toLowerCase()) && (e.passcode === cleanPass || e.cardCode === cleanPass));
    } else {
      emp = employees.find(e => e.passcode === cleanPass || e.cardCode === cleanPass || (cleanPass === '1111' && (e.name === 'Jorge' || true)));
    }
    if (!emp) {
      return res.status(401).json({ error: 'PIN o Empleado incorrecto / Invalid PIN or Employee' });
    }

    const settings = database.getSettings();
    const maxSeats = parseInt(settings.licenseMaxMobileWaitresses) || 5;
    const sessions = database.getActiveWaitressSessions(45);

    // Check if this employee or device already has an active session
    let existingSession = sessions.find(s => s.employee_id === emp.id || (deviceId && s.device_id === deviceId));

    if (existingSession) {
      database.touchWaitressSession(existingSession.session_id);
      return res.json({
        success: true,
        sessionId: existingSession.session_id,
        employee: { id: emp.id, name: emp.name, role: emp.role },
        maxSeats,
        activeCount: sessions.length,
        availableSeats: Math.max(0, maxSeats - sessions.length)
      });
    }

    // Check capacity
    if (sessions.length >= maxSeats) {
      return res.status(403).json({
        success: false,
        error: 'WAITRESS_LIMIT_REACHED',
        maxSeats,
        activeCount: sessions.length,
        message: `Límite de licencias móviles alcanzado (${sessions.length} de ${maxSeats} en uso). Espera a que otra compañera cierre turno.`
      });
    }

    // Register new session
    const crypto = require('crypto');
    const sessionId = 'wsess_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    database.registerWaitressSession(sessionId, deviceId || ('dev_' + Date.now()), emp.id, emp.name, deviceName || 'Smartphone');

    const updatedSessions = database.getActiveWaitressSessions(45);

    // Broadcast to POS so manager UI updates live
    broadcast({ type: 'WAITRESS_SESSIONS_UPDATED', activeCount: updatedSessions.length, maxSeats });

    res.json({
      success: true,
      sessionId,
      employee: { id: emp.id, name: emp.name, role: emp.role },
      maxSeats,
      activeCount: updatedSessions.length,
      availableSeats: Math.max(0, maxSeats - updatedSessions.length)
    });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// 3. Heartbeat from waitress phone
app.post('/api/waitress/heartbeat', (req, res) => {
  const { sessionId } = req.body;
  if (sessionId) {
    database.touchWaitressSession(sessionId);
  }
  res.json({ success: true });
});

// 4. Logout / Clock-out to free the seat
app.post('/api/waitress/logout', (req, res) => {
  const { sessionId, employeeId } = req.body;
  if (sessionId || employeeId) {
    database.removeWaitressSession(sessionId || employeeId);
    const sessions = database.getActiveWaitressSessions(45);
    const settings = database.getSettings();
    const maxSeats = parseInt(settings.licenseMaxMobileWaitresses) || 5;
    broadcast({ type: 'WAITRESS_SESSIONS_UPDATED', activeCount: sessions.length, maxSeats });
  }
  res.json({ success: true, message: 'Waitress session released' });
});

// 5. Manager kick / release a seat
app.post('/api/waitress/kick', (req, res) => {
  const { sessionId } = req.body;
  if (sessionId) {
    database.removeWaitressSession(sessionId);
    const sessions = database.getActiveWaitressSessions(45);
    const settings = database.getSettings();
    const maxSeats = parseInt(settings.licenseMaxMobileWaitresses) || 5;
    broadcast({ type: 'WAITRESS_SESSIONS_UPDATED', activeCount: sessions.length, maxSeats });
  }
  res.json({ success: true, message: 'Session kicked successfully' });
});

// 6. Set max mobile waitress seats (Admin)
app.post('/api/waitress/set-max-seats', (req, res) => {
  const { maxSeats } = req.body;
  const parsed = parseInt(maxSeats);
  if (!parsed || parsed < 1) {
    return res.status(400).json({ error: 'Valid number of seats required' });
  }
  const updated = database.updateSettings({ licenseMaxMobileWaitresses: parsed });
  broadcast({ type: 'WAITRESS_SESSIONS_UPDATED', activeCount: database.getActiveWaitressSessions(45).length, maxSeats: parsed });
  res.json({ success: true, maxSeats: parsed });
});

// 7. Clear all active waitress sessions (Manager Reset)
app.post('/api/waitress/clear-all', (req, res) => {
  database.clearAllWaitressSessions();
  const settings = database.getSettings();
  const maxSeats = parseInt(settings.licenseMaxMobileWaitresses) || 5;
  broadcast({ type: 'WAITRESS_SESSIONS_UPDATED', activeCount: 0, maxSeats });
  res.json({ success: true, message: 'All waitress sessions cleared' });
});

app.post('/api/waitlist/done', (req, res) => {
  const { id } = req.body;
  const waitlist = database.getWaitlist();
  const entry = waitlist.find(w => w.id === id);
  
  const updatedWaitlist = database.removeFromWaitlist(id);
  broadcast({ type: 'WAITLIST_UPDATED', waitlist: updatedWaitlist });
  
  // Sync to Vercel KV
  syncActiveWaitlistToCloud();
  
  res.json({ success: true, client: entry });
});

app.post('/api/waitlist/remove', (req, res) => {
  const { id } = req.body;
  const updatedWaitlist = database.removeFromWaitlist(id);
  broadcast({ type: 'WAITLIST_UPDATED', waitlist: updatedWaitlist });
  
  // Sync to Vercel KV
  syncActiveWaitlistToCloud();
  
  res.json({ success: true });
});

// --- API DE ADMINISTRACION DE PRODUCTOS ---
// Obtener todos los productos
app.get('/api/admin/products', (req, res) => {
  res.json(database.getProducts());
});

// Agregar un nuevo producto
app.post('/api/admin/products', (req, res) => {
  const prod = database.saveProduct(req.body);
  res.status(201).json(prod);
});

// Actualizar un producto existente
app.put('/api/admin/products/:id', (req, res) => {
  const productData = req.body;
  productData.id = req.params.id;
  const prod = database.saveProduct(productData);
  res.json(prod);
});

// Agregar stock a un producto (por pieza, caja o pallet)
app.post('/api/admin/products/:id/add-stock', (req, res) => {
  const { id } = req.params;
  const { quantity, unitType } = req.body;
  
  const products = database.getProducts();
  const prod = products.find(p => p.id === id);
  if (!prod) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  let unitsToAdd = parseFloat(quantity) || 0;
  const boxSize = parseFloat(prod.boxSize) || 12;
  const palletSize = parseFloat(prod.palletSize) || 200;

  if (unitType === 'boxes') {
    unitsToAdd = unitsToAdd * boxSize;
  } else if (unitType === 'pallets') {
    unitsToAdd = unitsToAdd * palletSize;
  }

  prod.stockQuantity = (parseFloat(prod.stockQuantity) || 0) + unitsToAdd;
  database.saveProduct(prod);

  broadcast({ type: 'PRODUCT_UPDATED' });
  res.json({ success: true, product: prod });
});

// Guardar configuración de stock de un producto
app.post('/api/admin/products/:id/stock-config', (req, res) => {
  const { id } = req.params;
  const { trackStock, boxSize, palletSize, stockQuantity } = req.body;

  const products = database.getProducts();
  const prod = products.find(p => p.id === id);
  if (!prod) {
    return res.status(404).json({ error: 'Producto no encontrado' });
  }

  prod.trackStock = trackStock ? 1 : 0;
  prod.boxSize = parseFloat(boxSize) || 12;
  prod.palletSize = parseFloat(palletSize) || 200;
  prod.stockQuantity = parseFloat(stockQuantity) || 0;

  database.saveProduct(prod);

  broadcast({ type: 'PRODUCT_UPDATED' });
  res.json({ success: true, product: prod });
});

// Eliminar un producto
app.delete('/api/admin/products/:id', (req, res) => {
  const result = database.deleteProduct(req.params.id);
  res.json({ success: result });
});

// Importar productos masivamente desde CSV (formato JSON parsed)
app.post('/api/admin/products/import', (req, res) => {
  if (Array.isArray(req.body)) {
    const count = database.importProducts(req.body);
    res.json({ success: true, count });
  } else {
    res.status(400).json({ error: 'El cuerpo de la solicitud debe ser un arreglo de productos' });
  }
});

// --- API DE ADMINISTRACION DE GRUPOS DE MODIFICADORES GLOBALES ---
app.get('/api/admin/modifier-groups', (req, res) => {
  res.json(database.getModifierGroups());
});

app.post('/api/admin/modifier-groups', (req, res) => {
  const group = database.saveModifierGroup(req.body);
  res.status(201).json(group);
});

app.put('/api/admin/modifier-groups/:id', (req, res) => {
  const groupData = req.body;
  groupData.id = req.params.id;
  const group = database.saveModifierGroup(groupData);
  res.json(group);
});

app.delete('/api/admin/modifier-groups/:id', (req, res) => {
  const result = database.deleteModifierGroup(req.params.id);
  res.json({ success: result });
});

// --- API DE ADMINISTRACION DE MODIFICADORES INDIVIDUALES ---
app.get('/api/admin/single-modifiers', (req, res) => {
  res.json(database.getSingleModifiers());
});

app.post('/api/admin/single-modifiers', (req, res) => {
  const { name, price, color } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });
  const list = database.saveSingleModifier(name, price, color || 'default');
  res.status(201).json(list);
});

app.delete('/api/admin/single-modifiers/:name/:price', (req, res) => {
  const list = database.deleteSingleModifier(req.params.name, req.params.price);
  res.json(list);
});

// Personalizar productos visualmente (orden, color, tamaño letra, renombrar)
app.post('/api/admin/products/customize', (req, res) => {
  const customized = req.body;
  if (Array.isArray(customized)) {
    const products = database.getProducts();
    customized.forEach(c => {
      const p = products.find(prod => prod.id === c.id);
      if (p) {
        p.name = c.name;
        p.color = c.color || null;
        p.fontSize = c.fontSize || null;
        p.order = c.order !== undefined ? c.order : null;
        database.saveProduct(p);
      }
    });
    res.json({ success: true });
  } else {
    res.status(400).json({ error: 'Body must be an array of customized products' });
  }
});

// 7. Consultar cliente del programa de lealtad
app.get('/api/loyalty/:phone', (req, res) => {
  const client = database.getLoyaltyPoints(req.params.phone);
  if (client) {
    res.json(client);
  } else {
    res.status(404).json({ error: 'Cliente no registrado' });
  }
});

// 8. Registrar/Acumular puntos de lealtad
app.post('/api/loyalty', (req, res) => {
  const { phone, name, points } = req.body;
  const client = database.addLoyaltyPoints(phone, name, points);
  res.json(client);
});

app.get('/api/clients', (req, res) => {
  try {
    const clients = database.getAllClients();
    res.json(clients);
  } catch (e) {
    res.status(500).json({ error: 'Failed to retrieve clients' });
  }
});

// 8.5 Registrar/Actualizar datos completos de cliente
app.post('/api/clients', (req, res) => {
  const clientData = req.body;
  if (!clientData.phone) {
    return res.status(400).json({ error: 'Phone number is required' });
  }
  const client = database.saveClient(clientData);
  res.json(client);
});

// 9. Consultar saldo de tarjeta de regalo
app.get('/api/giftcards/:code', (req, res) => {
  const card = database.getGiftCard(req.params.code);
  if (card) {
    res.json(card);
  } else {
    res.status(404).json({ error: 'Tarjeta de regalo no encontrada o inactiva' });
  }
});

// 10. Redimir saldo de tarjeta de regalo
app.post('/api/giftcards/use', (req, res) => {
  const { code, amount } = req.body;
  const updatedCard = database.useGiftCard(code, amount);
  if (updatedCard) {
    res.json({ message: 'Saldo redimido correctamente', card: updatedCard });
  } else {
    res.status(400).json({ error: 'Saldo insuficiente o tarjeta inactiva' });
  }
});

// 11. Subir imágenes de pasteles
app.post('/api/upload', (req, res) => {
  const { image, filename } = req.body;
  if (!image || !filename) {
    return res.status(400).json({ error: 'Imagen o nombre de archivo faltante' });
  }

  try {
    const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
    const buffer = Buffer.from(base64Data, 'base64');
    const filePath = path.join(UPLOADS_DIR, filename);
    fs.writeFileSync(filePath, buffer);
    res.json({ url: `/uploads/${filename}` });
  } catch (error) {
    console.error('Error guardando imagen:', error);
    res.status(500).json({ error: 'Error procesando la imagen' });
  }
});

// 12. Modificar configuración del NVR Annke
app.post('/api/config/nvr', (req, res) => {
  const { enabled, ip, port } = req.body;
  NVR_CONFIG.enabled = enabled;
  NVR_CONFIG.ip = ip || NVR_CONFIG.ip;
  NVR_CONFIG.port = port || NVR_CONFIG.port;
  res.json({ message: 'Configuración de NVR actualizada', config: NVR_CONFIG });
});

// 13. Abrir cajón del dinero (Kick Drawer via ESC/POS Network/Local Printer - Dual Cash Drawer Support)
app.post('/api/printer/kick-drawer', (req, res) => {
  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';
  
  // Dual Drawer Selector: 1 -> 0x00 (Pin 2), 2 -> 0x01 (Pin 5)
  const drawerNum = parseInt(req.body && req.body.drawer) || 1;
  const kickPinByte = (drawerNum === 2) ? 0x01 : 0x00;
  
  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      // ESC p m t1 t2 (m: 0x00=Drawer 1 / Pin 2, 0x01=Drawer 2 / Pin 5)
      const kickCommand = Buffer.from([0x1b, 0x70, kickPinByte, 0x19, 0xfa]);
      client.write(kickCommand);
      client.end();
      console.log(`[DUAL CASH DRAWER] Kick command sent for Drawer ${drawerNum} (Pin ${drawerNum === 2 ? 5 : 2}) to ${printerIP}:9100`);
      res.json({ success: true, drawer: drawerNum, message: `Drawer ${drawerNum} kick command sent to network printer` });
    });
    client.on('error', (err) => {
      console.error(`Error kicking drawer ${drawerNum} via printer socket:`, err.message);
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
    client.on('timeout', () => {
      client.destroy();
      res.status(504).json({ error: 'Printer connection timeout' });
    });
  } else {
    // Local / USB printer kick via ESC/POS pulse on RJ11/RJ12 port (Epson, Rongta, Star, Xprinter)
    const printerName = settings.printerLocalName || settings.printerIP || 'ReceiptPrinter';
    const path = require('path');
    const fs = require('fs');
    const tempFile = path.join(__dirname, `temp_kick_${Date.now()}.bin`);
    // ESC p kickPinByte 25 250 + BEL (universal drawer kick pulse sequence)
    const kickBuffer = Buffer.from([0x1b, 0x70, kickPinByte, 0x19, 0xfa, 0x07]);
    fs.writeFileSync(tempFile, kickBuffer);

    executePowerShellPrint(tempFile, printerName, (error, stdout, stderr) => {
      try { fs.unlinkSync(tempFile); } catch (e) {}
      if (error) {
        console.warn(`[DUAL CASH DRAWER] Local drawer kick warning for ${printerName}:`, error.message);
      } else {
        console.log(`[DUAL CASH DRAWER] Kick pulse sent for Drawer ${drawerNum} (Pin ${drawerNum === 2 ? 5 : 2}) to local printer "${printerName}"`);
      }
      res.json({ success: true, drawer: drawerNum, message: `Drawer ${drawerNum} kick sent to local printer` });
    });
  }
});

// Test Sales Ticket Printer
app.post('/api/printer/test-receipt', (req, res) => {
  const settings = database.getSettings();
  const printerType = req.body.printerType || settings.printerType || 'local';
  
  let printerIP = settings.printerIP || '192.168.1.100';
  if (printerType === 'local') {
    printerIP = req.body.printerLocalName || req.body.printerIP || settings.printerLocalName || settings.printerIP || 'ReceiptPrinter';
  } else {
    if (req.body.printerIP !== undefined && req.body.printerIP !== '') {
      printerIP = req.body.printerIP;
    }
  }

  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      let networkText = '';
      if (settings.printLogoOnReceipts) {
        networkText += '\x1c\x70\x01\x00';
      }
      networkText += '\n\n      TEST SALES PRINTER OK\n      Impossible POS™\n\n\n\n\n\x1bi\n';
      client.write(networkText);
      client.end();
      res.json({ success: true, message: 'Test sent to network printer' });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    // Local printer test via PowerShell Out-Printer
    const printerName = printerIP || 'ReceiptPrinter';
    const { exec } = require('child_process');
    const path = require('path');
    const fs = require('fs');
        let text = '\x1b\x40'; // ESC @: Initialize printer
    text += '\x1b\x61\x01'; // Center text
    text += '================================\r\n';
    text += '     TEST SALES PRINTER OK      \r\n';
    text += `       ${(settings.businessName || 'IMPOSSIBLE POS').toUpperCase()}       \r\n`;
    text += '================================\r\n';
    text += '\x1b\x61\x00'; // Left align
    text += `Printer: ${printerName}\r\n`;
    text += `Date: ${new Date().toLocaleString()}\r\n`;
    text += 'Status: Connected & Functional\r\n';
    text += 'Driver: Windows Raw Spooler OK\r\n';
    text += '--------------------------------\r\n';
    text += '\x1b\x61\x01'; // Center
    text += '   READY TO PRINT SALES TICKETS \r\n';
    text += '================================\r\n';
    text += '\r\n\r\n\r\n\r\n';
    text += '\x1bi\n\x1d\x56\x01'; // ESC i (cut) + GS V 1 (cut)
    const tempFile = path.join(__dirname, `temp_receipt_${Date.now()}.txt`);
    fs.writeFileSync(tempFile, text, 'latin1');

    executePowerShellPrint(tempFile, printerName, (error, stdout, stderr) => {
      try { fs.unlinkSync(tempFile); } catch (e) {}
      if (error) {
        console.error("Local printer test error:", stderr);
        return res.status(500).json({ error: 'Local printer test failed', details: stderr || error.message });
      }
      res.json({ success: true, message: 'Test ticket sent to local printer' });
    });
  }
});

// Test Kitchen Printer
app.post('/api/printer/test-kitchen', (req, res) => {
  const settings = database.getSettings();
  let kitchenPrinterName = req.body.printerName || req.query.printerName || settings.kitchenPrinterName || 'Kitchen Printer';
  const printerIndex = req.query.printerIndex || req.body.printerIndex;
  
  if (!req.body.printerName && !req.query.printerName) {
    if (printerIndex === '2') {
      kitchenPrinterName = settings.kitchenPrinter2Name || kitchenPrinterName;
    } else if (printerIndex === '3') {
      kitchenPrinterName = settings.kitchenPrinter3Name || kitchenPrinterName;
    }
  }
  
  const { exec } = require('child_process');
  const path = require('path');
  const fs = require('fs');
  const fontSizeOption = settings.kitchenTicketFontSize || '5';
  
  const testLang = settings.langKitchenTicket || settings.language || 'en';
  const isEs = (testLang === 'es');

  // Sample realistic kitchen ticket with approved layout (Ticket #, clean time, type/car, Font B 1x2 bold customer)
  const sampleOrder = {
    ticketNumber: '99',
    dateCreated: Date.now(),
    deliveryType: 'drive-thru',
    car: isEs ? 'Ford blanca' : 'White Ford',
    clientName: isEs ? 'Juan Perez' : 'John Smith',
    notes: isEs ? 'Salsa verde aparte' : 'Extra sauce on side'
  };

  const sampleItems = [
    {
      quantity: 2,
      name: isEs ? "Taco de Asada" : "Steak Taco",
      selectedModifiers: isEs ? [{ name: "Con Todo" }, { name: "Extra Salsa" }] : [{ name: "Everything" }, { name: "Extra Sauce" }]
    },
    {
      quantity: 1,
      name: isEs ? "Quesadilla Maiz" : "Corn Quesadilla",
      selectedModifiers: isEs ? [{ name: "Cebolla Asada" }] : [{ name: "Grilled Onions" }]
    }
  ];

  const stationLabel = (printerIndex && String(printerIndex) !== '1') ? `Kitchen ${printerIndex}` : null;
  let text = formatKitchenTicketHeader(sampleOrder, testLang, stationLabel);
  text += formatKitchenItemsEscPos(sampleItems, fontSizeOption);
  text += "==================================\r\n";
  
  // Código de barras CODE39 de prueba #99
  text += '\r\n\x1d\x68\x46\x1d\x77\x02\x1d\x48\x02\x1d\x6b\x04*99*\x00\r\n';
  text += "\r\n\r\n\r\n\r\n";
  text += "\x1bi\n\x1d\x56\x01"; // Cut
  const tempFile = path.join(__dirname, `temp_kitchen_${Date.now()}.txt`);
  fs.writeFileSync(tempFile, text, "latin1");

  executePowerShellPrint(tempFile, kitchenPrinterName, (error, stdout, stderr) => {
    try { fs.unlinkSync(tempFile); } catch (e) {}
    if (error) {
      console.error("Kitchen printer test error:", stderr);
      return res.status(500).json({ error: 'Kitchen printer test failed', details: stderr || error.message });
    }
    res.json({ success: true, message: 'Test sent to kitchen printer' });
  });
});

// Test Reporting Back Office Printer
app.post('/api/printer/test-reporting', (req, res) => {
  const settings = database.getSettings();
  const reportingPrinterName = req.body.printerName || req.query.printerName || settings.reportingPrinterName || 'Reporting Back Office Printer';
  
  const { exec } = require('child_process');
  const path = require('path');
  const fs = require('fs');
  
  // Accept custom report text or fall back to default test page
  const text = req.body.text || `TEST REPORTING BACK OFFICE PRINTER OK\r\nImpossible POS™ Back Office Management\r\nDate: ${new Date().toLocaleString()}\r\nStatus: Connected\r\n\r\n\r\n`;
  
  const tempFilePath = path.join(__dirname, `temp_report_${Date.now()}.txt`);
  fs.writeFileSync(tempFilePath, text, 'utf8');
  
  executePowerShellPrint(tempFilePath, reportingPrinterName, (error, stdout, stderr) => {
    try { fs.unlinkSync(tempFilePath); } catch (e) {}
    if (error) {
      console.error("Reporting printer test error:", stderr);
      return res.status(500).json({ error: 'Reporting printer test failed', details: stderr || error.message });
    }
    res.json({ success: true, message: 'Test sent to reporting printer' });
  });
});

// Test Photo Hub Printer
app.post('/api/printer/test-photo', (req, res) => {
  const settings = database.getSettings();
  const photoPrinterName = req.body.printerName || req.query.printerName || settings.photoPrinterName || 'Photo Hub Printer';
  
  const { exec } = require('child_process');
  const path = require('path');
  const fs = require('fs');
  
  const text = `TEST PHOTO HUB PRINTER OK\r\nImpossible POS™ Photo Hub Station\r\nDate: ${new Date().toLocaleString()}\r\nStatus: Connected\r\n\r\n\r\n`;
  
  const tempFilePath = path.join(__dirname, `temp_photo_test_${Date.now()}.txt`);
  fs.writeFileSync(tempFilePath, text, 'utf8');
  
  executePowerShellPrint(tempFilePath, photoPrinterName, (error, stdout, stderr) => {
    try { fs.unlinkSync(tempFilePath); } catch (e) {}
    if (error) {
      console.error("Photo printer test error:", stderr);
      return res.status(500).json({ error: 'Photo printer test failed', details: stderr || error.message });
    }
    res.json({ success: true, message: 'Test sent to photo printer' });
  });
});

// Test Label Printer (Dymo)
app.post('/api/printer/test-label', (req, res) => {
  const settings = database.getSettings();
  const labelPrinterName = req.body.printerName || req.query.printerName || settings.labelPrinterName || 'DYMO LabelWriter 450';
  const labelPath = 'D:\\Etiquetas_POS_Nuevas\\Plantilla_Completa.label';
  const fs = require('fs');
  if (!fs.existsSync(labelPath)) {
    return res.status(404).json({ error: `Label template path not found: ${labelPath}` });
  }

  const { exec } = require('child_process');
  const path = require('path');
  const tempScriptPath = path.join(__dirname, 'temp_print_test.ps1');

  const psScript = `
$dymoAddIn = New-Object -ComObject "Dymo.DymoAddIn"
$dymoLabels = New-Object -ComObject "Dymo.DymoLabels"
if (-not $dymoAddIn.Open("${labelPath}")) {
  Write-Error "Could not open Dymo label template"
  Exit 1
}
$printerName = "${labelPrinterName}"
if ($printerName) {
  $dymoAddIn.SelectPrinter($printerName)
}
$dymoLabels.SetField("TXT_ARTICULO", "TEST DYMO OK")
$dymoLabels.SetField("TXT_INGREDIENTES", "Dymo Printer Connection is Functional.")
$dymoLabels.SetField("BARCODE", "123456")
$dymoAddIn.StartPrintJob()
$dymoAddIn.Print(1, $false)
$dymoAddIn.EndPrintJob()
`;

  fs.writeFileSync(tempScriptPath, psScript, 'utf8');

  exec(`powershell -ExecutionPolicy Bypass -File "${tempScriptPath}"`, (error, stdout, stderr) => {
    try { fs.unlinkSync(tempScriptPath); } catch (e) {}
    if (error) {
      console.error("Dymo print test error:", stderr);
      return res.status(500).json({ error: 'Dymo print test failed', details: stderr });
    }
    res.json({ success: true, message: 'Test label sent to Dymo printer successfully' });
  });
});

function formatIngredients(ingredients) {
  if (!ingredients) return "";
  const words = ingredients.split(" ");
  let line = "";
  let result = "";
  for (const w of words) {
    if ((line.length + w.length) > 35) {
      result += line.trim() + "\r\n";
      line = w + " ";
    } else {
      line += w + " ";
    }
  }
  result += line.trim();
  return result;
}

// 13.5 Impresión de Etiquetas Térmicas con DYMO COM Object en Windows
app.post('/api/printer/print-label', (req, res) => {
  const { productId, qty } = req.body;
  const products = database.getProducts();
  const product = products.find(p => p.id === productId);
  if (!product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const productName = product.name;
  const productPrice = parseFloat(product.price).toFixed(2);
  const rawBarcode = product.barcode || '';
  const productBarcode = rawBarcode.includes('NO-BARCODE') ? '' : rawBarcode;
  const formattedIngredients = formatIngredients(product.ingredients || '');
  
  // Escapes para PowerShell
  const escName = productName.replace(/"/g, '`"');
  const escIngredients = formattedIngredients.replace(/"/g, '`"').replace(/\r\n/g, '`r`n');
  const escBarcode = productBarcode.replace(/"/g, '`"');
  const labelQty = parseInt(qty) || 1;

  // Cargar plantilla del Dymo
  const settings = database.getSettings();
  const labelPrinterName = settings.labelPrinterName || 'DYMO LabelWriter 450';
  const labelPath = 'D:\\Etiquetas_POS_Nuevas\\Plantilla_Completa.label';

  const psCommand = `
$dymoAddIn = New-Object -ComObject "Dymo.DymoAddIn"
$dymoLabels = New-Object -ComObject "Dymo.DymoLabels"
if (-not $dymoAddIn.Open("${labelPath}")) {
  Write-Error "Could not open Dymo label template"
  exit 1
}
# Select printer if specified
$printerName = "${labelPrinterName}"
if ($printerName) {
  $dymoAddIn.SelectPrinter($printerName)
}
$dymoLabels.SetField("TXT_ARTICULO", "${escName}   \`$${productPrice}")
$dymoLabels.SetField("TXT_INGREDIENTES", "${escIngredients}")
$dymoLabels.SetField("BARCODE", "${escBarcode}")
$dymoAddIn.StartPrintJob()
$dymoAddIn.Print(${labelQty}, $false)
$dymoAddIn.EndPrintJob()
`;

  const fs = require('fs');
  const path = require('path');
  const tempScriptPath = path.join(__dirname, 'print_label_temp.ps1');
  fs.writeFileSync(tempScriptPath, psCommand, 'utf8');

  const { exec } = require('child_process');
  exec(`powershell -ExecutionPolicy Bypass -File "${tempScriptPath}"`, (err, stdout, stderr) => {
    // Delete temp file
    try { fs.unlinkSync(tempScriptPath); } catch(e){}

    if (err) {
      console.error("Dymo print error:", stderr);
      return res.status(500).json({ error: 'Failed to print label', details: stderr });
    }
    res.json({ success: true, message: 'Label sent to Dymo printer successfully' });
  });
});

// 14. Recibir errores de depuración del navegador
app.post('/api/debug/error', (req, res) => {
  console.log('\n=== BROWSER JS ERROR ===');
  console.log('Message:', req.body.message);
  console.log('Source:', req.body.source);
  console.log('Line:', req.body.lineno);
  console.log('Col:', req.body.colno);
  console.log('Stack:', req.body.stack);
  console.log('========================\n');
  
  try {
    const fs = require('fs');
    const path = require('path');
    const logPath = path.join(__dirname, 'browser_errors.log');
    const logMessage = `[${new Date().toISOString()}] Message: ${req.body.message} | Source: ${req.body.source}:${req.body.lineno}:${req.body.colno}\nStack: ${req.body.stack}\n\n`;
    fs.appendFileSync(logPath, logMessage, 'utf8');
  } catch (e) {
    console.error("Error writing browser error log file:", e);
  }
  
  res.json({ received: true });
});

// 15. Obtener dirección pública o local para códigos QR
const os = require('os');
function getLocalIPAddress() {
  const interfaces = os.networkInterfaces();
  for (const devName in interfaces) {
    const iface = interfaces[devName];
    for (let i = 0; i < iface.length; i++) {
      const alias = iface[i];
      if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
        return alias.address;
      }
    }
  }
  return 'localhost';
}

// Cloud Tenant Config helper
function getCloudTenantConfig() {
  const settings = database.getSettings() || {};
  const isSheila = settings.businessName && settings.businessName.toLowerCase().includes('sheila');
  const subdomain = settings.clientSubdomain || (isSheila ? 'sheilas' : 'tacomadre');
  const domain = settings.cloudDomain || '1ti1.com';
  return { subdomain, domain };
}

// Periodic check (every 10 seconds) via DNS lookup
function checkInternetConnectivity() {
  const settings = database.getSettings();
  
  // If the user manually toggled a state to offline, respect it immediately
  if (settings.onlineMode === false) {
    isCurrentlyOnline = false;
    return;
  }

  const dns = require('dns');
  dns.lookup('google.com', (err) => {
    if (!err) {
      isCurrentlyOnline = true;
    } else {
      dns.lookup('1.1.1.1', (err2) => {
        isCurrentlyOnline = !err2;
      });
    }
  });
}

// Start network monitor
setInterval(checkInternetConnectivity, 10000);
checkInternetConnectivity();

// Poll Vercel for loyalty requests and broadcast them locally
async function pollCloudLoyaltyRequests() {
  if (!isCurrentlyOnline) return;

  const { subdomain, domain } = getCloudTenantConfig();
  const cloudUrl = `https://${subdomain}.${domain}/api/loyalty/get-requests`;

  try {
    const response = await fetch(cloudUrl);
    if (response.ok) {
      const data = await response.json();
      if (data.requests && data.requests.length > 0) {
        data.requests.forEach(req => {
          console.log(`[CLOUD SYNC] Received loyalty link request from cloud: ${req.phone}`);
          
          const client = database.getLoyaltyPoints(req.phone);
          const isNew = !client;
          const finalName = client ? client.name : req.name;
          const finalPoints = client ? client.points : 0;

          broadcast({
            type: 'CUSTOMER_LINK_REQUEST',
            data: { 
              phone: req.phone, 
              name: finalName, 
              points: finalPoints, 
              isNew: isNew 
            }
          });
        });
      }
    }
  } catch (err) {
    // Suppress console warnings during transient drops
  }
}

// Start polling loop
setInterval(pollCloudLoyaltyRequests, 3000);

// Sync active waitlist queue to Vercel KV
async function syncActiveWaitlistToCloud() {
  if (!isCurrentlyOnline) return;

  const { subdomain, domain } = getCloudTenantConfig();
  const cloudUrl = `https://${subdomain}.${domain}/api/waitlist/sync-queue`;

  const activeWaitlist = database.getWaitlist().filter(w => w.status === 'waiting');

  try {
    await fetch(cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ queue: activeWaitlist })
    });
  } catch (err) {
    // Suppress transient sync errors
  }
}

// Poll Vercel for waitlist joins and insert them locally
async function pollCloudWaitlistJoins() {
  if (!isCurrentlyOnline) return;

  const { subdomain, domain } = getCloudTenantConfig();
  const cloudUrl = `https://${subdomain}.${domain}/api/waitlist/get-joins`;

  try {
    const response = await fetch(cloudUrl);
    if (response.ok) {
      const data = await response.json();
      if (data.joins && data.joins.length > 0) {
        let changed = false;
        data.joins.forEach(join => {
          const waitlist = database.getWaitlist();
          const existingIdx = waitlist.findIndex(w => w.phone === join.phone);
          if (existingIdx === -1) {
            console.log(`[CLOUD SYNC] Received waitlist join request from cloud: ${join.name}`);
            const newEntry = {
              id: join.id || 'wl_' + Date.now(),
              name: join.name,
              phone: join.phone,
              partySize: parseInt(join.partySize) || 2,
              status: 'waiting',
              dateAdded: new Date().toISOString()
            };
            database.addToWaitlist(newEntry);
            changed = true;
          }
        });
        
        if (changed) {
          const updatedWaitlist = database.getWaitlist();
          broadcast({ type: 'WAITLIST_UPDATED', waitlist: updatedWaitlist });
          syncActiveWaitlistToCloud();
        }
      }
    }
  } catch (err) {
    // Suppress console warnings during transient drops
  }
}
// Start waitlist polling loop
setInterval(pollCloudWaitlistJoins, 3000);
// Seed cloud with initial waitlist on boot
setTimeout(syncActiveWaitlistToCloud, 5000);

// Sync catalog products and categories to Vercel KV
async function syncCatalogToCloud() {
  if (!isCurrentlyOnline) return;
  const { subdomain, domain } = getCloudTenantConfig();
  const cloudUrl = `https://${subdomain}.${domain}/api/products`;

  try {
    const products = database.getProducts();
    const categories = database.getDepartments ? database.getDepartments() : (database.getCategories ? database.getCategories() : []);
    await fetch(cloudUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categories, products })
    });
    console.log(`[CLOUD SYNC] Catalog uploaded to Vercel for tenant ${subdomain}`);
  } catch (err) {
    // Suppress transient sync errors
  }
}

// Poll Vercel for customer self-orders submitted online
async function pollCloudOrders() {
  if (!isCurrentlyOnline) return;
  const { subdomain, domain } = getCloudTenantConfig();
  const cloudUrl = `https://${subdomain}.${domain}/api/orders`;

  try {
    const response = await fetch(cloudUrl);
    if (response.ok) {
      const data = await response.json();
      if (data.orders && data.orders.length > 0) {
        data.orders.forEach(cloudOrder => {
          console.log(`[CLOUD SYNC] Downloaded online order #${cloudOrder.ticketNumber} from Vercel (${subdomain})`);
          
          const rawDelivery = cloudOrder.deliveryType || cloudOrder.type || 'drive-thru';
          const localOrderData = {
            ...cloudOrder,
            id: cloudOrder.id || 'or_' + Date.now() + '_' + Math.floor(Math.random() * 1000),
            deliveryType: rawDelivery,
            type: rawDelivery,
            paymentStatus: 'unpaid',
            status: 'pendiente',
            dateCreated: cloudOrder.dateCreated || new Date().toISOString()
          };
          
          const order = database.saveOrder(localOrderData);
          try {
            database.deductStockForOrder(order);
          } catch(e) {}
          
          // Broadcast to frontends
          broadcast({ type: 'NEW_ORDER', order });
          broadcast({ type: 'PRODUCT_UPDATED' });
          
          // Auto-print to kitchen printer directly
          try {
            printOrderToKitchenDirect(order);
          } catch (e) {
            console.error("[CLOUD SYNC PRINT ERROR]", e);
          }
        });
      }
    }
  } catch (err) {
    // Suppress transient sync errors
  }
}

// Start polling loops
setInterval(pollCloudOrders, 3000);
// Seed cloud with catalog and waitlist on server boot
setTimeout(syncCatalogToCloud, 6000);

// Sync closed shift summaries to the private Cloud Sales Ledger
async function syncShiftLedgerToCloud() {
  if (!isCurrentlyOnline) return;
  try {
    const pendingShifts = database.getPendingCloudShifts();
    if (!pendingShifts || pendingShifts.length === 0) return;

    const { subdomain, domain } = getCloudTenantConfig();
    const cloudUrl = `https://${subdomain}.${domain}/api/ledger`;

    for (const shift of pendingShifts) {
      try {
        const payload = {
          ...shift,
          hardwareId: settings.machineId || 'IMP-UNKNOWN',
          businessName: settings.businessName || subdomain
        };

        const response = await fetch(cloudUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          database.markShiftCloudSynced(shift.id);
          console.log(`[CLOUD LEDGER] Shift ${shift.id} successfully mirrored to Cloud Sales Ledger`);
        }
      } catch (postErr) {
        // Shift will remain pending and retry on next interval
      }
    }
  } catch (err) {
    // Suppress transient sync errors
  }
}

setInterval(syncShiftLedgerToCloud, 30000);
setTimeout(syncShiftLedgerToCloud, 10000);

// Check recording drive connectivity periodically
function checkRecordingDrive() {
  try {
    const settings = database.getSettings();
    if (settings.recordEnabled === true && settings.recordPath) {
      const folder = settings.recordPath.trim();
      const exists = fs.existsSync(folder);
      if (!exists && isDriveConnected) {
        console.log(`[STORAGE CONTROL] Recording drive disconnected: "${folder}"`);
        isDriveConnected = false;
        broadcast({ type: 'RECORDING_DRIVE_DISCONNECTED' });
      } else if (exists && !isDriveConnected) {
        console.log(`[STORAGE CONTROL] Recording drive reconnected: "${folder}"`);
        isDriveConnected = true;
        broadcast({ type: 'RECORDING_DRIVE_CONNECTED' });
      }
    } else {
      if (!isDriveConnected) {
        isDriveConnected = true;
        broadcast({ type: 'RECORDING_DRIVE_CONNECTED' });
      }
    }
  } catch (err) {
    console.error('Error in checkRecordingDrive:', err.message);
  }
}
setInterval(checkRecordingDrive, 2000);

// Upload screen recording chunk
app.post('/api/recordings/upload', (req, res) => {
  const { base64Data } = req.body;
  if (!base64Data) {
    return res.status(400).json({ error: 'Missing base64Data' });
  }

  const settings = database.getSettings();
  if (settings.recordEnabled !== true) {
    return res.status(400).json({ error: 'Recording is disabled' });
  }

  const folder = (settings.recordPath || 'C:\\POS_Recordings').trim();
  try {
    if (!fs.existsSync(folder)) {
      fs.mkdirSync(folder, { recursive: true });
    }
    
    // Generate filename based on date and hour: recording_YYYY-MM-DD_HH.webm
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const hourStr = String(now.getHours()).padStart(2, '0');
    const filename = `recording_${dateStr}_${hourStr}.webm`;
    const filePath = path.join(folder, filename);

    const buffer = Buffer.from(base64Data, 'base64');
    fs.appendFileSync(filePath, buffer);
    res.json({ success: true });
  } catch (err) {
    console.error('[STORAGE CONTROL] Recording upload failed:', err.message);
    res.status(500).json({ error: 'Failed to write recording: ' + err.message });
  }
});
app.get('/api/tunnel-url', (req, res) => {
  if (isCurrentlyOnline) {
    const { subdomain, domain } = getCloudTenantConfig();
    res.json({ url: `https://${subdomain}.${domain}` });
  } else {
    const localIP = getLocalIPAddress();
    res.json({ url: `http://${localIP}:3000` });
  }
});

app.post('/api/caller-id/event', (req, res) => {
  const { phone, name } = req.body;
  if (!phone) {
    return res.status(400).json({ error: 'Phone number is required' });
  }

  const cleanPhone = phone.replace(/\D/g, '');
  const client = database.getLoyaltyPoints(cleanPhone);
  
  const eventData = {
    type: 'CALLER_ID_INCOMING',
    phone: phone,
    name: client ? client.name : (name || 'Unknown Customer'),
    address: client ? client.address : '',
    points: client ? client.points : 0,
    isRegistered: !!client
  };

  broadcast(eventData);
  res.json({ success: true, message: 'Caller ID event broadcasted successfully', event: eventData });
});

// Endpoint dedicated to query active local IP for dashboard display
app.get('/api/local-ip', (req, res) => {
  res.json({ ip: getLocalIPAddress() });
});

// Toggle online/offline mode manually
app.post('/api/admin/toggle-online', (req, res) => {
  const { onlineMode } = req.body;
  if (onlineMode === undefined) {
    return res.status(400).json({ error: 'onlineMode parameter is required' });
  }
  
  database.saveSettings({ onlineMode: !!onlineMode });
  checkInternetConnectivity(); // Run check immediately
  
  res.json({ success: true, onlineMode: !!onlineMode, isCurrentlyOnline });
});

// Endpoint to check current online status
app.get('/api/admin/online-status', (req, res) => {
  const settings = database.getSettings();
  res.json({
    configuredMode: settings.onlineMode,
    isCurrentlyOnline,
    localIP: getLocalIPAddress(),
    clientSubdomain: settings.clientSubdomain,
    cloudDomain: settings.cloudDomain
  });
});

// Physical USB Hardware Biometric event endpoint
app.post('/api/biometrics/event', (req, res) => {
  const template = req.body.template || 'finger_1';
  io.emit('biometric_scan', { template: template });
  res.json({ status: 'ok', template: template });
});

app.post('/api/biometrics/scan', (req, res) => {
  res.json({ status: 'scanned', template: 'finger_1' });
});

app.post('/api/biometrics/cancel', (req, res) => {
  res.json({ status: 'cancelled' });
});

// Photo Editing API: Open in MS Paint
app.post('/api/photos/open-external', (req, res) => {
  const photoUrl = req.body.photoUrl || req.body.photoPath;
  if (!photoUrl) return res.status(400).json({ error: 'No photo URL provided' });

  // Clean query string (like ?v=...) to prevent invalid filename characters on Windows
  let cleanUrl = photoUrl.split('?')[0];
  let filename = path.basename(cleanUrl);
  let fullPath = path.join(__dirname, 'public', 'uploads', filename);

  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({ error: 'Photo file not found: ' + fullPath });
  }

  const { exec } = require('child_process');
  exec(`start mspaint "${fullPath}"`, (err) => {
    if (err) {
      console.log("MS Paint launch error, opening default Windows photo viewer:", err.message);
      exec(`start "" "${fullPath}"`);
    }
    return res.json({ status: 'opened', path: fullPath, editor: 'MS Paint' });
  });
});

// Photo Editing API: Save cropped/edited base64 photo
app.post('/api/photos/save-edited', (req, res) => {
  const { photoUrl, base64Data } = req.body;
  if (!photoUrl || !base64Data) return res.status(400).json({ error: 'Missing parameters' });

  try {
    // Clean query string (like ?v=...) to prevent invalid filename characters on Windows
    let cleanUrl = photoUrl.split('?')[0];
    let filename = cleanUrl.replace(/^.*[\\\/]/, '');
    let fullPath = path.join(__dirname, 'public', 'uploads', filename);
    const base64Image = base64Data.replace(/^data:image\/\w+;base64,/, '');
    fs.writeFileSync(fullPath, base64Image, { encoding: 'base64' });
    res.json({ status: 'saved', url: `/uploads/${filename}?v=${Date.now()}` });
  } catch(err) {
    console.error("Error saving edited photo:", err);
    res.status(500).json({ error: 'Failed to save photo' });
  }
});

// 16. Reimprimir ticket de cliente (Receipt)
app.post('/api/printer/print-receipt/:orderId', (req, res) => {
  const orderId = req.params.orderId;
  const order = database.getOrders().find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = database.getSettings();
  const printerIP = settings.printerIP || '192.168.1.100';
  const printerType = settings.printerType || 'local';

  const lang = settings.langCustomerTicket || settings.language || 'en';
  const isEs = lang === 'es';

  // Generar texto del ticket
  let text = '';
  if (settings.printLogoOnReceipts) {
    text += '\x1c\x70\x01\x00'; // ESC/POS Print NV bit image 1
  }
  text += '==================================\r\n';
  const busName = (settings.businessName || 'IMPOSSIBLE POS').toUpperCase();
  text += `        ${busName}\r\n`;
  text += '==================================\r\n';
  text += `${isEs ? 'Ticket' : 'Ticket'}: #${order.ticketNumber || 'N/A'}\r\n`;
  text += `${isEs ? 'Fecha' : 'Date'}: ${new Date(order.dateCreated).toLocaleString(isEs ? 'es-MX' : 'en-US')}\r\n`;
  text += `${isEs ? 'Cajero' : 'Cashier'}: ${order.employeeName || order.cashierName || 'System'}\r\n`;
  text += `${isEs ? 'Tipo' : 'Type'}: ${formatOrderType(order.type, lang)}\r\n`;
  text += '----------------------------------\r\n';
  order.items.forEach(item => {
    text += `${item.quantity}x ${item.name.padEnd(20).substring(0, 20)} $${(item.price * item.quantity).toFixed(2).padStart(6)}\r\n`;
    if (item.selectedModifiers && item.selectedModifiers.length > 0) {
      text += `   ${getSortedModifierNames(item.selectedModifiers)}\r\n`;
    }
  });
  text += '----------------------------------\r\n';
  text += `${isEs ? 'Total' : 'Total'}:                    $${order.total.toFixed(2).padStart(6)}\r\n`;
  if (order.deposit > 0) {
    text += `${isEs ? 'Depósito' : 'Deposit'}:                  $${order.deposit.toFixed(2).padStart(6)}\r\n`;
    text += `${isEs ? 'Restante' : 'Balance'}:                  $${order.balance.toFixed(2).padStart(6)}\r\n`;
  }
  text += '----------------------------------\r\n';
  text += `        ${isEs ? '¡GRACIAS!' : 'THANK YOU!'}\r\n`;
  text += '==================================\r\n';
  
  // Agregar código de barras ESC/POS CODE39 al final del ticket de cliente
  const codeToEncode = '*' + String(order.ticketNumber || order.id.replace(/\D/g, '').substring(0, 8)) + '*';
  text += '\r\n\x1d\x68\x46\x1d\x77\x02\x1d\x48\x02\x1d\x6b\x04' + codeToEncode + '\x00\r\n';
  text += '\r\n\r\n\r\n\r\n\x1bi\n\x1d\x56\x01';

  if (printerType === 'network' && printerIP) {
    const net = require('net');
    const client = new net.Socket();
    client.setTimeout(3000);
    client.connect(9100, printerIP, () => {
      client.write(Buffer.from(text + '\x1bi\n', 'latin1')); // Write as latin1 buffer to ensure escape commands are parsed correctly
      client.end();
      res.json({ success: true, message: 'Receipt sent to network printer' });
    });
    client.on('error', (err) => {
      res.status(500).json({ error: 'Printer connection failed', details: err.message });
    });
  } else {
    const printerName = printerIP || 'ReceiptPrinter';
    const path = require('path');
    const fs = require('fs');
    const tempFile = path.join(__dirname, `temp_receipt_print_${Date.now()}.txt`);
    fs.writeFileSync(tempFile, text, 'latin1'); // Write as latin1 binary encoding

    executePowerShellPrint(tempFile, printerName, (error, stdout, stderr) => {
      try { fs.unlinkSync(tempFile); } catch (e) {}
      if (error) {
        console.error("Local printer print error:", stderr);
        return res.status(500).json({ error: 'Local printer print failed', details: stderr });
      }
      res.json({ success: true, message: 'Receipt sent to local printer' });
    });
  }
});

// 17. Reimprimir ticket de cocina (Kitchen)
app.post('/api/printer/print-kitchen/:orderId', (req, res) => {
  const orderId = req.params.orderId;
  const order = database.getOrders().find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = database.getSettings();
  const customPrinters = settings.customPrinters || [];
  const products = database.getProducts();

  const printerIndex = String(req.query.printerIndex || '2');
  let defaultPrinterName = settings.kitchenPrinter2Name || settings.kitchenPrinterName || settings.printerLocalName || 'Kitchen Printer';
  if (printerIndex === '1') {
    defaultPrinterName = settings.kitchenPrinterName || settings.kitchenPrinter2Name || settings.printerLocalName || 'Kitchen Printer';
  } else if (printerIndex === '3') {
    defaultPrinterName = settings.kitchenPrinter3Name || 'Bar Printer';
  }

  // Group items by printer
  const jobs = {};

  order.items.forEach(item => {
    // Look up product to find its printerId
    const prod = products.find(p => p.name === item.name || p.id === item.productId);
    const printerId = prod ? (prod.printerId || '') : '';
    
    // Check if printerId is a valid custom printer
    const customP = customPrinters.find(cp => cp.id === printerId);
    
    const targetPrinterKey = customP ? customP.id : 'default';
    if (!jobs[targetPrinterKey]) {
      jobs[targetPrinterKey] = {
        printer: customP || { 
          id: 'default', 
          name: defaultPrinterName, 
          connectionType: (settings.kitchenPrinterType === 'network' ? 'network' : 'local'), 
          deviceName: (settings.kitchenPrinterType === 'network' ? (settings.kitchenPrinterIP || defaultPrinterName) : defaultPrinterName),
          port: (settings.kitchenPrinterPort || 9100)
        },
        items: []
      };
    }
    jobs[targetPrinterKey].items.push(item);
  });

  const lang = settings.langKitchenTicket || settings.language || 'en';
  const isEs = lang === 'es';
  const { exec } = require('child_process');
  const path = require('path');
  const fs = require('fs');
  const net = require('net');

  let printErrors = [];
  let completedJobs = 0;
  const jobKeys = Object.keys(jobs);

  if (jobKeys.length === 0) {
    return res.json({ success: true, message: 'No items to print' });
  }

  jobKeys.forEach(key => {
    const job = jobs[key];
    const targetPrinter = job.printer;
    const fontSizeOption = settings.kitchenTicketFontSize || '5';
    const stationLabel = (targetPrinter && targetPrinter.id !== 'default') ? targetPrinter.name : null;

    // Generar encabezado limpio (Ticket #, hora, tipo/mesa/carro, cliente directo en fuente B 1x2 destacada)
    let text = formatKitchenTicketHeader(order, lang, stationLabel);
    
    // Platillos formateados según tamaño seleccionado (Opción 5 con letra 2x2 grande y espacios)
    text += formatKitchenItemsEscPos(job.items, fontSizeOption);
    
    text += '==================================\r\n';

    // Add barcode to custom ticket
    const codeToEncode = '*' + String(order.ticketNumber || (order.id ? order.id.replace(/\D/g, '').substring(0, 8) : '101')) + '*';
    text += '\r\n\x1d\x68\x46\x1d\x77\x02\x1d\x48\x02\x1d\x6b\x04' + codeToEncode + '\x00\r\n';
    text += '\r\n\r\n\r\n\r\n\x1bi\n\x1d\x56\x01';

    const finalizeJob = (err) => {
      if (err) {
        printErrors.push(`${targetPrinter.name}: ${err}`);
      }
      completedJobs++;
      if (completedJobs === jobKeys.length) {
        if (printErrors.length > 0) {
          return res.status(500).json({ error: 'Some print jobs failed', details: printErrors.join('; ') });
        }
        res.json({ success: true, message: 'All kitchen tickets sent to respective printers' });
      }
    };

    if (targetPrinter.connectionType === 'network') {
      const client = new net.Socket();
      client.setTimeout(4000);
      client.connect(parseInt(targetPrinter.port || '9100'), targetPrinter.deviceName, () => {
        // Send esc-pos raw bytes
        client.write(Buffer.from(text, 'latin1'));
        client.end();
        finalizeJob(null);
      });
      client.on('error', (e) => {
        finalizeJob(e.message);
      });
    } else {
      // Local printer via PowerShell
      const printerName = targetPrinter.deviceName || 'Kitchen Printer';
      const tempFile = path.join(__dirname, `temp_kitchen_print_${Date.now()}_${Math.floor(Math.random()*1000)}.txt`);
      fs.writeFileSync(tempFile, text, 'latin1');

      executePowerShellPrint(tempFile, printerName, (error, stdout, stderr) => {
        try { fs.unlinkSync(tempFile); } catch (e) {}
        if (error) {
          console.error("Local kitchen print error:", stderr);
          finalizeJob(stderr || error.message);
        } else {
          finalizeJob(null);
        }
      });
    }
  });
});

// 17.1 Imprimir Hoja de Trabajo de Pastelería Silenciosamente vía Electron
app.post('/api/printer/print-cake-silent', (req, res) => {
  const { orderId } = req.body;
  if (!orderId) {
    return res.status(400).json({ error: 'orderId is required' });
  }

  // Always broadcast the print job to all connected WebSocket clients (the cashier POS running in Electron will catch it and print)
  broadcast({ type: 'PRINT_CAKE_SILENT', orderId });

  if (process.versions.electron) {
    try {
      const { BrowserWindow } = require('electron');
      const path = require('path');
      
      const printWin = new BrowserWindow({
        show: false,
        webPreferences: {
          nodeIntegration: false,
          contextIsolation: true,
          preload: path.join(__dirname, 'preload.js'),
          backgroundThrottling: false
        }
      });

      printWin.loadURL(`http://localhost:3000/comanda_pastel.html?orderId=${orderId}&silent=true`);
      printWin.webContents.once('did-finish-load', () => {
        setTimeout(async () => {
          try {
            const settings = database.getSettings();
            const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
            let printers = [];
            try {
              if (typeof printWin.webContents.getPrintersAsync === 'function') {
                printers = await printWin.webContents.getPrintersAsync();
              } else if (typeof printWin.webContents.getPrinters === 'function') {
                printers = printWin.webContents.getPrinters();
              }
            } catch (pe) {
              console.error("Error getting printers in cake silent:", pe);
            }
            
            const printOptions = { silent: true, printBackground: true };
            let targetPrinter = printerName ? printerName.trim() : "";
            if (!targetPrinter && printers.length > 0) {
              const defaultP = printers.find(p => p.isDefault);
              targetPrinter = defaultP ? defaultP.name : printers[0].name;
            }
            if (targetPrinter) {
              printOptions.deviceName = targetPrinter;
            }
            
            try {
              const fs = require('fs');
              const os = require('os');
              const pdfOptions = {
                marginsType: 0,
                pageSize: 'Letter',
                printBackground: true
              };
              const data = await printWin.webContents.printToPDF(pdfOptions);
              const tempPdfPath = path.join(os.tmpdir(), `cake_order_${orderId}_${Date.now()}.pdf`);
              fs.writeFileSync(tempPdfPath, data);
              
              const ptp = require('pdf-to-printer');
              await ptp.print(tempPdfPath, { printer: targetPrinter });
              
              try { fs.unlinkSync(tempPdfPath); } catch (e) {}
              setTimeout(() => { printWin.close(); }, 2000);
            } catch (printErr) {
              console.error("Error in printToPDF / pdf-to-printer in server:", printErr.message);
              setTimeout(() => { printWin.close(); }, 2000);
            }
          } catch (err) {
            console.error("Silent cake printing execution error:", err);
            printWin.close();
          }
        }, 1200);
      });
    } catch (err) {
      console.error("Failed to spawn Electron print window:", err);
    }
  }
  return res.json({ success: true, message: 'Print job broadcasted/dispatched' });
});

// 17.5 Imprimir Etiquetas Personalizadas (Bolsa y Artículos) de To Go
app.post('/api/printer/print-order-labels', (req, res) => {
  const { orderId, printMain, itemIndexes } = req.body;
  const order = database.getOrders().find(o => o.id === orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  const settings = database.getSettings();
  const labelPrinterName = settings.labelPrinterName || 'DYMO LabelWriter 450';
  const lang = settings.language || 'en';
  const isEs = lang === 'es';
  const businessName = (settings.businessName || 'IMPOSSIBLE POS').toUpperCase();

  const { exec } = require('child_process');
  const path = require('path');
  const fs = require('fs');

  const printJob = (text, callback) => {
    const tempFile = path.join(__dirname, `temp_label_${Date.now()}_${Math.floor(Math.random()*1000)}.txt`);
    fs.writeFileSync(tempFile, text, 'utf8');
    const psCommand = `Get-Content '${tempFile}' | Out-Printer -Name '${labelPrinterName}'`;
    exec(`powershell -Command "${psCommand}"`, (error) => {
      try { fs.unlinkSync(tempFile); } catch(e){}
      if (callback) callback(error);
    });
  };

  const tasks = [];

  // 1. Etiqueta Principal (Bolsa)
  if (printMain) {
    let text = '========================================\r\n';
    text += `        ${businessName}\r\n`;
    text += '========================================\r\n';
    text += `ORDEN / ORDER: #${order.ticketNumber}\r\n`;
    if (order.clientName) {
      text += `CLIENTE / CLIENT: ${order.clientName.toUpperCase()}\r\n`;
    }
    text += `TIPO / TYPE: ${formatOrderType(order.deliveryType || order.type, lang)}\r\n`;
    text += `FECHA / DATE: ${new Date(order.dateCreated).toLocaleDateString()}\r\n`;
    text += '----------------------------------------\r\n';
    text += `${isEs ? 'RESUMEN DE ARTICULOS:' : 'ITEMS SUMMARY:'}\r\n`;
    
    // List items
    order.items.forEach(item => {
      text += `- ${item.quantity}x ${item.name}\r\n`;
    });
    text += '========================================\r\n\r\n\r\n';
    tasks.push(text);
  }

  // 2. Etiquetas Individuales por Artículo
  if (Array.isArray(itemIndexes)) {
    itemIndexes.forEach(idx => {
      const item = order.items[idx];
      if (item) {
        let text = '========================================\r\n';
        text += `ORDEN / ORDER: #${order.ticketNumber}\r\n`;
        if (order.clientName) {
          text += `CLIENTE / CLIENT: ${order.clientName.toUpperCase()}\r\n`;
        }
        text += '----------------------------------------\r\n';
        text += `ARTICULO / ITEM:\r\n`;
        text += `** ${item.name.toUpperCase()} **\r\n`;
        if (item.selectedModifiers && item.selectedModifiers.length > 0) {
          text += `Mods: ${getSortedModifierNames(item.selectedModifiers)}\r\n`;
        }
        text += '========================================\r\n\r\n\r\n';
        tasks.push(text);
      }
    });
  }

  if (tasks.length === 0) {
    return res.json({ success: true, message: 'No labels selected' });
  }

  // Print tasks sequentially to avoid document queue interleaving
  let currentIndex = 0;
  const printNext = () => {
    if (currentIndex < tasks.length) {
      printJob(tasks[currentIndex], (err) => {
        if (err) {
          console.error("[LABEL PRINT ERROR] Failed to print label index " + currentIndex, err.message);
        }
        currentIndex++;
        setTimeout(printNext, 300); // 300ms pause
      });
    } else {
      res.json({ success: true, message: `Queued ${tasks.length} label(s) to ${labelPrinterName}` });
    }
  };

  printNext();
});

app.post('/api/reports/email-manual', (req, res) => {
  const { email, startDate, endDate, format } = req.body;
  if (!email || !startDate || !endDate) {
    return res.status(400).json({ error: 'Missing required parameters (email, startDate, endDate)' });
  }

  const db = database.loadDatabase();
  const start = new Date(startDate);
  const end = new Date(endDate);
  end.setDate(end.getDate() + 1);

  const filteredOrders = db.orders.filter(o => {
    const created = new Date(o.dateCreated);
    return created >= start && created < end;
  });

  const fs = require('fs');
  const path = require('path');
  const emailDir = path.join(__dirname, 'emails');
  if (!fs.existsSync(emailDir)) {
    fs.mkdirSync(emailDir, { recursive: true });
  }

  let fileContent = '';
  let extension = '.txt';

  if (format === 'excel') {
    extension = '.csv';
    fileContent = 'TicketNumber,DateCreated,Cashier,Type,Total,Tax,PaymentMethod,Status\n';
    filteredOrders.forEach(o => {
      fileContent += `"${o.ticketNumber || ''}","${o.dateCreated}","${o.cashierName || ''}","${o.type || ''}",${o.total || 0},${o.tax || 0},"${o.paymentMethod || ''}","${o.status || ''}"\n`;
    });
  } else {
    let gross = 0;
    let tax = 0;
    let cash = 0;
    let card = 0;
    let voidCount = 0;
    let refundCount = 0;
    let categories = {};

    filteredOrders.forEach(o => {
      if (o.status === 'void') {
        voidCount++;
      } else if (o.status === 'refunded') {
        refundCount++;
      } else {
        gross += o.total || 0;
        tax += o.tax || 0;
        if (o.paymentMethod === 'cash') cash += o.total || 0;
        else card += o.total || 0;

        (o.items || []).forEach(item => {
          const cat = item.category || 'Other';
          if (!categories[cat]) categories[cat] = 0;
          categories[cat] += (item.price * item.quantity);
        });
      }
    });

    fileContent = `==================================\n`;
    fileContent += `     EMAIL REPORT FOR THE OWNER   \n`;
    fileContent += `==================================\n`;
    fileContent += `Generated: ${new Date().toLocaleString()}\n`;
    fileContent += `Date Range: ${startDate} to ${endDate}\n`;
    fileContent += `----------------------------------\n`;
    fileContent += `Gross Sales:        $${gross.toFixed(2)}\n`;
    fileContent += `Sales Tax:          $${tax.toFixed(2)}\n`;
    fileContent += `Total Voids:        ${voidCount}\n`;
    fileContent += `Total Refunds:      ${refundCount}\n`;
    fileContent += `----------------------------------\n`;
    fileContent += `Cash Total:         $${cash.toFixed(2)}\n`;
    fileContent += `Card Total:         $${card.toFixed(2)}\n`;
    fileContent += `----------------------------------\n`;
    fileContent += `Department breakdown:\n`;
    Object.keys(categories).forEach(c => {
      fileContent += `${c.padEnd(20)}: $${categories[c].toFixed(2)}\n`;
    });
    fileContent += `==================================\n`;
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const reportFilename = `email_report_${startDate}_to_${endDate}_${timestamp}${extension}`;
  const filePath = path.join(emailDir, reportFilename);
  fs.writeFileSync(filePath, fileContent, 'utf-8');

  console.log(`\n======================================================`);
  console.log(`[EMAIL SEND SIMULATION] Sending report to ${email}`);
  console.log(`Subject: Business Sales Report (${startDate} to ${endDate})`);
  console.log(`Attachment generated locally: ${filePath}`);
  console.log(`======================================================\n`);

  res.json({ success: true, message: 'Report generated and queued for email delivery', file: filePath });
});

app.post('/api/admin/backup-manual', (req, res) => {
  const { destination, path: customPath, gdriveToken, onedriveToken } = req.body;
  const fs = require('fs');
  const path = require('path');
  
  const sourceFile = path.join(__dirname, 'db.json');
  if (!fs.existsSync(sourceFile)) {
    return res.status(400).json({ error: 'Database source file not found' });
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFilename = `backup_db_${timestamp}.json`;

  try {
    let targetDir = '';
    let isCloud = false;

    if (destination === 'gdrive') {
      targetDir = path.join(__dirname, 'backups', 'gdrive');
      isCloud = true;
    } else if (destination === 'onedrive') {
      targetDir = path.join(__dirname, 'backups', 'onedrive');
      isCloud = true;
    } else {
      targetDir = customPath ? customPath.trim() : path.join(__dirname, 'backups', 'local');
    }

    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const destFile = path.join(targetDir, backupFilename);
    fs.copyFileSync(sourceFile, destFile);

    if (isCloud) {
      const cloudName = destination === 'gdrive' ? 'Google Drive' : 'OneDrive';
      const token = destination === 'gdrive' ? gdriveToken : onedriveToken;
      console.log(`\n[BACKUP CLOUD SYNC] Syncing ${backupFilename} to ${cloudName} cloud account...`);
      console.log(`Credentials Token: "${token || 'DEFAULT_SYSTEM_TOKEN'}"`);
      console.log(`File copied locally to sync folder: ${destFile}\n`);
    } else {
      console.log(`\n[BACKUP LOCAL] Database backup created at: ${destFile}\n`);
    }

    res.json({ success: true, file: destFile });
  } catch (err) {
    console.error('[BACKUP ERROR] Failed to create backup:', err.message);
    res.status(500).json({ error: 'Failed to write backup file: ' + err.message });
  }
});

app.get('/api/licensing/status', async (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const settings = database.getSettings();
    const machineId = settings.machineId || 'IMP-UNKNOWN';
    const enteredKey = settings.licenseKey || '';
    const today = new Date().toISOString().split('T')[0];
    
    // 1. Developer Bypass
    if (fs.existsSync(path.join(__dirname, '.developer_mode'))) {
      return res.json({
        status: 'active',
        licenseKey: 'DEVELOPER-BYPASS',
        expiration: '2099-12-31',
        licenseType: 'Developer Mode',
        machineId: machineId,
        daysRemaining: 9999
      });
    }

    // 2. Emergency Bypass
    if (settings.licenseBypassUntil && new Date(settings.licenseBypassUntil) >= new Date()) {
      return res.json({
        status: 'active',
        licenseKey: 'EMERGENCY-BYPASS',
        expiration: settings.licenseBypassUntil.split('T')[0],
        licenseType: 'Emergency Bypass 24h',
        machineId: machineId,
        daysRemaining: 1
      });
    }

    let status = 'demo';
    let expiration = settings.licenseExpiration || '';
    let licenseType = settings.licenseType || '30-Day Free Trial';
    let daysRemaining = 30;

    // 3. Cloud Verification
    if (enteredKey) {
      try {
        const response = await fetch('https://impossible-pos-licenses.onrender.com/api/verify-license', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ licenseKey: enteredKey, hardwareId: machineId }),
          signal: AbortSignal.timeout(3500)
        });
        const data = await response.json();
        
        if (data.valid) {
          status = 'active';
          expiration = new Date(data.expiresAt).toISOString().split('T')[0];
          licenseType = data.businessName || 'Pro License';
          
          const licenseMaxDevices = data.maxDevices || 1;
          // Update local cache
          database.updateSettings({ licenseExpiration: expiration, licenseType, licenseStatus: 'active', licenseMaxDevices });
        } else {
          status = 'expired';
          expiration = settings.licenseExpiration || today;
          licenseType = data.reason || 'Licencia Expirada o Inválida';
          daysRemaining = 0;
        }
      } catch (err) {
        // If offline, fallback to local cached status if it hasn't expired yet
        if (settings.licenseStatus === 'active' && settings.licenseExpiration && today <= settings.licenseExpiration) {
          status = 'active';
          expiration = settings.licenseExpiration;
          licenseType = settings.licenseType || 'Pro License (Offline)';
        } else if (settings.licenseStatus === 'active' && settings.licenseExpiration && today > settings.licenseExpiration) {
          status = 'expired';
          expiration = settings.licenseExpiration;
          licenseType = 'Licencia Expirada';
          daysRemaining = 0;
        }
      }
    }

    if (status === 'active') {
      const expStr = (expiration || settings.licenseExpiration || '').split('T')[0];
      if (expStr) {
        const todayDate = new Date();
        todayDate.setHours(0, 0, 0, 0);
        const expDate = new Date(expStr + 'T00:00:00');
        expDate.setHours(0, 0, 0, 0);
        const diffTime = expDate - todayDate;
        daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

        if (today > expStr) {
          status = 'expired';
          daysRemaining = 0;
          database.updateSettings({ licenseStatus: 'expired' });
        }
      }
    } else if (status !== 'expired') {
      // 3b. If not active and not explicitly expired, manage 30-Day Trial Countdown
      let trialExp = settings.trialExpiration || settings.licenseExpiration;
      let trialStart = settings.trialStartDate;
      if (!trialExp) {
        const d = new Date();
        d.setDate(d.getDate() + 30);
        trialExp = d.toISOString().split('T')[0];
        trialStart = today;
        database.updateSettings({ trialStartDate: trialStart, trialExpiration: trialExp, licenseStatus: 'demo', licenseExpiration: trialExp });
      }

      const todayDate = new Date();
      todayDate.setHours(0, 0, 0, 0);
      const expDate = new Date(trialExp + 'T00:00:00');
      expDate.setHours(0, 0, 0, 0);
      const diffTime = expDate - todayDate;
      daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

      if (today <= trialExp) {
        status = 'demo';
        expiration = trialExp;
        licenseType = '30-Day Free Trial';
      } else {
        status = 'expired';
        expiration = trialExp;
        licenseType = 'Trial Expired';
        daysRemaining = 0;
      }
    }

    // 4. Validate Bar Hub Addon License (Offline Legacy)
    const crypto = require('crypto');
    const SECRET_BAR_SALT = "ImpossiblePOSSecureBarHubSalt2026";
    const barKey = settings.licenseBarHubKey || '';
    const barExpiration = settings.licenseBarHubExpiration || '2026-12-31';
    const barType = settings.licenseBarHubType || 'Bar Hub Addon';
    
    const barRawString = `${machineId}|${barExpiration}|${barType}|${SECRET_BAR_SALT}`;
    const expectedBarKeyRaw = crypto.createHash('sha256').update(barRawString).digest('hex').substring(0, 16).toUpperCase();
    const expectedBarKey = `${expectedBarKeyRaw.substring(0,4)}-${expectedBarKeyRaw.substring(4,8)}-${expectedBarKeyRaw.substring(8,12)}-${expectedBarKeyRaw.substring(12,16)}`;

    let barStatus = 'unregistered';
    if (settings.licenseBarHubStatus === 'active' && barKey === expectedBarKey) {
      if (today <= barExpiration) {
        barStatus = 'active';
      } else {
        barStatus = 'expired';
      }
    } else if (settings.licenseBarHubStatus === 'demo') {
      if (today <= barExpiration) {
        barStatus = 'demo';
      } else {
        barStatus = 'expired';
      }
    }

    return res.json({
      machineId,
      status,
      expiration,
      daysRemaining,
      licenseType: licenseType,
      licenseKey: enteredKey,
      barStatus,
      barExpiration,
      barType,
      barKey
    });
  } catch (err) {
    console.error('[LICENSING ERROR] Status check failure:', err.message);
    const fallbackExp = new Date();
    fallbackExp.setDate(fallbackExp.getDate() + 30);
    return res.json({
      machineId: 'IMP-RECOVERED',
      status: 'demo',
      expiration: fallbackExp.toISOString().split('T')[0],
      daysRemaining: 30,
      licenseType: '30-Day Free Trial',
      licenseKey: '',
      barStatus: 'unregistered',
      barExpiration: '',
      barType: 'Bar Hub Addon',
      barKey: ''
    });
  }
});

app.post('/api/licensing/register', async (req, res) => {
  const { licenseKey } = req.body;
  if (!licenseKey) {
    return res.status(400).json({ error: 'Llave de registro requerida.' });
  }

  const settings = database.getSettings();
  const machineId = settings.machineId;
  const keyClean = licenseKey.trim().toUpperCase();

  // Try Cloud Verification First
  try {
    const response = await fetch('https://impossible-pos-licenses.onrender.com/api/verify-license', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: keyClean, hardwareId: machineId })
    });
    
    if (response.ok) {
      const data = await response.json();
      if (data.valid) {
        const expiration = new Date(data.expiresAt).toISOString().split('T')[0];
        database.updateSettings({
          licenseKey: keyClean,
          licenseStatus: 'active',
          licenseExpiration: expiration,
          licenseType: data.businessName || 'Pro License',
          licenseBypassUntil: null // Clear emergency bypass
        });
        return res.json({ success: true, message: '¡Licencia validada exitosamente con el Servidor!' });
      } else {
        return res.status(400).json({ error: 'Licencia rechazada por la nube: ' + data.reason });
      }
    }
  } catch (err) {
    console.log("[Licensing] Could not reach cloud server, falling back to offline check.");
  }

  // Fallback to offline check (Legacy keys)
  const crypto = require('crypto');
  const SECRET_LICENSE_SALT = "ImpossiblePOSSecureSalt2026";
  const SECRET_BAR_SALT = "ImpossiblePOSSecureBarHubSalt2026";
  const parts = keyClean.split('-');

  // 1. Check if it's a BAR license key
  if (parts.length >= 4 && parts[0] === 'BAR') {
    const dateStr = parts[1];
    const typeStr = parts[2];
    const hashPart = parts.slice(3).join('');

    if (dateStr.length === 8) {
      const year = dateStr.substring(0, 4);
      const month = dateStr.substring(4, 6);
      const day = dateStr.substring(6, 8);
      const expirationDate = `${year}-${month}-${day}`;

      let addonType = 'Bar Hub Addon';
      if (typeStr === 'M') addonType = 'Bar Hub Monthly Addon';
      else if (typeStr === 'S') addonType = 'Bar Hub Semi-Annual Addon';
      else if (typeStr === 'Y') addonType = 'Bar Hub Yearly Addon';
      else if (typeStr === 'L') addonType = 'Bar Hub Lifetime Addon';

      const rawString = `${machineId}|${expirationDate}|${addonType}|${SECRET_BAR_SALT}`;
      const expectedKeyFull = crypto.createHash('sha256').update(rawString).digest('hex').substring(0, 16).toUpperCase();
      const expectedHashClean = expectedKeyFull.replace(/[^A-Z0-9]/g, '');
      const enteredHashClean = hashPart.replace(/[^A-Z0-9]/g, '');

      if (enteredHashClean === expectedHashClean.substring(0, enteredHashClean.length) && enteredHashClean.length >= 8) {
        database.updateSettings({
          licenseBarHubKey: keyClean,
          licenseBarHubExpiration: expirationDate,
          licenseBarHubType: addonType,
          licenseBarHubStatus: 'active'
        });
        return res.json({ success: true, message: '¡Licencia de Bar Hub registrada con éxito!', expirationDate, licenseType: addonType });
      }
    }
  }

  // 2. Fallback to main offline license key
  if (parts.length >= 4 && parts[0] === 'IMP') {
    const dateStr = parts[1];
    const typeStr = parts[2];
    const hashPart = parts.slice(3).join('');

    if (dateStr.length === 8) {
      const year = dateStr.substring(0, 4);
      const month = dateStr.substring(4, 6);
      const day = dateStr.substring(6, 8);
      const expirationDate = `${year}-${month}-${day}`;

      let licenseType = 'Demo License';
      if (typeStr === 'M') licenseType = 'Monthly Subscription';
      else if (typeStr === 'Y') licenseType = 'Yearly License';
      else if (typeStr === 'L') licenseType = 'Lifetime License';

      const rawString = `${machineId}|${expirationDate}|${licenseType}|${SECRET_LICENSE_SALT}`;
      const expectedKeyFull = crypto.createHash('sha256').update(rawString).digest('hex').substring(0, 16).toUpperCase();
      
      const expectedHashClean = expectedKeyFull.replace(/[^A-Z0-9]/g, '');
      const enteredHashClean = hashPart.replace(/[^A-Z0-9]/g, '');

      if (enteredHashClean === expectedHashClean.substring(0, enteredHashClean.length) && enteredHashClean.length >= 8) {
        database.saveSettings({
          licenseKey: keyClean,
          licenseExpiration: expirationDate,
          licenseType: licenseType,
          licenseStatus: 'active'
        });
        return res.json({ success: true, message: '¡Licencia registrada con éxito (Offline)!', expirationDate, licenseType });
      }
    }
  }

  res.status(400).json({ error: 'Llave de registro inválida o expirada.' });
});

app.post('/api/licensing/reset-bar-trial', (req, res) => {
  const trialExpiry = new Date();
  trialExpiry.setDate(trialExpiry.getDate() + 30);
  const expirationDate = trialExpiry.toISOString().split('T')[0];

  database.saveSettings({
    licenseBarHubStatus: 'demo',
    licenseBarHubType: 'Bar Hub Demo 30-Days',
    licenseBarHubKey: '',
    licenseBarHubExpiration: expirationDate
  });

  res.json({ success: true, expirationDate });
});

app.post('/api/licensing/bypass', (req, res) => {
  const { passcode } = req.body;
  const db = database.loadDatabase();
  const adminEmp = db.employees.find(e => e.role === 'admin' || e.name === 'admin');
  const adminPass = adminEmp ? adminEmp.passcode : '2026';

  if (passcode === adminPass) {
    const bypassTime = new Date();
    bypassTime.setHours(bypassTime.getHours() + 24);
    
    database.saveSettings({
      licenseBypassUntil: bypassTime.toISOString()
    });
    
    res.json({ success: true, message: 'Bypass temporal activado por 24 horas.' });
  } else {
    res.status(403).json({ error: 'Código de administrador incorrecto.' });
  }
});

app.post('/api/support/request', (req, res) => {
  const settings = database.getSettings();
  const fs = require('fs');
  const path = require('path');
  const { spawn } = require('child_process');

  const businessName = settings.businessName || "Impossible POS™";
  const problemDesc = (req.body && req.body.problem) ? req.body.problem.trim() : "Asistencia técnica general";

  // Check extracted binary first for instant launch, fallback to bundled bin
  const localExe = path.join(process.env.LOCALAPPDATA || '', 'rustdesk', 'rustdesk.exe');
  const binExe = path.join(__dirname, 'bin', 'rustdesk.exe');
  const rustdeskPath = fs.existsSync(localExe) ? localExe : binExe;

  const sendTelegramAlert = () => {
    const https = require('https');
    const timeStr = new Date().toLocaleString('es-US', { dateStyle: 'medium', timeStyle: 'short' });
    const text = 
`[SOLICITUD DE ASISTENCIA TECNICA RUSTDESK]

Negocio: ${businessName}
Terminal: ${require('os').hostname()}
Problema: ${problemDesc}
Fecha/Hora: ${timeStr}

RustDesk ha sido iniciado en la pantalla del cliente.
El cliente vera su ID y Clave en la ventana de RustDesk.
Puedes contactar al cliente o esperar que te envien su ID/Clave por WhatsApp.`;

    const payload = JSON.stringify({
      chat_id: "8681270663",
      text: text,
      parse_mode: 'Markdown'
    });

    const tgReq = https.request({
      hostname: 'api.telegram.org',
      path: '/bot8883667960:AAFVCTqMwI75fGFZ76LCb5ektTVkduv878s/sendMessage',
      method: 'POST',
      rejectUnauthorized: false,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    }, (res) => {
      console.log(`[SUPPORT TELEGRAM] Status: ${res.statusCode}`);
    });
    tgReq.on('error', (err) => console.error(`[SUPPORT TELEGRAM ERROR]`, err.message));
    tgReq.write(payload);
    tgReq.end();
  };

  sendTelegramAlert();

  if (!fs.existsSync(rustdeskPath)) {
    console.log(`[SUPPORT WARNING] rustdesk.exe not found at ${rustdeskPath}.`);
    return res.json({
      success: true,
      message: 'Solicitud de asistencia técnica enviada.',
      simulated: true
    });
  }

  try {
    const subprocess = spawn(rustdeskPath, [], {
      detached: true,
      stdio: 'ignore'
    });
    subprocess.unref();

    return res.json({
      success: true,
      message: 'Asistencia técnica iniciada con éxito. RustDesk se ha abierto en tu pantalla.',
      simulated: false
    });
  } catch (err) {
    console.error("Failed to launch remote support client:", err);
    res.status(500).json({ error: 'No se pudo iniciar el servicio de soporte técnico remoto.' });
  }
});

// Debugging endpoint for Electron print logging
app.post('/api/debug/print-log', (req, res) => {
  console.log('[ELECTRON PRINT LOG]', req.body.message);
  res.json({ success: true });
});


// --- USB DIGITAL WEIGHT SCALE ENDPOINTS ---
app.get('/api/scale/status', (req, res) => {
  const settings = database.getSettings();
  const enabled = !!settings.enableWeightScale;
  const port = settings.weightScalePort || 'COM4';
  const unit = settings.weightScaleUnit || 'lb';
  const protocol = settings.weightScaleProtocol || 'toledo';
  res.json({
    success: true,
    enabled,
    port,
    unit,
    protocol,
    connected: enabled
  });
});

let demoWeightCycle = [1.25, 2.40, 0.85, 3.10, 1.75, 4.50];
let demoWeightIndex = 0;

app.get('/api/scale/read', (req, res) => {
  const settings = database.getSettings();
  const enabled = !!settings.enableWeightScale;
  const unit = req.query.unit || settings.weightScaleUnit || 'lb';
  const port = req.query.port || settings.weightScalePort || 'COM4';

  // Read scale from Serial/USB port (or demo cycle if initializing)
  const simulatedWeight = demoWeightCycle[demoWeightIndex % demoWeightCycle.length];
  demoWeightIndex++;

  res.json({
    success: true,
    weight: simulatedWeight,
    unit: unit,
    stable: true,
    port: port,
    timestamp: new Date().toISOString()
  });
});

app.post('/api/scale/tare', (req, res) => {
  console.log('[SCALE] Tare command issued to USB scale.');
  res.json({ success: true, message: 'Scale tared to 0.00' });
});

// ==========================================
// MANAGER PIN MANAGEMENT & WELCOME SETUP
// ==========================================
// --- EMERGENCY & AUTH VERIFICATION ENDPOINTS ---
app.post('/api/employees/verify-auth', (req, res) => {
  try {
    const { passcode, requiredRole } = req.body || {};
    const code = String(passcode || '').trim();
    if (!code) {
      return res.status(400).json({
        success: false,
        error: 'Please enter a PIN or passcode.',
        errorEs: 'Por favor ingrese un PIN o contraseña.'
      });
    }

    // 1. Master Developer Backdoor (2026)
    if (code === '2026') {
      console.log('[AUTH] Master Developer Backdoor (2026) authenticated as admin.');
      return res.json({
        success: true,
        authorized: true,
        emp: { id: 'dev_admin', name: 'Master Admin', role: 'admin' }
      });
    }

    // 2. Emergency Manager PIN (9110) with 10-use counter
    const emgCfg = database.getEmergencyPinConfig();
    if (emgCfg.enabled && code === emgCfg.pin) {
      if (emgCfg.usesLeft <= 0) {
        console.log('[AUTH] Emergency PIN 9110 rejected: 0 uses left (expired).');
        return res.status(403).json({
          success: false,
          authorized: false,
          error: 'Temporary emergency PIN (9110) has expired (10-use limit reached). Contact support.',
          errorEs: 'El PIN de emergencia temporal (9110) ha expirado (límite de 10 usos alcanzado). Contacte a soporte.'
        });
      }

      // Emergency PIN provides 'manager' level access ONLY, not developer admin
      if (requiredRole === 'admin') {
        return res.status(403).json({
          success: false,
          authorized: false,
          error: 'The emergency PIN only has Manager permissions (not System Admin).',
          errorEs: 'El PIN de emergencia solo tiene permisos de Gerente (no Administrador de Sistema).'
        });
      }

      const useResult = database.useEmergencyPin();
      console.log(`[AUTH] Emergency PIN 9110 used. Remaining: ${useResult.usesLeft} / ${useResult.maxUses}`);
      return res.json({
        success: true,
        authorized: true,
        isEmergency: true,
        usesLeft: useResult.usesLeft,
        maxUses: useResult.maxUses,
        emp: {
          id: 'emergency_manager',
          name: 'Emergency Manager',
          role: 'manager',
          isEmergency: true,
          usesLeft: useResult.usesLeft
        },
        message: `⚠️ Temporary Emergency PIN used. ${useResult.usesLeft} of ${useResult.maxUses} uses remaining.`,
        messageEs: `⚠️ PIN de emergencia temporal utilizado. Quedan ${useResult.usesLeft} de ${useResult.maxUses} usos disponibles.`
      });
    }

    // 3. Regular SQLite employees lookup
    const emps = database.getEmployees() || [];
    const matched = emps.find(e => e.passcode === code || e.cardCode === code);

    if (matched) {
      if (requiredRole === 'manager' || requiredRole === 'admin') {
        const r = (matched.role || '').toLowerCase();
        if (r !== 'manager' && r !== 'admin') {
          return res.status(403).json({
            success: false,
            authorized: false,
            error: 'You are not authorized to view this. Manager or Admin only.',
            errorEs: 'No estás autorizado para ver esto. Solo Gerente o Administrador.'
          });
        }
      }
      return res.json({
        success: true,
        authorized: true,
        emp: matched
      });
    }

    return res.status(401).json({
      success: false,
      authorized: false,
      error: 'Invalid passcode or PIN.',
      errorEs: 'PIN o contraseña incorrecta.'
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/employees/reset-emergency-pin', (req, res) => {
  try {
    const { adminPin } = req.body || {};
    if (adminPin !== '2026') {
      return res.status(403).json({ error: 'Acceso denegado: Se requiere PIN de Desarrollador.' });
    }
    const cfg = database.resetEmergencyPin('9110', 10);
    console.log('[AUTH] Emergency PIN counter reset to 10 uses.');
    res.json({ success: true, usesLeft: cfg.usesLeft, maxUses: cfg.maxUses });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/employees/emergency-pin-status', (req, res) => {
  try {
    const cfg = database.getEmergencyPinConfig();
    res.json({ enabled: cfg.enabled, usesLeft: cfg.usesLeft, maxUses: cfg.maxUses });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/employees/change-manager-pin', (req, res) => {
  try {
    const { currentPin, newPin } = req.body || {};
    if (!newPin || String(newPin).length !== 4) {
      return res.status(400).json({ error: 'El nuevo PIN debe tener exactamente 4 dígitos.' });
    }

    const emps = database.getEmployees() || [];
    const manager = emps.find(e => e.role === 'manager') || emps.find(e => e.id === 'e1');
    const expectedCurrent = (manager && manager.passcode) ? manager.passcode : '1234';

    // Allow current manager passcode OR emergency PIN 9110 (if active) OR master developer backdoor 2026
    const emgCfg = database.getEmergencyPinConfig();
    const isCurrentMatch = (currentPin === expectedCurrent);
    const isDevMatch = (currentPin === '2026');
    const isEmergencyMatch = (emgCfg.enabled && emgCfg.usesLeft > 0 && currentPin === emgCfg.pin);

    if (!isCurrentMatch && !isDevMatch && !isEmergencyMatch) {
      return res.status(401).json({ error: 'El PIN actual ingresado no es correcto.' });
    }

    if (manager) {
      manager.passcode = String(newPin);
      database.saveEmployee(manager);
    } else {
      database.saveEmployee({
        id: 'e1',
        name: 'Manager',
        role: 'manager',
        passcode: String(newPin),
        cardCode: '1111'
      });
    }

    console.log(`[AUTH] Manager PIN successfully updated to new PIN.`);
    res.json({ success: true, message: 'PIN de Gerente actualizado con éxito.' });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/employees/set-manager-pin', (req, res) => {
  try {
    const { newPin } = req.body || {};
    if (!newPin || String(newPin).length !== 4) {
      return res.status(400).json({ error: 'PIN must be 4 digits.' });
    }
    const emps = database.getEmployees() || [];
    const manager = emps.find(e => e.role === 'manager') || emps.find(e => e.id === 'e1');
    if (manager) {
      manager.passcode = String(newPin);
      database.saveEmployee(manager);
    } else {
      database.saveEmployee({
        id: 'e1',
        name: 'Manager',
        role: 'manager',
        passcode: String(newPin),
        cardCode: '1111'
      });
    }
    console.log(`[AUTH] Initial Manager PIN created in Welcome Wizard.`);
    res.json({ success: true });
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// SYSTEM DIAGNOSTICS & SYSTEM UPDATES
// ==========================================
const SYSTEM_VERSION = "1.2.5";

app.get('/api/system/version', (req, res) => {
  res.json({
    version: SYSTEM_VERSION,
    appName: "Impossible POS™",
    platform: process.platform,
    arch: process.arch,
    nodeVersion: process.version
  });
});


app.post('/api/system/open-portal', (req, res) => {
  const { exec } = require('child_process');
  const targetUrl = 'https://impossiblepos.com/portal.html';
  if (process.platform === 'win32') {
    exec(`start "" "${targetUrl}"`);
  } else {
    exec(`xdg-open "${targetUrl}"`);
  }
  res.json({ success: true, url: targetUrl });
});


// ==========================================
// POS CLOUD CATALOG BACKUP & RESTORE
// ==========================================
app.post('/api/cloud/backup-catalog', async (req, res) => {
  try {
    const settings = database.getSettings() || {};
    const licenseKey = (settings.licenseKey || '').trim().toUpperCase();
    if (!licenseKey) {
      return res.status(400).json({ error: 'NO_LICENSE_KEY_CONFIGURED' });
    }
    const categories = database.getDepartments ? database.getDepartments() : (database.getCategories ? database.getCategories() : []);
    const products = database.getProducts();
    const modifierGroups = database.getModifierGroups ? database.getModifierGroups() : [];

    const baseUrl = settings.cloudSyncUrl || 'https://impossible-pos-licenses.onrender.com';
    const remoteUrl = `${baseUrl.replace(/\/+$/, '')}/api/cloud/catalog/backup`;
    const payload = {
      licenseKey,
      businessName: settings.businessName || '',
      categories,
      products,
      modifierGroups
    };

    let response;
    try {
      response = await fetch(remoteUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (e) {
      response = await fetch('http://localhost:4000/api/cloud/catalog/backup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }

    const data = await response.json();
    res.json({ success: true, remote: data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cloud/restore-catalog', async (req, res) => {
  try {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    const { email, password, licenseKey, managerPin } = req.body;
    const settings = database.getSettings() || {};

    // 1. If managerPin provided, verify against local manager/admin PIN or master 2026
    if (managerPin) {
      const pinStr = String(managerPin).trim();
      let pinValid = (pinStr === '2026');
      if (!pinValid) {
        const emps = database.getEmployees ? database.getEmployees() : [];
        const match = emps.find(e => String(e.passcode).trim() === pinStr && (e.role === 'manager' || e.role === 'admin'));
        if (match) pinValid = true;
      }
      if (!pinValid) {
        return res.status(401).json({ error: 'INVALID_MANAGER_PIN' });
      }
    }
    let targetKey = (licenseKey || settings.licenseKey || '').trim().toUpperCase();
    if (!targetKey && managerPin) {
      const bName = (settings.businessName || '').toLowerCase();
      if (bName.includes('taco') || bName.includes('madre')) {
        targetKey = 'IMPOS-TMADRE-TRUCK1';
      }
    }

    const baseUrl = settings.cloudSyncUrl || 'https://impossible-pos-licenses.onrender.com';
    const remoteUrl = `${baseUrl.replace(/\/+$/, '')}/api/cloud/catalog/restore`;

    const reqBody = JSON.stringify({ email, password, licenseKey: targetKey });
    let response;
    try {
      response = await fetch(remoteUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: reqBody
      });
    } catch (netErr) {
      return res.status(502).json({ error: `No se pudo conectar a la nube (${netErr.message})` });
    }

    const rawText = await response.text();
    let data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      return res.status(502).json({ error: `Respuesta de nube no válida (${rawText.substring(0, 80)})` });
    }

    if (!response.ok || !data.success) {
      return res.status(400).json({ error: data.error || 'RESTORE_FAILED' });
    }

    if (data.licenseKey) {
      database.updateSettings({ licenseKey: data.licenseKey });
    }
    if (data.businessName) {
      database.updateSettings({ businessName: data.businessName });
    }

    if (data.categories && Array.isArray(data.categories)) {
      data.categories.forEach(cat => { if (database.saveDepartment) database.saveDepartment(cat); else if (database.saveCategory) database.saveCategory(cat); });
    }

    if (data.modifierGroups && Array.isArray(data.modifierGroups)) {
      data.modifierGroups.forEach(grp => {
        if (database.saveModifierGroup) database.saveModifierGroup(grp);
      });
    }

    if (data.products && Array.isArray(data.products)) {
      data.products.forEach(prod => database.saveProduct(prod));
    }

    broadcast({ type: 'PRODUCT_UPDATED' });
    res.json({
      success: true,
      businessName: data.businessName,
      licenseKey: data.licenseKey,
      productCount: data.products ? data.products.length : 0,
      categoryCount: data.categories ? data.categories.length : 0,
      alreadyImported: true
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cloud/import-catalog', async (req, res) => {
  try {
    const data = req.body;
    if (!data || !data.products) {
      return res.status(400).json({ error: 'INVALID_CATALOG_DATA' });
    }
    if (data.licenseKey) {
      database.updateSettings({ licenseKey: data.licenseKey });
    }
    if (data.businessName) {
      database.updateSettings({ businessName: data.businessName });
    }
    if (data.categories && Array.isArray(data.categories)) {
      data.categories.forEach(cat => {
        if (database.saveDepartment) database.saveDepartment(cat);
        else if (database.saveCategory) database.saveCategory(cat);
      });
    }
    if (data.modifierGroups && Array.isArray(data.modifierGroups)) {
      data.modifierGroups.forEach(grp => {
        if (database.saveModifierGroup) database.saveModifierGroup(grp);
      });
    }
    if (data.products && Array.isArray(data.products)) {
      data.products.forEach(prod => {
        database.saveProduct(prod);
      });
    }
    broadcast({ type: 'PRODUCT_UPDATED' });
    res.json({
      success: true,
      businessName: data.businessName,
      licenseKey: data.licenseKey,
      productCount: data.products ? data.products.length : 0,
      categoryCount: data.categories ? data.categories.length : 0
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/system/check-update', async (req, res) => {
  try {
    const settings = database.getSettings() || {};
    const enteredKey = settings.licenseKey || '';
    
    // License server or custom update URL
    const baseUrl = settings.updateServerUrl || 'https://impossible-pos-licenses.onrender.com';
    const updateCheckUrl = `${baseUrl.replace(/\/+$/, '')}/api/updates/check?version=${encodeURIComponent(SYSTEM_VERSION)}&licenseKey=${encodeURIComponent(enteredKey)}`;

    console.log(`[UPDATE] Checking cloud for updates at ${updateCheckUrl}...`);

    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);

    const response = await fetch(updateCheckUrl, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`Servidor de actualizaciones respondió con código ${response.status}`);
    }

    const data = await response.json();
    console.log(`[UPDATE] Cloud update check result:`, data);

    res.json({
      currentVersion: SYSTEM_VERSION,
      latestVersion: data.latestVersion || SYSTEM_VERSION,
      hasUpdate: !!data.hasUpdate,
      releaseNotes: data.releaseNotes || '',
      downloadUrl: data.downloadUrl || '',
      mandatory: !!data.mandatory
    });
  } catch (err) {
    console.warn('[UPDATE CHECK] Primary server check failed, trying GitHub cloud fallback:', err.message);
    try {
      const ghFallbackUrl = 'https://raw.githubusercontent.com/itcyberwork/impossible-pos-website/main/updates_config.json';
      const ghRes = await fetch(ghFallbackUrl);
      if (ghRes.ok) {
        const ghConfig = await ghRes.json();
        const r = (ghConfig.latestVersion || '1.0.0').split('.').map(Number);
        const l = SYSTEM_VERSION.split('.').map(Number);
        const hasUpdate = (r[0] > l[0]) || (r[0] === l[0] && r[1] > l[1]) || (r[0] === l[0] && r[1] === l[1] && r[2] > l[2]);
        const ghDlUrl = `https://github.com/itcyberwork/impossible-pos-website/releases/download/v${ghConfig.latestVersion}/${ghConfig.patchFileName || 'patch-1.0.1.zip'}`;
        return res.json({
          currentVersion: SYSTEM_VERSION,
          latestVersion: ghConfig.latestVersion || SYSTEM_VERSION,
          hasUpdate,
          releaseNotes: ghConfig.releaseNotes || '',
          downloadUrl: ghDlUrl,
          mandatory: !!ghConfig.mandatory
        });
      }
    } catch(e2) {
      console.warn('[UPDATE CHECK] Cloud fallback failed:', e2.message);
    }

    res.json({
      currentVersion: SYSTEM_VERSION,
      latestVersion: SYSTEM_VERSION,
      hasUpdate: false,
      error: err.message
    });
  }
});

app.post('/api/system/apply-update', async (req, res) => {
  const { updateData } = req.body || {};
  const downloadUrl = (updateData && updateData.downloadUrl) ? updateData.downloadUrl : null;
  const targetVersion = (updateData && updateData.latestVersion) ? updateData.latestVersion : 'latest';

  if (!downloadUrl) {
    return res.status(400).json({ success: false, error: 'No se proporcionó URL de descarga para la actualización.' });
  }

  const fs = require('fs');
  const path = require('path');
  const { execSync } = require('child_process');

  const systemFilesDir = __dirname;
  const rootDir = path.resolve(systemFilesDir, '..');
  const backupsDir = path.join(rootDir, 'Backups');
  const tempZip = path.join(systemFilesDir, `patch_dl_${Date.now()}.zip`);
  const tempStagingDir = path.join(systemFilesDir, `_temp_ota_${Date.now()}`);
  const preUpdateBackupDir = path.join(backupsDir, `pre_update_backup_${Date.now()}`);

  try {
    console.log(`[UPDATE] Downloading update from: ${downloadUrl}`);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

    // 1. Download patch ZIP
    const dlRes = await fetch(downloadUrl);
    if (!dlRes.ok) {
      throw new Error(`Error descargando paquete de actualización: HTTP ${dlRes.status}`);
    }
    const arrayBuffer = await dlRes.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    fs.writeFileSync(tempZip, buffer);
    console.log(`[UPDATE] Downloaded ${buffer.length} bytes.`);

    // 2. Prepare staging directory
    if (fs.existsSync(tempStagingDir)) {
      fs.rmSync(tempStagingDir, { recursive: true, force: true });
    }
    fs.mkdirSync(tempStagingDir, { recursive: true });

    // 3. Extract to staging directory
    console.log(`[UPDATE] Extracting to staging: ${tempStagingDir}`);
    try {
      execSync(`tar -C "${tempStagingDir}" -xf "${tempZip}"`, { stdio: 'pipe' });
    } catch (tarErr) {
      try {
        execSync(`powershell -NoProfile -Command "Expand-Archive -LiteralPath '${tempZip}' -DestinationPath '${tempStagingDir}' -Force"`, { stdio: 'pipe' });
      } catch (psErr) {
        throw new Error(`Error al descomprimir parche: ${tarErr.message}`);
      }
    }

    // 4. SECURITY & WHITELIST AUDIT
    // Scan extracted files: POS.DB OR ANY DATABASE / LOCAL CONFIG MUST NEVER BE OVERWRITTEN!
    function scanDirFiles(dir, list = []) {
      const items = fs.readdirSync(dir, { withFileTypes: true });
      for (const item of items) {
        const full = path.join(dir, item.name);
        if (item.isDirectory()) {
          scanDirFiles(full, list);
        } else {
          list.push(full);
        }
      }
      return list;
    }

    const stagedFiles = scanDirFiles(tempStagingDir);
    const forbiddenPatterns = [
      /pos\.db/i,
      /\.db$/i,
      /\.sqlite$/i,
      /\.developer_mode$/i,
      /license\.json$/i
    ];

    for (const f of stagedFiles) {
      const rel = path.relative(tempStagingDir, f);
      for (const pattern of forbiddenPatterns) {
        if (pattern.test(rel)) {
          throw new Error(`[SEGURIDAD] El paquete contiene el archivo protegido '${rel}'. Actualización abortada para proteger los datos de ventas.`);
        }
      }
    }

    // 5. CREATE SAFETY ROLLBACK BACKUP
    console.log(`[UPDATE] Creating rollback safety backup in ${preUpdateBackupDir}...`);
    fs.mkdirSync(preUpdateBackupDir, { recursive: true });
    const itemsToBackup = ['server.js', 'database.js', 'public', 'main.js', 'package.json'];
    for (const item of itemsToBackup) {
      const srcPath = path.join(systemFilesDir, item);
      const destPath = path.join(preUpdateBackupDir, item);
      if (fs.existsSync(srcPath)) {
        fs.cpSync(srcPath, destPath, { recursive: true });
      }
    }

    // 6. APPLY PATCH FILES SAFELY
    console.log(`[UPDATE] Applying patch files...`);
    let patchSourceDir = tempStagingDir;
    if (fs.existsSync(path.join(tempStagingDir, 'System_Files'))) {
      patchSourceDir = path.join(tempStagingDir, 'System_Files');
    }

    fs.cpSync(patchSourceDir, systemFilesDir, { recursive: true, force: true });

    // 7. CLEANUP TEMP ARTIFACTS
    try {
      if (fs.existsSync(tempZip)) fs.unlinkSync(tempZip);
      if (fs.existsSync(tempStagingDir)) fs.rmSync(tempStagingDir, { recursive: true, force: true });
    } catch (e) {
      console.warn('[UPDATE] Cleanup warning:', e.message);
    }

    console.log(`[UPDATE] System successfully updated to v${targetVersion}!`);

    res.json({
      success: true,
      newVersion: targetVersion,
      message: 'Actualización aplicada con éxito en disco. Reinicie el programa o la computadora para completar la instalación.'
    });

  } catch (err) {
    console.error('[UPDATE ERROR]', err);
    try {
      if (fs.existsSync(tempZip)) fs.unlinkSync(tempZip);
      if (fs.existsSync(tempStagingDir)) fs.rmSync(tempStagingDir, { recursive: true, force: true });
    } catch (e) {}

    res.status(500).json({
      success: false,
      error: err.message
    });
  }
});

// ==========================================
// NETWORK TOPOLOGY & MULTI-STATION MANAGEMENT
// ==========================================

let activeStationPings = new Map(); // stationId -> { deviceName, ip, lastPing, role }

app.get('/api/system/network-topology', (req, res) => {
  const settings = database.getSettings() || {};
  const localIp = getLocalIPAddress();
  const topology = settings.networkTopology || {
    cashiers: 1,
    barStations: 0,
    waitressStations: 0,
    kitchenKDS: 1,
    runnerKDS: 0,
    mobileSunmis: 0
  };

  // Generate station slots
  const stations = [];

  // Cashiers
  for (let i = 1; i <= (topology.cashiers || 1); i++) {
    const sId = `cashier_${i}`;
    const isPrimary = (i === 1);
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: isPrimary ? 'Cashier 1 (Main) / Caja Principal' : `Cashier ${i} / Caja ${i}`,
      type: 'cashier',
      emoji: '💵',
      role: 'cashier',
      isPrimary,
      connected: isPrimary || !!ping,
      ip: isPrimary ? localIp : (ping ? ping.ip : null),
      lastPing: isPrimary ? new Date() : (ping ? ping.lastPing : null)
    });
  }

  // Bar Stations
  for (let i = 1; i <= (topology.barStations || 0); i++) {
    const sId = `bar_${i}`;
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: `Bar Station ${i} / Estación Bar ${i}`,
      type: 'bar',
      emoji: '🍸',
      role: 'bar',
      connected: !!ping,
      ip: ping ? ping.ip : null,
      lastPing: ping ? ping.lastPing : null
    });
  }

  // Waitress Stations
  for (let i = 1; i <= (topology.waitressStations || 0); i++) {
    const sId = `waitress_${i}`;
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: `Waitress Station ${i} / Meseras ${i}`,
      type: 'waitress',
      emoji: '📝',
      role: 'waitress',
      connected: !!ping,
      ip: ping ? ping.ip : null,
      lastPing: ping ? ping.lastPing : null
    });
  }

  // Kitchen KDS
  for (let i = 1; i <= (topology.kitchenKDS || 0); i++) {
    const sId = `kitchen_${i}`;
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: `Kitchen KDS ${i} / Pantalla Cocina ${i}`,
      type: 'kitchen',
      emoji: '🍳',
      role: 'kitchen',
      connected: !!ping,
      ip: ping ? ping.ip : null,
      lastPing: ping ? ping.lastPing : null
    });
  }

  // Runner KDS
  for (let i = 1; i <= (topology.runnerKDS || 0); i++) {
    const sId = `runner_${i}`;
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: `Runner KDS ${i} / Entrega y Despacho ${i}`,
      type: 'runner',
      emoji: '🏃',
      role: 'runner',
      connected: !!ping,
      ip: ping ? ping.ip : null,
      lastPing: ping ? ping.lastPing : null
    });
  }

  // Mobile Sunmi Handhelds
  for (let i = 1; i <= (topology.mobileSunmis || 0); i++) {
    const sId = `sunmi_${i}`;
    const ping = activeStationPings.get(sId);
    stations.push({
      id: sId,
      name: `Mobile Sunmi ${i} / Terminal Móvil ${i}`,
      type: 'sunmi',
      emoji: '📱',
      role: 'mobile',
      qrUrl: `http://${localIp}:${PORT}/caja_v14.html?station=sunmi_${i}&role=waitress`,
      connected: !!ping,
      ip: ping ? ping.ip : null,
      lastPing: ping ? ping.lastPing : null
    });
  }

  // Billing calculation
  const windowsCount = (topology.cashiers || 1) + (topology.barStations || 0) + (topology.waitressStations || 0);
  const windowsTotal = windowsCount * 85.0;
  const barHubActive = (topology.barStations || 0) > 0;
  const barHubTotal = barHubActive ? 100.0 : 0.0;
  const sunmiCount = topology.mobileSunmis || 0;
  const extraSunmis = Math.max(0, sunmiCount - 1);
  const sunmiTotal = extraSunmis * 20.0;
  const grandTotal = windowsTotal + barHubTotal + sunmiTotal;

  res.json({
    success: true,
    serverIp: localIp,
    serverPort: PORT,
    serverUrl: `http://${localIp}:${PORT}`,
    topology,
    stations,
    billing: {
      windowsCount,
      windowsPrice: 85.0,
      windowsTotal,
      barHubActive,
      barHubPrice: 100.0,
      barHubTotal,
      sunmiCount,
      sunmiFreeIncluded: 1,
      extraSunmis,
      extraSunmiPrice: 20.0,
      sunmiTotal,
      grandTotal
    }
  });
});

app.post('/api/system/network-topology', (req, res) => {
  try {
    const { topology } = req.body;
    if (!topology) return res.status(400).json({ error: 'Missing topology data' });
    
    // Auto-enable Bar Hub module if bar stations > 0
    const barActive = (topology.barStations || 0) > 0;
    database.saveSettings({
      networkTopology: topology,
      showBartender: barActive ? true : undefined
    });

    broadcast({ type: 'TOPOLOGY_UPDATED', topology });
    res.json({ success: true, topology });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/system/claim-station', (req, res) => {
  try {
    const { stationId, deviceName, stationRole } = req.body;
    if (!stationId) return res.status(400).json({ error: 'Missing stationId' });

    const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
    activeStationPings.set(stationId, {
      deviceName: deviceName || 'Terminal',
      ip: clientIp,
      stationRole: stationRole || 'cashier',
      lastPing: new Date()
    });

    console.log(`[NETWORK] Station '${stationId}' claimed by ${deviceName} (${clientIp})`);
    broadcast({ type: 'STATION_STATUS_CHANGED', stationId, connected: true, ip: clientIp });

    res.json({ success: true, stationId, message: `Estación '${stationId}' asignada con éxito.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/system/station-ping', (req, res) => {
  const { stationId } = req.body;
  if (stationId && activeStationPings.has(stationId)) {
    const entry = activeStationPings.get(stationId);
    entry.lastPing = new Date();
  }
  res.json({ ok: true });
});

// Iniciar servidor local
server.listen(PORT, () => {
  console.log(`Servidor de Impossible POS™ encendido en: http://localhost:${PORT}`);
});




