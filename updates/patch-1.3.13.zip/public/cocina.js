const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let employees = [];
let activeWebSocket = null;
let currentMonth = new Date().getMonth();
let currentYear = new Date().getFullYear();
let currentLanguage = 'en';
let currentPage = 0;
let currentMaxPage = 0;
let showPastOrders = false;

// Control de selección activa de comanda para Bump Bar y Teclado Numérico
let selectedCardKey = '1';

function selectCardByKey(key) {
  selectedCardKey = String(key);
  const cards = document.querySelectorAll('.kds-card');
  let found = false;
  cards.forEach(c => {
    if (c.getAttribute('data-bump-key') === selectedCardKey) {
      c.classList.add('selected-kds-card');
      const badge = c.querySelector('.bump-index-badge');
      if (badge) badge.classList.add('selected');
      c.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      found = true;
    } else {
      c.classList.remove('selected-kds-card');
      const badge = c.querySelector('.bump-index-badge');
      if (badge) badge.classList.remove('selected');
    }
  });
  if (!found && cards.length > 0) {
    cards[0].classList.add('selected-kds-card');
    selectedCardKey = cards[0].getAttribute('data-bump-key') || '1';
    const badge = cards[0].querySelector('.bump-index-badge');
    if (badge) badge.classList.add('selected');
  }
}

function getSelectedOrFirstCard() {
  let card = document.querySelector(`.kds-card[data-bump-key="${selectedCardKey}"]`);
  if (!card) {
    card = document.querySelector('.kds-card');
    if (card) {
      selectedCardKey = card.getAttribute('data-bump-key') || '1';
      card.classList.add('selected-kds-card');
      const badge = card.querySelector('.bump-index-badge');
      if (badge) badge.classList.add('selected');
    }
  }
  return card;
}

function selectNextCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card[data-bump-key]'));
  if (cards.length === 0) return;
  const currentIdx = cards.findIndex(c => c.getAttribute('data-bump-key') === selectedCardKey);
  if (currentIdx >= 0 && currentIdx < cards.length - 1) {
    selectCardByKey(cards[currentIdx + 1].getAttribute('data-bump-key'));
  } else {
    // Si estamos al final de la página actual
    if (currentPage < currentMaxPage) {
      currentPage++;
      renderKDS();
      setTimeout(() => selectCardByKey('1'), 50);
    } else {
      // Regresar a la primera comanda de la pantalla
      selectCardByKey(cards[0].getAttribute('data-bump-key'));
    }
  }
}

function selectPrevCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card[data-bump-key]'));
  if (cards.length === 0) return;
  const currentIdx = cards.findIndex(c => c.getAttribute('data-bump-key') === selectedCardKey);
  if (currentIdx > 0) {
    selectCardByKey(cards[currentIdx - 1].getAttribute('data-bump-key'));
  } else if (currentPage > 0) {
    currentPage--;
    renderKDS();
    setTimeout(() => {
      const newCards = Array.from(document.querySelectorAll('.kds-card[data-bump-key]'));
      if (newCards.length > 0) selectCardByKey(newCards[newCards.length - 1].getAttribute('data-bump-key'));
    }, 50);
  } else {
    // Si estamos en la primera y no hay página previa, ir a la última de la pantalla
    selectCardByKey(cards[cards.length - 1].getAttribute('data-bump-key'));
  }
}

// Para registrar ubicación
let selectedOrderIdForLocation = null;
let selectedLocationName = '';

function initBarcodeScanner() {
  let scannerBuffer = '';
  let lastKeyTime = 0;

  window.addEventListener('keypress', async (e) => {
    const currentTime = Date.now();
    // A barcode scanner types extremely fast (delay < 50ms)
    if (currentTime - lastKeyTime > 50) {
      scannerBuffer = '';
    }
    lastKeyTime = currentTime;

    if (e.key === 'Enter') {
      if (scannerBuffer.length >= 4) {
        e.preventDefault();
        const code = scannerBuffer.trim();
        scannerBuffer = '';
        console.log("KDS Scanner detected ticket number:", code);
        
        let order = orders.find(o => String(o.ticketNumber) === code || o.id === code);
        if (order) {
          openWorkSheetModal(order.id);
          showToast(currentLanguage === 'es' ? `Comanda #${code} encontrada` : `Order #${code} found`, 'success');
          if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA')) {
            document.activeElement.blur();
          }
        } else {
          try {
            const res = await fetch(`${SERVER_URL}/api/orders`);
            if (res.ok) {
              const allOrders = await res.json();
              const found = allOrders.find(o => String(o.ticketNumber) === code || o.id === code);
              if (found) {
                if (!orders.some(o => o.id === found.id)) {
                  orders.push(found);
                }
                openWorkSheetModal(found.id);
                showToast(currentLanguage === 'es' ? `Comanda #${code} encontrada` : `Order #${code} found`, 'success');
              } else {
                showToast(currentLanguage === 'es' ? `Comanda #${code} no encontrada` : `Order #${code} not found`, 'error');
              }
            }
          } catch (err) {
            console.error("Barcode lookup failed:", err);
          }
        }
      }
      scannerBuffer = '';
    } else if (e.key.match(/^[a-zA-Z0-9]$/)) {
      scannerBuffer += e.key;
    }
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  initWebSocket();
  initBarcodeScanner();
  loadOrders();
  loadEmployees();
  setupEventListeners();
});

// Business details printed on the cake order sheet header (filled from Settings)
let kdsBrand = { name: '', phone: '', address: '' };
function kdsEsc(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

async function loadSettings() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      const settings = await res.json();
      kdsBrand = { name: settings.businessName || '', phone: settings.phone || '', address: settings.address || '' };
      currentLanguage = settings.langKDS || settings.language || 'en';
      applyStaticTranslations();
    }
  } catch (e) {
    console.error("Error loading settings in KDS:", e);
  }
}

function applyStaticTranslations() {
  const isBakery = activeStation === 'bakery';
  const stationTitle = isBakery 
    ? (isEs ? 'Pedidos Especiales KDS' : 'Custom Orders KDS') 
    : (isEs ? 'Cocina KDS' : 'Kitchen KDS');
  document.title = `Impossible POS™ - ${stationTitle}`;
  
  const logoText = document.querySelector('.logo-text');
  if (logoText) {
    logoText.innerHTML = isBakery ? 'Custom <span>Orders</span>' : 'Kitchen <span>Hub</span>';
  }
  
  const badge = document.querySelector('.station-badge');
  if (badge) badge.innerText = stationTitle;
  
  const btnActive = document.getElementById('btnActiveOrders');
  if (btnActive) btnActive.innerText = isEs ? 'Órdenes Activas' : 'Active Orders';
  
  const btnCal = document.getElementById('btnCalendarView');
  if (btnCal) btnCal.innerText = isEs ? 'Calendario de Producción' : 'Production Calendar';
  
  const calHeader = document.querySelector('#modalCalendar h3');
  if (calHeader) calHeader.innerText = isEs ? 'Calendario de Producción de Pastelería' : 'Cake Production Calendar';
  
  const btnPrev = document.getElementById('btnPrevMonth');
  if (btnPrev) btnPrev.innerText = isEs ? '◀ Anterior' : '◀ Prev';
  
  const btnNext = document.getElementById('btnNextMonth');
  if (btnNext) btnNext.innerText = isEs ? 'Siguiente ▶' : 'Next ▶';
  
  const locHeader = document.querySelector('#modalLocation h3');
  if (locHeader) locHeader.innerText = isEs ? 'Registrar Ubicación en Refrigerador' : 'Register Refrigerator Location';
  
  const locLabel = document.querySelector('#modalLocation label');
  if (locLabel) locLabel.innerText = isEs ? 'Identificación de Empleado (Passcode)' : 'Employee ID (Passcode)';
  
  const locTitle = document.querySelector('#modalLocation .selection-title');
  if (locTitle) locTitle.innerText = isEs ? 'Selecciona el Refrigerador / Anaquel' : 'Select Refrigerator / Shelf';
  
  const btnCancelLoc = document.getElementById('btnCancelLoc');
  if (btnCancelLoc) btnCancelLoc.innerText = isEs ? 'Cancelar' : 'Cancel';
  
  const btnSaveLoc = document.getElementById('btnSaveLoc');
  if (btnSaveLoc) btnSaveLoc.innerText = isEs ? 'Guardar Ubicación' : 'Save Location';

  // Translate location buttons
  const locButtons = document.querySelectorAll('#modalLocation .btn-option');
  locButtons.forEach(btn => {
    let loc = btn.getAttribute('data-loc') || '';
    if (isEs) {
      loc = loc.replace('Fridge', 'Refrigerador').replace('Shelf', 'Anaquel');
      btn.setAttribute('data-loc', loc);
      btn.innerText = loc.replace('Refrigerador A', 'Ref A').replace('Refrigerador B', 'Ref B');
    } else {
      loc = loc.replace('Refrigerador', 'Fridge').replace('Anaquel', 'Shelf');
      btn.setAttribute('data-loc', loc);
      btn.innerText = loc.replace('Fridge A', 'Ref A').replace('Fridge B', 'Ref B');
    }
  });
}

// Inicializar WebSockets para tiempo real
function initWebSocket() {
  activeWebSocket = new WebSocket(WS_URL);
  
  activeWebSocket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    if (data.type === 'NEW_ORDER' || data.type === 'DELIVERY_ORDER_ARRIVED') {
      const order = data.order;
      const isCakeOrder = order && Array.isArray(order.items) && order.items.some(i => i.isCustomCake || i.category === 'pastel_pedido' || i.category === 'bodas_quince');
      
      // Filtrar alertas según la estación activa (Cocina vs Pastelería)
      if (activeStation !== 'bakery' && isCakeOrder) {
        return; // La pantalla de cocina caliente no suena ni muestra pasteles
      }
      if (activeStation === 'bakery' && !isCakeOrder) {
        return; // La pantalla de pastelería no suena ni muestra comida caliente
      }

      playAlertSound();
      loadOrders();
      const plat = data.platform || (data.order && data.order.deliveryPlatform ? data.order.deliveryPlatform.toUpperCase() : '');
      const prefix = plat ? `[${plat}] ` : '';
      const orderNum = (data.order && (data.order.externalOrderId || data.order.ticketNumber)) || '';
      showToast(`${prefix}New Order: ${orderNum}!`);
    } else if (data.type === 'ORDER_UPDATED') {
      const order = data.order;
      const isCakeOrder = order && Array.isArray(order.items) && order.items.some(i => i.isCustomCake || i.category === 'pastel_pedido' || i.category === 'bodas_quince');
      if (activeStation !== 'bakery' && isCakeOrder) {
        return;
      }
      if (activeStation === 'bakery' && !isCakeOrder) {
        return;
      }
      const hasNew = data.order && Array.isArray(data.order.items) && data.order.items.some(i => i.isNewRound);
      if (hasNew) {
        playAlertSound();
        const tableLabel = data.order.tableName || data.order.tableNumber || data.order.ticketNumber || '';
        showToast(`New items added to Table ${tableLabel}!`);
      }
      loadOrders();
    }
  };

  activeWebSocket.onclose = () => {
    setTimeout(initWebSocket, 5000);
  };
}

// Cargar empleados para la validación del Reloj/Ubicaciones
async function loadEmployees() {
  try {
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (res.ok) {
      employees = await res.json();
    } else {
      console.warn("Failed to load employees from server, using fallback.");
      employees = [
        { id: "e1", name: "Pedro Gomez", passcode: "1234", cardCode: "1111" },
        { id: "e2", name: "Jose Rodriguez", passcode: "5678", cardCode: "2222" }
      ];
    }
  } catch (e) {
    console.error("Error loading employees:", e);
    employees = [
      { id: "e1", name: "Pedro Gomez", passcode: "1234", cardCode: "1111" },
      { id: "e2", name: "Jose Rodriguez", passcode: "5678", cardCode: "2222" }
    ];
  }
}

// Cargar órdenes con re-intento automático de inicio
async function loadOrders() {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      orders = await response.json();
      renderKDS();
    } else {
      setTimeout(loadOrders, 1500);
    }
  } catch (error) {
    console.warn("Initial server connect attempt, retrying in 1.5s...", error);
    setTimeout(loadOrders, 1500);
  }
}

function sortCustomCakes(a, b) {
  const cakeA = a.items && a.items.find(i => i.isCustomCake);
  const cakeB = b.items && b.items.find(i => i.isCustomCake);
  
  const detailsA = cakeA ? cakeA.details : null;
  const detailsB = cakeB ? cakeB.details : null;
  
  const dateA = detailsA && detailsA.pickupDate ? detailsA.pickupDate : '9999-12-31';
  const dateB = detailsB && detailsB.pickupDate ? detailsB.pickupDate : '9999-12-31';
  
  if (dateA !== dateB) {
    return dateA.localeCompare(dateB);
  }
  
  const timeA = detailsA && detailsA.pickupTime ? detailsA.pickupTime : '23:59';
  const timeB = detailsB && detailsB.pickupTime ? detailsB.pickupTime : '23:59';
  
  return timeA.localeCompare(timeB);
}

function isMeatModifier(name) {
  const n = name.toLowerCase().trim();
  const meats = ['asada', 'pollo', 'pastor', 'tripa', 'barbacoa', 'carnitas', 'lengua', 'chorizo', 'camaron', 'camarón', 'pescado', 'cabeza', 'barbacoa', 'chicharron', 'charrada', 'carne'];
  return meats.some(meat => n.includes(meat));
}

function getSortedFormattedModifiers(modifiers, isDarkBackground) {
  if (!modifiers || modifiers.length === 0) return '';
  
  // Sort by color: red (meat) first, then green (veg), then yellow (dressing), then default
  const colorOrder = { 'red': 1, 'green': 2, 'yellow': 3, 'default': 4 };
  const sorted = [...modifiers].sort((a, b) => {
    const cA = a.color || (isMeatModifier(a.name) ? 'red' : 'default');
    const cB = b.color || (isMeatModifier(b.name) ? 'red' : 'default');
    return (colorOrder[cA] || 5) - (colorOrder[cB] || 5);
  });
  
  const themeColors = {
    'red': isDarkBackground ? '#ff4d4f' : '#d9381e',
    'green': isDarkBackground ? '#52c41a' : '#388e3c',
    'yellow': isDarkBackground ? '#fadb14' : '#fbc02d',
    'default': isDarkBackground ? '#ffffff' : '#000000'
  };
  
  return sorted.map(m => {
    let c = m.color;
    // Fallback for old orders without color field
    if (!c) {
      c = isMeatModifier(m.name) ? 'red' : 'default';
    }
    const hexColor = themeColors[c] || themeColors['default'];
    return `<div style="color: ${hexColor}; font-weight: bold; font-size: 12px; margin-top: 1px; padding-left: 6px;">${m.name.toUpperCase()}</div>`;
  }).join('');
}

function formatDateHeader(dateStr) {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  const year = parts[0];
  const monthNum = parts[1];
  const day = parts[2];
  
  const monthsEs = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const idx = parseInt(monthNum, 10) - 1;
  const monthName = currentLanguage === 'es' ? monthsEs[idx] : monthsEn[idx];
  
  return `${day} - ${monthName} - ${year}`;
}

const urlParams = new URLSearchParams(window.location.search);
const stationParam = urlParams.get('station');
let activeStation = (stationParam === 'togo' || stationParam === 'bakery') ? stationParam : 'kitchen';

// Renderizar las tarjetas del KDS
function renderKDS() {
  clearRightPanel();
  const container = document.getElementById('kdsContainer');
  container.innerHTML = '';

  const isEs = currentLanguage === 'es';

  // Toggle buttons styles
  const btnActive = document.getElementById('btnActiveOrders');
  const btnPast = document.getElementById('btnPastOrders');
  if (btnActive && btnPast) {
    if (showPastOrders) {
      btnPast.style.backgroundColor = 'var(--accent-color)';
      btnPast.style.color = '#000';
      btnPast.style.fontWeight = 'bold';
      btnActive.style.backgroundColor = 'var(--bg-tertiary)';
      btnActive.style.color = '#fff';
      btnActive.style.fontWeight = 'normal';
    } else {
      btnActive.style.backgroundColor = 'var(--accent-color)';
      btnActive.style.color = '#000';
      btnActive.style.fontWeight = 'bold';
      btnPast.style.backgroundColor = 'var(--bg-tertiary)';
      btnPast.style.color = '#fff';
      btnPast.style.fontWeight = 'normal';
    }
  }

  // Filtrar órdenes: activas vs pasadas
  let activeOrders = [];
  if (showPastOrders) {
    activeOrders = orders.filter(o => o.status === 'completado' || o.status === 'entregado' || o.status === 'cancelado' || o.status === 'listo');
  } else {
    activeOrders = orders.filter(o => o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion');
  }

  // Filtrar comandas antiguas (para mantener la pantalla limpia sin ocultar órdenes pendientes activas)
  const now = Date.now();
  const cutoffTime = now - (48 * 60 * 60 * 1000); // 48 hours ago
  const activeCutoffTime = now - (7 * 24 * 60 * 60 * 1000); // 7 days ago for active pending orders
  const todayStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  activeOrders = activeOrders.filter(o => {
    const orderTime = new Date(o.dateUpdated || o.dateCreated).getTime();
    const isRecent = !isNaN(orderTime) && orderTime > cutoffTime;
    const isScheduledTodayOrFuture = o.scheduledDate && (o.scheduledDate >= todayStr);
    const isUnfinishedActive = !showPastOrders && (o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion') && (!isNaN(orderTime) && orderTime > activeCutoffTime);
    return isRecent || isScheduledTodayOrFuture || isUnfinishedActive;
  });

  // =========================================================================
  // FILTRADO ESTRICTO DE RAÍZ POR ESTACIÓN (COCINA CALIENTE VS PEDIDOS ESPECIALES)
  // =========================================================================
  if (activeStation === 'bakery') {
    // Pantalla de Pastelería: Mostrar EXCLUSIVAMENTE órdenes con Custom Cakes / Bodas y Eventos
    activeOrders = activeOrders.filter(o => {
      return Array.isArray(o.items) && o.items.some(i => i.isCustomCake || i.category === 'pastel_pedido' || i.category === 'bodas_quince');
    });
    activeOrders.sort(sortCustomCakes);
  } else {
    // Pantalla de Cocina Caliente (kitchen / togo): EXCLUIR rotundamente Custom Cakes y Wedding & Events
    activeOrders = activeOrders.filter(o => {
      const isCake = Array.isArray(o.items) && o.items.some(i => i.isCustomCake || i.category === 'pastel_pedido' || i.category === 'bodas_quince');
      return !isCake;
    });
    activeOrders.sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
  }

  if (activeOrders.length === 0) {
    currentMaxPage = 0;
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">No active orders</div>`;
    const lblPageIndicator = document.getElementById('lblKdsPageIndicator');
    if (lblPageIndicator) lblPageIndicator.innerText = `Page 1 of 1`;
    const btnScrollBack = document.getElementById('btnKdsScrollBack');
    const btnScrollNext = document.getElementById('btnKdsScrollNext');
    if (btnScrollBack) btnScrollBack.style.opacity = '0.35';
    if (btnScrollNext) btnScrollNext.style.opacity = '0.35';
    return;
  }

  // CALCULAR PAGINACIÓN (10 por página)
  const totalOrdersCount = activeOrders.length;
  currentMaxPage = Math.max(0, Math.ceil(totalOrdersCount / 10) - 1);
  if (currentPage > currentMaxPage) {
    currentPage = currentMaxPage;
  }
  
  const startIndex = currentPage * 10;
  const endIndex = startIndex + 10;
  const pageOrders = activeOrders.slice(startIndex, endIndex);

  // Actualizar indicador de páginas
  const lblPageIndicator = document.getElementById('lblKdsPageIndicator');
  if (lblPageIndicator) {
    lblPageIndicator.innerText = `Page ${currentPage + 1} of ${currentMaxPage + 1}`;
  }

  // Actualizar estilo visual de los botones de cambio de página
  const btnScrollBack = document.getElementById('btnKdsScrollBack');
  const btnScrollNext = document.getElementById('btnKdsScrollNext');
  if (btnScrollBack) {
    btnScrollBack.style.opacity = (currentPage > 0) ? '1' : '0.35';
  }
  if (btnScrollNext) {
    btnScrollNext.style.opacity = (currentPage < currentMaxPage) ? '1' : '0.35';
  }

  pageOrders.forEach((order, index) => {
    const card = document.createElement('div');
    const isAnticipated = !!order.scheduledDate;
    const orderType = order.deliveryType || order.type || 'llevar';
    let platformClass = '';
    const plat = (order.deliveryPlatform || '').toLowerCase();
    if (plat === 'doordash' || (order.notes && order.notes.includes('[DoorDash]'))) platformClass = 'platform-doordash';
    else if (plat === 'ubereats' || (order.notes && order.notes.includes('[Uber Eats]'))) platformClass = 'platform-ubereats';
    else if (plat === 'grubhub' || (order.notes && order.notes.includes('[Grubhub]'))) platformClass = 'platform-grubhub';
    else if (plat === 'online_menu' || (order.notes && order.notes.includes('[Online]'))) platformClass = 'platform-online_menu';

    const orderAgeMs = Date.now() - new Date(order.dateCreated).getTime();
    const elapsedMins = Math.floor(orderAgeMs / 60000);

    // Regla de color del contorno/borde:
    // 0 a 4 min: Verde (timer-green)
    // 5 a 8 min: Amarillo (timer-yellow)
    // 9+ min: Rojo (timer-red)
    let timerClass = 'timer-green';
    if (elapsedMins >= 9) {
      timerClass = 'timer-red';
    } else if (elapsedMins >= 5) {
      timerClass = 'timer-yellow';
    }

    // Flasheo del contorno en tickets recién llegados (primeros 20 segundos)
    const isFlashingNew = orderAgeMs < 20000;
    const flashClass = isFlashingNew ? 'flashing-new' : '';

    card.className = `kds-card ${timerClass} ${flashClass} ${order.status === 'en_decoracion' ? 'priority' : ''} ${isAnticipated ? 'anticipated' : ''} type-${orderType} ${platformClass}`;
    
    if (isFlashingNew) {
      const remainingMs = Math.max(500, 20000 - orderAgeMs);
      setTimeout(() => {
        if (card) card.classList.remove('flashing-new');
      }, remainingMs);
    }
    
    const cakeItem = order.items && order.items.find(i => i.isCustomCake);
    const details = cakeItem ? cakeItem.details : null;
    
    // Asignar número del 1 al 10 para el Bump Bar (1-9 y 0 para la 10ma)
    let bumpBadge = '';
    if (index < 10) {
      const bumpKey = (index + 1 === 10) ? '0' : String(index + 1);
      const isSelected = (selectedCardKey === bumpKey) || (!selectedCardKey && index === 0);
      bumpBadge = `<div class="bump-index-badge ${isSelected ? 'selected' : ''}">${bumpKey}</div>`;
      card.setAttribute('data-bump-key', bumpKey);
      if (isSelected) {
        card.classList.add('selected-kds-card');
        selectedCardKey = bumpKey;
      }
      card.addEventListener('click', (e) => {
        if (!e.target.closest('button')) {
          selectCardByKey(bumpKey);
        }
      });
    }

    const elapsed = getElapsedTime(order.dateCreated);
    const dateFormatted = new Date(order.dateCreated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let itemsHtml = '';
    let isCakeOrder = false;

    // Helper to extract guest number
    const getGuestNum = (it) => {
      if (it.clientSeat && parseInt(it.clientSeat, 10) > 0) return parseInt(it.clientSeat, 10);
      const m = String(it.name || '').match(/\((?:Guest|Cliente)\s*(\d+)\)/i);
      return m ? parseInt(m[1], 10) : null;
    };

    const hasMultipleGuests = Array.isArray(order.items) && order.items.some(it => {
      const g = getGuestNum(it);
      return g !== null && g > 1;
    });

    let kdsItems = [...(order.items || [])];
    if (!order.isKitchenAddon && kdsItems.some(i => i.isNewRound && i.previousSentQty > 0)) {
      const filtered = kdsItems.filter(i => !i.isNewRound);
      if (filtered.length > 0) kdsItems = filtered;
    }
    if (hasMultipleGuests) {
      kdsItems.sort((a, b) => (getGuestNum(a) || 1) - (getGuestNum(b) || 1));
    }

    let currentKdsGuest = null;

    kdsItems.forEach(item => {
      const guestNum = hasMultipleGuests ? (getGuestNum(item) || 1) : null;
      if (hasMultipleGuests && guestNum !== currentKdsGuest) {
        currentKdsGuest = guestNum;
        itemsHtml += `
          <div style="width: 100%; font-size: 10.5px; font-weight: 800; color: #5ac8fa; background: rgba(90, 200, 250, 0.15); border-left: 3px solid #5ac8fa; padding: 2px 6px; border-radius: 2px; margin-top: 6px; margin-bottom: 4px; letter-spacing: 0.5px;">
            GUEST ${currentKdsGuest}
          </div>
        `;
      }

      let specs = '';
      if (item.isCustomCake) {
        isCakeOrder = true;
        
        let tiersHtml = '';
        if (item.details.tiersBreakdown && item.details.tiersBreakdown.length > 0) {
          tiersHtml = `<div style="margin-top: 6px; background: rgba(0,0,0,0.3); padding: 6px; border-radius: 4px; font-size: 13px; line-height: 1.4;">
            <strong style="color: var(--accent-color);">TIER BREAKDOWN:</strong><br>`;
          item.details.tiersBreakdown.forEach(t => {
            tiersHtml += `• <strong>Piso ${t.tier} (${t.size || ''}):</strong> Flavor: ${t.flavor} | Filling: ${t.filling} | Fruit: ${t.fruit}<br>`;
          });
          tiersHtml += '</div>';
        }

        const weddingInfo = item.details.isSpecialEvent ? `
          <div style="font-size: 13px; font-weight: bold; color: var(--accent-color); margin-bottom: 4px;">
            ${item.details.folio ? `FOLIO: ${item.details.folio} | ` : ''} MODEL #: ${item.details.bookModel || 'N/A'}<br>
            SHAPE: ${item.details.shape || 'Round'} | GUESTS: ${item.details.ppl || 'N/A'} | COLOR: ${item.details.color || 'N/A'}
          </div>
        ` : '';

        specs = `
          <div class="kds-item-specs">
            ${weddingInfo}
            ${!item.details.isSpecialEvent ? `
              <strong>Flavor:</strong> ${item.details.flavor} | <strong>Size:</strong> ${item.details.size}<br>
              <strong>Fillings:</strong> ${item.details.fillings ? item.details.fillings.join(', ') : 'N/A'}<br>
              <strong>Fruits:</strong> ${item.details.fruits ? item.details.fruits.join(', ') : 'N/A'}
            ` : ''}
            ${tiersHtml}
          </div>
          ${item.details.notes ? `<div class="kds-item-notes" style="font-size: 14px; font-weight: bold; color: #ffeb3b; background: rgba(255,235,59,0.1); padding: 6px; border-radius: 4px; margin-top: 6px;">NOTES: ${item.details.notes}</div>` : ''}
        `;
      } else if (item.selectedModifiers && item.selectedModifiers.length > 0) {
        specs = `<div class="kds-item-specs" style="margin-top: 2px; display: block; width: 100%;">
          ${getSortedFormattedModifiers(item.selectedModifiers, true)}
        </div>`;
      }

      // Clean food name: strip noise (Seat, Guest, to go)
      const cleanName = String(item.name || '')
        .replace(/\((?:Cliente|Guest)\s*\d+\)/gi, '')
        .replace(/\(Seat \d+\)/gi, '')
        .replace(/\(to go\)/gi, '')
        .trim();

      // Clean, pure food display (no strikethrough, no round badges)
      const itemStyle = 'font-size: 13px; font-weight: 700; color: #ffffff; line-height: 1.35;';

      // Only show TO GO on dish if the order is DINE IN and this specific dish is to go
      const isWholeOrderToGo = (orderType === 'llevar' || orderType === 'to go' || orderType === 'togo' || orderType === 'walkin' || orderType === 'pickup');
      const showItemToGo = !isWholeOrderToGo && (item.isToGo === true || String(item.name).toLowerCase().includes('(to go)'));
      const itemToGoBadge = showItemToGo ? ' <span style="background: #ff453a; color: #fff; font-size: 9px; font-weight: 900; padding: 1px 5px; border-radius: 3px; margin-left: 6px;">TO GO</span>' : '';

      const seatMatch = item.name.match(/\((?:Cliente|Guest)\s*(\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
      const clientBadge = (seatMatch && !hasMultipleGuests) 
        ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 4px; padding: 1px 4px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">G${seatMatch[1]}</span>` 
        : '';

      itemsHtml += `
        <div class="kds-item" style="display: flex; align-items: flex-start; flex-wrap: wrap; margin-bottom: 6px; width: 100%; border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 4px;">
          ${clientBadge}
          <span class="kds-item-name" style="${itemStyle}"><span style="color: #ffd60a; font-weight: 900; margin-right: 4px;">${item.quantity}</span> ${cleanName}${itemToGoBadge}</span>
          ${specs}
        </div>
      `;
    });

    // 1. Extraer identificador limpio ingresado por la cajera (Mesa, Cliente, Carro o Nota)
    let identifierParts = [];

    // Mesa / Ubicación
    if (order.tableName) {
      let tName = String(order.tableName).replace(/\[ADD-ON\]/gi, '').replace(/\(ADD-ON\)/gi, '').trim();
      if (tName.toLowerCase().startsWith('customer:')) {
        tName = tName.replace(/^customer:\s*/i, '').trim();
      }
      if (tName) identifierParts.push(tName);
    } else if (order.tableNumber) {
      identifierParts.push(`Table ${order.tableNumber}`);
    }

    // Nombre de Cliente
    if (order.clientName) {
      let cName = String(order.clientName).replace(/\[ADD-ON\]/gi, '').replace(/\(ADD-ON\)/gi, '').trim();
      if (cName.toLowerCase().startsWith('customer:')) {
        cName = cName.replace(/^customer:\s*/i, '').trim();
      }
      if (cName && !identifierParts.some(p => p.toLowerCase().includes(cName.toLowerCase()))) {
        identifierParts.push(cName);
      }
    }

    // Carro / Vehículo (ej. "Chevy blanco")
    const carVal = order.car || order.vehicle || order.carDescription;
    if (carVal) {
      const cStr = String(carVal).trim();
      if (cStr && !identifierParts.some(p => p.toLowerCase().includes(cStr.toLowerCase()))) {
        identifierParts.push(cStr);
      }
    }

    // Notas de carro o descripción
    if (identifierParts.length === 0 && order.notes) {
      const noteMatch = order.notes.match(/\[(?:CAR|VEHICLE):\s*([^\]]+)\]/i);
      if (noteMatch) {
        identifierParts.push(noteMatch[1].trim());
      }
    }

    const cleanIdentifier = identifierParts.join(' • ');

    // 2. Tipo de orden y badge
    let typeBadgeColor = '#ffd60a';
    let typeTagText = 'TO GO';
    if (orderType === 'comer' || orderType === 'dine-in') {
      typeTagText = 'DINE IN';
      typeBadgeColor = '#30d158';
    } else if (orderType === 'walkin' || orderType === 'walk-in') {
      typeTagText = 'WALK-IN';
      typeBadgeColor = '#64d2ff';
    } else if (orderType === 'pickup') {
      typeTagText = 'PICKUP';
      typeBadgeColor = '#0a84ff';
    } else if (orderType === 'delivery') {
      typeTagText = 'DELIVERY';
      typeBadgeColor = '#bf5af2';
    } else if (orderType === 'drive-thru' || orderType === 'car') {
      typeTagText = 'DRIVE-THRU';
      typeBadgeColor = '#ff9f0a';
    } else if (orderType === 'llevar') {
      typeTagText = 'TO GO';
      typeBadgeColor = '#ffd60a';
    }

    // 3. Número consecutivo y sub-rondas (e.g. #1007, #1007-A, #1007-B)
    const rawTicket = order.ticketDisplay || order.ticketNumber || (order.id ? String(order.id).replace(/\D/g, '').slice(-4) : '101');
    const cleanTicketNum = String(rawTicket).replace(/[^0-9A-Za-z\-]/g, '') || '101';
    let headerTitle = `#${cleanTicketNum}`;
    let platformBadgeHtml = '';

    if (platformClass === 'platform-doordash') {
      headerTitle = `#${cleanTicketNum}`;
      typeTagText = 'DOORDASH';
    } else if (platformClass === 'platform-ubereats') {
      headerTitle = `#${cleanTicketNum}`;
      typeTagText = 'UBER EATS';
    } else if (platformClass === 'platform-grubhub') {
      headerTitle = `#${cleanTicketNum}`;
      typeTagText = 'GRUBHUB';
    } else if (platformClass === 'platform-online_menu') {
      headerTitle = `#${cleanTicketNum}`;
      typeTagText = 'WEB ORDER';
    }

    if (platformClass) {
      platformBadgeHtml = `
        <div style="background: rgba(255,255,255,0.06); border: 1px dashed rgba(255,255,255,0.3); border-radius: 6px; padding: 4px 6px; margin-bottom: 6px; font-size: 11px;">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <strong style="color: #fff;">${order.clientName || 'Cliente'}</strong>
            <span style="background: #fff; color: #000; padding: 2px 6px; border-radius: 4px; font-weight: 900; font-size: 11px; letter-spacing: 0.5px;">${order.pickupCode || cleanTicketNum}</span>
          </div>
          ${order.driverInfo ? `<div style="font-size: 10px; color: #ffd60a; margin-top: 2px;">${order.driverInfo}</div>` : ''}
        </div>
      `;
    }

    const orderTimeFormatted = order.dateCreated ? new Date(order.dateCreated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';

    card.innerHTML = `
      <div class="kds-card-header">
        <div style="display: flex; align-items: center; gap: 6px;">
          ${bumpBadge}
          <span class="kds-card-num">${headerTitle}</span>
          ${order.roundLetter ? `<span style="background: #ff9f0a; color: #000; font-weight: 900; font-size: 11px; padding: 2px 6px; border-radius: 4px; letter-spacing: 0.5px;">ROUND ${order.roundLetter}</span>` : ''}
        </div>
        <span class="kds-card-time" style="color: ${typeBadgeColor}; font-weight: 800;">${typeTagText} (${elapsed})</span>
      </div>
      <div class="kds-card-body">
        ${cleanIdentifier ? `
          <div style="background: rgba(255, 255, 255, 0.08); border-left: 4px solid #ffd60a; padding: 5px 8px; border-radius: 4px; margin-bottom: 8px;">
            <div style="font-size: 13px; font-weight: 900; color: #ffd60a; letter-spacing: 0.5px; text-transform: uppercase; word-break: break-word; line-height: 1.2;">
              ${cleanIdentifier}
            </div>
            ${order.orderOrigin ? `
              <div style="font-size: 10px; color: #64d2ff; font-weight: 700; margin-top: 4px; display: flex; justify-content: space-between; border-top: 1px dashed rgba(255,255,255,0.1); padding-top: 3px;">
                <span>Sent by: ${order.orderOrigin}</span>
                <span>${orderTimeFormatted}</span>
              </div>
            ` : ''}
          </div>
        ` : (order.orderOrigin ? `
          <div style="font-size: 10px; color: #64d2ff; font-weight: 700; margin-bottom: 6px; display: flex; justify-content: space-between; background: rgba(255,255,255,0.05); padding: 4px 6px; border-radius: 4px;">
            <span>Sent by: ${order.orderOrigin}</span>
            <span>${orderTimeFormatted}</span>
          </div>
        ` : '')}
        ${platformBadgeHtml}
        ${isCakeOrder && details ? `
          <div class="kds-client-info">
            <strong>Deliver:</strong> ${details.pickupDate || 'N/A'} - ${details.pickupTime || 'N/A'}<br>
            <strong>Customer:</strong> ${details.clientName || 'N/A'} (${details.clientPhone || 'N/A'})
          </div>
        ` : (order.scheduledDate ? `
          <div class="kds-client-info" style="border: 1px solid #0a84ff; background-color: rgba(10,132,255,0.1); color: #fff; padding: 4px; border-radius: 4px; margin-bottom: 6px;">
            <strong>ANTICIPATE ORDER:</strong><br>
            ${order.scheduledDate} ${order.scheduledTime ? `at ${order.scheduledTime}` : ''}
          </div>
        ` : '')}
        ${itemsHtml}
      </div>
      <div class="kds-card-footer" style="padding: 8px; display: flex; flex-direction: column; gap: 6px; background-color: #151518;">
        ${isCakeOrder ? `
          <!-- Row 1: Sheet & Model -->
          <div style="display: flex; gap: 6px; width: 100%;">
            <button class="btn-kds" onclick="openWorkSheetModal('${order.id}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: var(--accent-color); color: #000;">Sheet <span style="opacity: 0.85; font-size: 9px; margin-left: 2px;">[Enter]</span></button>
            <button class="btn-kds" onclick="viewBookModelPhoto('${details ? details.bookModel || '' : ''}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #ff9f0a; color: #000;">Model <span style="opacity: 0.85; font-size: 9px; margin-left: 2px;">[*]</span></button>
          </div>
          <!-- Row 2: Photo & Bump/Restore -->
          <div style="display: flex; gap: 6px; width: 100%;">
            <button class="btn-kds" onclick="viewReferencePhoto('${details ? details.photoUrl || '' : ''}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #bf5af2; color: #fff;">Photo <span style="opacity: 0.85; font-size: 9px; margin-left: 2px;">[/]</span></button>
            ${showPastOrders ? `
              <button class="btn-kds" onclick="restoreOrder('${order.id}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #ff9f0a; color: #000;">Restore <span style="opacity: 0.85; font-size: 9px; margin-left: 2px;">[Del]</span></button>
            ` : `
              <button class="btn-kds bump" onclick="bumpOrder('${order.id}', ${isCakeOrder})" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold;">✓ Bump <span style="opacity: 0.85; font-size: 9px; margin-left: 2px;">[Del]</span></button>
            `}
          </div>
        ` : `
          ${!showPastOrders ? `
            <div style="display: flex; gap: 6px; width: 100%;">
              <button class="btn-kds" onclick="openWorkSheetModal('${order.id}')" style="flex: 1; padding: 4px 6px; font-size: 10px; font-weight: bold; background-color: var(--accent-color); color: #000;">View <span style="opacity: 0.85; font-size: 8.5px; margin-left: 2px;">[Enter]</span></button>
              <button class="btn-kds bump" onclick="bumpOrder('${order.id}', ${isCakeOrder})" style="flex: 1; padding: 4px 6px; font-size: 10px; font-weight: bold;">✓ Bump <span style="opacity: 0.85; font-size: 8.5px; margin-left: 2px;">[Del]</span></button>
            </div>
          ` : `
            <div style="display: flex; gap: 6px; width: 100%;">
              <button class="btn-kds" onclick="restoreOrder('${order.id}')" style="flex: 1; padding: 4px 6px; font-size: 10px; font-weight: bold; background-color: #ff9f0a; color: #000;">Restore <span style="opacity: 0.85; font-size: 8.5px; margin-left: 2px;">[Del]</span></button>
            </div>
          `}
        `}
      </div>
    `;

    container.appendChild(card);
  });

  // Asegurar que siempre haya una tarjeta seleccionada visualmente
  const firstCard = container.querySelector('.kds-card[data-bump-key]');
  if (firstCard && !container.querySelector('.kds-card.selected-kds-card')) {
    firstCard.classList.add('selected-kds-card');
    selectedCardKey = firstCard.getAttribute('data-bump-key') || '1';
    const badge = firstCard.querySelector('.bump-index-badge');
    if (badge) badge.classList.add('selected');
  }
}

// Tiempo transcurrido
function getElapsedTime(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  return `${mins}m`;
}

// Acción de BUMP (Completar orden)
function bumpOrder(orderId, isCakeOrder) {
  if (isCakeOrder) {
    // Para pasteles, requiere guardar ubicación de refrigerador
    selectedOrderIdForLocation = orderId;
    document.getElementById('locEmployeeCode').value = '';
    // Limpiar selección previa
    document.querySelectorAll('#modalLocation .btn-option').forEach(b => b.classList.remove('selected'));
    selectedLocationName = '';
    document.getElementById('modalLocation').style.display = 'flex';
    // Auto focus on the card scan input
    setTimeout(() => {
      const codeInput = document.getElementById('locEmployeeCode');
      if (codeInput) {
        codeInput.focus();
      }
    }, 100);
  } else {
    // Para órdenes normales
    completeOrderStatus(orderId, 'listo');
  }
}

async function completeOrderStatus(orderId, status, shelfLocation = null, employeeName = null) {
  try {
    // 1. Actualizar estado
    await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });

    // 2. Si es pastel, registrar ubicación
    if (shelfLocation) {
      await fetch(`${SERVER_URL}/api/orders/${orderId}/location`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shelfLocation, employeeName })
      });
    }

    showToast('Orden completada y movida a despacho');
    loadOrders();
  } catch (error) {
    showToast('Error actualizando orden', 'error');
  }
}

async function restoreOrder(orderId) {
  const isEs = currentLanguage === 'es';
  try {
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'pendiente' })
    });
    if (response.ok) {
      showToast(isEs ? 'Comanda restaurada con éxito!' : 'Order restored successfully!');
      loadOrders();
    } else {
      showToast(isEs ? 'Error al restaurar comanda' : 'Error restoring order', 'error');
    }
  } catch (e) {
    console.error("Error restoring order:", e);
    showToast(isEs ? 'Error de conexión' : 'Connection error', 'error');
  }
}
window.restoreOrder = restoreOrder;

// Imprimir comanda directamente en iframe silencioso (Sin salir de modo kiosco)
function printColorSheet(orderId) {
  showToast(currentLanguage === 'es' ? 'Enviando comanda a la impresora de pastelería...' : 'Sending work sheet to pastry printer...', 'info');
  
  fetch(`${SERVER_URL}/api/printer/print-cake-silent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ orderId })
  })
  .then(res => {
    if (res.ok) {
      showToast(currentLanguage === 'es' ? '¡Hoja de trabajo impresa exitosamente!' : 'Work sheet printed successfully!', 'success');
    } else {
      window.open(`/comanda_pastel.html?orderId=${orderId}`, '_blank');
    }
  })
  .catch(() => {
    window.open(`/comanda_pastel.html?orderId=${orderId}`, '_blank');
  });
}

function clearRightPanel() {
  const rightPanelContent = document.getElementById('workSheetRightContent');
  if (rightPanelContent) {
    rightPanelContent.innerHTML = `
      <div style="text-align: center; margin-top: 150px; color: #777; font-size: 18px; font-weight: bold;">
        Select an order card on the left to view the Bakery Work Sheet
      </div>
    `;
  }
}

// Abrir / Cargar vista previa de la hoja de trabajo en el panel derecho o modal
function openWorkSheetModal(orderId) {
  const order = orders.find(o => o.id === orderId);
  if (!order) return;

  const rightPanelContent = document.getElementById('workSheetRightContent');
  const modalBody = document.getElementById('workSheetModalBody');
  const modal = document.getElementById('modalWorkSheetPreview');

  const cakeItem = order.items.find(i => i.isCustomCake);
  const titleEl = document.getElementById('lblWorkSheetModalTitle');

  if (!cakeItem) {
    // Non-cake order preview (e.g. KDS 2: Togo / Store Orders)
    if (titleEl) {
      titleEl.innerText = 'TICKET';
      titleEl.style.fontSize = '12px';
    }
    
    // Permitir reimprimir la comanda de cocina directamente desde el visor KDS
    const printBtn = document.getElementById('btnPrintWorkSheetFromModal');
    if (printBtn) {
      printBtn.style.display = 'inline-block';
      printBtn.innerHTML = (currentLanguage === 'es' ? 'Imprimir Comanda' : 'Print Ticket') + ' <span style="background: rgba(0,0,0,0.25); padding: 2px 6px; border-radius: 4px; font-size: 11px; margin-left: 6px; border: 1px solid rgba(255,255,255,0.2);">[*] / [Enter]</span>';
      printBtn.onclick = () => printKdsTicket(orderId);
    }

    // Dynamically size modal content and disable scroll to fit screen
    if (modal) {
      const modalContent = modal.querySelector('.modal-content');
      if (modalContent) modalContent.style.maxWidth = '450px';
    }
    if (modalBody) {
      modalBody.style.maxHeight = '80vh';
      modalBody.style.overflowY = 'hidden';
      modalBody.style.padding = '8px';
    }
    
    const orderType = order.deliveryType || order.type || 'llevar';
    const getTableDisplay = (o) => {
      const num = o.tableNumber;
      if (num) {
        return num.toLowerCase().includes('table') || num.toLowerCase().includes('mesa') ? num : `Table ${num}`;
      }
      return o.tableName || '';
    };
    const tableText = (orderType === 'comer') 
      ? (getTableDisplay(order) || 'TABLE N/A') 
      : 'TO GO';
    const tableStyle = (orderType === 'comer')
      ? 'font-size: 14px; font-weight: bold; color: #000;'
      : 'font-size: 14px; font-weight: bold; color: #ff3b30;';

    const detailsHtml = `
      <div style="max-width: 420px; margin: 0 auto; padding: 10px; background-color: #fff; color: #000; font-family: 'Courier New', Courier, monospace; border: 2px dashed #000; border-radius: 4px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); box-sizing: border-box; width: 100%;">
        
        <!-- Aligned Meta Header (Folio/Table left, Time/Date right) -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px dashed #000; padding-bottom: 6px; margin-bottom: 8px; font-size: 13px; line-height: 1.35; color: #000;">
          <div>
            <div><strong>FOLIO #:</strong> <span style="font-size: 14px; font-weight: bold;">#${order.ticketNumber || order.id.substring(2, 8).toUpperCase()}</span></div>
            <div><strong>TABLE:</strong> <span style="${tableStyle}; text-transform: uppercase;">${tableText}</span></div>
          </div>
          <div style="text-align: right;">
            <div><strong>TIME:</strong> ${new Date(order.dateCreated).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</div>
            <div><strong>DATE:</strong> ${new Date(order.dateCreated).toLocaleDateString()}</div>
          </div>
        </div>

        <!-- Items List -->
        <div style="font-size: 14px; line-height: 1.4; color: #000; text-align: left;">
          ${order.items.map(item => {
            let modsHtml = '';
            if (item.selectedModifiers && item.selectedModifiers.length > 0) {
              modsHtml = `<div style="margin-left: 12px; margin-top: 2px;">
                ${getSortedFormattedModifiers(item.selectedModifiers, false)}
              </div>`;
            }
            const isItemToGo = item.isToGo || item.name.includes('(To Go)') || item.name.includes('(to go)');
            const itemStyle = `font-size: 13px; font-weight: bold; color: #000;`;
              
            const seatMatch = item.name.match(/\((?:Cliente|Guest)\s*(\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
            const clientBadge = seatMatch 
              ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 4px; padding: 1px 4px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">G${seatMatch[1]}</span>` 
              : '';
            const cleanName = item.name.replace(/\((?:Cliente|Guest)\s*\d+\)/gi, '').replace(/\(Seat \d+\)/i, '').replace(/\(to go\)/gi, '').trim().toUpperCase();

            return `
              <div style="margin-bottom: 6px; border-bottom: 1px solid #eee; padding-bottom: 4px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <span style="${itemStyle}">${clientBadge}${item.quantity} ${cleanName}${isItemToGo ? ' <span style="color: #ff3b30; font-weight: 950; margin-left: 6px;">TO GO</span>' : ''}</span>
                </div>
                ${modsHtml}
              </div>
            `;
          }).join('')}
        </div>

        <!-- Footer -->
        <div style="text-align: center; border-top: 2px dashed #000; padding-top: 8px; margin-top: 8px; font-size: 10px; font-weight: bold; color: #555;">
          *** END OF TICKET / FIN DE COMANDA ***
        </div>
      </div>
    `;
    
    if (modalBody) modalBody.innerHTML = detailsHtml;
    if (modal) modal.style.display = 'flex';
    return;
  }

  if (titleEl) {
    titleEl.innerText = currentLanguage === 'es' ? 'Vista Previa de Hoja de Trabajo de Pastelería' : 'Bakery Work Sheet Preview';
    titleEl.style.fontSize = '16px';
  }
  const printBtn = document.getElementById('btnPrintWorkSheetFromModal');
  if (printBtn) printBtn.style.display = 'inline-block';

  // Restore cake order modal sizing
  if (modal) {
    const modalContent = modal.querySelector('.modal-content');
    if (modalContent) modalContent.style.maxWidth = '850px';
  }
  if (modalBody) {
    modalBody.style.maxHeight = '75vh';
    modalBody.style.overflowY = 'auto';
    modalBody.style.padding = '15px';
  }

  const details = cakeItem.details;
  const isEs = currentLanguage === 'es';

  let tiersRows = '';
  if (details.tiersBreakdown && details.tiersBreakdown.length > 0) {
    tiersRows = details.tiersBreakdown.map(t => `
      <tr style="border-bottom: 1px solid #ccc; text-align: center;">
        <td style="padding: 6px; font-weight: bold; background: #fafafa;">Piso ${t.tier}</td>
        <td style="padding: 6px; font-weight: bold; color: #000;">${t.size || 'N/A'}</td>
        <td style="padding: 6px; text-align: left;">${t.flavor}</td>
        <td style="padding: 6px; text-align: left;">${t.filling}</td>
        <td style="padding: 6px; text-align: left;">${t.fruit}</td>
      </tr>
    `).join('');
  }

  // Checkboxes parsing for KDS screen view
  const flv = (details.flavor || '').toLowerCase();
  const isChk = (cond) => cond ? 'checked' : '';

  const chkChocolate = isChk(flv.includes('chocolate'));
  const chkYellow = isChk(flv.includes('vainilla') || flv.includes('yellow') || flv.includes('vanilla') || details.flavor === 'Regular');
  const chkMarble = isChk(flv.includes('marmoleado') || flv.includes('marble'));
  const chk1212 = isChk(flv.includes('1/2 & 1/2') || flv.includes('1/2 y 1/2') || flv.includes('mitad'));

  const is3L = flv.includes('tres leches') || flv.includes('3 leches') || flv.includes('3l') || flv.includes('regular 3l') || flv.includes('cappuccino 3l') || flv.includes('fresa 3l');
  const chkRegular3L = isChk(is3L && !flv.includes('cappuccino') && !flv.includes('fresa'));
  const chkStrawberry3L = isChk(is3L && flv.includes('fresa'));
  const chkCappuccino3L = isChk(is3L && flv.includes('cappuccino'));

  const gel = (details.gelatina || '').toLowerCase();
  const isGel = flv.includes('gelatina') || gel.includes('gelatina');
  const chkMosaico = isChk(isGel && (flv.includes('mosaico') || flv.includes('mozaico') || gel.includes('mosaico') || (!flv.includes('fruta') && !gel.includes('fruta'))));
  const chkFrutas = isChk(isGel && (flv.includes('fruta') || flv.includes('artística') || gel.includes('fruta') || gel.includes('fruits')));
  const chkChcoFlan = isChk(flv.includes('chocoflan') || flv.includes('choco-flan') || gel.includes('chocoflan') || gel.includes('choco-flan'));
  const chkFlanNap = isChk(flv.includes('napolitano') || gel.includes('napolitano'));
  const chkCheeseCake = isChk(flv.includes('cheesecake') || flv.includes('cheese cake') || gel.includes('cheesecake') || gel.includes('cheese cake'));

  const sz = (details.size || '').toLowerCase();
  const chk6in = isChk(sz.includes('6'));
  const chk8in = isChk(sz.includes('8'));
  const chk10in = isChk(sz.includes('10'));
  const chk14Sheet = isChk(sz.includes('1/4'));
  const chk12Sheet = isChk(sz.includes('1/2'));
  const chkFullSheet = isChk(sz.includes('hoja') || sz.includes('completa') || sz.includes('full'));

  const fruits = details.fruits || [];
  const chkFresaFruta = isChk(fruits.includes('Fresa') || fruits.includes('Strawberry'));
  const chkDuraznoFruta = isChk(fruits.includes('Durazno') || fruits.includes('Peach'));
  const chkPinaFruta = isChk(fruits.includes('Piña') || fruits.includes('Pineapple'));
  const chkPlatanoFruta = isChk(fruits.includes('Plátano') || fruits.includes('Banana'));

  const fillings = details.fillings || [];
  const chkStrawberryFilling = isChk(fillings.includes('Strawberry') || fillings.includes('Fresa'));
  const chkPineappleFilling = isChk(fillings.includes('Pineapple') || fillings.includes('Piña'));
  const chkWhippedCream = isChk(fillings.includes('Whipped Cream') || fillings.includes('Whipped'));
  const chkBavarianCream = isChk(fillings.includes('Crema Bávara') || fillings.includes('Bavarian'));

  const workSheetHtml = `
    <div style="border: 2px solid #000; padding: 15px; background-color: #fff; color: #000; font-family: Arial, sans-serif;">
      <style>
        .checkbox-item {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-bottom: 5px;
          font-size: 11px;
          color: #000 !important;
          text-align: left;
        }
        .box {
          width: 12px;
          height: 12px;
          border: 1px solid #000;
          display: inline-block;
          text-align: center;
          line-height: 10px;
          font-size: 10px;
          font-weight: bold;
          background-color: #fff;
          color: #000 !important;
          flex-shrink: 0;
        }
        .box.checked::after {
          content: "X";
          color: #000 !important;
        }
      </style>
      
      <!-- HEADER -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; background-color: #fff; color: #000;">
        <tr>
          <td style="width: 45%; vertical-align: top; text-align: left;">
            <div style="font-size: 24px; font-weight: bold; font-style: italic; color: #000; text-align: left;">${kdsEsc(kdsBrand.name)}</div>
            <div style="font-size: 10px; color:#555; text-align: left;">${kdsEsc(kdsBrand.phone)}</div>
            <div style="font-size: 10px; color:#555; text-align: left;">${kdsEsc(kdsBrand.address)}</div>
          </td>
          <td style="width: 35%; text-align: center; vertical-align: middle;">
            <svg id="kdsBarcodeCanvas" style="height: 40px; max-width: 160px;"></svg>
          </td>
          <td style="width: 20%; text-align: right; vertical-align: top;">
            <div style="font-size: 11px; font-weight: bold; color: #000;">
              FOLIO: <span style="border-bottom:1px solid #000; display:inline-block; min-width:60px; text-align:center;">#${order.ticketNumber || order.id.substring(2, 8).toUpperCase()}</span>
            </div>
            <div style="font-size: 10px; color: #000; margin-top: 4px;">
              Ubicación: <span style="font-weight: bold; font-size:11px; text-decoration: underline;">${order.shelfLocation || 'PENDING'}</span>
            </div>
            <div style="margin-top: 6px;">
              <button onclick="printColorSheet('${order.id}')" style="padding: 4px 8px; background-color: #30d158; color: #000; font-weight: bold; border: 1px solid #000; border-radius: 4px; cursor: pointer; font-size: 10px;">Print Sheet</button>
            </div>
          </td>
        </tr>
      </table>

      <!-- DATOS DEL CLIENTE Y FECHAS -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-size: 11px; background-color: #fff; color: #000;">
        <tr>
          <!-- Info del cliente -->
          <td style="width: 75%; border: 2px solid #000; padding: 8px; vertical-align: top; text-align: left;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="width: 15%; font-weight: bold; padding: 2px 0;">Customer / Cliente:</td>
                <td style="width: 45%; padding: 2px 0;">${details.clientName}</td>
                <td style="width: 15%; font-weight: bold; padding: 2px 0;">Order Date:</td>
                <td style="width: 25%; padding: 2px 0;">${new Date(order.dateCreated).toLocaleDateString()}</td>
              </tr>
              <tr>
                <td style="font-weight: bold; padding: 2px 0;">Phone / Tel:</td>
                <td style="padding: 2px 0;">${details.clientPhone}</td>
                <td style="font-weight: bold; padding: 2px 0;">Order Time:</td>
                <td style="padding: 2px 0;">${new Date(order.dateCreated).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</td>
              </tr>
              <tr>
                <td style="font-weight: bold; padding: 2px 0; color: red;">PICKUP / ENTREGA:</td>
                <td style="padding: 2px 0; font-weight: bold; color: red; font-size: 13px;" colspan="3">${details.pickupDate} - ${details.pickupTime}</td>
              </tr>
            </table>
          </td>
          <!-- QR Track & Upload -->
          <td style="width: 25%; border: 2px solid #000; border-left: none; padding: 4px; text-align: center; vertical-align: middle; background-color: #fff;">
            <div id="kdsTrackQR" style="display: inline-block;"></div>
            <div style="font-size: 8px; font-weight: bold; color: #000; margin-top: 2px;">SCAN TO SCAN/TRACK</div>
          </td>
        </tr>
      </table>

      <!-- WEDDING EVENT SPECIFICATIONS / CHECKLIST -->
      <div style="background: #000; color: #fff; padding: 4px 8px; font-weight: bold; font-size: 11px; margin-bottom: 6px; text-transform: uppercase; text-align: left;">
        ${details.isSpecialEvent ? 'WEDDING & QUINCEAÑERA EVENT ORDER SPECIFICATIONS' : 'CUSTOM CAKE SPECIFICATIONS'}
      </div>
      
      ${details.isSpecialEvent || (details.tiersBreakdown && details.tiersBreakdown.length > 0) ? `
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr 1fr; gap: 4px; margin-bottom: 8px; font-size: 11px; font-weight: bold; background: #f0f0f0; padding: 6px; border: 1px solid #ccc; text-align: left; color:#000;">
          <div>FOLIO: <span style="color: #000;">#${order.ticketNumber || order.id.substring(2, 8).toUpperCase()}</span></div>
          <div>BOOK MODEL #: <span style="color: #000;">${details.bookModel || 'N/A'}</span></div>
          <div>CAKE SHAPE: <span style="color: #000;">${details.shape || 'Redondo'}</span></div>
          <div>GUESTS (# PPL): <span style="color: #000;">${details.ppl || 'N/A'}</span></div>
          <div>COLOR / THEME: <span style="color: #000;">${details.color || 'N/A'}</span></div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #000; margin-bottom: 10px; background-color:#fff; color:#000;">
          <thead>
            <tr style="background-color: #e0e0e0; color: #000; font-weight: bold; text-align: center; border-bottom: 2px solid #000;">
              <th style="padding: 4px; border-right: 1px solid #000; width: 12%; color:#000;">Tier / Nivel</th>
              <th style="padding: 4px; border-right: 1px solid #000; width: 18%; color:#000;">Size</th>
              <th style="padding: 4px; border-right: 1px solid #000; width: 25%; color:#000;">Flavor</th>
              <th style="padding: 4px; border-right: 1px solid #000; width: 23%; color:#000;">Filling</th>
              <th style="padding: 4px; width: 22%; color:#000;">Fruit</th>
            </tr>
          </thead>
          <tbody>
            ${tiersRows}
          </tbody>
        </table>
      ` : `
        <table style="width: 100%; border-collapse: collapse; font-size: 11px; border: 1px solid #000; margin-bottom: 10px; background-color: #fff; color: #000;">
          <thead>
            <tr style="background-color: #000; color: #fff; font-weight: bold; text-align: center; border-bottom: 2px solid #000;">
              <th style="padding: 4px; width: 16.6%; color: #fff;">Size</th>
              <th style="padding: 4px; width: 16.6%; color: #fff;">Flavor Available</th>
              <th style="padding: 4px; width: 16.6%; color: #fff;">Fruits</th>
              <th style="padding: 4px; width: 16.6%; color: #fff;">Filling</th>
              <th style="padding: 4px; width: 16.6%; color: #fff;">3 Leches</th>
              <th style="padding: 4px; width: 16.6%; color: #fff;">Otros</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <!-- Size -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chk6in}"></span> 6"</div>
                <div class="checkbox-item"><span class="box ${chk8in}"></span> 8"</div>
                <div class="checkbox-item"><span class="box ${chk10in}"></span> 10"</div>
                <div class="checkbox-item"><span class="box ${chk14Sheet}"></span> 1/4 Sheet</div>
                <div class="checkbox-item"><span class="box ${chk12Sheet}"></span> 1/2 Sheet</div>
                <div class="checkbox-item"><span class="box ${chkFullSheet}"></span> Full Sheet</div>
                <div style="margin-top: 10px; font-weight: bold; color:#000; text-align: left;">Num. Ppl: ${details.ppl || '-'}</div>
              </td>
              <!-- Flavor -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chkChocolate}"></span> Chocolate</div>
                <div class="checkbox-item"><span class="box ${chkYellow}"></span> Yellow</div>
                <div class="checkbox-item"><span class="box ${chk1212}"></span> 1/2 & 1/2</div>
                <div class="checkbox-item"><span class="box ${chkMarble}"></span> Marble</div>
              </td>
              <!-- Fruits -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chkFresaFruta}"></span> Strawberry</div>
                <div class="checkbox-item"><span class="box ${chkDuraznoFruta}"></span> Peach</div>
                <div class="checkbox-item"><span class="box ${chkPinaFruta}"></span> Pineapple</div>
                <div class="checkbox-item"><span class="box ${chkPlatanoFruta}"></span> Banana</div>
              </td>
              <!-- Filling -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chkStrawberryFilling}"></span> Strawberry</div>
                <div class="checkbox-item"><span class="box ${chkPineappleFilling}"></span> Pineapple</div>
                <div class="checkbox-item"><span class="box ${chkWhippedCream}"></span> Whipped Cream</div>
                <div class="checkbox-item"><span class="box ${chkBavarianCream}"></span> Bavarian Cream</div>
              </td>
              <!-- 3 Leches -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chkRegular3L}"></span> Regular</div>
                <div class="checkbox-item"><span class="box ${chkStrawberry3L}"></span> Strawberry</div>
                <div class="checkbox-item"><span class="box ${chkCappuccino3L}"></span> Cappuccino</div>
              </td>
              <!-- Otros -->
              <td style="border: 1px solid #ccc; padding: 6px; vertical-align: top; color:#000;">
                <div class="checkbox-item"><span class="box ${chkMosaico}"></span> Gelatina Mosaico</div>
                <div class="checkbox-item"><span class="box ${chkFrutas}"></span> Gelatina de Frutas</div>
                <div class="checkbox-item"><span class="box ${chkChcoFlan}"></span> Chocoflan</div>
                <div class="checkbox-item"><span class="box ${chkFlanNap}"></span> Flan Napolitano</div>
                <div class="checkbox-item"><span class="box ${chkCheeseCake}"></span> Cheesecake</div>
              </td>
            </tr>
          </tbody>
        </table>
      `}

      <!-- NOTES -->
      <div style="background: #000; color: #fff; padding: 4px 8px; font-weight: bold; font-size: 11px; margin-bottom: 4px; text-align: left;">DECORATION SPECIFICATIONS / NOTES</div>
      <div style="font-size: 12px; font-weight: bold; color: #000; background: #fffbe6; padding: 6px; border: 1px solid #ffe58f; margin-bottom: 8px; min-height: 35px; text-align: left;">
        ${details.notes || 'No extra notes.'}
      </div>

      <!-- PHOTO -->
      ${details.photoUrl ? `
        <div style="background: #000; color: #fff; padding: 4px 8px; font-weight: bold; font-size: 11px; margin-bottom: 4px; text-align: left;">REFERENCE PHOTO</div>
        <div style="text-align: center; margin-bottom: 8px;">
          <img src="${details.photoUrl}" style="max-height: 220px; max-width: 100%; border: 1px solid #ccc; border-radius: 4px;" alt="Design Reference">
        </div>
      ` : ''}

      <!-- PRICING -->
      <div style="display: flex; justify-content: flex-end; gap: 15px; font-size: 12px; font-weight: bold; border-top: 1px solid #000; padding-top: 6px;">
        <div>Price: $${(details.totalPrice || order.total || 0).toFixed(2)}</div>
        <div style="color: green;">Deposit Paid Today: $${(details.deposit || order.deposit || 0).toFixed(2)}</div>
        <div style="color: red;">Balance Due on Pickup: $${(details.balance || Math.max(0, (details.totalPrice || order.total || 0) - (details.deposit || order.deposit || 0))).toFixed(2)}</div>
      </div>
    </div>
  `;

  if (rightPanelContent) {
    rightPanelContent.innerHTML = workSheetHtml.replace('id="kdsBarcodeCanvas"', 'id="kdsBarcodeCanvas_right"').replace('id="kdsTrackQR"', 'id="kdsTrackQR_right"');
  }

  if (modalBody && modal) {
    modalBody.innerHTML = workSheetHtml.replace('id="kdsBarcodeCanvas"', 'id="kdsBarcodeCanvas_modal"').replace('id="kdsTrackQR"', 'id="kdsTrackQR_modal"');
    modal.style.display = 'flex';
    const btnPrintFromModal = document.getElementById('btnPrintWorkSheetFromModal');
    if (btnPrintFromModal) {
      btnPrintFromModal.style.display = 'inline-block';
      btnPrintFromModal.innerHTML = (currentLanguage === 'es' ? 'Imprimir Hoja' : 'Print Sheet') + ' <span style="background: rgba(0,0,0,0.25); padding: 2px 6px; border-radius: 4px; font-size: 11px; margin-left: 6px; border: 1px solid rgba(255,255,255,0.2);">[*] / [Enter]</span>';
      btnPrintFromModal.onclick = () => printColorSheet(orderId);
    }
  }

  // Draw barcode and QR dynamically
  const drawBarcodeAndQR = () => {
    try {
      const barcodeValue = String(order.ticketNumber || order.id.replace(/\D/g, '').substring(0, 8));
      if (typeof JsBarcode !== 'undefined') {
        const canvasRight = document.getElementById('kdsBarcodeCanvas_right');
        if (canvasRight) {
          JsBarcode(canvasRight, barcodeValue, {
            format: "CODE128",
            width: 1.5,
            height: 25,
            displayValue: true,
            fontSize: 9,
            margin: 0
          });
        }
        const canvasModal = document.getElementById('kdsBarcodeCanvas_modal');
        if (canvasModal) {
          JsBarcode(canvasModal, barcodeValue, {
            format: "CODE128",
            width: 1.5,
            height: 25,
            displayValue: true,
            fontSize: 9,
            margin: 0
          });
        }
      }
    } catch(e) {
      console.error("JsBarcode generation failed in KDS:", e);
    }

    try {
      if (typeof QRCode !== 'undefined') {
        const qrRight = document.getElementById('kdsTrackQR_right');
        if (qrRight) {
          qrRight.innerHTML = '';
          new QRCode(qrRight, {
            text: order.id,
            width: 80,
            height: 80,
            colorDark : "#000000",
            colorLight : "#ffffff"
          });
        }
        const qrModal = document.getElementById('kdsTrackQR_modal');
        if (qrModal) {
          qrModal.innerHTML = '';
          new QRCode(qrModal, {
            text: order.id,
            width: 80,
            height: 80,
            colorDark : "#000000",
            colorLight : "#ffffff"
          });
        }
      }
    } catch(e) {
      console.error("QRCode generation failed in KDS:", e);
    }
  };

  setTimeout(drawBarcodeAndQR, 50);
}

// Ver foto de diseño
function viewReferencePhoto(url) {
  if (!url || url.trim() === '') {
    showToast('No custom design photo uploaded for this order / No se subió foto de diseño para esta orden', 'warning');
    return;
  }
  const viewer = document.getElementById('modalPhotoViewer');
  const img = document.getElementById('modalViewerImage');
  
  img.onerror = () => {
    img.onerror = null; // Prevent infinite loop recursive trigger when setting src = ''
    img.src = '';
    viewer.style.display = 'none';
    showToast('Error loading custom photo / Error al cargar la foto de diseño', 'error');
  };
  
  img.onload = () => {
    img.onerror = null; // reset
  };
  
  img.src = url;
  viewer.style.display = 'flex';
}

// Ver foto del modelo de libro de pasteles
function viewBookModelPhoto(bookModel) {
  if (!bookModel || bookModel.trim() === '' || bookModel === 'N/A') {
    showToast('No book model number specified for this cake / No se especificó número de modelo para este pastel', 'warning');
    return;
  }
  const viewer = document.getElementById('modalPhotoViewer');
  const img = document.getElementById('modalViewerImage');
  
  img.onerror = () => {
    img.onerror = null; // Prevent infinite loop recursive trigger when setting src = ''
    img.src = '';
    viewer.style.display = 'none';
    showToast(`No photo uploaded for Model #${bookModel} / No hay foto cargada para el Modelo #${bookModel}`, 'warning');
  };
  
  img.onload = () => {
    img.onerror = null; // reset
  };
  
  // Guardamos url del modelo
  const modelUrl = `/uploads/models/model_${bookModel.trim()}.jpg`;
  img.src = modelUrl;
  viewer.style.display = 'flex';
}

// --- BUMP BAR TECLADO (1 al 9) ---
function setupEventListeners() {
  // No active station filter buttons to bind

  const btnScrollBack = document.getElementById('btnKdsScrollBack');
  const btnScrollNext = document.getElementById('btnKdsScrollNext');
  
  if (btnScrollBack) {
    btnScrollBack.onclick = (e) => {
      e.preventDefault();
      if (currentPage > 0) {
        currentPage--;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
      } else {
        showToast(
          currentMaxPage === 0
            ? (currentLanguage === 'es' ? 'Pagina 1 de 1: Todas las ordenes activas caben en esta pantalla (maximo 10)' : 'Page 1 of 1: All active orders fit on this screen (max 10)')
            : (currentLanguage === 'es' ? 'Ya estas en la primera pagina' : 'You are already on the first page'),
          'info',
          2500
        );
      }
    };
  }
  
  if (btnScrollNext) {
    btnScrollNext.onclick = (e) => {
      e.preventDefault();
      if (currentPage < currentMaxPage) {
        currentPage++;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
      } else {
        showToast(
          currentMaxPage === 0
            ? (currentLanguage === 'es' ? 'Pagina 1 de 1: Todas las ordenes activas caben en esta pantalla (maximo 10)' : 'Page 1 of 1: All active orders fit on this screen (max 10)')
            : (currentLanguage === 'es' ? 'Ya estas en la ultima pagina' : 'You are already on the last page'),
          'info',
          2500
        );
      }
    };
  }

  const btnKiosk = document.getElementById('btnDownloadKioskDirect');
  if (btnKiosk) {
    btnKiosk.onclick = (e) => {
      e.preventDefault();
      downloadKioskShortcutForThisStation();
    };
  }

  // Escuchar teclado para Bump Bar Hardware y Teclados Numéricos USB
  window.addEventListener('keydown', (e) => {
    // Si el usuario está escribiendo en un input de texto, no interceptar (excepto Escape)
    if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA')) {
      if (e.key === 'Escape') {
        document.activeElement.blur();
        closeAllModals();
      }
      return;
    }

    let key = e.key;

    // Normalizar teclas de Teclado Numérico (Numpad) tanto con NumLock ON como NumLock OFF
    if (e.code && e.code.startsWith('Numpad')) {
      const numMatch = e.code.match(/Numpad([0-9])/);
      if (numMatch) {
        key = numMatch[1];
      } else if (e.code === 'NumpadDecimal') {
        key = 'Delete';
      } else if (e.code === 'NumpadEnter') {
        key = 'Enter';
      } else if (e.code === 'NumpadAdd') {
        key = '+';
      } else if (e.code === 'NumpadSubtract') {
        key = '-';
      } else if (e.code === 'NumpadMultiply') {
        key = '*';
      } else if (e.code === 'NumpadDivide') {
        key = '/';
      }
    }

    // Detectar si alguna ventana modal está visible en pantalla
    const isModalOpen = Array.from(document.querySelectorAll('.modal')).some(m => m.style.display && m.style.display !== 'none');

    // ==========================================
    // CASO 1: VENTANA MODAL ABIERTA (VER TICKET COMPLETO O FOTO)
    // ==========================================
    if (isModalOpen) {
      // Teclas * o Enter: Imprimir comanda / ticket de cocina
      if (key === '*' || key === 'Enter') {
        e.preventDefault();
        const printBtn = document.getElementById('btnPrintWorkSheetFromModal') || document.getElementById('btnPrintReferencePhoto');
        if (printBtn && printBtn.offsetParent !== null) {
          printBtn.click();
        }
        return;
      }

      // Teclas Backspace (<-), /, Delete, ., Tab, Escape: Cerrar ventana modal
      if (key === 'Backspace' || key === '/' || key === 'Delete' || key === '.' || key === 'Tab' || key === 'Escape') {
        e.preventDefault();
        closeAllModals();
        return;
      }

      // Teclas numéricas 0 al 9: Cerrar el modal y seleccionar la comanda directamente
      if (key >= '0' && key <= '9') {
        e.preventDefault();
        closeAllModals();
        selectCardByKey(key);
        return;
      }

      // Teclas + y - dentro del modal: Cerrar modal y navegar a la siguiente o anterior comanda
      if (key === '+') {
        e.preventDefault();
        closeAllModals();
        selectNextCard();
        return;
      }
      if (key === '-') {
        e.preventDefault();
        closeAllModals();
        selectPrevCard();
        return;
      }

      return;
    }

    // ==========================================
    // CASO 2: PANTALLA PRINCIPAL DEL KDS (TARJETAS DE COMANDAS)
    // ==========================================

    // 1. Teclas del 0 al 9: SELECCIONAR LA COMANDA ESPECÍFICA DIRECTAMENTE (1 a 9, y 0 para la 10ma)
    if (key >= '0' && key <= '9') {
      e.preventDefault();
      selectCardByKey(key);
      return;
    }

    // 2. Tecla MAS (+): AVANZAR DE COMANDA EN COMANDA (1 -> 2 -> 3 -> 4...)
    if (key === '+') {
      e.preventDefault();
      selectNextCard();
      return;
    }

    // 3. Tecla MENOS (-): RETROCEDER DE COMANDA EN COMANDA (4 -> 3 -> 2 -> 1...)
    if (key === '-') {
      e.preventDefault();
      selectPrevCard();
      return;
    }

    // 4. Tecla ENTER: ENTRAR / VER TICKET COMPLETO (VIEW / SHEET)
    if (key === 'Enter') {
      e.preventDefault();
      const card = getSelectedOrFirstCard();
      if (card) {
        // En órdenes de pastel: botón Sheet. En comida: botón View.
        const viewBtn = card.querySelector('.btn-kds:not(.bump):not(.print-label)') || card.querySelector('.btn-kds');
        if (viewBtn) viewBtn.click();
      }
      return;
    }

    // 5. Tecla DELETE o PUNTO (.): DESPACHAR / BORRAR / BUMP (ÚNICA TECLA DE DESPACHO) O RESTAURAR EN PAST ORDERS
    if (key === 'Delete' || key === '.') {
      e.preventDefault();
      const card = getSelectedOrFirstCard();
      if (card) {
        if (showPastOrders) {
          const restoreBtn = card.querySelector('.btn-kds[onclick*="restoreOrder"]') || card.querySelector('.btn-kds');
          if (restoreBtn) restoreBtn.click();
        } else {
          const bumpBtn = card.querySelector('.btn-kds.bump') || card.querySelector('.btn-kds[onclick*="bumpOrder"]');
          if (bumpBtn) bumpBtn.click();
        }
      }
      return;
    }

    // 6. Tecla TAB: NAVEGAR PÁGINA SIGUIENTE O ALTERNAR PESTAÑAS (ACTIVE ⇄ PAST)
    if (key === 'Tab') {
      e.preventDefault();
      if (currentPage < currentMaxPage) {
        currentPage++;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
      } else {
        // Si ya está en la última página o solo hay 1 página, alterna a la otra pestaña
        showPastOrders = !showPastOrders;
        currentPage = 0;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
        showToast(showPastOrders ? 'Past Orders (Historial)' : 'Active Orders (Cocina Activa)', 'info', 2000);
      }
      return;
    }

    // 7. Tecla BACKSPACE (<-): REGRESAR PÁGINA O A LA PRIMERA COMANDA
    if (key === 'Backspace') {
      e.preventDefault();
      if (currentPage > 0) {
        currentPage--;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
      } else {
        selectCardByKey('1');
      }
      return;
    }

    // 8. Tecla ASTERISCO (*):
    // Si la comanda es de pastel, abre Model. Si es comida, alterna Active / Past.
    if (key === '*') {
      e.preventDefault();
      const card = getSelectedOrFirstCard();
      const modelBtn = card ? card.querySelector('.btn-kds[onclick*="viewBookModelPhoto"]') : null;
      if (modelBtn) {
        modelBtn.click();
      } else {
        showPastOrders = !showPastOrders;
        currentPage = 0;
        renderKDS();
        setTimeout(() => selectCardByKey('1'), 50);
        showToast(showPastOrders ? 'Past Orders (Historial)' : 'Active Orders (Cocina Activa)', 'info', 2000);
      }
      return;
    }

    // 9. Tecla BARRA (/):
    // Si la comanda es de pastel, abre Photo. Si es comida, abre View.
    if (key === '/') {
      e.preventDefault();
      const card = getSelectedOrFirstCard();
      const photoBtn = card ? card.querySelector('.btn-kds[onclick*="viewReferencePhoto"]') : null;
      if (photoBtn) {
        photoBtn.click();
      } else if (card) {
        const viewBtn = card.querySelector('.btn-kds:not(.bump):not(.print-label)') || card.querySelector('.btn-kds');
        if (viewBtn) viewBtn.click();
      }
      return;
    }

    // 10. Navegación por flechas o Re Pág / Av Pág
    if (key === 'ArrowRight' || key === 'ArrowDown' || key === 'PageDown') {
      e.preventDefault();
      selectNextCard();
      return;
    }
    if (key === 'ArrowLeft' || key === 'ArrowUp' || key === 'PageUp') {
      e.preventDefault();
      selectPrevCard();
      return;
    }

    // 11. Tecla ESCAPE: Cerrar modal
    if (key === 'Escape') {
      e.preventDefault();
      closeAllModals();
      return;
    }
  });

  // Modal close buttons
  document.querySelectorAll('.close-modal, #btnCancelLoc').forEach(btn => {
    btn.addEventListener('click', () => {
      closeAllModals();
    });
  });

  // Imprimir foto de azúcar
  const btnPrint = document.getElementById('btnPrintReferencePhoto');
  if (btnPrint) {
    btnPrint.addEventListener('click', () => {
      const img = document.getElementById('modalViewerImage');
      if (img && img.src) {
        const printWin = window.open('', '_blank');
        printWin.document.write(`
          <html>
            <head>
              <title>Edible Photo Print</title>
              <style>
                body { margin: 0; display: flex; align-items: center; justify-content: center; height: 100vh; background-color: white; }
                img { max-height: 100%; max-width: 100%; object-fit: contain; }
                @page { size: auto; margin: 0mm; }
              </style>
            </head>
            <body>
              <img src="${img.src}" onload="window.print(); setTimeout(function(){ window.close(); }, 500);">
            </body>
          </html>
        `);
        printWin.document.close();
      }
    });
  }

  // Guardar ubicación en el refrigerador
  const locBtns = document.querySelectorAll('#modalLocation .btn-option');
  locBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      locBtns.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      selectedLocationName = btn.getAttribute('data-loc');
    });
  });

  // Keypress Enter on employee code input triggers Save button (hands-free card reader)
  const locInput = document.getElementById('locEmployeeCode');
  if (locInput) {
    // Remove previous listeners by replacing node or adding once
    const newLocInput = locInput.cloneNode(true);
    locInput.parentNode.replaceChild(newLocInput, locInput);
    newLocInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        document.getElementById('btnSaveLoc').click();
      }
    });
  }

  document.getElementById('btnSaveLoc').addEventListener('click', () => {
    const code = document.getElementById('locEmployeeCode').value;
    if (!code || !selectedLocationName) {
      showToast(currentLanguage === 'es' ? 'Escanea tu tarjeta y selecciona un refrigerador' : 'Scan card and select a refrigerator location', 'error');
      return;
    }

    // Validar empleado con la base de datos real
    const cleanCode = code.trim();
    const matchedEmp = employees.find(e => e.passcode === cleanCode || e.cardCode === cleanCode || e.id === cleanCode);
    let employeeName = matchedEmp ? matchedEmp.name : '';

    if (!employeeName) {
      showToast(currentLanguage === 'es' ? 'Tarjeta o código inválido' : 'Invalid employee card or code', 'error');
      document.getElementById('locEmployeeCode').value = '';
      document.getElementById('locEmployeeCode').focus();
      return;
    }

    completeOrderStatus(selectedOrderIdForLocation, 'listo', selectedLocationName, employeeName);
    closeAllModals();
  });

  // Toggle de vistas
  document.getElementById('btnActiveOrders').addEventListener('click', () => {
    document.getElementById('modalCalendar').style.display = 'none';
    showPastOrders = false;
    loadOrders();
  });

  const btnPast = document.getElementById('btnPastOrders');
  if (btnPast) {
    btnPast.addEventListener('click', () => {
      document.getElementById('modalCalendar').style.display = 'none';
      showPastOrders = true;
      loadOrders();
    });
  }

  document.getElementById('btnCalendarView').addEventListener('click', () => {
    document.getElementById('modalCalendar').style.display = 'flex';
    renderCalendar();
  });

  // Navegación del Calendario
  document.getElementById('btnPrevMonth').addEventListener('click', () => {
    currentMonth--;
    if (currentMonth < 0) {
      currentMonth = 11;
      currentYear--;
    }
    renderCalendar();
  });

  document.getElementById('btnNextMonth').addEventListener('click', () => {
    currentMonth++;
    if (currentMonth > 11) {
      currentMonth = 0;
      currentYear++;
    }
    renderCalendar();
  });
}

function closeAllModals() {
  document.querySelectorAll('.modal').forEach(modal => modal.style.display = 'none');
}

// --- CALENDARIO DE PRODUCCIÓN ---
function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  grid.innerHTML = '';

  const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
  const calTitle = activeStation === 'bakery' ? 'Calendario de Pasteles' : 'Calendario de Cocina / Anticipadas';
  document.getElementById('calendarMonthTitle').innerText = `${calTitle} - ${monthNames[currentMonth]} ${currentYear}`;

  // Cabecera de días
  const daysHeader = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  daysHeader.forEach(d => {
    const div = document.createElement('div');
    div.className = 'calendar-day-header';
    div.innerText = d;
    grid.appendChild(div);
  });

  const firstDay = new Date(currentYear, currentMonth, 1).getDay();
  const totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();

  // Rellenar espacios en blanco del mes anterior
  for (let i = 0; i < firstDay; i++) {
    const cell = document.createElement('div');
    cell.style.visibility = 'hidden';
    grid.appendChild(cell);
  }

  // Rellenar celdas de días
  for (let day = 1; day <= totalDays; day++) {
    const cell = document.createElement('div');
    cell.className = 'calendar-day-cell';
    
    const dateString = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    
    // Contar cuántas órdenes hay para este día según la estación
    let dayOrders = [];
    if (activeStation === 'bakery') {
      dayOrders = orders.filter(order => {
        const cakeItem = order.items && order.items.find(i => i.isCustomCake);
        if (!cakeItem || !cakeItem.details || !cakeItem.details.pickupDate) return false;
        const dateParts = cakeItem.details.pickupDate.split('-');
        if (dateParts.length !== 3) return false;
        const pYear = parseInt(dateParts[0], 10);
        const pMonth = parseInt(dateParts[1], 10) - 1; // 0-indexed month
        const pDay = parseInt(dateParts[2], 10);
        return pYear === currentYear && pMonth === currentMonth && pDay === day;
      });
    } else {
      // Estación 2: To-Go / Cocina. Filtrar por scheduledDate
      dayOrders = orders.filter(order => {
        if (!order.scheduledDate) return false;
        const dateParts = order.scheduledDate.split('-');
        if (dateParts.length !== 3) return false;
        const pYear = parseInt(dateParts[0], 10);
        const pMonth = parseInt(dateParts[1], 10) - 1;
        const pDay = parseInt(dateParts[2], 10);
        return pYear === currentYear && pMonth === currentMonth && pDay === day;
      });
    }

    const label = activeStation === 'bakery' ? 'Cakes' : 'Orders';
    cell.innerHTML = `
      <div class="calendar-day-num">${day}</div>
      ${dayOrders.length > 0 ? `<div class="calendar-day-orders-count" style="${activeStation !== 'bakery' ? 'background-color: #0a84ff; color: #fff;' : ''}">${dayOrders.length} ${label}</div>` : '<div style="font-size:10px; color:var(--text-secondary); margin-top:4px;">No Orders</div>'}
    `;

    if (dayOrders.length > 0) {
      cell.style.cursor = 'pointer';
      if (activeStation === 'bakery') {
        cell.style.border = '2px solid var(--accent-color)';
        cell.style.backgroundColor = 'rgba(255, 159, 10, 0.15)';
      } else {
        cell.style.border = '2px solid #0a84ff';
        cell.style.backgroundColor = 'rgba(10, 132, 255, 0.15)';
      }
    }

    cell.addEventListener('click', () => {
      showOrdersForDay(dateString, dayOrders);
    });

    grid.appendChild(cell);
  }
}

// Mostrar lista de pedidos al hacer clic en un día del calendario
function showOrdersForDay(dateString, dayOrders) {
  clearRightPanel();
  if (dayOrders) {
    dayOrders.sort(sortCustomCakes);
  }
  closeAllModals();
  const container = document.getElementById('kdsContainer');

  const isBakery = activeStation === 'bakery';
  const label = isBakery ? 'Cakes / Pasteles' : 'Orders / Pedidos';
  const color = isBakery ? 'var(--accent-color)' : '#0a84ff';

  if (!dayOrders || dayOrders.length === 0) {
    container.innerHTML = `
      <div style="width: 100%; text-align: center; margin-top: 60px;">
        <h3 style="color:var(--text-secondary);">No scheduled orders for date: ${dateString}</h3>
        <button class="btn-header" onclick="loadOrders()" style="margin-top: 20px; background-color: ${color}; color: #000; font-weight: bold; padding: 10px 20px;">Show All Active Orders</button>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div style="width: 100%; display: flex; justify-content: space-between; align-items: center; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 8px; margin-bottom: 10px;">
      <h3 style="color:${color}; margin: 0; font-size: 16px;">Scheduled Orders for (${formatDateHeader(dateString)}) - [${dayOrders.length} ${label}]:</h3>
      <button class="btn-header" onclick="loadOrders()" style="background-color: ${color}; color: #000; font-weight: bold;">Show All Active Orders</button>
    </div>
  `;

  // No auto-load order details by default to keep screen clean

  dayOrders.forEach((order, index) => {
    const isAnticipated = !!order.scheduledDate;
    const card = document.createElement('div');
    card.className = `kds-card ${isAnticipated ? 'anticipated' : ''} type-${order.type || 'llevar'}`;
    card.setAttribute('data-bump-key', index + 1);
    
    const cakeItem = order.items && order.items.find(i => i.isCustomCake);
    const details = cakeItem ? cakeItem.details : null;
    
    let itemsHtml = '';
    let isCakeOrder = false;

    order.items.forEach(item => {
      let specs = '';
      if (item.isCustomCake) {
        isCakeOrder = true;
        let tiersHtml = '';
        if (item.details.tiersBreakdown && item.details.tiersBreakdown.length > 0) {
          tiersHtml = `<div style="margin-top: 6px; background: rgba(0,0,0,0.3); padding: 6px; border-radius: 4px; font-size: 13px; line-height: 1.4;">
            <strong style="color: var(--accent-color);">TIER BREAKDOWN:</strong><br>`;
          item.details.tiersBreakdown.forEach(t => {
            tiersHtml += `• <strong>Piso ${t.tier} (${t.size || ''}):</strong> Flavor: ${t.flavor} | Filling: ${t.filling} | Fruit: ${t.fruit}<br>`;
          });
          tiersHtml += '</div>';
        }

        const weddingInfo = item.details.isSpecialEvent ? `
          <div style="font-size: 13px; font-weight: bold; color: var(--accent-color); margin-bottom: 4px;">
            ${item.details.folio ? `FOLIO: ${item.details.folio} | ` : ''} MODEL #: ${item.details.bookModel || 'N/A'}<br>
            SHAPE: ${item.details.shape || 'Round'} | GUESTS: ${item.details.ppl || 'N/A'} | COLOR: ${item.details.color || 'N/A'}
          </div>
        ` : '';

        specs = `
          <div class="kds-item-specs">
            ${weddingInfo}
            ${!item.details.isSpecialEvent ? `
              <strong>Flavor:</strong> ${item.details.flavor} | <strong>Size:</strong> ${item.details.size}<br>
              <strong>Fillings:</strong> ${item.details.fillings ? item.details.fillings.join(', ') : 'N/A'}<br>
              <strong>Fruits:</strong> ${item.details.fruits ? item.details.fruits.join(', ') : 'N/A'}
            ` : ''}
            ${tiersHtml}
          </div>
          ${item.details.notes ? `<div class="kds-item-notes" style="font-size: 14px; font-weight: bold; color: #ffeb3b; background: rgba(255,235,59,0.1); padding: 6px; border-radius: 4px; margin-top: 6px;">NOTES: ${item.details.notes}</div>` : ''}
        `;
      } else if (item.selectedModifiers && item.selectedModifiers.length > 0) {
        specs = `<div class="kds-item-specs" style="margin-top: 2px; display: block; width: 100%;">
          ${getSortedFormattedModifiers(item.selectedModifiers, true)}
        </div>`;
      }

      const isItemToGo = item.isToGo || item.name.includes('(To Go)') || item.name.includes('(to go)');
      const itemStyle = `font-size: 11px; font-weight: 600; color: #fff;`;

      const seatMatch = item.name.match(/\((?:Cliente|Guest)\s*(\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
      const clientBadge = seatMatch 
        ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 4px; padding: 1px 4px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">G${seatMatch[1]}</span>` 
        : '';
      const cleanName = item.name.replace(/\((?:Cliente|Guest)\s*\d+\)/gi, '').replace(/\(Seat \d+\)/i, '').replace(/\(to go\)/gi, '').trim();

      itemsHtml += `
        <div class="kds-item" style="display: flex; align-items: center; flex-wrap: wrap; margin-bottom: 4px; width: 100%;">
          ${clientBadge}
          <span class="kds-item-name" style="${itemStyle}">${item.quantity} ${cleanName}${isItemToGo ? ' <span style="color: #ff453a; font-weight: 900; margin-left: 6px;">TO GO</span>' : ''}</span>
          ${specs}
        </div>
      `;
    });

    const pastTicketNum = String(order.ticketDisplay || order.ticketNumber || (order.id ? String(order.id).replace(/\D/g, '').slice(-4) : '101')).replace(/[^0-9A-Za-z\-]/g, '') || '101';
    card.innerHTML = `
      <div class="kds-card-header">
        <span class="kds-card-num">#${pastTicketNum}</span>
        <span class="kds-card-time" style="color:var(--success-color)">${order.status.toUpperCase()}</span>
      </div>
      <div class="kds-card-body">
        ${isCakeOrder && details ? `
          <div class="kds-client-info">
            <strong>Deliver:</strong> ${details.pickupDate || 'N/A'} - ${details.pickupTime || 'N/A'}<br>
            <strong>Customer:</strong> ${details.clientName || 'N/A'} (${details.clientPhone || 'N/A'})
          </div>
        ` : (order.scheduledDate ? `
          <div class="kds-client-info" style="border: 1px solid #0a84ff; background-color: rgba(10,132,255,0.1); color: #fff; padding: 4px; border-radius: 4px; margin-bottom: 6px;">
            <strong>ANTICIPATE ORDER:</strong><br>
            ${order.scheduledDate} ${order.scheduledTime ? `at ${order.scheduledTime}` : ''}
          </div>
        ` : '')}
        ${itemsHtml}
      </div>
      <div class="kds-card-footer" style="padding: 8px; display: flex; flex-direction: column; gap: 6px; background-color: #151518;">
        ${isCakeOrder ? `
          <!-- Row 1: Sheet & Model -->
          <div style="display: flex; gap: 6px; width: 100%;">
            <button class="btn-kds" onclick="openWorkSheetModal('${order.id}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: var(--accent-color); color: #000;">Sheet</button>
            <button class="btn-kds" onclick="viewBookModelPhoto('${details ? details.bookModel || '' : ''}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #ff9f0a; color: #000;">Model</button>
          </div>
          <!-- Row 2: Photo & Bump/Restore -->
          <div style="display: flex; gap: 6px; width: 100%;">
            <button class="btn-kds" onclick="viewReferencePhoto('${details ? details.photoUrl || '' : ''}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #bf5af2; color: #fff;">Photo</button>
            ${order.status === 'completado' || order.status === 'entregado' || order.status === 'cancelado' || order.status === 'listo' ? `
              <button class="btn-kds" onclick="restoreOrder('${order.id}')" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold; background-color: #ff9f0a; color: #000;">Restore</button>
            ` : `
              <button class="btn-kds bump" onclick="bumpOrder('${order.id}', ${isCakeOrder})" style="flex: 1; padding: 6px; font-size: 11px; font-weight: bold;">✓ Bump</button>
            `}
          </div>
        ` : `
          <div style="display: flex; gap: 6px; width: 100%;">
            <button class="btn-kds" onclick="openWorkSheetModal('${order.id}')" style="flex: 1; padding: 8px; font-size: 12px; font-weight: bold; background-color: var(--accent-color); color: #000;">View</button>
            ${order.status === 'completado' || order.status === 'entregado' || order.status === 'cancelado' || order.status === 'listo' ? `
              <button class="btn-kds" onclick="restoreOrder('${order.id}')" style="flex: 1; padding: 8px; font-size: 12px; font-weight: bold; background-color: #ff9f0a; color: #000;">Restore</button>
            ` : `
              <button class="btn-kds bump" onclick="bumpOrder('${order.id}', ${isCakeOrder})" style="flex: 1; padding: 8px; font-size: 12px; font-weight: bold;">✓ Bump</button>
            `}
          </div>
        `}
      </div>
    `;

    container.appendChild(card);
  });
}

// Reproducir sonido de comanda
function playAlertSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const audioContext = new AudioCtx();
    const now = audioContext.currentTime;
    
    // Repique de campana de cocina: "tin tin tin tin tin tin"
    const chimeFrequencies = [1174.66, 1318.51, 1174.66, 1318.51, 1567.98, 2093.00]; // D6, E6, D6, E6, G6, C7
    chimeFrequencies.forEach((freq, idx) => {
      const startTime = now + (idx * 0.12);
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      
      osc.type = 'triangle'; // tono campana metálica brillante
      osc.frequency.setValueAtTime(freq, startTime);
      
      gain.gain.setValueAtTime(0.7, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);
      
      osc.connect(gain);
      gain.connect(audioContext.destination);
      
      osc.start(startTime);
      osc.stop(startTime + 0.22);
    });
  } catch (e) {
    console.log("Audio no permitido sin interacción inicial:", e);
  }
}

// --- ALERTA TOAST ---
function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  toast.className = `toast ${type}`;
  toastText.innerText = text;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

async function printKdsTicket(orderId) {
  try {
    const station = new URLSearchParams(window.location.search).get('station') || 'bakery';
    let printerIndex = 1;
    if (station === 'togo') {
      printerIndex = 2;
    } else if (station === 'station3') {
      printerIndex = 3;
    }
    
    const response = await fetch(`${SERVER_URL}/api/printer/print-kitchen/${orderId}?printerIndex=${printerIndex}`, {
      method: 'POST'
    });
    
    if (response.ok) {
      showToast(currentLanguage === 'es' ? 'Ticket enviado a la impresora de cocina!' : 'Ticket sent to kitchen printer!', 'success');
    } else {
      const errData = await response.json();
      showToast((currentLanguage === 'es' ? 'Error al imprimir: ' : 'Print error: ') + (errData.error || 'Unknown'), 'error');
    }
  } catch (e) {
    console.error("Error printing KDS ticket:", e);
    showToast(currentLanguage === 'es' ? 'Error de conexión con la impresora' : 'Connection error with printer', 'error');
  }
}

window.printKdsTicket = printKdsTicket;

// Registrar pago de la comanda en KDS
async function registerOrderPayment(orderId) {
  const isEs = currentLanguage === 'es';
  if (!confirm(isEs ? '¿Está seguro de que desea marcar este pedido como PAGADO?' : 'Are you sure you want to mark this order as PAID?')) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/${orderId}/pay`, {
      method: 'PUT'
    });
    if (res.ok) {
      showToast(isEs ? '¡Pedido marcado como pagado exitosamente!' : 'Order marked as paid successfully!', 'success');
      loadOrders();
    } else {
      const err = await res.json();
      showToast((isEs ? 'Error al registrar pago: ' : 'Error registering payment: ') + (err.error || 'Unknown error'), 'error');
    }
  } catch (e) {
    console.error(e);
    showToast(isEs ? 'Error de conexión con el servidor' : 'Error connecting to server to register payment', 'error');
  }
}
window.registerOrderPayment = registerOrderPayment;

// --- DESCARGAR ACCESO DIRECTO DE KIOSCO PARA ESTA ESTACIÓN ---
function downloadKioskShortcutForThisStation() {
  const isEs = currentLanguage === 'es';
  const urlParams = new URLSearchParams(window.location.search);
  const stationParam = urlParams.get('station') || '';
  const isBakery = stationParam.toLowerCase().includes('bakery') || stationParam.toLowerCase().includes('cake') || stationParam.toLowerCase().includes('pastel');
  
  const stationId = isBakery ? 'cocina_pasteleria' : 'cocina';
  const stationName = isBakery ? 'Cocina Pedidos Especiales' : 'Cocina KDS';
  const shortcutName = isBakery ? 'Impossible POS - Cocina Pedidos Especiales.lnk' : 'Impossible POS - Cocina KDS.lnk';
  const iconName = isBakery ? 'cake_kds.ico' : 'kitchen.ico';
  const iconUrl = `${window.location.origin}/icons/${iconName}`;
  const fullUrl = window.location.href;
  const desc = isBakery ? 'Pantalla de pedidos especiales y pasteleria personalizada' : 'Pantalla de cocina KDS para preparacion de comandas';

  const scriptContent = `@echo off
setlocal EnableDelayedExpansion
title Instalar ${stationName} - Impossible POS
color 0A

echo ======================================================================
echo   IMPOSSIBLE POS - INSTALADOR DE KIOSCO EN ESTE EQUIPO
echo   Estacion: ${stationName}
echo ======================================================================
echo.

set "SERVER_URL=${fullUrl}"
set "ICON_URL=${iconUrl}"
set "SHORTCUT_NAME=${shortcutName}"
set "ICON_NAME=${iconName}"
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"
set "ICON_FILE=%APP_DIR%\\Icons\\%ICON_NAME%"
set "USER_DATA=%APP_DIR%\\Kiosk_${stationId}"

if not exist "%APP_DIR%\\Icons" mkdir "%APP_DIR%\\Icons"
if not exist "%USER_DATA%" mkdir "%USER_DATA%"

echo [1/3] Descargando icono oficial desde el servidor...
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('%ICON_URL%', '%ICON_FILE%')" >nul 2>&1
if not exist "%ICON_FILE%" (
    curl -s -o "%ICON_FILE%" "%ICON_URL%" >nul 2>&1
)

echo [2/3] Localizando navegador compatible (Edge o Chrome)...
set "BROWSER_EXE="
set "BROWSER_ARGS="

if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
    set BROWSER_ARGS=--app="%SERVER_URL%" --user-data-dir="%USER_DATA%" --kiosk --edge-kiosk-type=fullscreen --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
    set BROWSER_ARGS=--app="%SERVER_URL%" --user-data-dir="%USER_DATA%" --kiosk --edge-kiosk-type=fullscreen --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
    set BROWSER_ARGS=--app="%SERVER_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
    set BROWSER_ARGS=--app="%SERVER_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"
    set BROWSER_ARGS=--app="%SERVER_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
)

if "%BROWSER_EXE%"=="" (
    echo ERROR: No se encontro Microsoft Edge ni Google Chrome en esta computadora.
    pause
    exit /b 1
)

echo [3/3] Creando acceso directo en el Escritorio...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%BROWSER_EXE%'; $shortcut.Arguments = '%BROWSER_ARGS%'; if (Test-Path '%ICON_FILE%') { $shortcut.IconLocation = '%ICON_FILE%,0' }; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.Description = '${desc}'; $shortcut.Save();"

echo.
echo ======================================================================
echo   FELICIDADES: Acceso Directo creado con exito en tu Escritorio:
echo   "%SHORTCUT_NAME%"
echo.
echo   - Modo: Kiosco Pantalla Completa (sin bordes de navegador)
echo   - URL:  %SERVER_URL%
echo   - Icono: Oficial (%ICON_NAME%)
echo ======================================================================
echo.
timeout /t 5
`;

  const blob = new Blob([scriptContent], { type: 'application/x-bat' });
  const downloadUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = downloadUrl;
  a.download = `Instalar_Kiosco_${isBakery ? 'Cocina_Pasteleria' : 'Cocina'}.bat`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(downloadUrl);

  showToast(
    isEs
      ? '¡Instalador descargado! Ábrelo en esta computadora para crear el icono en tu Escritorio.'
      : 'Installer downloaded! Run it on this PC to create the desktop kiosk shortcut.',
    'success'
  );
}
window.downloadKioskShortcutForThisStation = downloadKioskShortcutForThisStation;

// Actualizar contornos y tiempos transcurridos en vivo cada 30 segundos
setInterval(() => {
  if (!showPastOrders && typeof renderKDS === 'function') {
    renderKDS();
  }
}, 30000);

