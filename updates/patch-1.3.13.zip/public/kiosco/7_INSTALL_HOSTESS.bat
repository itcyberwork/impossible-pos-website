@echo off
setlocal EnableDelayedExpansion
title Install Hostess (Reception and Tables) - Impossible POS
color 0B

echo ======================================================================
echo   IMPOSSIBLE POS - KIOSK SHORTCUT INSTALLER
echo   Station: Hostess (Reception and Tables)
echo ======================================================================
echo.

set "SERVER_IP="
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"
if "%SERVER_IP%"=="" set "SERVER_IP=127.0.0.1"

set "SHORTCUT_NAME=Impossible POS - Hostess.lnk"
set "ICON_NAME=hostess.ico"
set "APP_DIR=%LOCALAPPDATA%\ImpossiblePOS"
set "ICON_DEST=%APP_DIR%\Icons\%ICON_NAME%"
set "LAUNCH_BAT=%APP_DIR%\launch_hostess.bat"

if not exist "%APP_DIR%\Icons" mkdir "%APP_DIR%\Icons"

:: 1. Copy or download the official icon
echo [1/3] Setting up the official icon...
if exist "%~dp0Icons\%ICON_NAME%" (
    copy /Y "%~dp0Icons\%ICON_NAME%" "%ICON_DEST%" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1
    if not exist "%ICON_DEST%" (
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1
    )
)

:: 2. Copy or download the DHCP auto-discovery script
if exist "%~dp0discover_server.ps1" (
    copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\discover_server.ps1" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/kiosco/discover_server.ps1', '%APP_DIR%\discover_server.ps1')" >nul 2>&1
    if not exist "%APP_DIR%\discover_server.ps1" (
        curl -s -o "%APP_DIR%\discover_server.ps1" "http://%SERVER_IP%:3000/kiosco/discover_server.ps1" >nul 2>&1
    )
)

echo %SERVER_IP%>"%APP_DIR%\server_ip.txt"

:: 3. Locate a Chromium browser (Edge or Chrome)
echo [2/3] Locating a compatible browser (Edge or Chrome)...
set "BROWSER_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

if "%BROWSER_EXE%"=="" (
    echo ERROR: Neither Microsoft Edge nor Google Chrome was found on this computer.
    pause
    exit /b 1
)

:: 4. Generate the smart launcher with automatic DHCP support
(
echo @echo off
echo setlocal EnableDelayedExpansion
echo set "APP_DIR=%%LOCALAPPDATA%%\ImpossiblePOS"
echo set "SERVER_IP="
echo if exist "%%APP_DIR%%\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\server_ip.txt"
echo set "IP_OK=0"
echo if not "!SERVER_IP!"=="" (
echo     powershell -NoProfile -ExecutionPolicy Bypass -Command "$r=[System.Net.WebRequest]::Create('http://' + '!SERVER_IP!' + ':3000/api/ping'); $r.Timeout=400; if ((New-Object IO.StreamReader($r.GetResponse().GetResponseStream())).ReadToEnd() -match 'impossible-pos') { exit 0 } else { exit 1 }" >nul 2^>^&1
echo     if "!ERRORLEVEL!"=="0" set "IP_OK=1"
echo )
echo if "!IP_OK!"=="0" (
echo     if exist "%%APP_DIR%%\discover_server.ps1" (
echo         for /f "usebackq tokens=*" %%%%A in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\discover_server.ps1" -LastKnownIp "!SERVER_IP!"`) do (
echo             set "SERVER_IP=%%%%A"
echo         )
echo         if not "!SERVER_IP!"=="" (
echo             echo !SERVER_IP!^>"%%APP_DIR%%\server_ip.txt"
echo             set "IP_OK=1"
echo         )
echo     )
echo )
echo if "!SERVER_IP!"=="" set "SERVER_IP=%SERVER_IP%"
echo start "" "%BROWSER_EXE%" --app="http://!SERVER_IP!:3000/hostess.html" --kiosk --no-first-run
echo exit
) > "%LAUNCH_BAT%"

:: 5. Create the Desktop shortcut with PowerShell
echo [3/3] Creating the Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = 'Table control and reception'; $shortcut.Save();"

echo.
echo ======================================================================
echo   SUCCESS: Shortcut created on your Desktop:
echo   "%SHORTCUT_NAME%"
echo.
echo   - Mode: Full-Screen Kiosk (DHCP auto-discovery active)
echo   - URL:  http://%SERVER_IP%:3000/hostess.html
echo   - Icon: Official (%ICON_NAME%)
echo ======================================================================
echo.
echo Starting Hostess (Reception and Tables) in full screen...
start "" "%LAUNCH_BAT%"
timeout /t 2 >nul
exit