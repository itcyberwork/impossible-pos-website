param(
    [string]$LastKnownIp = "",
    [int]$TimeoutMs = 1500
)

# 1. Quick check on LastKnownIp (100ms)
if ($LastKnownIp) {
    try {
        $req = [System.Net.WebRequest]::Create("http://$LastKnownIp:3000/api/ping")
        $req.Timeout = 400
        $resp = $req.GetResponse()
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $txt = $reader.ReadToEnd()
        $resp.Close()
        if ($txt -match '"app"\s*:\s*"impossible-pos"') {
            Write-Output $LastKnownIp
            exit 0
        }
    } catch {}
}

# 2. UDP Broadcast Discovery (Fastest on LAN/Wi-Fi: ~20ms)
try {
    $udp = New-Object System.Net.Sockets.UdpClient
    $udp.EnableBroadcast = $true
    $udp.Client.ReceiveTimeout = $TimeoutMs
    $ep = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Broadcast, 38899)
    $payload = [System.Text.Encoding]::ASCII.GetBytes("DISCOVER_IMPOSSIBLE_POS")
    [void]$udp.Send($payload, $payload.Length, $ep)
    
    $remoteEp = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
    $data = $udp.Receive([ref]$remoteEp)
    $msg = [System.Text.Encoding]::ASCII.GetString($data)
    $udp.Close()
    
    if ($msg -match '"ip"\s*:\s*"([^"]+)"') {
        $foundIp = $matches[1]
        Write-Output $foundIp
        exit 0
    } elseif ($remoteEp.Address) {
        Write-Output $remoteEp.Address.ToString()
        exit 0
    }
} catch {
    if ($udp) { try { $udp.Close() } catch {} }
}

# 3. Hostname Resolution
$knownHosts = @("backoffice", "pos-master", "pos", "master")
foreach ($h in $knownHosts) {
    try {
        $req = [System.Net.WebRequest]::Create("http://$h:3000/api/ping")
        $req.Timeout = 500
        $resp = $req.GetResponse()
        $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $txt = $reader.ReadToEnd()
        $resp.Close()
        if ($txt -match '"ip"\s*:\s*"([^"]+)"') {
            Write-Output $matches[1]
            exit 0
        }
        Write-Output $h
        exit 0
    } catch {}
}

# 4. Fast Subnet Parallel Port Scan (Fallback if UDP is dropped by Wi-Fi AP)
try {
    $myIps = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) | 
             Where-Object { $_.AddressFamily -eq 'InterNetwork' -and $_.IPAddressToString -notlike '127.*' -and $_.IPAddressToString -notlike '169.254.*' }
    foreach ($localIp in $myIps) {
        $parts = $localIp.IPAddressToString.Split('.')
        $subnet = "$($parts[0]).$($parts[1]).$($parts[2])."
        $targets = 1..254 | ForEach-Object { "$subnet$_" }
        $found = [System.Collections.Concurrent.ConcurrentBag[string]]::new()
        
        [System.Threading.Tasks.Parallel]::ForEach($targets, [System.Threading.Tasks.ParallelOptions]@{ MaxDegreeOfParallelism = 64 }, [Action[string]]{
            param($target)
            try {
                $tcp = New-Object System.Net.Sockets.TcpClient
                $iar = $tcp.BeginConnect($target, 3000, $null, $null)
                if ($iar.AsyncWaitHandle.WaitOne(300, $false) -and $tcp.Connected) {
                    $tcp.EndConnect($iar)
                    $tcp.Close()
                    
                    # Verify it's actually Impossible POS
                    $req = [System.Net.WebRequest]::Create("http://$target:3000/api/ping")
                    $req.Timeout = 500
                    $resp = $req.GetResponse()
                    $txt = (New-Object System.IO.StreamReader($resp.GetResponseStream())).ReadToEnd()
                    $resp.Close()
                    if ($txt -match '"app"\s*:\s*"impossible-pos"') {
                        $found.Add($target)
                    }
                } else {
                    $tcp.Close()
                }
            } catch {}
        })
        
        if ($found.Count -gt 0) {
            Write-Output ($found | Select-Object -First 1)
            exit 0
        }
    }
} catch {}

exit 1
