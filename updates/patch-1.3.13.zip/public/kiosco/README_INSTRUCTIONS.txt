======================================================================
IMPOSSIBLE POS - FOLDER: KIOSK SHORTCUT INSTALLERS
======================================================================

This folder contains the automatic installers that turn any secondary
computer (kitchen display, bar, bakery area, lobby or secondary register)
into an industrial full-screen Kiosk display.

HOW TO USE:
1. Copy this folder to a USB drive, or open it over the local network
   from the secondary computer.
2. With the secondary computer on the same Wi-Fi or cable network,
   run the file for the station you want:

   - 1_INSTALL_KITCHEN_KDS.bat            -> Main Kitchen Display
   - 2_INSTALL_BAKERY_SPECIAL_ORDERS.bat  -> Bakery and Special Orders Kitchen
   - 3_INSTALL_BAR_KDS.bat                -> Bar and Drinks Display
   - 4_INSTALL_PHOTO_HUB.bat              -> Photo Viewer and Terminal
   - 5_INSTALL_LOBBY_TV.bat               -> Queue / Waiting Display
   - 6_INSTALL_RUNNER.bat                 -> Order Dispatch Display
   - 7_INSTALL_HOSTESS.bat                -> Reception and Tables Display
   - 8_INSTALL_SECONDARY_REGISTER.bat     -> Secondary Checkout Terminal
   - 9_INSTALL_ALL_STATIONS.bat           -> Installs all of them at once

3. The installer automatically detects Microsoft Edge or Google Chrome,
   copies the matching official icon (so the browser "E" is not shown)
   and creates a shortcut on the Desktop.

4. Double-clicking the Desktop shortcut opens the station directly in
   FULL-SCREEN KIOSK MODE, with no address bar and no tabs, using its
   official icon. The launcher finds the server automatically (DHCP
   auto-discovery), even if the router changes the IP addresses.

CHANGING THE SERVER IP:
If you changed modem or the main computer has a new IP, run:
   - CHANGE_SERVER_IP.bat
