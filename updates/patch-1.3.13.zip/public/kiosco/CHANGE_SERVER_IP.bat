@echo off
setlocal EnableDelayedExpansion
title Change Central Server IP - Impossible POS
color 0A

echo ======================================================================
echo   SET / CHANGE THE CENTRAL SERVER IP ADDRESS
echo ======================================================================
echo.
set "CURRENT_IP="
if exist "%~dp0server_ip.txt" set /p CURRENT_IP=<"%~dp0server_ip.txt"
if "%CURRENT_IP%"=="" set "CURRENT_IP=127.0.0.1"

echo The current server IP address is: %CURRENT_IP%
echo.
set /p NEW_IP="Enter the new IP address of the Central Server (example 192.168.1.50): "

if not "%NEW_IP%"=="" (
    echo %NEW_IP%>"%~dp0server_ip.txt"
    echo.
    echo Saved successfully. The new IP is: %NEW_IP%
) else (
    echo No changes were made.
)
echo.
pause
