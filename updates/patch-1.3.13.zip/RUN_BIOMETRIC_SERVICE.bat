@echo off
cd /d "%~dp0"
if exist "C:\Python314\python.exe" (
    "C:\Python314\python.exe" -u biometric_bridge.py > biometric_bridge.log 2>&1
) else (
    python -u biometric_bridge.py > biometric_bridge.log 2>&1
)
