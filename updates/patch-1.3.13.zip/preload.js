const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('electron-minimize'),
  restore: () => ipcRenderer.send('electron-restore'),
  shutdown: () => ipcRenderer.send('system-shutdown'),
  restart: () => ipcRenderer.send('system-restart'),
  printCakeSilent: (orderId) => ipcRenderer.send('print-cake-silent', { orderId }),
  printInvoiceSilent: (orderId) => ipcRenderer.send('print-invoice-silent', { orderId }),
  getPrimaryScreenSourceId: () => ipcRenderer.invoke('get-primary-screen-source-id'),
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  printReceiptSilent: (orderId, serverUrl, isCheck) => ipcRenderer.send('print-receipt-silent', { orderId, serverUrl, isCheck: !!isCheck }),
  printTestSilent: (printerName, serverUrl) => ipcRenderer.send('print-test-silent', { printerName, serverUrl }),
  openCashDrawer: (printerName) => ipcRenderer.send('open-cash-drawer', { printerName })
});

