const { app, BrowserWindow } = require('electron');
app.commandLine.appendSwitch('kiosk-printing');
const path = require('path');
const net = require('net');
const fs = require('fs');

let mainWindow = null;

// Configuración de Estación / Servidor
let stationConfig = {
  serverHost: '127.0.0.1',
  serverPort: 3000,
  serverUrl: 'http://localhost:3000',
  stationId: '1',
  isClientOnly: false
};

// 1. Cargar station_config.json si existe en System_Files o raíz
const possibleConfigFiles = [
  path.join(__dirname, 'station_config.json'),
  path.join(__dirname, '..', 'station_config.json')
];
for (const p of possibleConfigFiles) {
  if (fs.existsSync(p)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
      stationConfig = Object.assign(stationConfig, cfg);
      if (stationConfig.serverHost && stationConfig.serverHost !== '127.0.0.1' && stationConfig.serverHost !== 'localhost') {
        stationConfig.isClientOnly = true;
        stationConfig.serverUrl = `http://${stationConfig.serverHost}:${stationConfig.serverPort || 3000}`;
      }
      console.log(`[CONFIG] Cargada configuración de estación: Caja ${stationConfig.stationId} -> Servidor: ${stationConfig.serverUrl}`);
      break;
    } catch (e) {
      console.warn('[MAIN] Error reading station_config.json:', e.message);
    }
  }
}

// 2. Argumentos por línea de comando (--server=192.168.1.10:3000 --station=2)
process.argv.forEach(arg => {
  if (arg.startsWith('--server=')) {
    const sVal = arg.replace('--server=', '').trim().replace(/^https?:\/\//, '');
    const parts = sVal.split(':');
    stationConfig.serverHost = parts[0];
    stationConfig.serverPort = parts[1] ? parseInt(parts[1]) : 3000;
    stationConfig.serverUrl = `http://${stationConfig.serverHost}:${stationConfig.serverPort}`;
    if (stationConfig.serverHost !== '127.0.0.1' && stationConfig.serverHost !== 'localhost') {
      stationConfig.isClientOnly = true;
    }
  }
  if (arg.startsWith('--station=')) {
    stationConfig.stationId = arg.replace('--station=', '').trim();
  }
});

function ensureServerRunning() {
  if (stationConfig.isClientOnly) {
    console.log(`[STATION] Modo estación remota (Caja ${stationConfig.stationId}) -> Servidor central: ${stationConfig.serverUrl}`);
    return Promise.resolve(true);
  }
  return new Promise((resolve) => {
    const client = new net.Socket();
    client.setTimeout(350);
    client.connect(3000, '127.0.0.1', () => {
      client.destroy();
      resolve(true);
    });
    client.on('error', () => {
      console.log('Starting Express server on port 3000...');
      try {
        require('./server.js');
      } catch (err) {
        console.error('Error starting Express server:', err);
      }
      resolve(false);
    });
    client.on('timeout', () => {
      client.destroy();
      try {
        require('./server.js');
      } catch (e) {}
      resolve(false);
    });
  });
}

function createWindow() {
  let pageArg = process.argv.find(arg => arg.includes('.html')) || 'caja_v14.html';
  if (pageArg === 'caja_v14.html' && !stationConfig.isClientOnly) {
    try {
      const db = require('./database.js');
      const settings = db.getSettings();
      if (!settings || !settings.setupWizardCompleted) {
        pageArg = 'setup_hardware.html';
      }
    } catch (e) {
      console.warn('[MAIN] Could not check setup status on boot:', e.message);
    }
  }
  const stationParam = (pageArg.includes('?') ? '&' : '?') + `station=${stationConfig.stationId || '1'}`;
  const targetUrl = `${stationConfig.serverUrl}/${pageArg}${stationParam}`;
  console.log(`[MAIN] Cargando Impossible POS desde: ${targetUrl}`);

  mainWindow = new BrowserWindow({
    title: "Impossible POS™",
    icon: path.join(__dirname, '../Shortcuts_Installer/pos.ico'),
    width: 1280,
    height: 800,
    fullscreen: true,
    kiosk: true,
    frame: false,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[RENDERER CONSOLE] [Level ${level}] ${message} (at ${sourceId}:${line})`);
  });

  function loadWithRetry(retriesLeft = 25) {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.loadURL(targetUrl).catch((err) => {
      console.log(`Waiting for POS server (${retriesLeft} retries remaining)...`);
      if (retriesLeft > 0) {
        setTimeout(() => loadWithRetry(retriesLeft - 1), 350);
      }
    });
  }

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDesc, validatedURL) => {
    console.log(`Page did-fail-load (${errorCode}: ${errorDesc}). Retrying in 500ms...`);
    setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.loadURL(validatedURL);
      }
    }, 500);
  });

  mainWindow.webContents.once('did-finish-load', () => {
    console.log('POS terminal UI loaded successfully.');
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
      mainWindow.focus();
      mainWindow.setAlwaysOnTop(true);
      mainWindow.setAlwaysOnTop(false);
    }
  });

  mainWindow.webContents.session.clearCache().then(() => {
    loadWithRetry();
  }).catch(() => {
    loadWithRetry();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

const { ipcMain } = require('electron');
const { exec } = require('child_process');

ipcMain.on('electron-minimize', () => {
  if (mainWindow) {
    mainWindow.minimize();
    // Use PowerShell to find the python window titled "Biometric Bridge" and force-focus it
    exec('powershell -Command "Add-Type \'[DllImport(\\\"user32.dll\\\")] public static extern bool SetForegroundWindow(IntPtr hWnd);\' -Name Utils -Namespace Win32; $proc = Get-Process -Name python -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowTitle -like \\\"*Biometric Bridge*\\\"}; if ($proc) { [Win32.Utils]::SetForegroundWindow($proc.MainWindowHandle) }"');
  }
});

ipcMain.on('electron-restore', () => {
  if (mainWindow) {
    mainWindow.restore();
    mainWindow.focus();
  }
});

ipcMain.on('system-shutdown', () => {
  console.log('[ELECTRON] Executing ACPI System Shutdown...');
  exec('shutdown /s /t 2 /f /c "Impossible POS System Shutdown"');
});

ipcMain.on('system-restart', () => {
  console.log('[ELECTRON] Executing ACPI System Restart...');
  exec('shutdown /r /t 2 /f /c "Impossible POS System Restart"');
});

ipcMain.handle('get-primary-screen-source-id', async () => {
  const { desktopCapturer } = require('electron');
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
  if (sources.length > 0) {
    return sources[0].id;
  }
  return null;
});

ipcMain.handle('get-printers', async (event) => {
  try {
    let printers = [];
    if (typeof event.sender.getPrintersAsync === 'function') {
      printers = await event.sender.getPrintersAsync();
    } else if (typeof event.sender.getPrinters === 'function') {
      printers = event.sender.getPrinters();
    }
    return printers.map(p => (typeof p === 'string' ? p : p.name)).filter(Boolean);
  } catch (err) {
    console.error("Error in get-printers handler:", err);
    return [];
  }
});

ipcMain.on('print-receipt-silent', async (event, { orderId, serverUrl, isCheck }) => {
  const baseUrl = serverUrl || stationConfig.serverUrl || 'http://localhost:3000';
  sendPrintDebugLog(`Received print-receipt-silent request for orderId: ${orderId} using base ${baseUrl}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`${baseUrl}/receipt_template.html?orderId=${encodeURIComponent(orderId)}${isCheck ? '&isCheck=true' : ''}`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for receipt orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        let settings = {};
        try {
          settings = await getSettingsFromServer(baseUrl);
        } catch (e) {}
        const printerName = settings.printerLocalName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        let targetPrinter = printerName ? printerName.trim() : "";
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          targetPrinter = defaultP ? defaultP.name : printers[0].name;
        }
        
        const printOptions = {
          silent: true,
          printBackground: true
        };
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }

        printWin.webContents.print(printOptions, (success, failureReason) => {
          if (!success) {
            sendPrintDebugLog(`Silent receipt printing failed: ${failureReason}`);
          } else {
            sendPrintDebugLog(`Silent receipt printed successfully on: ${targetPrinter || 'default'}`);
          }
          try { printWin.close(); } catch (e) {}
        });
      } catch (err) {
        sendPrintDebugLog(`Error during silent receipt printing: ${err.message}`);
        try { printWin.close(); } catch (e) {}
      }
    }, 350);
  });
});

ipcMain.on('print-test-silent', async (event, { printerName, serverUrl }) => {
  const baseUrl = serverUrl || stationConfig.serverUrl || 'http://localhost:3000';
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`${baseUrl}/receipt_template.html?test=true&printerName=${encodeURIComponent(printerName || '')}`);
  printWin.webContents.once('did-finish-load', () => {
    setTimeout(async () => {
      try {
        let target = printerName;
        if (!target) {
          let printers = [];
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
          const defaultP = printers.find(p => p.isDefault);
          target = defaultP ? defaultP.name : (printers[0] ? printers[0].name : '');
        }
        const printOptions = { silent: true, printBackground: true };
        if (target) printOptions.deviceName = target;
        printWin.webContents.print(printOptions, () => {
          try { printWin.close(); } catch (e) {}
        });
      } catch (err) {
        try { printWin.close(); } catch (e) {}
      }
    }, 350);
  });
});

ipcMain.on('open-cash-drawer', (event, data = {}) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    const tempKick = path.join(os.tmpdir(), `temp_kick_${Date.now()}.bin`);
    // ESC p 0 25 250 (Epson Pin 2) + ESC p 1 25 250 (Epson Pin 5) + BEL 0x07 (Star Micronics)
    const kickBytes = Buffer.from([
      0x1b, 0x70, 0x00, 0x19, 0xfa,
      0x1b, 0x70, 0x01, 0x19, 0xfa,
      0x07
    ]);
    fs.writeFileSync(tempKick, kickBytes);
    const printerArg = (data && data.printerName) ? data.printerName : '';
    const scriptPath = path.join(__dirname, 'print_raw.ps1');
    const psCmd = `powershell -ExecutionPolicy Bypass -NoProfile -Command "$p = if ('${printerArg}') { '${printerArg}' } else { ((Get-CimInstance Win32_Printer | Where-Object { $_.Default -or $_.Name -like '*TM-T*' -or $_.Name -like '*Receipt*' -or $_.Name -like '*EPSON*' -or $_.Name -like '*Star*' -or $_.Name -like '*TSP*' -or $_.Name -like '*Rongta*' } | Select-Object -First 1).Name) }; if ($p) { & '${scriptPath.replace(/\\/g, '\\\\')}' -PrinterName $p -FilePath '${tempKick.replace(/\\/g, '\\\\')}' }"`;
    exec(psCmd, () => {
      try { fs.unlinkSync(tempKick); } catch(e) {}
    });
  } catch (e) {
    console.error('Error opening cash drawer via Electron:', e);
  }
});

const http = require('http');

function getSettingsFromServer(serverUrl) {
  return new Promise((resolve) => {
    const baseUrl = serverUrl || stationConfig.serverUrl || 'http://127.0.0.1:3000';
    const urlStr = `${baseUrl}/api/admin/settings`;
    const client = urlStr.startsWith('https') ? require('https') : require('http');
    client.get(urlStr, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({});
        }
      });
    }).on('error', (e) => {
      resolve({});
    });
  });
}

function sendPrintDebugLog(msg) {
  try {
    const postData = JSON.stringify({ message: msg });
    const targetHost = stationConfig.serverHost || '127.0.0.1';
    const targetPort = stationConfig.serverPort || 3000;
    const req = http.request({
      hostname: targetHost,
      port: targetPort,
      path: '/api/print-debug',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    }, (res) => {
      res.resume();
    });
    req.on('error', (e) => {
      console.error(`Error sending print log to server: ${e.message}`);
    });
    req.write(postData);
    req.end();
  } catch (err) {
    console.error("Error in sendPrintDebugLog:", err);
  }
}

ipcMain.on('print-invoice-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-invoice-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`http://localhost:3000/invoice_template.html?orderId=${orderId}`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for invoice orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
          } else {
            targetPrinter = printers[0].name;
          }
        }
        
        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        try {
          const fs = require('fs');
          const path = require('path');
          const os = require('os');
          
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `invoice_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        printWin.close();
      }
    }, 1500); // Dar 1.5 segundos para cargar y renderizar la plantilla HTML
  });
});

ipcMain.on('print-cake-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-cake-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      backgroundThrottling: false
    }
  });
  printWin.loadURL(`http://localhost:3000/comanda_pastel.html?orderId=${orderId}&silent=true`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        sendPrintDebugLog(`Printers available in Electron: ${JSON.stringify(printers.map(p => ({ name: p.name, isDefault: p.isDefault })))}`);
        sendPrintDebugLog(`Configured reportingPrinterName: "${printerName}"`);

        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        // Robust fallback: if no reporting printer is configured, attempt to use the OS default or first available printer
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
            sendPrintDebugLog(`No reportingPrinterName configured. Falling back to default printer: "${targetPrinter}"`);
          } else {
            targetPrinter = printers[0].name;
            sendPrintDebugLog(`No default printer set. Falling back to first available printer: "${targetPrinter}"`);
          }
        }
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        sendPrintDebugLog(`Generating PDF via printToPDF...`);
        try {
          const fs = require('fs');
          const os = require('os');
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `cake_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);
          sendPrintDebugLog(`PDF generated successfully at ${tempPdfPath}. Printing via pdf-to-printer to: "${targetPrinter}"`);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          sendPrintDebugLog(`Print job sent successfully via SumatraPDF to "${targetPrinter}"`);
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          sendPrintDebugLog(`Error in printToPDF / pdf-to-printer execution: ${printErr.message}`);
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        sendPrintDebugLog(`Print error catch: ${err.message}`);
        printWin.close();
      }
    }, 1200); // Dar 1.2 segundos para cargar y renderizar la plantilla HTML
  });
});

function checkWindowsEnvironment() {
  if (process.platform !== 'win32') return;

  const { exec } = require('child_process');
  
  // Whitelist current app path and parent path
  const appPath = path.resolve(__dirname).replace(/\\/g, '\\\\');
  const parentPath = path.resolve(__dirname, '..').replace(/\\/g, '\\\\');

  // 1. Check Defender Exclusions
  exec('powershell -Command "Get-MpPreference | Select-Object -ExpandProperty ExclusionPath"', (err, stdout, stderr) => {
    if (err) {
      console.error('Error checking Defender exclusions:', err);
      return;
    }
    const exclusions = stdout || '';
    const isAppExcluded = exclusions.includes(path.resolve(__dirname)) || exclusions.includes(path.resolve(__dirname, '..'));

    if (!isAppExcluded) {
      console.log('App directory is not whitelisted in Windows Defender. Requesting exclusion...');
      const addExclusionCmd = `powershell -Command "Start-Process powershell -ArgumentList '-Command Add-MpPreference -ExclusionPath \\\"${appPath}\\\",\\\"${parentPath}\\\"' -Verb RunAs -WindowStyle Hidden"`;
      exec(addExclusionCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Defender exclusion request:', uacErr);
      });
    } else {
      console.log('Windows Defender exclusion check: OK.');
    }
  });

  // 2. Check Firewall Rule for Port 3000
  exec('powershell -Command "Get-NetFirewallRule -DisplayName \\\"Impossible POS Local Server\\\" -ErrorAction SilentlyContinue"', (err, stdout, stderr) => {
    const ruleExists = stdout && stdout.includes('Impossible POS Local Server');
    if (!ruleExists) {
      console.log('Firewall rule for Impossible POS is missing. Requesting addition...');
      const addFirewallCmd = `powershell -Command "Start-Process cmd -ArgumentList '/c netsh advfirewall firewall add rule name=\\\"Impossible POS Local Server\\\" dir=in action=allow protocol=TCP localport=3000 profile=private,domain' -Verb RunAs -WindowStyle Hidden"`;
      exec(addFirewallCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Firewall addition request:', uacErr);
      });
    } else {
      console.log('Windows Firewall rule check: OK.');
    }
  });
}

function startLocalDrawerService() {
  if (process.platform !== 'win32') return;
  try {
    const fsLocal = require('fs');
    const pathLocal = require('path');
    const scriptPath = pathLocal.join(__dirname, 'drawer_service.ps1');
    if (!fsLocal.existsSync(scriptPath)) return;
    const child = require('child_process').spawn('powershell.exe', ['-ExecutionPolicy', 'Bypass', '-NoProfile', '-WindowStyle', 'Hidden', '-File', scriptPath], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    });
    child.unref();
  } catch (e) {
    console.warn('Could not launch local drawer service:', e.message);
  }
}

app.whenReady().then(async () => {
  await ensureServerRunning();
  startLocalDrawerService();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

