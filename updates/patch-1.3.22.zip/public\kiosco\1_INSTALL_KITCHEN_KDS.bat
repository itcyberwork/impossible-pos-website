@echo off
setlocal EnableDelayedExpansion
title Install Kitchen KDS - Impossible POS
color 0B

echo ======================================================================
echo   IMPOSSIBLE POS - KIOSK SHORTCUT INSTALLER
echo   Station: Kitchen KDS
echo ======================================================================
echo.

set "SERVER_IP="
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"
if "%SERVER_IP%"=="" set "SERVER_IP=127.0.0.1"

set "SHORTCUT_NAME=Impossible POS - Kitchen KDS.lnk"
set "ICON_NAME=kitchen.ico"
set "APP_DIR=%LOCALAPPDATA%\ImpossiblePOS"
set "ICON_DEST=%APP_DIR%\Icons\%ICON_NAME%"
set "LAUNCH_BAT=%APP_DIR%\launch_kitchen.bat"

if not exist "%APP_DIR%\Icons" mkdir "%APP_DIR%\Icons"

:: 1. Copy or download the official icon
echo [1/3] Setting up the official icon...
if exist "%~dp0Icons\%ICON_NAME%" (
    copy /Y "%~dp0Icons\%ICON_NAME%" "%ICON_DEST%" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1
    if not exist "%ICON_DEST%" (
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1
    )
)

:: 2. Copy or download the DHCP auto-discovery script
if exist "%~dp0discover_server.ps1" (
    copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\discover_server.ps1" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/kiosco/discover_server.ps1', '%APP_DIR%\discover_server.ps1')" >nul 2>&1
    if not exist "%APP_DIR%\discover_server.ps1" (
        curl -s -o "%APP_DIR%\discover_server.ps1" "http://%SERVER_IP%:3000/kiosco/discover_server.ps1" >nul 2>&1
    )
)

echo %SERVER_IP%>"%APP_DIR%\server_ip.txt"

:: 3. Locate a Chromium browser (Edge or Chrome)
echo [2/3] Locating a compatible browser (Edge or Chrome)...
set "BROWSER_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

if "%BROWSER_EXE%"=="" (
    echo ERROR: Neither Microsoft Edge nor Google Chrome was found on this computer.
    pause
    exit /b 1
)

:: 4. Generate the direct kiosk launcher
echo @echo off > "%LAUNCH_BAT%"
echo start "" "%BROWSER_EXE%" --app="http://%SERVER_IP%:3000/cocina.html" --kiosk --no-first-run >> "%LAUNCH_BAT%"
echo exit >> "%LAUNCH_BAT%"

:: 5. Create Desktop shortcut and Windows Startup auto-launch
echo [3/3] Creating Desktop shortcut and auto-start configuration...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = 'Main Kitchen Display (KDS Tickets)'; $shortcut.Save(); $startup = $ws.SpecialFolders('Startup'); $sShortcut = $ws.CreateShortcut($startup + '\%SHORTCUT_NAME%'); $sShortcut.TargetPath = '%LAUNCH_BAT%'; $sShortcut.WorkingDirectory = '%APP_DIR%'; $sShortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $sShortcut.IconLocation = '%ICON_DEST%,0' }; $sShortcut.Save();"

:: 6. Create clean Desktop instructions file
set "GUIDE_FILE=%USERPROFILE%\Desktop\KITCHEN_KEYPAD_INSTRUCTIONS.txt"
(
echo ======================================================================
echo   IMPOSSIBLE POS - KITCHEN DISPLAY SYSTEM ^(KDS^)
echo   NUMERIC KEYPAD ^(BUMP BAR^) OPERATING INSTRUCTIONS
echo ======================================================================
echo.
echo 1. AUTOMATIC STARTUP ^(WHEN POWERING ON COMPUTER^):
echo    - Simply press the Power button on the computer.
echo    - Windows starts up and AUTOMATICALLY opens the Kitchen Display
echo      in Full Screen mode. You do not need to click anything.
echo.
echo 2. HOW TO CONTROL ORDERS WITH THE NUMERIC KEYPAD:
echo    - [ 1 ] to [ 9 ] : Select order card directly.
echo    - [ + ]          : Move forward to next order.
echo    - [ - ]          : Move backward to previous order.
echo    - [ ENTER ]      : View complete order ticket / work sheet.
echo    - [ . ] or [Del] : Bump / Complete order ^(clears it from kitchen screen^).
echo    - [ * ]          : Print work sheet / reference photo.
echo    - [ / ]          : View reference photo ^(custom cake orders^).
echo    - [ Tab ]        : Switch between Active Orders and Past Orders history.
echo    - [ Backspace ]  : Close preview modal or return to first order.
echo.
echo 3. HOW TO SHUT DOWN THE COMPUTER AT THE END OF THE SHIFT:
echo    - Press [ 0 ] twice quickly: [ 0 ] [ 0 ]
echo    - A red confirmation window will appear on screen.
echo    - Press [ ENTER ] to confirm and turn off the computer safely.
echo    - ^(If pressed by mistake, press any other key to cancel^).
echo.
echo 4. IF THE SCREEN WAS CLOSED BY ACCIDENT:
echo    - Double-click the "Impossible POS - Kitchen KDS" shortcut on Desktop.
echo ======================================================================
) > "%GUIDE_FILE%"

echo.
echo ======================================================================
echo   SUCCESS: Kitchen KDS configured on this computer:
echo.
echo   - Desktop Shortcut: "%SHORTCUT_NAME%"
echo   - Auto-Start on Boot: ENABLED (Starts automatically on power-on)
echo   - Keypad Guide: "KITCHEN_KEYPAD_INSTRUCTIONS.txt" on Desktop
echo   - Mode: Full-Screen Kiosk (DHCP auto-discovery active)
echo   - URL:  http://%SERVER_IP%:3000/cocina.html
echo ======================================================================
echo.
echo Starting Kitchen KDS in full screen...
start "" "%LAUNCH_BAT%"
timeout /t 2 >nul
exit