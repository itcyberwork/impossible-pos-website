# ==============================================================================
# IMPOSSIBLE POS - SERVICIO LOCAL DE CAJON DE DINERO (DRAWER SERVICE)
# ==============================================================================
# Este servicio ultra-ligero corre en segundo plano en cada estacion de trabajo.
# Permite abrir el cajon de dinero de forma instantanea por hardware (winspool.drv)
# sin depender de que el controlador de Windows abra el cajon en CADA impresion.
# ==============================================================================

param([int]$Port = 3005)

$csharp = @"
using System;
using System.Runtime.InteropServices;
public class DrawerRawPrinter {
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
    public class DOCINFOA {
        [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPStr)] public string pDataType;
    }
    [DllImport("winspool.Drv", EntryPoint="OpenPrinterA", SetLastError=true, CharSet=CharSet.Ansi, ExactSpelling=true)]
    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);
    [DllImport("winspool.Drv", EntryPoint="ClosePrinter", SetLastError=true)]
    public static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint="StartDocPrinterA", SetLastError=true, CharSet=CharSet.Ansi, ExactSpelling=true)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);
    [DllImport("winspool.Drv", EntryPoint="EndDocPrinter", SetLastError=true)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint="StartPagePrinter", SetLastError=true)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint="EndPagePrinter", SetLastError=true)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint="WritePrinter", SetLastError=true)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

    public static bool SendKickPulse(string szPrinterName, byte pinByte) {
        IntPtr hPrinter = IntPtr.Zero;
        DOCINFOA di = new DOCINFOA();
        di.pDocName = "Impossible POS Drawer Kick";
        di.pDataType = "RAW";
        bool success = false;
        if (OpenPrinter(szPrinterName, out hPrinter, IntPtr.Zero)) {
            if (StartDocPrinter(hPrinter, 1, di)) {
                if (StartPagePrinter(hPrinter)) {
                    // ESC p m t1 t2 + BEL (universal drawer kick)
                    byte[] bytes = new byte[] { 0x1B, 0x70, pinByte, 0x19, 0xFA, 0x07 };
                    IntPtr pUnmanagedBytes = Marshal.AllocCoTaskMem(bytes.Length);
                    Marshal.Copy(bytes, 0, pUnmanagedBytes, bytes.Length);
                    Int32 dwWritten = 0;
                    success = WritePrinter(hPrinter, pUnmanagedBytes, bytes.Length, out dwWritten);
                    Marshal.FreeCoTaskMem(pUnmanagedBytes);
                    EndPagePrinter(hPrinter);
                }
                EndDocPrinter(hPrinter);
            }
            ClosePrinter(hPrinter);
        }
        return success;
    }
}
"@

try {
    Add-Type -TypeDefinition $csharp -ErrorAction SilentlyContinue
} catch {}

function Get-TargetThermalPrinter {
    $all = Get-CimInstance Win32_Printer | Where-Object { 
        $_.Name -notlike "*PDF*" -and 
        $_.Name -notlike "*XPS*" -and 
        $_.Name -notlike "*OneNote*" -and 
        $_.Name -notlike "*Fax*" 
    }
    $thermal = $all | Where-Object { 
        $_.Name -like "*Star*" -or 
        $_.Name -like "*TSP*" -or 
        $_.Name -like "*TM-T*" -or 
        $_.Name -like "*Receipt*" -or 
        $_.Name -like "*EPSON*" -or 
        $_.Name -like "*Rongta*" -or 
        $_.Name -like "*POS*" 
    } | Select-Object -First 1

    if (-not $thermal -and $all) {
        $thermal = $all | Where-Object { $_.Default } | Select-Object -First 1
        if (-not $thermal) { $thermal = $all | Select-Object -First 1 }
    }
    if ($thermal) { return $thermal.Name }
    return $null
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$Port/")

try {
    $listener.Start()
} catch {
    # Si ya esta corriendo otra instancia en el puerto, salir silenciosamente
    exit 0
}

# Cachear la impresora al inicio para respuesta instantanea (0ms de retraso)
$cachedPrinter = Get-TargetThermalPrinter

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $req = $context.Request
        $res = $context.Response

        $res.Headers.Add("Access-Control-Allow-Origin", "*")
        $res.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        $res.Headers.Add("Access-Control-Allow-Headers", "*")
        $res.Headers.Add("Content-Type", "application/json")

        if ($req.HttpMethod -eq "OPTIONS") {
            $res.StatusCode = 200
            $res.Close()
            continue
        }

        $path = $req.Url.AbsolutePath
        if (-not $cachedPrinter) { $cachedPrinter = Get-TargetThermalPrinter }

        if ($path -eq "/health" -or $path -eq "/ping") {
            $resBody = '{"status":"ready","printer":"' + $cachedPrinter + '"}'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($resBody)
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }

        if ($path -eq "/printers") {
            # List every printer installed on THIS station (USB, shared and network printers added to Windows)
            $names = @()
            try {
                Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
                $names += [System.Drawing.Printing.PrinterSettings]::InstalledPrinters | ForEach-Object { $_ }
            } catch {}
            if (-not $names -or $names.Count -eq 0) {
                try { $names += Get-CimInstance Win32_Printer | ForEach-Object { $_.Name } } catch {}
                try { $names += Get-Printer | ForEach-Object { $_.Name } } catch {}
            }
            $names = $names | Where-Object { $_ } | Sort-Object -Unique
            $items = $names | ForEach-Object { '"' + ($_ -replace '\\', '\\' -replace '"', '\"') + '"' }
            $resBody = '[' + ($items -join ',') + ']'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($resBody)
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }

        if ($path -eq "/kick" -or $path -eq "/open-drawer") {
            $drawerNum = 1
            if ($req.QueryString["drawer"] -eq "2") { $drawerNum = 2 }
            $pinByte = if ($drawerNum -eq 2) { [byte]0x01 } else { [byte]0x00 }

            $ok = [DrawerRawPrinter]::SendKickPulse($cachedPrinter, $pinByte)
            if (-not $ok) {
                # Reintentar refrescando deteccion de impresora si fallo
                $cachedPrinter = Get-TargetThermalPrinter
                $ok = [DrawerRawPrinter]::SendKickPulse($cachedPrinter, $pinByte)
            }

            $resBody = '{"status":"ok","kicked":' + ($ok.ToString().ToLower()) + ',"printer":"' + $cachedPrinter + '","drawer":' + $drawerNum + '}'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($resBody)
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
            $res.OutputStream.Close()
            continue
        }

        $res.StatusCode = 404
        $res.Close()
    } catch {
        # Ignorar errores de conexion y seguir escuchando
    }
}
