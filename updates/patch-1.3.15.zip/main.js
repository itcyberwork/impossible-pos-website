const { app, BrowserWindow } = require('electron');
app.commandLine.appendSwitch('kiosk-printing');
const path = require('path');
const net = require('net');
const fs = require('fs');

let mainWindow = null;

// Station / Server Configuration
let stationConfig = {
  serverHost: '127.0.0.1',
  serverPort: 3000,
  serverUrl: 'http://localhost:3000',
  stationId: '1',
  stationName: 'Register 1',
  stationRole: 'cashier',
  isClientOnly: false,
  setupCompleted: false
};

// 1. Load station_config.json if it exists
let hasConfigFile = false;
const possibleConfigFiles = [
  path.join(__dirname, 'station_config.json'),
  path.join(__dirname, '..', 'station_config.json')
];
for (const p of possibleConfigFiles) {
  if (fs.existsSync(p)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (cfg && (cfg.setupCompleted || cfg.serverHost)) {
        stationConfig = Object.assign(stationConfig, cfg);
        hasConfigFile = true;
        if (stationConfig.serverHost && stationConfig.serverHost !== '127.0.0.1' && stationConfig.serverHost !== 'localhost') {
          stationConfig.isClientOnly = true;
          stationConfig.serverUrl = `http://${stationConfig.serverHost}:${stationConfig.serverPort || 3000}`;
        }
        console.log(`[CONFIG] Loaded station config: Station ${stationConfig.stationId} -> Server: ${stationConfig.serverUrl}`);
        break;
      }
    } catch (e) {
      console.warn('[MAIN] Error reading station_config.json:', e.message);
    }
  }
}

// 2. Command-line arguments override (--server=192.168.1.10:3000 --station=2)
let hasServerArg = false;
process.argv.forEach(arg => {
  if (arg.startsWith('--server=')) {
    hasServerArg = true;
    const sVal = arg.replace('--server=', '').trim().replace(/^https?:\/\//, '');
    const parts = sVal.split(':');
    stationConfig.serverHost = parts[0];
    stationConfig.serverPort = parts[1] ? parseInt(parts[1]) : 3000;
    stationConfig.serverUrl = `http://${stationConfig.serverHost}:${stationConfig.serverPort}`;
    if (stationConfig.serverHost !== '127.0.0.1' && stationConfig.serverHost !== 'localhost') {
      stationConfig.isClientOnly = true;
    }
  }
  if (arg.startsWith('--station=')) {
    stationConfig.stationId = arg.replace('--station=', '').trim();
  }
});

const forceSetup = process.argv.includes('--setup') || process.argv.includes('--wizard');
const needsWizard = !hasConfigFile && !hasServerArg;

function ensureServerRunning() {
  if (stationConfig.isClientOnly) {
    console.log(`[STATION] Client station mode (Register ${stationConfig.stationId}) -> Central Server: ${stationConfig.serverUrl}`);
    return Promise.resolve(true);
  }
  return new Promise((resolve) => {
    const client = new net.Socket();
    client.setTimeout(350);
    client.connect(3000, '127.0.0.1', () => {
      client.destroy();
      resolve(true);
    });
    client.on('error', () => {
      console.log('Starting Express server on port 3000...');
      try {
        require('./server.js');
      } catch (err) {
        console.error('Error starting Express server:', err);
      }
      resolve(false);
    });
    client.on('timeout', () => {
      client.destroy();
      try {
        require('./server.js');
      } catch (e) {}
      resolve(false);
    });
  });
}

function launchStationUI() {
  if (!mainWindow || mainWindow.isDestroyed()) return;

  let pageArg = process.argv.find(arg => arg.includes('.html')) || 'caja_v14.html';
  if (pageArg === 'caja_v14.html' && !stationConfig.isClientOnly) {
    try {
      const db = require('./database.js');
      const settings = db.getSettings();
      if (!settings || !settings.setupWizardCompleted) {
        pageArg = 'setup_hardware.html';
      }
    } catch (e) {
      console.warn('[MAIN] Could not check setup status on boot:', e.message);
    }
  }
  const stationParam = (pageArg.includes('?') ? '&' : '?') + `station=${stationConfig.stationId || '1'}`;
  const targetUrl = `${stationConfig.serverUrl}/${pageArg}${stationParam}`;
  console.log(`[MAIN] Loading Impossible POS from: ${targetUrl}`);

  let retriesLeft = 25;
  function loadWithRetry() {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    mainWindow.loadURL(targetUrl).catch((err) => {
      console.log(`Waiting for POS server (${retriesLeft} retries remaining)...`);
      if (retriesLeft > 0) {
        retriesLeft--;
        setTimeout(loadWithRetry, 400);
      } else {
        console.warn(`[MAIN] Could not connect to ${targetUrl}. Opening Setup Wizard...`);
        mainWindow.loadFile(path.join(__dirname, 'public', 'station_wizard.html'), {
          query: { error: 'server_unreachable', host: stationConfig.serverHost }
        });
      }
    });
  }

  loadWithRetry();
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: "Impossible POS™",
    icon: path.join(__dirname, '../Shortcuts_Installer/pos.ico'),
    width: 1280,
    height: 800,
    fullscreen: true,
    kiosk: true,
    frame: false,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log(`[RENDERER CONSOLE] [Level ${level}] ${message} (at ${sourceId}:${line})`);
  });

  mainWindow.webContents.once('did-finish-load', () => {
    console.log('POS terminal window loaded successfully.');
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.show();
      mainWindow.focus();
      mainWindow.setAlwaysOnTop(true);
      mainWindow.setAlwaysOnTop(false);
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  if (needsWizard || forceSetup) {
    console.log('[MAIN] Station not configured or setup requested. Launching Setup Wizard...');
    mainWindow.loadFile(path.join(__dirname, 'public', 'station_wizard.html'));
  } else {
    mainWindow.webContents.session.clearCache().then(() => {
      launchStationUI();
    }).catch(() => {
      launchStationUI();
    });
  }
}


const { ipcMain } = require('electron');
const { exec } = require('child_process');

// Station Connection Wizard IPC Handlers
ipcMain.handle('get-station-config', async () => {
  return stationConfig;
});

ipcMain.handle('save-station-config', async (event, config) => {
  try {
    stationConfig = Object.assign(stationConfig, config);
    const savePayload = JSON.stringify(stationConfig, null, 2);

    const pathsToSave = [
      path.join(__dirname, 'station_config.json'),
      path.join(__dirname, '..', 'station_config.json')
    ];
    for (const p of pathsToSave) {
      try {
        fs.writeFileSync(p, savePayload, 'utf8');
        console.log(`[MAIN] Station config successfully written to: ${p}`);
      } catch (e) {
        console.warn(`[MAIN] Could not write station config to ${p}:`, e.message);
      }
    }

    if (stationConfig.isClientOnly) {
      console.log(`[MAIN] Starting client mode -> Connecting to ${stationConfig.serverUrl}`);
      launchStationUI();
    } else {
      console.log(`[MAIN] Starting Main Server mode -> Ensuring server is active...`);
      await ensureServerRunning();
      launchStationUI();
    }
    return { ok: true };
  } catch (err) {
    console.error('[MAIN] Error saving station config:', err);
    return { ok: false, error: err.message };
  }
});

ipcMain.on('open-station-wizard', () => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    console.log('[MAIN] Opening Station Setup Wizard on user request...');
    mainWindow.loadFile(path.join(__dirname, 'public', 'station_wizard.html'));
  }
});

ipcMain.handle('test-server-connection', async (event, { host, port = 3000 }) => {
  return new Promise((resolve) => {
    const cleanHost = (host || '').trim().replace(/^https?:\/\//i, '').split('/')[0].split(':')[0];
    if (!cleanHost) return resolve({ ok: false, error: 'Host is required' });
    const targetPort = parseInt(port, 10) || 3000;
    const http = require('http');
    const req = http.get(`http://${cleanHost}:${targetPort}/api/ping`, { timeout: 3500 }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ ok: true, data: parsed, host: cleanHost, port: targetPort });
        } catch (e) {
          if (res.statusCode === 200) {
            resolve({ ok: true, host: cleanHost, port: targetPort, data: { app: 'impossible-pos' } });
          } else {
            resolve({ ok: false, error: `Server returned HTTP status ${res.statusCode}` });
          }
        }
      });
    });
    req.on('error', (err) => {
      resolve({ ok: false, error: err.message });
    });
    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, error: 'Connection timed out' });
    });
  });
});

ipcMain.handle('discover-servers', async () => {
  return new Promise((resolve) => {
    const dgram = require('dgram');
    const client = dgram.createSocket('udp4');
    const discovered = [];

    client.on('error', (err) => {
      console.warn('[UDP DISCOVER] Socket error:', err.message);
      try { client.close(); } catch(e) {}
      resolve({ ok: true, servers: discovered });
    });

    client.on('message', (msg, rinfo) => {
      try {
        const data = JSON.parse(msg.toString());
        if (data && data.app === 'impossible-pos') {
          const srvIp = data.ip || rinfo.address;
          if (!discovered.some(s => s.ip === srvIp)) {
            discovered.push({
              ip: srvIp,
              port: data.port || 3000,
              hostname: data.hostname || srvIp,
              version: data.version || '10.0'
            });
          }
        }
      } catch (e) {}
    });

    client.bind(() => {
      try {
        client.setBroadcast(true);
        client.send('DISCOVER_IMPOSSIBLE_POS', 38899, '255.255.255.255', (err) => {
          if (err) console.warn('[UDP DISCOVER] Broadcast send error:', err.message);
        });
      } catch(e) {
        console.warn('[UDP DISCOVER] Broadcast bind error:', e.message);
      }
    });

    // Probe localhost:3000 in parallel
    const http = require('http');
    const localReq = http.get('http://127.0.0.1:3000/api/ping', { timeout: 1000 }, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (parsed && parsed.app === 'impossible-pos') {
            if (!discovered.some(s => s.ip === '127.0.0.1' || s.ip === parsed.ip)) {
              discovered.push({
                ip: '127.0.0.1',
                port: 3000,
                hostname: parsed.hostname || 'Local Computer',
                version: parsed.version || '10.0'
              });
            }
          }
        } catch(e) {}
      });
    });
    localReq.on('error', () => {});

    setTimeout(() => {
      try { client.close(); } catch(e) {}
      resolve({ ok: true, servers: discovered });
    }, 1500);
  });
});

ipcMain.on('electron-minimize', () => {
  if (mainWindow) {
    mainWindow.minimize();
    // Use PowerShell to find the python window titled "Biometric Bridge" and force-focus it
    exec('powershell -Command "Add-Type \'[DllImport(\\\"user32.dll\\\")] public static extern bool SetForegroundWindow(IntPtr hWnd);\' -Name Utils -Namespace Win32; $proc = Get-Process -Name python -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowTitle -like \\\"*Biometric Bridge*\\\"}; if ($proc) { [Win32.Utils]::SetForegroundWindow($proc.MainWindowHandle) }"');
  }
});

ipcMain.on('electron-restore', () => {
  if (mainWindow) {
    mainWindow.restore();
    mainWindow.focus();
  }
});

ipcMain.on('system-shutdown', () => {
  console.log('[ELECTRON] Executing ACPI System Shutdown...');
  exec('shutdown /s /t 2 /f /c "Impossible POS System Shutdown"');
});

ipcMain.on('system-restart', () => {
  console.log('[ELECTRON] Executing ACPI System Restart...');
  exec('shutdown /r /t 2 /f /c "Impossible POS System Restart"');
});

ipcMain.handle('get-primary-screen-source-id', async () => {
  const { desktopCapturer } = require('electron');
  const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
  if (sources.length > 0) {
    return sources[0].id;
  }
  return null;
});

ipcMain.handle('get-printers', async (event) => {
  try {
    let printers = [];
    if (typeof event.sender.getPrintersAsync === 'function') {
      printers = await event.sender.getPrintersAsync();
    } else if (typeof event.sender.getPrinters === 'function') {
      printers = event.sender.getPrinters();
    }
    return printers.map(p => (typeof p === 'string' ? p : p.name)).filter(Boolean);
  } catch (err) {
    console.error("Error in get-printers handler:", err);
    return [];
  }
});

let cachedServerSettings = null;
let cachedSettingsTime = 0;

const { execFile } = require('child_process');

async function resolveThermalPrinter(suggestedName) {
  let printers = [];
  try {
    if (mainWindow && mainWindow.webContents) {
      if (typeof mainWindow.webContents.getPrintersAsync === 'function') {
        printers = await mainWindow.webContents.getPrintersAsync();
      } else if (typeof mainWindow.webContents.getPrinters === 'function') {
        printers = mainWindow.webContents.getPrinters();
      }
    }
  } catch (e) {}

  if (suggestedName && suggestedName.trim()) {
    return suggestedName.trim();
  }
  if (printers.length > 0) {
    const thermal = printers.find(p => /TM-T|EPSON|Receipt|Star|TSP|POS|Rongta|Thermal/i.test(p.name) && !/PDF|XPS|OneNote|Fax/i.test(p.name));
    if (thermal) return thermal.name;
  }
  if (printers.length > 0) {
    const def = printers.find(p => p.isDefault && !/PDF|XPS|OneNote|Fax/i.test(p.name));
    if (def) return def.name;
  }
  if (printers.length > 0) {
    const nonVirtual = printers.find(p => !/PDF|XPS|OneNote|Fax/i.test(p.name));
    if (nonVirtual) return nonVirtual.name;
  }
  return suggestedName || '';
}

function kickCashDrawerRaw(printerName) {
  return new Promise(async (resolve) => {
    try {
      const targetPrinter = await resolveThermalPrinter(printerName);
      if (!targetPrinter) {
        sendPrintDebugLog('No thermal printer found for drawer kick');
        return resolve(false);
      }
      const fs = require('fs');
      const os = require('os');
      const tempKick = path.join(os.tmpdir(), `temp_kick_${Date.now()}.bin`);
      // ESC p 0 25 250 (Epson Pin 2) + ESC p 1 25 250 (Epson Pin 5) + BEL 0x07 (Star TSP100 / Star Micronics)
      const kickBytes = Buffer.from([
        0x1b, 0x70, 0x00, 0x19, 0xfa,
        0x1b, 0x70, 0x01, 0x19, 0xfa,
        0x07
      ]);
      fs.writeFileSync(tempKick, kickBytes);
      const scriptPath = path.join(__dirname, 'print_raw.ps1');
      execFile('powershell.exe', [
        '-ExecutionPolicy', 'Bypass',
        '-NoProfile',
        '-File', scriptPath,
        '-PrinterName', targetPrinter,
        '-FilePath', tempKick
      ], (err, stdout, stderr) => {
        try { fs.unlinkSync(tempKick); } catch (e) {}
        const ok = !err && (stdout || '').includes('PRINT_SUCCESS');
        sendPrintDebugLog(`Cash drawer kick raw result on '${targetPrinter}': ${ok ? 'SUCCESS' : 'FAILED'}`);
        resolve(ok);
      });
    } catch (e) {
      sendPrintDebugLog(`Error in kickCashDrawerRaw: ${e.message}`);
      resolve(false);
    }
  });
}

ipcMain.on('print-receipt-silent', async (event, { orderId, serverUrl, isCheck, printerName }) => {
  const baseUrl = serverUrl || stationConfig.serverUrl || 'http://localhost:3000';
  sendPrintDebugLog(`Received print-receipt-silent request for orderId: ${orderId}, isCheck: ${isCheck}, printerName: ${printerName || 'none'}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  let hasPrinted = false;

  async function performPrint() {
    if (hasPrinted) return;
    hasPrinted = true;

    try {
      let settings = {};
      const now = Date.now();
      if (cachedServerSettings && (now - cachedSettingsTime < 30000)) {
        settings = cachedServerSettings;
      } else {
        try {
          settings = await getSettingsFromServer(baseUrl);
          cachedServerSettings = settings;
          cachedSettingsTime = now;
        } catch (e) {}
      }

      const configuredPrinter = (printerName && printerName.trim()) ? printerName.trim() : ((settings && settings.printerLocalName) ? settings.printerLocalName.trim() : '');
      const targetPrinter = await resolveThermalPrinter(configuredPrinter);

      sendPrintDebugLog(`Target printer resolved: '${targetPrinter}' for orderId: ${orderId}`);

      let printedOk = false;

      // 1. Direct PDF spooling via SumatraPDF (bypasses Electron 43.x "Invalid printer settings" regression on thermal roll paper)
      try {
        const heightPx = await printWin.webContents.executeJavaScript(`
          (function() {
            const rc = document.getElementById('receiptContainer');
            if (rc) {
              return Math.ceil(rc.getBoundingClientRect().height || rc.scrollHeight || 250);
            }
            return Math.ceil(document.body.scrollHeight || 250);
          })()
        `);
        // 96 CSS px = 1 inch. Add minimal 0.15 inch bottom padding for clean cut
        const heightInches = Math.max(1.8, (heightPx / 96) + 0.15);
        const pdfOptions = {
          marginsType: 1, // none (CSS in receipt_template.html handles exact margins)
          printBackground: true,
          pageSize: {
            width: 3.15, // 80mm roll width = 3.1496 inches
            height: heightInches
          }
        };

        sendPrintDebugLog(`Generating receipt PDF: 3.15in x ${heightInches.toFixed(2)}in (${heightPx}px content)`);
        const pdfData = await printWin.webContents.printToPDF(pdfOptions);
        const os = require('os');
        const tempPdfPath = path.join(os.tmpdir(), `receipt_${orderId}_${Date.now()}.pdf`);
        fs.writeFileSync(tempPdfPath, pdfData);
        sendPrintDebugLog(`Receipt PDF saved: ${tempPdfPath}. Sending to '${targetPrinter}' via pdf-to-printer (noscale)...`);

        const ptp = require('pdf-to-printer');
        await ptp.print(tempPdfPath, targetPrinter ? { printer: targetPrinter, scale: 'noscale' } : { scale: 'noscale' });
        sendPrintDebugLog(`Receipt printed successfully via pdf-to-printer on: '${targetPrinter || 'default'}'`);
        printedOk = true;

        try { fs.unlinkSync(tempPdfPath); } catch (e) {}
      } catch (pdfErr) {
        sendPrintDebugLog(`pdf-to-printer error: ${pdfErr.message}. Attempting webContents.print fallback...`);
      }

      // 2. Fallback to Chromium webContents.print if pdf-to-printer failed
      if (!printedOk) {
        const printOptions = {
          silent: true,
          printBackground: true,
          margins: { marginType: 'none' }
        };
        if (targetPrinter && !/PDF|XPS|OneNote|Fax/i.test(targetPrinter)) {
          printOptions.deviceName = targetPrinter;
        }
        sendPrintDebugLog(`Fallback: executing webContents.print to '${printOptions.deviceName || 'default'}'`);
        printWin.webContents.print(printOptions, (success, failureReason) => {
          if (!success) {
            sendPrintDebugLog(`Fallback webContents.print also failed: ${failureReason}`);
          } else {
            sendPrintDebugLog(`Fallback webContents.print succeeded on: ${targetPrinter || 'default'}`);
          }
        });
      }

      // 3. Open cash drawer on cash payment
      if (!isCheck) {
        setTimeout(() => {
          kickCashDrawerRaw(targetPrinter);
        }, 150);
      }

      setTimeout(() => {
        try { printWin.close(); } catch (e) {}
      }, 3000);

    } catch (err) {
      sendPrintDebugLog(`Error in performPrint: ${err.message}`);
      try { printWin.close(); } catch (e) {}
    }
  }

  // Sincronización instantánea: cuando la plantilla termina de cargar el logo y los datos, cambia el título
  printWin.webContents.on('page-title-updated', (e, title) => {
    if (title === 'READY_TO_PRINT') {
      sendPrintDebugLog(`Page title signaled READY_TO_PRINT for orderId: ${orderId}`);
      performPrint();
    }
  });

  // Temporizador de respaldo por si el título ya cambió antes del listener
  printWin.webContents.once('did-finish-load', () => {
    setTimeout(() => {
      if (!hasPrinted) {
        sendPrintDebugLog(`Fallback timer triggered performPrint for orderId: ${orderId}`);
        performPrint();
      }
    }, 700);
  });

  printWin.loadURL(`${baseUrl}/receipt_template.html?orderId=${encodeURIComponent(orderId)}${isCheck ? '&isCheck=true' : ''}`);
});

ipcMain.on('print-test-silent', async (event, { printerName, serverUrl }) => {
  const baseUrl = serverUrl || stationConfig.serverUrl || 'http://localhost:3000';
  sendPrintDebugLog(`Received print-test-silent request for printer: ${printerName || 'none'}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`${baseUrl}/receipt_template.html?test=true&printerName=${encodeURIComponent(printerName || '')}`);
  printWin.webContents.once('did-finish-load', () => {
    setTimeout(async () => {
      try {
        let target = printerName;
        if (!target) {
          target = await resolveThermalPrinter('');
        }

        let printedOk = false;
        try {
          const heightPx = await printWin.webContents.executeJavaScript('Math.max(document.body.scrollHeight || 0, document.documentElement.scrollHeight || 0, 350)');
          const heightInches = Math.max(3.5, (heightPx / 96) + 0.4);
          const pdfOptions = {
            marginsType: 1,
            printBackground: true,
            pageSize: { width: 3.15, height: heightInches }
          };
          sendPrintDebugLog(`Generating test receipt PDF: 3.15in x ${heightInches.toFixed(2)}in`);
          const pdfData = await printWin.webContents.printToPDF(pdfOptions);
          const os = require('os');
          const tempPdfPath = path.join(os.tmpdir(), `test_receipt_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, pdfData);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, target ? { printer: target } : {});
          sendPrintDebugLog(`Test receipt printed successfully via pdf-to-printer on: '${target || 'default'}'`);
          printedOk = true;
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
        } catch (pdfErr) {
          sendPrintDebugLog(`Test receipt pdf-to-printer error: ${pdfErr.message}`);
        }

        if (!printedOk) {
          const printOptions = { silent: true, printBackground: true, margins: { marginType: 'none' } };
          if (target) printOptions.deviceName = target;
          printWin.webContents.print(printOptions, (success, failureReason) => {
            if (!success) sendPrintDebugLog(`Test receipt webContents.print failed: ${failureReason}`);
            else sendPrintDebugLog(`Test receipt webContents.print succeeded`);
          });
        }

        setTimeout(() => {
          try { printWin.close(); } catch (e) {}
        }, 3000);
      } catch (err) {
        sendPrintDebugLog(`Error in print-test-silent: ${err.message}`);
        try { printWin.close(); } catch (e) {}
      }
    }, 400);
  });
});

ipcMain.on('open-cash-drawer', async (event, data = {}) => {
  try {
    const printerName = (data && data.printerName) ? data.printerName.trim() : '';
    // 1. Try local drawer service first if active (<50ms)
    const kicked = await new Promise((resolve) => {
      const http = require('http');
      const req = http.request({
        hostname: '127.0.0.1',
        port: 3005,
        path: '/kick',
        method: 'POST',
        timeout: 200
      }, (res) => resolve(res.statusCode === 200));
      req.on('error', () => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
      req.end();
    });

    if (kicked) {
      sendPrintDebugLog('Cash drawer opened via local drawer service (instant)');
      return;
    }

    // 2. Direct Winspool RAW kick via print_raw.ps1
    await kickCashDrawerRaw(printerName);
  } catch (e) {
    sendPrintDebugLog(`Error opening cash drawer: ${e.message}`);
  }
});

const http = require('http');

function getSettingsFromServer(serverUrl) {
  return new Promise((resolve) => {
    const baseUrl = serverUrl || stationConfig.serverUrl || 'http://127.0.0.1:3000';
    const urlStr = `${baseUrl}/api/admin/settings`;
    const client = urlStr.startsWith('https') ? require('https') : require('http');
    client.get(urlStr, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve({});
        }
      });
    }).on('error', (e) => {
      resolve({});
    });
  });
}

function sendPrintDebugLog(msg) {
  try {
    const postData = JSON.stringify({ message: msg });
    const targetHost = stationConfig.serverHost || '127.0.0.1';
    const targetPort = stationConfig.serverPort || 3000;
    const req = http.request({
      hostname: targetHost,
      port: targetPort,
      path: '/api/print-debug',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    }, (res) => {
      res.resume();
    });
    req.on('error', (e) => {
      console.error(`Error sending print log to server: ${e.message}`);
    });
    req.write(postData);
    req.end();
  } catch (err) {
    console.error("Error in sendPrintDebugLog:", err);
  }
}

ipcMain.on('print-invoice-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-invoice-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  printWin.loadURL(`http://localhost:3000/invoice_template.html?orderId=${orderId}`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for invoice orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
          } else {
            targetPrinter = printers[0].name;
          }
        }
        
        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        try {
          const fs = require('fs');
          const path = require('path');
          const os = require('os');
          
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `invoice_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        printWin.close();
      }
    }, 1500); // Dar 1.5 segundos para cargar y renderizar la plantilla HTML
  });
});

ipcMain.on('print-cake-silent', (event, { orderId }) => {
  sendPrintDebugLog(`Received print-cake-silent request for orderId: ${orderId}`);
  const printWin = new BrowserWindow({
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      backgroundThrottling: false
    }
  });
  printWin.loadURL(`http://localhost:3000/comanda_pastel.html?orderId=${orderId}&silent=true`);
  printWin.webContents.once('did-finish-load', () => {
    sendPrintDebugLog(`webContents did-finish-load event fired for orderId: ${orderId}`);
    setTimeout(async () => {
      try {
        const settings = await getSettingsFromServer();
        const printerName = settings.reportingPrinterName || settings.kitchenPrinterName || '';
        let printers = [];
        try {
          if (typeof printWin.webContents.getPrintersAsync === 'function') {
            printers = await printWin.webContents.getPrintersAsync();
          } else if (typeof printWin.webContents.getPrinters === 'function') {
            printers = printWin.webContents.getPrinters();
          }
        } catch (pe) {
          sendPrintDebugLog(`Error getting printers list: ${pe.message}`);
        }
        
        sendPrintDebugLog(`Printers available in Electron: ${JSON.stringify(printers.map(p => ({ name: p.name, isDefault: p.isDefault })))}`);
        sendPrintDebugLog(`Configured reportingPrinterName: "${printerName}"`);

        const printOptions = {
          silent: true,
          printBackground: true
        };
        
        let targetPrinter = printerName ? printerName.trim() : "";
        
        // Robust fallback: if no reporting printer is configured, attempt to use the OS default or first available printer
        if (!targetPrinter && printers.length > 0) {
          const defaultP = printers.find(p => p.isDefault);
          if (defaultP) {
            targetPrinter = defaultP.name;
            sendPrintDebugLog(`No reportingPrinterName configured. Falling back to default printer: "${targetPrinter}"`);
          } else {
            targetPrinter = printers[0].name;
            sendPrintDebugLog(`No default printer set. Falling back to first available printer: "${targetPrinter}"`);
          }
        }
        
        if (targetPrinter) {
          printOptions.deviceName = targetPrinter;
        }
        
        sendPrintDebugLog(`Generating PDF via printToPDF...`);
        try {
          const fs = require('fs');
          const os = require('os');
          const pdfOptions = {
            marginsType: 0,
            pageSize: 'Letter',
            printBackground: true
          };
          const data = await printWin.webContents.printToPDF(pdfOptions);
          const tempPdfPath = path.join(os.tmpdir(), `cake_order_${orderId}_${Date.now()}.pdf`);
          fs.writeFileSync(tempPdfPath, data);
          sendPrintDebugLog(`PDF generated successfully at ${tempPdfPath}. Printing via pdf-to-printer to: "${targetPrinter}"`);

          const ptp = require('pdf-to-printer');
          await ptp.print(tempPdfPath, { printer: targetPrinter });
          sendPrintDebugLog(`Print job sent successfully via SumatraPDF to "${targetPrinter}"`);
          
          try { fs.unlinkSync(tempPdfPath); } catch (e) {}
          setTimeout(() => { printWin.close(); }, 2000);
        } catch (printErr) {
          sendPrintDebugLog(`Error in printToPDF / pdf-to-printer execution: ${printErr.message}`);
          console.error(printErr);
          setTimeout(() => { printWin.close(); }, 2000);
        }
      } catch (err) {
        sendPrintDebugLog(`Print error catch: ${err.message}`);
        printWin.close();
      }
    }, 1200); // Dar 1.2 segundos para cargar y renderizar la plantilla HTML
  });
});

function checkWindowsEnvironment() {
  if (process.platform !== 'win32') return;

  const { exec } = require('child_process');
  
  // Whitelist current app path and parent path
  const appPath = path.resolve(__dirname).replace(/\\/g, '\\\\');
  const parentPath = path.resolve(__dirname, '..').replace(/\\/g, '\\\\');

  // 1. Check Defender Exclusions
  exec('powershell -Command "Get-MpPreference | Select-Object -ExpandProperty ExclusionPath"', (err, stdout, stderr) => {
    if (err) {
      console.error('Error checking Defender exclusions:', err);
      return;
    }
    const exclusions = stdout || '';
    const isAppExcluded = exclusions.includes(path.resolve(__dirname)) || exclusions.includes(path.resolve(__dirname, '..'));

    if (!isAppExcluded) {
      console.log('App directory is not whitelisted in Windows Defender. Requesting exclusion...');
      const addExclusionCmd = `powershell -Command "Start-Process powershell -ArgumentList '-Command Add-MpPreference -ExclusionPath \\\"${appPath}\\\",\\\"${parentPath}\\\"' -Verb RunAs -WindowStyle Hidden"`;
      exec(addExclusionCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Defender exclusion request:', uacErr);
      });
    } else {
      console.log('Windows Defender exclusion check: OK.');
    }
  });

  // 2. Check Firewall Rule for Port 3000
  exec('powershell -Command "Get-NetFirewallRule -DisplayName \\\"Impossible POS Local Server\\\" -ErrorAction SilentlyContinue"', (err, stdout, stderr) => {
    const ruleExists = stdout && stdout.includes('Impossible POS Local Server');
    if (!ruleExists) {
      console.log('Firewall rule for Impossible POS is missing. Requesting addition...');
      const addFirewallCmd = `powershell -Command "Start-Process cmd -ArgumentList '/c netsh advfirewall firewall add rule name=\\\"Impossible POS Local Server\\\" dir=in action=allow protocol=TCP localport=3000 profile=private,domain' -Verb RunAs -WindowStyle Hidden"`;
      exec(addFirewallCmd, (uacErr) => {
        if (uacErr) console.error('Error running UAC Firewall addition request:', uacErr);
      });
    } else {
      console.log('Windows Firewall rule check: OK.');
    }
  });
}

function startLocalDrawerService() {
  if (process.platform !== 'win32') return;
  try {
    const fsLocal = require('fs');
    const pathLocal = require('path');
    const scriptPath = pathLocal.join(__dirname, 'drawer_service.ps1');
    if (!fsLocal.existsSync(scriptPath)) return;
    const child = require('child_process').spawn('powershell.exe', ['-ExecutionPolicy', 'Bypass', '-NoProfile', '-WindowStyle', 'Hidden', '-File', scriptPath], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true
    });
    child.unref();
  } catch (e) {
    console.warn('Could not launch local drawer service:', e.message);
  }
}

app.whenReady().then(async () => {
  if (!needsWizard && !forceSetup) {
    await ensureServerRunning();
  }
  startLocalDrawerService();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

