const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('electron-minimize'),
  restore: () => ipcRenderer.send('electron-restore'),
  shutdown: () => ipcRenderer.send('system-shutdown'),
  restart: () => ipcRenderer.send('system-restart'),
  printCakeSilent: (orderId) => ipcRenderer.send('print-cake-silent', { orderId }),
  printInvoiceSilent: (orderId) => ipcRenderer.send('print-invoice-silent', { orderId }),
  getPrimaryScreenSourceId: () => ipcRenderer.invoke('get-primary-screen-source-id'),
  getPrinters: () => ipcRenderer.invoke('get-printers'),
  printReceiptSilent: (orderId, serverUrl, isCheck, printerName) => ipcRenderer.send('print-receipt-silent', { orderId, serverUrl, isCheck: !!isCheck, printerName }),
  printTestSilent: (printerName, serverUrl) => ipcRenderer.send('print-test-silent', { printerName, serverUrl }),
  openCashDrawer: (printerName) => ipcRenderer.send('open-cash-drawer', { printerName }),
  saveStationConfig: (config) => ipcRenderer.invoke('save-station-config', config),
  getStationConfig: () => ipcRenderer.invoke('get-station-config'),
  discoverServers: () => ipcRenderer.invoke('discover-servers'),
  testServerConnection: (host, port) => ipcRenderer.invoke('test-server-connection', { host, port }),
  openStationWizard: () => ipcRenderer.send('open-station-wizard')
});
