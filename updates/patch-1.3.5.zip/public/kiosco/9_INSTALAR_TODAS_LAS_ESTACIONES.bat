@echo off
setlocal EnableDelayedExpansion
title Instalar Todas las Estaciones Kiosco - Impossible POS
color 0E

echo ======================================================================
echo   IMPOSSIBLE POS - INSTALADOR DE TODAS LAS ESTACIONES EN EL ESCRITORIO
echo ======================================================================
echo.
echo Este asistente instalara los accesos directos de todas las estaciones
echo (Cocina, Bar, Photo Hub, Lobby TV, Runner, Hostess, Caja).
echo.
pause

call "%~dp01_INSTALAR_COCINA_KDS.bat"
call "%~dp02_INSTALAR_COCINA_PEDIDOS_ESPECIALES.bat"
call "%~dp03_INSTALAR_BAR_KDS.bat"
call "%~dp04_INSTALAR_PHOTO_HUB.bat"
call "%~dp05_INSTALAR_LOBBY_TV.bat"
call "%~dp06_INSTALAR_RUNNER.bat"
call "%~dp07_INSTALAR_HOSTESS.bat"
call "%~dp08_INSTALAR_CAJA_SECUNDARIA.bat"

echo.
echo ======================================================================
echo   TODAS LAS ESTACIONES FUERON INSTALADAS CON EXITO EN TU ESCRITORIO!
echo ======================================================================
pause
