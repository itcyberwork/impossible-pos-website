@echo off
setlocal EnableDelayedExpansion
title Instalar Hostess (Recepcion y Mesas) - Impossible POS
color 0B

echo ======================================================================
echo   IMPOSSIBLE POS - INSTALADOR DE ACCESO DIRECTO KIOSCO
echo   Estacion: Hostess (Recepcion y Mesas)
echo ======================================================================
echo.

:: 1. Cargar o solicitar la direccion IP del Servidor Central (Sheila's PC)
set "SERVER_IP="
if exist "%~dp0server_ip.txt" (
    set /p SERVER_IP=<"%~dp0server_ip.txt"
)

if "%SERVER_IP%"=="" (
    echo Detectando conexion...
    powershell -Command "$ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notlike '*Loopback*' -and $_.IPAddress -notlike '169.254*' } | Select-Object -First 1).IPAddress; if ($ip) { [IO.File]::WriteAllText('%~dp0server_ip.txt', $ip) }"
    if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"
)

if "%SERVER_IP%"=="" set "SERVER_IP=127.0.0.1"

echo Direccion actual del servidor POS: http://%SERVER_IP%:3000
echo.
set /p USER_INPUT="Presiona [ENTER] para usar esa IP o escribe una nueva direccion IP: "
if not "!USER_INPUT!"=="" (
    set "SERVER_IP=!USER_INPUT!"
    echo !SERVER_IP!>"%~dp0server_ip.txt"
)

set "TARGET_URL=http://%SERVER_IP%:3000/hostess.html"
set "SHORTCUT_NAME=Impossible POS - Hostess.lnk"
set "ICON_NAME=hostess.ico"
set "APP_DIR=%LOCALAPPDATA%\ImpossiblePOS"
set "ICON_DEST=%APP_DIR%\Icons\%ICON_NAME%"
set "USER_DATA=%APP_DIR%\Kiosk_hostess"

if not exist "%APP_DIR%\Icons" mkdir "%APP_DIR%\Icons"
if not exist "%USER_DATA%" mkdir "%USER_DATA%"

:: 2. Copiar icono oficial (primero local si existe, o descargarlo del servidor)
echo [1/3] Configurando icono oficial...
if exist "%~dp0Icons\%ICON_NAME%" (
    copy /Y "%~dp0Icons\%ICON_NAME%" "%ICON_DEST%" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1
    if not exist "%ICON_DEST%" (
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1
    )
)

:: 3. Detectar navegador Chromium (Edge o Chrome)
echo [2/3] Localizando navegador compatible (Edge o Chrome)...
set "BROWSER_EXE="
set "BROWSER_ARGS="

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
    set BROWSER_ARGS=--app="%TARGET_URL%" --user-data-dir="%USER_DATA%" --kiosk --edge-kiosk-type=fullscreen --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
    set BROWSER_ARGS=--app="%TARGET_URL%" --user-data-dir="%USER_DATA%" --kiosk --edge-kiosk-type=fullscreen --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
    set BROWSER_ARGS=--app="%TARGET_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
    set BROWSER_ARGS=--app="%TARGET_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
    set BROWSER_ARGS=--app="%TARGET_URL%" --user-data-dir="%USER_DATA%" --kiosk --no-first-run --disable-pinch --overscroll-history-navigation=0
)

if "%BROWSER_EXE%"=="" (
    echo ERROR: No se encontro Microsoft Edge ni Google Chrome en esta computadora.
    pause
    exit /b 1
)

:: 4. Crear acceso directo en el Escritorio con PowerShell
echo [3/3] Creando acceso directo en el Escritorio...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%BROWSER_EXE%'; $shortcut.Arguments = '%BROWSER_ARGS%'; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.Description = 'Pantalla de Recepcion, Lista de Espera y Mesas'; $shortcut.Save();"

echo.
echo ======================================================================
echo   FELICIDADES: Acceso Directo creado con exito en tu Escritorio:
echo   "%SHORTCUT_NAME%"
echo.
echo   - Modo: Kiosco Pantalla Completa (sin bordes de navegador)
echo   - URL:  %TARGET_URL%
echo   - Icono: Oficial (%ICON_NAME%)
echo ======================================================================
echo.
timeout /t 5
