@echo off
setlocal EnableDelayedExpansion
title Cambiar IP del Servidor Central - Impossible POS
color 0A

echo ======================================================================
echo   CONFIGURAR / CAMBIAR DIRECCION IP DEL SERVIDOR CENTRAL
echo ======================================================================
echo.
set "CURRENT_IP="
if exist "%~dp0server_ip.txt" set /p CURRENT_IP=<"%~dp0server_ip.txt"
if "%CURRENT_IP%"=="" set "CURRENT_IP=127.0.0.1"

echo La direccion IP actual del servidor es: %CURRENT_IP%
echo.
set /p NEW_IP="Ingresa la nueva direccion IP del Servidor Central (ejemplo 192.168.1.50): "

if not "%NEW_IP%"=="" (
    echo %NEW_IP%>"%~dp0server_ip.txt"
    echo.
    echo Guardado exitosamente. La nueva IP es: %NEW_IP%
) else (
    echo No se hicieron cambios.
)
echo.
pause
