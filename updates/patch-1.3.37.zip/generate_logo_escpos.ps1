param(
    [string]$ImagePath,
    [string]$OutputPath,
    [int]$MaxWidth = 384
)

if (-not (Test-Path $ImagePath)) {
    Write-Error "Image file does not exist: $ImagePath"
    exit 1
}

$cleanPngPath = [System.IO.Path]::Combine([System.IO.Path]::GetDirectoryName($OutputPath), "logo_clean.png")

$csharpCode = @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

public class FastEscpos {
    public static byte[] Process(string imagePath, string cleanPngPath, int maxWidth) {
        byte[] imgBytes = File.ReadAllBytes(imagePath);
        using (MemoryStream inMs = new MemoryStream(imgBytes))
        using (Bitmap orig = new Bitmap(inMs)) {
            int targetWidth = maxWidth;
            if (orig.Width < targetWidth) {
                targetWidth = (orig.Width / 8) * 8;
                if (targetWidth < 8) targetWidth = 8;
            } else {
                targetWidth = (targetWidth / 8) * 8;
            }
            double ratio = (double)targetWidth / orig.Width;
            int targetHeight = (int)Math.Round(orig.Height * ratio);
            if (targetHeight < 1) targetHeight = 1;

            using (Bitmap resized = new Bitmap(targetWidth, targetHeight)) {
                using (Graphics g = Graphics.FromImage(resized)) {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.Clear(Color.White);
                    g.DrawImage(orig, 0, 0, targetWidth, targetHeight);
                }

                // Sample dark pixels to detect dark background
                long darkCount = 0, totalSampled = 0;
                for (int y = 0; y < targetHeight; y += 4) {
                    for (int x = 0; x < targetWidth; x += 4) {
                        Color p = resized.GetPixel(x, y);
                        if (p.A > 50) {
                            double lum = (p.R * 0.299) + (p.G * 0.587) + (p.B * 0.114);
                            if (lum < 128) darkCount++;
                            totalSampled++;
                        }
                    }
                }
                bool isInverted = (totalSampled > 0) && ((double)darkCount / totalSampled > 0.55);

                // If inverted, produce clean white-background inverted PNG for HTML printing
                if (isInverted && !string.IsNullOrEmpty(cleanPngPath)) {
                    try {
                        using (Bitmap cleanBmp = new Bitmap(targetWidth, targetHeight)) {
                            using (Graphics cg = Graphics.FromImage(cleanBmp)) {
                                ColorMatrix cm = new ColorMatrix(new float[][] {
                                    new float[] {-1,  0,  0, 0, 0},
                                    new float[] { 0, -1,  0, 0, 0},
                                    new float[] { 0,  0, -1, 0, 0},
                                    new float[] { 0,  0,  0, 1, 0},
                                    new float[] { 1,  1,  1, 0, 1}
                                });
                                using (ImageAttributes ia = new ImageAttributes()) {
                                    ia.SetColorMatrix(cm);
                                    cg.DrawImage(resized, new Rectangle(0, 0, targetWidth, targetHeight), 0, 0, targetWidth, targetHeight, GraphicsUnit.Pixel, ia);
                                }
                            }
                            cleanBmp.Save(cleanPngPath, ImageFormat.Png);
                        }
                    } catch {}
                }

                int widthBytes = targetWidth / 8;
                byte xL = (byte)(widthBytes & 0xFF);
                byte xH = (byte)((widthBytes >> 8) & 0xFF);
                byte yL = (byte)(targetHeight & 0xFF);
                byte yH = (byte)((targetHeight >> 8) & 0xFF);

                using (MemoryStream ms = new MemoryStream()) {
                    ms.Write(new byte[] { 0x1B, 0x40, 0x1B, 0x61, 0x01 }, 0, 5);
                    ms.Write(new byte[] { 0x1D, 0x76, 0x30, 0x00, xL, xH, yL, yH }, 0, 8);

                    for (int y = 0; y < targetHeight; y++) {
                        for (int xb = 0; xb < widthBytes; xb++) {
                            byte b = 0;
                            for (int bit = 0; bit < 8; bit++) {
                                int x = (xb * 8) + bit;
                                Color px = resized.GetPixel(x, y);
                                double lum = (px.R * 0.299) + (px.G * 0.587) + (px.B * 0.114);
                                if (isInverted) {
                                    if (lum > 80) b |= (byte)(1 << (7 - bit));
                                } else {
                                    if (lum < 140) b |= (byte)(1 << (7 - bit));
                                }
                            }
                            ms.WriteByte(b);
                        }
                    }
                    ms.Write(new byte[] { 0x1B, 0x61, 0x00, 0x0A }, 0, 4);
                    return ms.ToArray();
                }
            }
        }
    }
}
"@

try {
    Add-Type -TypeDefinition $csharpCode -ReferencedAssemblies System.Drawing -ErrorAction SilentlyContinue
} catch {}

try {
    $bytes = [FastEscpos]::Process($ImagePath, $cleanPngPath, $MaxWidth)
    $outDir = [System.IO.Path]::GetDirectoryName($OutputPath)
    if ($outDir -and -not (Test-Path $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }
    [System.IO.File]::WriteAllBytes($OutputPath, $bytes)
    Write-Host "SUCCESS: Generated ESC/POS raster image ($($bytes.Length) bytes)"
} catch {
    Write-Error "Failed to process logo: $_"
    exit 1
}
