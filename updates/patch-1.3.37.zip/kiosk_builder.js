const path = require('path');
const fs = require('fs');

const STATIONS_CONFIG = {
  kitchen: {
    id: 'kitchen',
    num: 1,
    name_en: 'Kitchen Display 1 (Hot Food / Grill KDS)',
    name_es: 'Pantalla de Cocina 1 (Platos Calientes / KDS)',
    fileName_en: '1_INSTALL_KITCHEN_KDS.bat',
    fileName_es: '1_INSTALAR_COCINA_KDS.bat',
    shortcut_en: 'Impossible POS - Kitchen KDS.lnk',
    shortcut_es: 'Impossible POS - Cocina KDS.lnk',
    icon: 'kitchen.ico',
    url: '/cocina.html',
    desc_en: 'Main Kitchen Display (KDS)',
    desc_es: 'Pantalla de Cocina (KDS)'
  },
  bakery: {
    id: 'bakery',
    num: 2,
    name_en: 'Kitchen Display 2 (Cold Prep / Bakery KDS)',
    name_es: 'Pantalla de Cocina 2 (Preparacion Fria / Panaderia)',
    fileName_en: '2_INSTALL_BAKERY_SPECIAL_ORDERS.bat',
    fileName_es: '2_INSTALAR_PASTELERIA_KDS.bat',
    shortcut_en: 'Impossible POS - Bakery KDS.lnk',
    shortcut_es: 'Impossible POS - Cocina Panaderia.lnk',
    icon: 'cake_kds.ico',
    url: '/cocina.html?station=bakery',
    desc_en: 'Cold Prep and Bakery Display',
    desc_es: 'Pantalla de Cocina Fria y Panaderia'
  },
  bar: {
    id: 'bar',
    num: 3,
    name_en: 'Bar Display (Cocktails & Beverages KDS)',
    name_es: 'Pantalla de Bar (Bebidas y Cocteleria)',
    fileName_en: '3_INSTALL_BAR_KDS.bat',
    fileName_es: '3_INSTALAR_BAR_KDS.bat',
    shortcut_en: 'Impossible POS - Bar Hub.lnk',
    shortcut_es: 'Impossible POS - Bar Hub.lnk',
    icon: 'bar.ico',
    url: '/kds_bar.html',
    desc_en: 'Bar and Drinks Display',
    desc_es: 'Pantalla de Barra y Bebidas'
  },
  special: {
    id: 'special',
    num: 4,
    name_en: 'Special Orders Display (Custom Cakes & Catering)',
    name_es: 'Pantalla de Pedidos Especiales (Pasteles Personalizados)',
    fileName_en: '4_INSTALL_SPECIAL_ORDERS.bat',
    fileName_es: '4_INSTALAR_PEDIDOS_ESPECIALES.bat',
    shortcut_en: 'Impossible POS - Special Orders.lnk',
    shortcut_es: 'Impossible POS - Pedidos Especiales.lnk',
    icon: 'cake_kds.ico',
    url: '/comanda_pastel.html',
    desc_en: 'Custom Orders & Catering Display',
    desc_es: 'Pantalla de Pedidos Especiales y Eventos'
  },
  photo: {
    id: 'photo',
    num: 5,
    name_en: 'Photo Hub (Cake & Custom Order Photo Viewer)',
    name_es: 'Photo Hub (Visor de Fotos de Pasteles y Pedidos)',
    fileName_en: '5_INSTALL_PHOTO_HUB.bat',
    fileName_es: '5_INSTALAR_PHOTO_HUB.bat',
    shortcut_en: 'Impossible POS - Photo Hub.lnk',
    shortcut_es: 'Impossible POS - Photo Hub.lnk',
    icon: 'photo_hub.ico',
    url: '/photos.html',
    desc_en: 'Customer Photos Viewer',
    desc_es: 'Visor de Fotos'
  },
  lobby_tv: {
    id: 'lobby_tv',
    num: 6,
    name_en: 'Lobby TV (Customer Queue & Waitlist Display)',
    name_es: 'Lobby TV (Pantalla de Turnos y Sala de Espera)',
    fileName_en: '6_INSTALL_LOBBY_TV.bat',
    fileName_es: '6_INSTALAR_LOBBY_TV.bat',
    shortcut_en: 'Impossible POS - Lobby TV.lnk',
    shortcut_es: 'Impossible POS - Lobby TV.lnk',
    icon: 'lobby_tv.ico',
    url: '/espera.html',
    desc_en: 'Customer Queue Display',
    desc_es: 'Pantalla de Turnos'
  },
  runner: {
    id: 'runner',
    num: 7,
    name_en: 'Runner Hub (Order Expediter & Dispatch)',
    name_es: 'Runner Hub (Despacho de Pedidos y Expo)',
    fileName_en: '7_INSTALL_RUNNER.bat',
    fileName_es: '7_INSTALAR_RUNNER.bat',
    shortcut_en: 'Impossible POS - Runner Dispatch.lnk',
    shortcut_es: 'Impossible POS - Runner Despacho.lnk',
    icon: 'runner.ico',
    url: '/runner.html',
    desc_en: 'Order Expediter Display',
    desc_es: 'Pantalla de Despacho'
  },
  hostess: {
    id: 'hostess',
    num: 8,
    name_en: 'Hostess Hub (Table Seating & Reception)',
    name_es: 'Hostess Hub (Mesas y Recepcion)',
    fileName_en: '8_INSTALL_HOSTESS.bat',
    fileName_es: '8_INSTALAR_HOSTESS.bat',
    shortcut_en: 'Impossible POS - Hostess.lnk',
    shortcut_es: 'Impossible POS - Hostess.lnk',
    icon: 'hostess.ico',
    url: '/hostess.html',
    desc_en: 'Hostess Tables Display',
    desc_es: 'Pantalla de Mesas y Recepcion'
  },
  kiosk: {
    id: 'kiosk',
    num: 9,
    name_en: 'Self-Ordering Kiosk (Customer Ordering Station)',
    name_es: 'Kiosco de Autoservicio (Ordenes para Clientes)',
    fileName_en: '9_INSTALL_ORDERING_KIOSK.bat',
    fileName_es: '9_INSTALAR_KIOSCO_ORDENAR.bat',
    shortcut_en: 'Impossible POS - Ordering Kiosk.lnk',
    shortcut_es: 'Impossible POS - Kiosco de Ordenes.lnk',
    icon: 'pos.ico',
    url: '/ordena.html',
    desc_en: 'Customer Self-Ordering Terminal',
    desc_es: 'Terminal de Autoservicio para Clientes'
  },
  secondary: {
    id: 'secondary',
    num: 10,
    name_en: 'Secondary Register (Cashier POS Terminal 2)',
    name_es: 'Caja Secundaria (Terminal POS 2)',
    fileName_en: '10_INSTALL_SECONDARY_REGISTER.bat',
    fileName_es: '10_INSTALAR_CAJA_SECUNDARIA.bat',
    shortcut_en: 'Impossible POS - Secondary POS.lnk',
    shortcut_es: 'Impossible POS - Caja Secundaria.lnk',
    icon: 'pos.ico',
    url: '/caja_v14.html?station=2',
    desc_en: 'Secondary Checkout Terminal',
    desc_es: 'Terminal de Cobro Secundaria'
  }
};

function generateStationLauncherBat(st, serverIp) {
  return `@echo off\r
setlocal EnableDelayedExpansion\r
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"\r
set "SERVER_IP=${serverIp}"\r
if exist "%APP_DIR%\\server_ip.txt" set /p SERVER_IP=<"%APP_DIR%\\server_ip.txt"\r
if "%SERVER_IP%"=="" set "SERVER_IP=${serverIp}"\r
\r
:: Plug and Play: Auto-discover server if not responding\r
set "AUTO_IP="\r
if exist "%APP_DIR%\\discover_server.ps1" (\r
    for /f "usebackq delims=" %%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%\\discover_server.ps1" -LastKnownIp "%SERVER_IP%"\`) do (\r
        if not "%%i"=="" set "AUTO_IP=%%i"\r
    )\r
)\r
if not "!AUTO_IP!"=="" (\r
    set "SERVER_IP=!AUTO_IP!"\r
    echo !AUTO_IP!>"%APP_DIR%\\server_ip.txt"\r
)\r
\r
:: Verify if Central Server is reachable locally\r
set "SERVER_FOUND=0"\r
powershell -NoProfile -Command "try { $c = New-Object System.Net.Sockets.TcpClient; $ar = $c.BeginConnect('%SERVER_IP%', 3000, $null, $null); if ($ar.AsyncWaitHandle.WaitOne(400, $false) -and $c.Connected) { $c.EndConnect($ar); $c.Close(); exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1\r
if %ERRORLEVEL% EQU 0 set "SERVER_FOUND=1"\r
\r
if "%SERVER_FOUND%"=="0" if "%SERVER_IP%"=="127.0.0.1" (\r
    echo.\r
    echo ======================================================================\r
    echo   [!] CENTRAL SERVER NOT FOUND LOCALLY ON 127.0.0.1\r
    echo ======================================================================\r
    echo   If this computer is a Secondary Screen (Kitchen Display, Bar, etc.),\r
    echo   please enter the IP address of your Main Cash Register:\r
    echo.\r
    set /p INPUT_IP="  Enter Main Cash Register IP (e.g. 10.0.0.125): "\r
    if not "!INPUT_IP!"=="" (\r
        set "SERVER_IP=!INPUT_IP!"\r
        echo !INPUT_IP!>"%APP_DIR%\\server_ip.txt"\r
        echo !INPUT_IP!>"%~dp0server_ip.txt"\r
    )\r
)\r
\r
set "BROWSER_EXE="\r
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"\r
\r
if "%BROWSER_EXE%"=="" (\r
    start "http://%SERVER_IP%:3000${st.url}"\r
    exit\r
)\r
\r
start "" "%BROWSER_EXE%" --app="http://%SERVER_IP%:3000${st.url}" --kiosk --no-first-run\r
exit\r
`;
}

function generateSingleStationInstaller(st, serverIp, lang) {
  const isEs = lang === 'es';
  const title = isEs ? `Instalar ${st.name_es} - Impossible POS` : `Install ${st.name_en} - Impossible POS`;
  const shortcutName = isEs ? st.shortcut_es : st.shortcut_en;
  const desc = isEs ? st.desc_es : st.desc_en;
  const step1 = isEs ? '[1/3] Configurando icono oficial...' : '[1/3] Setting up official icon...';
  const step2 = isEs ? '[2/3] Localizando navegador (Chrome o Edge)...' : '[2/3] Locating browser (Chrome or Edge)...';
  const step3 = isEs ? '[3/3] Creando acceso directo en el escritorio y auto-arranque...' : '[3/3] Creating Desktop shortcut and auto-start...';
  const errBrowser = isEs ? 'ERROR: No se encontro Google Chrome ni Microsoft Edge en esta computadora.' : 'ERROR: Neither Google Chrome nor Microsoft Edge was found on this computer.';
  const successMsg = isEs ? `EXITO: ${st.name_es} configurada con exito en esta computadora.` : `SUCCESS: ${st.name_en} configured successfully on this computer.`;

  return `@echo off\r
setlocal EnableDelayedExpansion\r
title ${title}\r
color 0B\r
\r
echo ======================================================================\r
echo   IMPOSSIBLE POS - HARDWARE STATIONS INSTALLER\r
echo   Station: ${isEs ? st.name_es : st.name_en}\r
echo ======================================================================\r
echo.\r
\r
set "SERVER_IP=${serverIp}"\r
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"\r
if "%SERVER_IP%"=="" set "SERVER_IP=${serverIp}"\r
\r
set "SHORTCUT_NAME=${shortcutName}"\r
set "ICON_NAME=${st.icon}"\r
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"\r
set "ICON_DEST=%APP_DIR%\\Icons\\%ICON_NAME%"\r
set "LAUNCH_BAT=%APP_DIR%\\launch_${st.id}.bat"\r
\r
if not exist "%APP_DIR%\\Icons" mkdir "%APP_DIR%\\Icons"\r
if exist "%~dp0Icons\\%ICON_NAME%" copy /Y "%~dp0Icons\\%ICON_NAME%" "%ICON_DEST%" >nul\r
if exist "%~dp0discover_server.ps1" copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\\discover_server.ps1" >nul\r
if exist "%~dp0launch_${st.id}.bat" copy /Y "%~dp0launch_${st.id}.bat" "%LAUNCH_BAT%" >nul\r
echo %SERVER_IP%>"%APP_DIR%\\server_ip.txt"\r
\r
echo ${step1}\r
if not exist "%ICON_DEST%" (\r
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1\r
    if not exist "%ICON_DEST%" (\r
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1\r
    )\r
)\r
\r
if not exist "%APP_DIR%\\discover_server.ps1" (\r
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/kiosco/discover_server.ps1', '%APP_DIR%\\discover_server.ps1')" >nul 2>&1\r
)\r
\r
echo ${step2}\r
set "BROWSER_EXE="\r
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (\r
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"\r
) else if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (\r
    set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"\r
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"\r
) else if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"\r
) else if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"\r
)\r
\r
if "%BROWSER_EXE%"=="" (\r
    echo ${errBrowser}\r
    pause\r
    exit /b 1\r
)\r
\r
:: Si no existe launch_bat, generarlo con auto-discovery integrado\r
if not exist "%LAUNCH_BAT%" (\r
    echo @echo off > "%LAUNCH_BAT%"\r
    echo set "APP_DIR=%%LOCALAPPDATA%%\\ImpossiblePOS" >> "%LAUNCH_BAT%"\r
    echo set "SERVER_IP=${serverIp}" >> "%LAUNCH_BAT%"\r
    echo if exist "%%APP_DIR%%\\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\\server_ip.txt" >> "%LAUNCH_BAT%"\r
    echo if exist "%%APP_DIR%%\\discover_server.ps1" for /f "usebackq delims=" %%%%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\\discover_server.ps1" -LastKnownIp "%%SERVER_IP%%"\`^) do if not "%%%%i"=="" set "SERVER_IP=%%%%i" >> "%LAUNCH_BAT%"\r
    echo start "" "%BROWSER_EXE%" --app="http://%%SERVER_IP%%:3000${st.url}" --kiosk --no-first-run >> "%LAUNCH_BAT%"\r
    echo exit >> "%LAUNCH_BAT%"\r
)\r
\r
echo ${step3}\r
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = '${desc}'; $shortcut.Save(); $startup = $ws.SpecialFolders('Startup'); $sShortcut = $ws.CreateShortcut($startup + '\\%SHORTCUT_NAME%'); $sShortcut.TargetPath = '%LAUNCH_BAT%'; $sShortcut.WorkingDirectory = '%APP_DIR%'; $sShortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $sShortcut.IconLocation = '%ICON_DEST%,0' }; $sShortcut.Save();"\r
\r
echo.\r
echo ======================================================================\r
echo   ${successMsg}\r
echo   - Desktop Shortcut: "%SHORTCUT_NAME%"\r
echo   - URL: http://%SERVER_IP%:3000${st.url}\r
echo ======================================================================\r
echo.\r
start "" "%LAUNCH_BAT%"\r
timeout /t 2 >nul\r
exit\r
`;
}

function generateUniversalHardwareSetupBat(serverIp) {
  return `@echo off\r
setlocal EnableDelayedExpansion\r
title Impossible POS - Hardware Stations Setup\r
color 0A\r
\r
:: Setup working directory\r
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"\r
if not exist "%APP_DIR%" mkdir "%APP_DIR%"\r
if not exist "%APP_DIR%\\Icons" mkdir "%APP_DIR%\\Icons"\r
\r
set "SERVER_IP=${serverIp}"\r
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"\r
if exist "%APP_DIR%\\server_ip.txt" set /p SERVER_IP=<"%APP_DIR%\\server_ip.txt"\r
if "%SERVER_IP%"=="" set "SERVER_IP=${serverIp}"\r
\r
cls\r
echo ======================================================================\r
echo               IMPOSSIBLE POS - HARDWARE STATIONS SETUP\r
echo ======================================================================\r
echo  Detecting Central Register Server on Local Network...\r
\r
:: Auto-discover server if not responding\r
set "AUTO_IP="\r
if exist "%~dp0discover_server.ps1" copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\\discover_server.ps1" >nul\r
if exist "%APP_DIR%\\discover_server.ps1" (\r
    for /f "usebackq delims=" %%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%\\discover_server.ps1" -LastKnownIp "%SERVER_IP%"\`) do (\r
        if not "%%i"=="" set "AUTO_IP=%%i"\r
    )\r
)\r
\r
if not "!AUTO_IP!"=="" (\r
    set "SERVER_IP=!AUTO_IP!"\r
    echo !AUTO_IP!>"%APP_DIR%\\server_ip.txt"\r
)\r
\r
:: Browser Check\r
set "BROWSER_EXE="\r
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"\r
\r
:MENU\r
cls\r
echo ======================================================================\r
echo               IMPOSSIBLE POS - HARDWARE STATIONS SETUP\r
echo ======================================================================\r
echo   Central Server: %SERVER_IP% (Port 3000)\r
echo ======================================================================\r
echo   Select what this screen or computer will be:\r
echo.\r
echo     [1]  Kitchen Display 1 (Hot Food / Grill KDS)\r
echo     [2]  Kitchen Display 2 (Cold Prep / Bakery KDS)\r
echo     [3]  Bar Display (Cocktails and Beverages KDS)\r
echo     [4]  Special Orders Display (Custom Cakes and Catering)\r
echo     [5]  Photo Hub (Cake and Custom Order Photos)\r
echo     [6]  Lobby TV (Customer Queue and Waitlist Display)\r
echo     [7]  Runner Hub (Order Expediter and Dispatch)\r
echo     [8]  Hostess Hub (Table Seating and Reception)\r
echo     [9]  Self-Ordering Kiosk (Customer Ordering Station)\r
echo     [10] Secondary Register (Cashier POS Terminal 2)\r
echo     [11] Setup Thermal Printers and Cash Drawer Service\r
echo     [12] Pair Screen with Cash Register (Smart 4-Digit Code)\r
echo     [13] Install All Station Shortcuts\r
echo     [C]  Set / Change Central Server IP (Current: %SERVER_IP%)\r
echo.\r
echo     [0]  Exit\r
echo ======================================================================\r
set /p CHOICE="Enter your choice (1-12) or 0 to exit: "\r
\r
if "%CHOICE%"=="0" exit /b 0\r
if "%CHOICE%"=="1" goto INST_1\r
if "%CHOICE%"=="2" goto INST_2\r
if "%CHOICE%"=="3" goto INST_3\r
if "%CHOICE%"=="4" goto INST_4\r
if "%CHOICE%"=="5" goto INST_5\r
if "%CHOICE%"=="6" goto INST_6\r
if "%CHOICE%"=="7" goto INST_7\r
if "%CHOICE%"=="8" goto INST_8\r
if "%CHOICE%"=="9" goto INST_9\r
if "%CHOICE%"=="10" goto INST_10\r
if "%CHOICE%"=="11" goto INST_PRINTERS\r
if "%CHOICE%"=="12" goto PAIR_CODE\r
if "%CHOICE%"=="13" goto INST_ALL\r
if /i "%CHOICE%"=="C" goto CHANGE_IP\r
\r
echo Invalid selection. Please try again.\r
timeout /t 2 >nul\r
goto MENU\r
\r
:INST_1\r
set "ST_ID=kitchen"\r
set "ST_NAME=Impossible POS - Kitchen KDS"\r
set "ST_URL=/cocina.html"\r
set "ST_ICON=kitchen.ico"\r
goto DO_INSTALL\r
\r
:INST_2\r
set "ST_ID=bakery"\r
set "ST_NAME=Impossible POS - Bakery KDS"\r
set "ST_URL=/cocina.html?station=bakery"\r
set "ST_ICON=cake_kds.ico"\r
goto DO_INSTALL\r
\r
:INST_3\r
set "ST_ID=bar"\r
set "ST_NAME=Impossible POS - Bar Hub"\r
set "ST_URL=/kds_bar.html"\r
set "ST_ICON=bar.ico"\r
goto DO_INSTALL\r
\r
:INST_4\r
set "ST_ID=special"\r
set "ST_NAME=Impossible POS - Special Orders"\r
set "ST_URL=/comanda_pastel.html"\r
set "ST_ICON=cake_kds.ico"\r
goto DO_INSTALL\r
\r
:INST_5\r
set "ST_ID=photo"\r
set "ST_NAME=Impossible POS - Photo Hub"\r
set "ST_URL=/photos.html"\r
set "ST_ICON=photo_hub.ico"\r
goto DO_INSTALL\r
\r
:INST_6\r
set "ST_ID=lobby_tv"\r
set "ST_NAME=Impossible POS - Lobby TV"\r
set "ST_URL=/espera.html"\r
set "ST_ICON=lobby_tv.ico"\r
goto DO_INSTALL\r
\r
:INST_7\r
set "ST_ID=runner"\r
set "ST_NAME=Impossible POS - Runner Dispatch"\r
set "ST_URL=/runner.html"\r
set "ST_ICON=runner.ico"\r
goto DO_INSTALL\r
\r
:INST_8\r
set "ST_ID=hostess"\r
set "ST_NAME=Impossible POS - Hostess"\r
set "ST_URL=/hostess.html"\r
set "ST_ICON=hostess.ico"\r
goto DO_INSTALL\r
\r
:INST_9\r
set "ST_ID=kiosk"\r
set "ST_NAME=Impossible POS - Ordering Kiosk"\r
set "ST_URL=/ordena.html"\r
set "ST_ICON=pos.ico"\r
goto DO_INSTALL\r
\r
:INST_10\r
set "ST_ID=secondary"\r
set "ST_NAME=Impossible POS - Secondary POS"\r
set "ST_URL=/caja_v14.html?station=2"\r
set "ST_ICON=pos.ico"\r
goto DO_INSTALL\r
\r

:INST_PRINTERS
cls
echo ======================================================================
echo       SETUP THERMAL PRINTERS AND CASH DRAWER SERVICE
echo ======================================================================
echo.
echo [1/3] Downloading Printer & Drawer Service components...
set "DRAWER_DIR=%LOCALAPPDATA%\ImpossiblePOS\DrawerService"
if not exist "%DRAWER_DIR%" mkdir "%DRAWER_DIR%"
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/drawer_service.ps1', '%DRAWER_DIR%\drawer_service.ps1')" >nul 2>&1
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/ACTIVAR_CAJON_RAPIDO.bat', '%DRAWER_DIR%\ACTIVAR_CAJON_RAPIDO.bat')" >nul 2>&1

echo [2/3] Detecting installed Windows thermal printers...
powershell -NoProfile -Command "Get-Printer | Select-Object Name, PortName, PrinterStatus | Format-Table -AutoSize"

echo [3/3] Activating Ultra-Fast Local Cash Drawer Service (0.05s response)...
if exist "%DRAWER_DIR%\ACTIVAR_CAJON_RAPIDO.bat" (
    call "%DRAWER_DIR%\ACTIVAR_CAJON_RAPIDO.bat" >nul 2>&1
)

echo.
echo ======================================================================
echo   SUCCESS: Thermal printer service is configured and ready.
echo   - To test or select printer, open POS -> Options -> Setup -> Hardware
echo ======================================================================
echo.
pause
goto MENU

:PAIR_CODE\r
if "%SERVER_IP%"=="127.0.0.1" (\r
    echo.\r
    echo ======================================================================\r
    echo   PAIRING SETUP: Main Cash Register IP Required\r
    echo ======================================================================\r
    echo   The Pairing screen connects to the Central Server.\r
    echo   Current Server IP is set to 127.0.0.1 (Localhost).\r
    echo.\r
    set /p PAIR_IP="  Enter Main Cash Register IP (e.g. 10.0.0.125): "\r
    if not "!PAIR_IP!"=="" (\r
        set "SERVER_IP=!PAIR_IP!"\r
        echo !PAIR_IP!>"%APP_DIR%\\server_ip.txt"\r
        echo !PAIR_IP!>"%~dp0server_ip.txt"\r
    )\r
)\r
echo Starting Smart Pairing Screen (http://%SERVER_IP%:3000/pair.html)...\r
if "%BROWSER_EXE%"=="" (\r
    start "http://%SERVER_IP%:3000/pair.html"\r
) else (\r
    start "" "%BROWSER_EXE%" --app="http://%SERVER_IP%:3000/pair.html" --no-first-run\r
)\r
exit /b 0\r
\r
:CHANGE_IP\r
echo.\r
echo ======================================================================\r
echo   SET / CHANGE CENTRAL SERVER IP ADDRESS\r
echo ======================================================================\r
echo Current Server IP: %SERVER_IP%\r
echo.\r
set /p NEW_IP="Enter new Central Server IP address (e.g. 10.0.0.125): "\r
if not "!NEW_IP!"=="" (\r
    set "SERVER_IP=!NEW_IP!"\r
    echo !NEW_IP!>"%APP_DIR%\\server_ip.txt"\r
    echo !NEW_IP!>"%~dp0server_ip.txt"\r
    echo Server IP updated successfully to: !NEW_IP!\r
    timeout /t 2 >nul\r
)\r
goto MENU\r
\r
:DO_INSTALL\r
echo.\r
echo [1/3] Downloading official icon (%ST_ICON%)...\r
set "ICON_DEST=%APP_DIR%\\Icons\\%ST_ICON%"\r
if not exist "%ICON_DEST%" (\r
    if exist "%~dp0Icons\\%ST_ICON%" copy /Y "%~dp0Icons\\%ST_ICON%" "%ICON_DEST%" >nul\r
    if not exist "%ICON_DEST%" (\r
        powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ST_ICON%', '%ICON_DEST%')" >nul 2>&1\r
    )\r
)\r
\r
echo [2/3] Generating station launcher...\r
set "LAUNCH_BAT=%APP_DIR%\\launch_%ST_ID%.bat"\r
echo @echo off > "%LAUNCH_BAT%"\r
echo setlocal EnableDelayedExpansion >> "%LAUNCH_BAT%"\r
echo set "APP_DIR=%%LOCALAPPDATA%%\\ImpossiblePOS" >> "%LAUNCH_BAT%"\r
echo set "SERVER_IP=%SERVER_IP%" >> "%LAUNCH_BAT%"\r
echo if exist "%%APP_DIR%%\\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\\server_ip.txt" >> "%LAUNCH_BAT%"\r
echo if exist "%%APP_DIR%%\\discover_server.ps1" for /f "usebackq delims=" %%%%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\\discover_server.ps1" -LastKnownIp "%%SERVER_IP%%"\`^) do if not "%%%%i"=="" set "SERVER_IP=%%%%i" >> "%LAUNCH_BAT%"\r
echo set "BROWSER_EXE=" >> "%LAUNCH_BAT%"\r
echo if exist "%%ProgramFiles(x86)%%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%%ProgramFiles(x86)%%\\Microsoft\\Edge\\Application\\msedge.exe" >> "%LAUNCH_BAT%"\r
echo if exist "%%ProgramFiles%%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%%ProgramFiles%%\\Microsoft\\Edge\\Application\\msedge.exe" >> "%LAUNCH_BAT%"\r
echo if exist "%%ProgramFiles%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%ProgramFiles%%\\Google\\Chrome\\Application\\chrome.exe" >> "%LAUNCH_BAT%"\r
echo if exist "%%ProgramFiles(x86)%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%ProgramFiles(x86)%%\\Google\\Chrome\\Application\\chrome.exe" >> "%LAUNCH_BAT%"\r
echo if exist "%%LocalAppData%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%LocalAppData%%\\Google\\Chrome\\Application\\chrome.exe" >> "%LAUNCH_BAT%"\r
echo if "%%BROWSER_EXE%%"=="" ( start "http://%%SERVER_IP%%:3000%ST_URL%" ^& exit ) >> "%LAUNCH_BAT%"\r
echo start "" "%%BROWSER_EXE%%" --app="http://%%SERVER_IP%%:3000%ST_URL%" --kiosk --no-first-run >> "%LAUNCH_BAT%"\r
echo exit >> "%LAUNCH_BAT%"\r
\r
echo [3/3] Creating Desktop shortcut...\r
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\\%ST_NAME%.lnk'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = '%ST_NAME%'; $shortcut.Save(); $startup = $ws.SpecialFolders('Startup'); $sShortcut = $ws.CreateShortcut($startup + '\\%ST_NAME%.lnk'); $sShortcut.TargetPath = '%LAUNCH_BAT%'; $sShortcut.WorkingDirectory = '%APP_DIR%'; $sShortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $sShortcut.IconLocation = '%ICON_DEST%,0' }; $sShortcut.Save();"\r
\r
echo.\r
echo ======================================================================\r
echo   SUCCESS: %ST_NAME% has been installed!\r
echo   - Desktop shortcut created: "%ST_NAME%.lnk"\r
echo   - Auto-start on boot: Enabled\r
echo   - Connecting to: http://%SERVER_IP%:3000%ST_URL%\r
echo ======================================================================\r
echo.\r
start "" "%LAUNCH_BAT%"\r
timeout /t 3 >nul\r
exit /b 0\r
\r
:INST_ALL\r
echo Installing all station shortcuts...\r
for %%S in (kitchen bakery bar special photo lobby_tv runner hostess kiosk secondary) do (\r
    call :INSTALL_ONE %%S\r
)\r
echo.\r
echo ======================================================================\r
echo   SUCCESS: All station shortcuts have been created on your Desktop!\r
echo ======================================================================\r
pause\r
exit /b 0\r
\r
:INSTALL_ONE\r
set "ONE_ID=%1"\r
if "%ONE_ID%"=="kitchen" ( set "ONE_NAME=Impossible POS - Kitchen KDS" & set "ONE_URL=/cocina.html" & set "ONE_ICON=kitchen.ico" )\r
if "%ONE_ID%"=="bakery" ( set "ONE_NAME=Impossible POS - Bakery KDS" & set "ONE_URL=/cocina.html?station=bakery" & set "ONE_ICON=cake_kds.ico" )\r
if "%ONE_ID%"=="bar" ( set "ONE_NAME=Impossible POS - Bar Hub" & set "ONE_URL=/kds_bar.html" & set "ONE_ICON=bar.ico" )\r
if "%ONE_ID%"=="special" ( set "ONE_NAME=Impossible POS - Special Orders" & set "ONE_URL=/comanda_pastel.html" & set "ONE_ICON=cake_kds.ico" )\r
if "%ONE_ID%"=="photo" ( set "ONE_NAME=Impossible POS - Photo Hub" & set "ONE_URL=/photos.html" & set "ONE_ICON=photo_hub.ico" )\r
if "%ONE_ID%"=="lobby_tv" ( set "ONE_NAME=Impossible POS - Lobby TV" & set "ONE_URL=/espera.html" & set "ONE_ICON=lobby_tv.ico" )\r
if "%ONE_ID%"=="runner" ( set "ONE_NAME=Impossible POS - Runner Dispatch" & set "ONE_URL=/runner.html" & set "ONE_ICON=runner.ico" )\r
if "%ONE_ID%"=="hostess" ( set "ONE_NAME=Impossible POS - Hostess" & set "ONE_URL=/hostess.html" & set "ONE_ICON=hostess.ico" )\r
if "%ONE_ID%"=="kiosk" ( set "ONE_NAME=Impossible POS - Ordering Kiosk" & set "ONE_URL=/ordena.html" & set "ONE_ICON=pos.ico" )\r
if "%ONE_ID%"=="secondary" ( set "ONE_NAME=Impossible POS - Secondary POS" & set "ONE_URL=/caja_v14.html?station=2" & set "ONE_ICON=pos.ico" )\r
\r
set "BAT_FILE=%APP_DIR%\\launch_%ONE_ID%.bat"\r
echo @echo off > "%BAT_FILE%"\r
echo set "APP_DIR=%%LOCALAPPDATA%%\\ImpossiblePOS" >> "%BAT_FILE%"\r
echo set "SERVER_IP=%SERVER_IP%" >> "%BAT_FILE%"\r
echo if exist "%%APP_DIR%%\\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\\server_ip.txt" >> "%BAT_FILE%"\r
echo if exist "%%APP_DIR%%\\discover_server.ps1" for /f "usebackq delims=" %%%%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\\discover_server.ps1" -LastKnownIp "%%SERVER_IP%%"\`^) do if not "%%%%i"=="" set "SERVER_IP=%%%%i" >> "%BAT_FILE%"\r
echo set "BROWSER_EXE=" >> "%BAT_FILE%"\r
echo if exist "%%ProgramFiles(x86)%%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%%ProgramFiles(x86)%%\\Microsoft\\Edge\\Application\\msedge.exe" >> "%BAT_FILE%"\r
echo if exist "%%ProgramFiles%%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%%ProgramFiles%%\\Microsoft\\Edge\\Application\\msedge.exe" >> "%BAT_FILE%"\r
echo if exist "%%ProgramFiles%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%ProgramFiles%%\\Google\\Chrome\\Application\\chrome.exe" >> "%BAT_FILE%"\r
echo if exist "%%ProgramFiles(x86)%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%ProgramFiles(x86)%%\\Google\\Chrome\\Application\\chrome.exe" >> "%BAT_FILE%"\r
echo if exist "%%LocalAppData%%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%%LocalAppData%%\\Google\\Chrome\\Application\\chrome.exe" >> "%BAT_FILE%"\r
echo if "%%BROWSER_EXE%%"=="" ( start "http://%%SERVER_IP%%:3000%ONE_URL%" ^& exit ) >> "%BAT_FILE%"\r
echo start "" "%%BROWSER_EXE%%" --app="http://%%SERVER_IP%%:3000%ONE_URL%" --kiosk --no-first-run >> "%BAT_FILE%"\r
echo exit >> "%BAT_FILE%"\r
\r
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\\%ONE_NAME%.lnk'); $shortcut.TargetPath = '%BAT_FILE%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; $shortcut.Description = '%ONE_NAME%'; $shortcut.Save();" >nul 2>&1\r
echo  - Installed: %ONE_NAME%\r
goto :eof\r
`;
}

module.exports = {
  STATIONS_CONFIG,
  generateSingleStationInstaller,
  generateStationLauncherBat,
  generateUniversalHardwareSetupBat
};
