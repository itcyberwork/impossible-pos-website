const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const DB_FILE = path.join(__dirname, 'db.json');
const SQLITE_FILE = path.join(__dirname, 'pos.db');

// Test folder write permissions and auto-heal
try {
  const testFile = path.join(__dirname, 'write_test.tmp');
  fs.writeFileSync(testFile, 'test');
  fs.unlinkSync(testFile);
} catch (e) {
  console.error('CRITICAL: Directory has no write permissions. Attempting to repair...', e);
  if (process.platform === 'win32') {
    try {
      const { execSync } = require('child_process');
      execSync(`icacls "${__dirname}" /grant Everyone:(OI)(CI)F /T`);
      console.log('Folder permissions auto-healed successfully!');
    } catch (err) {
      console.error('Failed to auto-heal folder permissions via icacls:', err);
    }
  }
}

// Connect to SQLite
const sqlDB = new Database(SQLITE_FILE);

// Enable WAL mode for high performance and concurrency
sqlDB.pragma('journal_mode = WAL');

// Initialize database tables
function initSQLiteSchema() {
  sqlDB.exec(`
    CREATE TABLE IF NOT EXISTS key_value_store (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS registered_devices (
      device_id TEXT PRIMARY KEY,
      device_name TEXT,
      registered_at TEXT
    );

    CREATE TABLE IF NOT EXISTS active_waitress_sessions (
      session_id TEXT PRIMARY KEY,
      device_id TEXT,
      employee_id TEXT,
      employee_name TEXT,
      device_name TEXT,
      connected_at TEXT,
      last_activity TEXT
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT,
      category TEXT,
      price REAL,
      barcode TEXT,
      ingredients TEXT,
      isTaxable INTEGER DEFAULT 1,
      modifierGroups TEXT, -- JSON string
      trackStock INTEGER DEFAULT 0,
      stockQuantity REAL DEFAULT 0,
      boxSize REAL DEFAULT 12,
      palletSize REAL DEFAULT 200,
      image TEXT DEFAULT '',
      printerId TEXT DEFAULT '',
      subCategory TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS modifier_groups (
      id TEXT PRIMARY KEY,
      name TEXT,
      minSelection INTEGER DEFAULT 0,
      maxSelection INTEGER DEFAULT 0,
      options TEXT -- JSON string
    );

    CREATE TABLE IF NOT EXISTS single_modifiers (
      name TEXT,
      price REAL,
      color TEXT DEFAULT 'default',
      PRIMARY KEY (name, price)
    );

    CREATE TABLE IF NOT EXISTS employees (
      id TEXT PRIMARY KEY,
      name TEXT,
      passcode TEXT,
      cardCode TEXT,
      role TEXT,
      punchHistory TEXT, -- JSON string
      fingerprintRegistered INTEGER DEFAULT 0,
      fingerprintTemplate TEXT,
      phone TEXT,
      address TEXT,
      tasks TEXT
    );

    CREATE TABLE IF NOT EXISTS loyalty (
      phone TEXT PRIMARY KEY,
      name TEXT,
      points INTEGER DEFAULT 0,
      type TEXT DEFAULT 'individual',
      companyName TEXT DEFAULT '',
      address TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS gift_cards (
      code TEXT PRIMARY KEY,
      balance REAL DEFAULT 0,
      active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS waitlist (
      id TEXT PRIMARY KEY,
      name TEXT,
      phone TEXT,
      partySize INTEGER DEFAULT 1,
      status TEXT DEFAULT 'waiting',
      dateAdded TEXT,
      orderType TEXT DEFAULT 'cake',
      hasCake INTEGER DEFAULT 0,
      dedication TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      lang TEXT DEFAULT 'en'
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      ticketNumber INTEGER,
      status TEXT DEFAULT 'pendiente',
      paymentStatus TEXT DEFAULT 'unpaid',
      cashierName TEXT DEFAULT '',
      clientName TEXT DEFAULT '',
      clientPhone TEXT DEFAULT '',
      deliveryType TEXT DEFAULT 'walkin',
      tableNumber TEXT DEFAULT '',
      tableName TEXT DEFAULT '',
      guestCount INTEGER DEFAULT 1,
      activeSeat TEXT DEFAULT '',
      items TEXT, -- JSON string representation of items and modifiers
      subtotal REAL DEFAULT 0,
      tax REAL DEFAULT 0,
      total REAL DEFAULT 0,
      cardTip REAL DEFAULT 0,
      cashReceived REAL DEFAULT 0,
      changeGiven REAL DEFAULT 0,
      changeDue REAL DEFAULT 0,
      tipAmount REAL DEFAULT 0,
      dateCreated TEXT,
      dateUpdated TEXT DEFAULT '',
      courtesyApprovedBy TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      crossBillDetails TEXT, -- JSON string
      paymentMethod TEXT DEFAULT '',
      datePaid TEXT DEFAULT '',
      splitDetails TEXT, -- JSON string
      dateRefunded TEXT DEFAULT '',
      voidReason TEXT DEFAULT '',
      voidAuthorizedBy TEXT DEFAULT '',
      dateVoided TEXT DEFAULT '',
      refundReason TEXT DEFAULT '',
      refundAuthorizedBy TEXT DEFAULT '',
      shelfLocation TEXT DEFAULT '',
      locationLoggedBy TEXT DEFAULT '',
      locationLoggedAt TEXT DEFAULT '',
      courtesyApprovedReason TEXT DEFAULT '',
      parentOrderId TEXT DEFAULT '',
      parentTicketNumber INTEGER DEFAULT 0,
      roundLetter TEXT DEFAULT '',
      ticketDisplay TEXT DEFAULT '',
      orderOrigin TEXT DEFAULT '',
      roundHistory TEXT DEFAULT '[]'
    );

    CREATE TABLE IF NOT EXISTS shifts (
      id TEXT PRIMARY KEY,
      cashierName TEXT DEFAULT '',
      status TEXT DEFAULT 'closed',
      openingCash REAL DEFAULT 0,
      details TEXT, -- JSON string
      dateOpened TEXT,
      dateClosed TEXT DEFAULT '',
      closingCash REAL DEFAULT 0,
      closingDetails TEXT, -- JSON string
      closingCashier TEXT DEFAULT '',
      summary TEXT -- JSON string
    );

    CREATE TABLE IF NOT EXISTS alcohol_products (
      id TEXT PRIMARY KEY,
      barcode TEXT DEFAULT '',
      brand TEXT DEFAULT '',
      model TEXT DEFAULT '',
      fullWeight REAL DEFAULT 0,
      emptyWeight REAL DEFAULT 0,
      liquidOunces REAL DEFAULT 0,
      shotSize REAL DEFAULT 0,
      gramsPerOunce REAL DEFAULT 0,
      currentVolumeOunces REAL DEFAULT 0,
      sealedBottleCount INTEGER DEFAULT 0,
      bottlePrice REAL DEFAULT 0,
      shotPrice REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS bartender_shifts (
      id TEXT PRIMARY KEY,
      status TEXT DEFAULT 'closed',
      dateStarted TEXT,
      dateEnded TEXT DEFAULT '',
      bartenderName TEXT DEFAULT '',
      startDiscrepancyOunces REAL DEFAULT 0,
      expectedEndOunces REAL DEFAULT 0,
      soldOunces REAL DEFAULT 0,
      endWeight REAL DEFAULT 0,
      endOunces REAL DEFAULT 0,
      discrepancyOunces REAL DEFAULT 0,
      inventory TEXT -- JSON string
    );

    CREATE TABLE IF NOT EXISTS departments (
      id TEXT PRIMARY KEY,
      name TEXT,
      "order" INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS reservations (
      id TEXT PRIMARY KEY,
      customerName TEXT,
      customerPhone TEXT,
      dateTime TEXT,
      pax INTEGER DEFAULT 1,
      tableNum TEXT DEFAULT '',
      status TEXT DEFAULT 'pending',
      source TEXT DEFAULT 'local',
      createdAt TEXT
    );

    CREATE TABLE IF NOT EXISTS cloud_sync_queue (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      payloadType TEXT NOT NULL,
      payloadJson TEXT NOT NULL,
      createdAt TEXT,
      attempts INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS call_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT NOT NULL,
      customerName TEXT,
      customerAddress TEXT,
      points INTEGER DEFAULT 0,
      isRegistered INTEGER DEFAULT 0,
      status TEXT DEFAULT 'received',
      orderId TEXT,
      timestamp TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pin_audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      createdAt TEXT NOT NULL,
      actorName TEXT,
      actorRole TEXT,
      targetEmployeeId TEXT,
      targetEmployeeName TEXT,
      targetEmployeeRole TEXT,
      actionResult TEXT,
      method TEXT,
      notes TEXT
    );
  `);

  // Dynamically add fingerprint, phone, address, and tasks columns if they don't exist in the existing database
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(employees)").all();
    const hasFingerprintReg = tableInfo.some(col => col.name === 'fingerprintRegistered');
    const hasFingerprintTemp = tableInfo.some(col => col.name === 'fingerprintTemplate');
    const hasPhone = tableInfo.some(col => col.name === 'phone');
    const hasAddress = tableInfo.some(col => col.name === 'address');
    const hasTasks = tableInfo.some(col => col.name === 'tasks');
    
    if (!hasFingerprintReg) {
      sqlDB.prepare("ALTER TABLE employees ADD COLUMN fingerprintRegistered INTEGER DEFAULT 0").run();
    }
    if (!hasFingerprintTemp) {
      sqlDB.prepare("ALTER TABLE employees ADD COLUMN fingerprintTemplate TEXT").run();
    }
    if (!hasPhone) {
      sqlDB.prepare("ALTER TABLE employees ADD COLUMN phone TEXT").run();
    }
    if (!hasAddress) {
      sqlDB.prepare("ALTER TABLE employees ADD COLUMN address TEXT").run();
    }
    if (!hasTasks) {
      sqlDB.prepare("ALTER TABLE employees ADD COLUMN tasks TEXT").run();
    }
  } catch (err) {
    console.error("Error migrating employees table columns:", err);
  }

  // Dynamically add stock size columns if they don't exist in the existing database
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(products)").all();
    const prodCols = tableInfo.map(col => col.name);
    const hasBoxSize = tableInfo.some(col => col.name === 'boxSize');
    const hasPalletSize = tableInfo.some(col => col.name === 'palletSize');
    const hasImage = tableInfo.some(col => col.name === 'image');
    const hasPrinterId = tableInfo.some(col => col.name === 'printerId');
    const hasSubCategory = tableInfo.some(col => col.name === 'subCategory');
    
    if (!hasBoxSize) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN boxSize REAL DEFAULT 12").run();
    }
    if (!hasPalletSize) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN palletSize REAL DEFAULT 200").run();
    }
    if (!hasImage) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN image TEXT DEFAULT ''").run();
    }
    if (!hasPrinterId) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN printerId TEXT DEFAULT ''").run();
    }
    if (!hasSubCategory) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN subCategory TEXT DEFAULT ''").run();
    }
    const hasCanPrice = prodCols.includes('canPrice');
    const hasCanBarcode = prodCols.includes('canBarcode');
    const hasBucketPrice = prodCols.includes('bucketPrice');
    const hasBucketSize = prodCols.includes('bucketSize');
    if (!hasCanPrice) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN canPrice REAL DEFAULT NULL").run();
    }
    if (!hasCanBarcode) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN canBarcode TEXT DEFAULT ''").run();
    }
    if (!hasBucketPrice) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN bucketPrice REAL DEFAULT NULL").run();
    }
    if (!hasBucketSize) {
      sqlDB.prepare("ALTER TABLE products ADD COLUMN bucketSize INTEGER DEFAULT 5").run();
    }
  } catch (err) {
    console.error("Error migrating products table columns:", err);
  }

  // Ensure color column on single_modifiers
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(single_modifiers)").all();
    const hasColor = tableInfo.some(col => col.name === 'color');
    if (!hasColor) {
      sqlDB.prepare("ALTER TABLE single_modifiers ADD COLUMN color TEXT DEFAULT 'default'").run();
    }
  } catch (err) {
    console.error("Error migrating single_modifiers table columns:", err);
  }

  // Ensure delivery integration columns and table/update columns on orders table
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(orders)").all();
    const cols = tableInfo.map(c => c.name);
    if (!cols.includes('tableName')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN tableName TEXT DEFAULT ''").run();
    }
    if (!cols.includes('dateUpdated')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN dateUpdated TEXT DEFAULT ''").run();
    }
    if (!cols.includes('deliveryPlatform')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN deliveryPlatform TEXT DEFAULT 'pos'").run();
    }
    if (!cols.includes('externalOrderId')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN externalOrderId TEXT DEFAULT ''").run();
    }
    if (!cols.includes('pickupCode')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN pickupCode TEXT DEFAULT ''").run();
    }
    if (!cols.includes('driverInfo')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN driverInfo TEXT DEFAULT ''").run();
    }
    if (!cols.includes('handoverCashier')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN handoverCashier TEXT DEFAULT ''").run();
    }
    if (!cols.includes('dateHandedOver')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN dateHandedOver TEXT DEFAULT ''").run();
    }
    if (!cols.includes('parentOrderId')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN parentOrderId TEXT DEFAULT ''").run();
    }
    if (!cols.includes('parentTicketNumber')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN parentTicketNumber INTEGER DEFAULT 0").run();
    }
    if (!cols.includes('roundLetter')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN roundLetter TEXT DEFAULT ''").run();
    }
    if (!cols.includes('ticketDisplay')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN ticketDisplay TEXT DEFAULT ''").run();
    }
    if (!cols.includes('orderOrigin')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN orderOrigin TEXT DEFAULT ''").run();
    }
    if (!cols.includes('roundHistory')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN roundHistory TEXT DEFAULT '[]'").run();
    }
    if (!cols.includes('cashReceived')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN cashReceived REAL DEFAULT 0").run();
    }
    if (!cols.includes('changeGiven')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN changeGiven REAL DEFAULT 0").run();
    }
    if (!cols.includes('changeDue')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN changeDue REAL DEFAULT 0").run();
    }
    if (!cols.includes('tipAmount')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN tipAmount REAL DEFAULT 0").run();
    }
    if (!cols.includes('isOpenTabAuthorized')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN isOpenTabAuthorized INTEGER DEFAULT 0").run();
    }
    if (!cols.includes('authorizedBy')) {
      sqlDB.prepare("ALTER TABLE orders ADD COLUMN authorizedBy TEXT DEFAULT ''").run();
    }
  } catch (err) {
    console.error("Error migrating orders delivery integration columns:", err);
  }

  // Ensure alcohol_products table columns exist
  try {
    const alcTableInfo = sqlDB.prepare("PRAGMA table_info(alcohol_products)").all();
    const alcCols = alcTableInfo.map(c => c.name);
    if (!alcCols.includes('sealedBottleCount')) {
      sqlDB.prepare("ALTER TABLE alcohol_products ADD COLUMN sealedBottleCount INTEGER DEFAULT 0").run();
    }
    if (!alcCols.includes('bottlePrice')) {
      sqlDB.prepare("ALTER TABLE alcohol_products ADD COLUMN bottlePrice REAL DEFAULT 0").run();
    }
    if (!alcCols.includes('shotPrice')) {
      sqlDB.prepare("ALTER TABLE alcohol_products ADD COLUMN shotPrice REAL DEFAULT 0").run();
    }
  } catch (err) {
    console.error("Error migrating alcohol_products columns:", err);
  }

  // Ensure waitlist cake and dedication columns exist
  try {
    const wlInfo = sqlDB.prepare("PRAGMA table_info(waitlist)").all();
    const wlCols = wlInfo.map(c => c.name);
    if (!wlCols.includes('orderType')) sqlDB.prepare("ALTER TABLE waitlist ADD COLUMN orderType TEXT DEFAULT 'cake'").run();
    if (!wlCols.includes('hasCake')) sqlDB.prepare("ALTER TABLE waitlist ADD COLUMN hasCake INTEGER DEFAULT 0").run();
    if (!wlCols.includes('dedication')) sqlDB.prepare("ALTER TABLE waitlist ADD COLUMN dedication TEXT DEFAULT ''").run();
    if (!wlCols.includes('notes')) sqlDB.prepare("ALTER TABLE waitlist ADD COLUMN notes TEXT DEFAULT ''").run();
    if (!wlCols.includes('lang')) sqlDB.prepare("ALTER TABLE waitlist ADD COLUMN lang TEXT DEFAULT 'en'").run();
  } catch (err) {
    console.error("Error migrating waitlist columns:", err);
  }

  // Ensure cloudSynced column on shifts
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(shifts)").all();
    const hasCloudSynced = tableInfo.some(col => col.name === 'cloudSynced');
    if (!hasCloudSynced) {
      sqlDB.prepare("ALTER TABLE shifts ADD COLUMN cloudSynced INTEGER DEFAULT 0").run();
    }
  } catch (err) {
    console.error("Error migrating shifts table columns:", err);
  }

  // Ensure drawerNumber column on shifts
  try {
    const tableInfo = sqlDB.prepare("PRAGMA table_info(shifts)").all();
    const hasDrawerNumber = tableInfo.some(col => col.name === 'drawerNumber');
    if (!hasDrawerNumber) {
      sqlDB.prepare("ALTER TABLE shifts ADD COLUMN drawerNumber INTEGER DEFAULT 1").run();
    }
  } catch (err) {
    console.error("Error migrating shifts table drawerNumber column:", err);
  }

  // Ensure default admin (2026) exists in every database
  try {
    const adminCheck = sqlDB.prepare("SELECT * FROM employees WHERE passcode = '2026' OR role = 'admin'").get();
    if (!adminCheck) {
      sqlDB.prepare("INSERT OR REPLACE INTO employees (id, name, passcode, cardCode, role, punchHistory, fingerprintRegistered, fingerprintTemplate) VALUES ('e2', 'Admin', '2026', '2222', 'admin', '[]', 0, null)").run();
    }
  } catch (err) {
    console.error("Error ensuring default admin employee:", err);
  }

  // Normalize products subCategory names (trim spaces and unify case) on drinks
  try {
    const prods = sqlDB.prepare("SELECT id, subCategory FROM products WHERE subCategory IS NOT NULL AND TRIM(subCategory) != ''").all();
    const updateStmt = sqlDB.prepare("UPDATE products SET subCategory = ? WHERE id = ?");
    for (const p of prods) {
      const clean = p.subCategory.trim();
      if (clean !== p.subCategory) {
        updateStmt.run(clean, p.id);
      }
    }
  } catch (err) {
    console.error("Error normalizing product subCategories:", err);
  }
}

// Default departments created for each business type the owner selects.
// Nothing is created until a business type is chosen (software ships empty). No products are ever created.
const BUSINESS_TYPE_PRESETS = {
  bakery: [['panaderia', 'Bakery'], ['postres', 'Desserts'], ['pasteles_stock', 'Cakes in Stock'], ['bebidas', 'Drinks']],
  restaurant: [['appetizers', 'Appetizers'], ['entrees', 'Entrees'], ['sides', 'Sides'], ['postres', 'Desserts'], ['bebidas', 'Drinks']],
  taco_truck: [['tacos', 'Tacos'], ['burritos', 'Burritos & Bowls'], ['quesadillas', 'Quesadillas & Tortas'], ['antojitos', 'Sides'], ['bebidas', 'Drinks']],
  bar: [['beer', 'Beer'], ['wine', 'Wine'], ['liquor', 'Liquor'], ['cocktails', 'Cocktails'], ['soft_drinks', 'Soft Drinks']],
  store: [['tienda', 'Store'], ['grocery', 'Grocery'], ['snacks', 'Snacks'], ['bebidas', 'Drinks']],
  cafe: [['coffee', 'Coffee'], ['tea', 'Tea'], ['panaderia', 'Bakery'], ['sandwiches', 'Sandwiches']]
};
function parseBusinessTypes(value) {
  return String(value || '').toLowerCase().split(',').map(t => t.trim().replace(/^tacotruck$/, 'taco_truck')).filter(t => BUSINESS_TYPE_PRESETS[t]);
}

// Seed clean default database values if empty
function seedDefaultDatabase() {
  sqlDB.transaction(() => {
    // 1. Settings (Key-Value)
    const defaultSettings = {
      taxRate: 6.0,
      autoPrint: true,
      welcomePoints: 10,
      printerType: "local",
      printerIP: "192.168.1.100",
      paymentTerminalType: "external",
      paymentTerminalIP: "192.168.1.110",
      paymentTerminalPort: "8080",
      biometricWebSocketUrl: "ws://localhost:9000/biometrics",
      language: "en",
      langKDS: "en",
      langRunner: "en",
      langLobby: "en",
      langCustomerTicket: "en",
      langKitchenTicket: "en",
      printLogoOnReceipts: true,
      blindDropShiftClose: false,
      enableMultiGuest: false,
      enableLoyalty: false,
      kitchenPrinter2Name: "",
      kitchenPrinter3Name: "",
      kitchenTicketFontSize: "5",
      developerSupportPhone: "",
      businessName: "",
      businessType: "",
      eulaAccepted: false,
      trialStartDate: "",
      trialExpiration: "",
      licenseExpiration: "",
      licenseStatus: "demo",
      showBartender: false,
      posStations: [
        { id: "1", name: "Caja 1 (Main POS)", type: "computer", role: "cashier", isDefault: true }
      ],
      networkTopology: {
        cashiers: 1,
        barStations: 0,
        waitressStations: 0,
        kitchenKDS: 1,
        runnerKDS: 0,
        mobileSunmis: 0
      }
    };
    sqlDB.prepare('INSERT OR REPLACE INTO key_value_store (key, value) VALUES (\'settings\', ?)')
      .run(JSON.stringify(defaultSettings));

    // 2. Default Employees
    const defaultEmployees = [
      { id: "e1", name: "manager", passcode: "1234", cardCode: "1111", role: "manager", punchHistory: [], fingerprintRegistered: 0, fingerprintTemplate: null },
      { id: "e2", name: "admin", passcode: "2026", cardCode: "2222", role: "admin", punchHistory: [], fingerprintRegistered: 0, fingerprintTemplate: null }
    ];
    const insertEmployee = sqlDB.prepare(`
      INSERT OR REPLACE INTO employees (id, name, passcode, cardCode, role, punchHistory, fingerprintRegistered, fingerprintTemplate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    defaultEmployees.forEach(e => {
      insertEmployee.run(e.id, e.name, e.passcode, e.cardCode, e.role, JSON.stringify(e.punchHistory), e.fingerprintRegistered, e.fingerprintTemplate);
    });

    // 3. Default Products (Virgin - empty by default)
    const defaultProducts = [];
    const insertProduct = sqlDB.prepare(`
      INSERT OR REPLACE INTO products (id, name, category, price, barcode, ingredients, isTaxable, modifierGroups, trackStock, stockQuantity)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0)
    `);
    defaultProducts.forEach(p => {
      insertProduct.run(p.id, p.name, p.category, p.price, p.barcode, p.ingredients, p.isTaxable ? 1 : 0, JSON.stringify(p.modifierGroups));
    });

    // 4. Default Single Modifiers (Virgin - empty by default)
    const defaultSingle = [];
    const insertSingle = sqlDB.prepare(`
      INSERT OR IGNORE INTO single_modifiers (name, price)
      VALUES (?, ?)
    `);
    defaultSingle.forEach(m => {
      insertSingle.run(m.name, m.price);
    });

    // 5. Default Modifier Groups (Virgin - empty by default)
    const defaultGroups = [];
    const insertGroup = sqlDB.prepare(`
      INSERT OR REPLACE INTO modifier_groups (id, name, minSelection, maxSelection, options)
      VALUES (?, ?, ?, ?, ?)
    `);
    defaultGroups.forEach(g => {
      insertGroup.run(g.id, g.name, g.minSelection, g.maxSelection, JSON.stringify(g.options));
    });
  })();
  console.log('Seeded virgin SQLite database successfully!');
}

// Convert data from db.json to SQLite pos.db if db.json is present
function migrateFromJSON() {
  if (!fs.existsSync(DB_FILE)) {
    // Check if database needs seeding
    const employeeCount = sqlDB.prepare('SELECT COUNT(*) as count FROM employees').get().count;
    if (employeeCount === 0) {
      seedDefaultDatabase();
    }
    return;
  }

  try {
    console.log('Found db.json! Starting migration to SQLite...');
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    const db = JSON.parse(data);

    // Perform migration inside a transaction
    const runMigration = sqlDB.transaction(() => {
      // 1. Settings (Key-Value)
      if (db.settings) {
        sqlDB.prepare('INSERT OR REPLACE INTO key_value_store (key, value) VALUES (\'settings\', ?)')
          .run(JSON.stringify(db.settings));
      }

      // 2. Tables layout
      if (db.tables) {
        sqlDB.prepare('INSERT OR REPLACE INTO key_value_store (key, value) VALUES (\'tables\', ?)')
          .run(JSON.stringify(db.tables));
      }

      // 3. Products
      if (db.products && Array.isArray(db.products)) {
        const insertProduct = sqlDB.prepare(`
          INSERT OR REPLACE INTO products (id, name, category, price, barcode, ingredients, isTaxable, modifierGroups, trackStock, stockQuantity)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.products.forEach(p => {
          insertProduct.run(
            p.id,
            p.name,
            p.category || 'varios',
            p.price || 0,
            p.barcode || '',
            p.ingredients || '',
            p.isTaxable !== false ? 1 : 0,
            JSON.stringify(p.modifierGroups || []),
            p.trackStock ? 1 : 0,
            p.stockQuantity || 0
          );
        });
      }

      // 4. Modifier Groups
      if (db.modifierGroups && Array.isArray(db.modifierGroups)) {
        const insertGroup = sqlDB.prepare(`
          INSERT OR REPLACE INTO modifier_groups (id, name, minSelection, maxSelection, options)
          VALUES (?, ?, ?, ?, ?)
        `);
        db.modifierGroups.forEach(g => {
          insertGroup.run(
            g.id,
            g.name,
            g.minSelection || 0,
            g.maxSelection || 0,
            JSON.stringify(g.options || [])
          );
        });
      }

      // 5. Single Modifiers
      if (db.singleModifiers && Array.isArray(db.singleModifiers)) {
        const insertSingle = sqlDB.prepare(`
          INSERT OR IGNORE INTO single_modifiers (name, price)
          VALUES (?, ?)
        `);
        db.singleModifiers.forEach(m => {
          if (m && m.name) {
            insertSingle.run(m.name, m.price || 0);
          }
        });
      }

      // 6. Employees
      if (db.employees && Array.isArray(db.employees)) {
        const insertEmployee = sqlDB.prepare(`
          INSERT OR REPLACE INTO employees (id, name, passcode, cardCode, role, punchHistory, fingerprintRegistered, fingerprintTemplate)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.employees.forEach(e => {
          insertEmployee.run(
            e.id,
            e.name,
            e.passcode || '',
            e.cardCode || '',
            e.role || 'cajero',
            JSON.stringify(e.punchHistory || []),
            e.fingerprintRegistered ? 1 : 0,
            e.fingerprintTemplate || null
          );
        });
      }

      // 7. Loyalty clients
      if (db.loyalty && Array.isArray(db.loyalty)) {
        const insertLoyalty = sqlDB.prepare(`
          INSERT OR REPLACE INTO loyalty (phone, name, points, type, companyName, address)
          VALUES (?, ?, ?, ?, ?, ?)
        `);
        db.loyalty.forEach(c => {
          insertLoyalty.run(
            c.phone,
            c.name,
            c.points || 0,
            c.type || 'individual',
            c.companyName || '',
            c.address || ''
          );
        });
      }

      // 8. Gift cards
      if (db.giftCards && Array.isArray(db.giftCards)) {
        const insertGift = sqlDB.prepare(`
          INSERT OR REPLACE INTO gift_cards (code, balance, active)
          VALUES (?, ?, ?)
        `);
        db.giftCards.forEach(g => {
          insertGift.run(g.code, g.balance || 0, g.active ? 1 : 0);
        });
      }

      // 9. Waitlist
      if (db.waitlist && Array.isArray(db.waitlist)) {
        const insertWait = sqlDB.prepare(`
          INSERT OR REPLACE INTO waitlist (id, name, phone, partySize, status, dateAdded)
          VALUES (?, ?, ?, ?, ?, ?)
        `);
        db.waitlist.forEach(w => {
          insertWait.run(w.id, w.name, w.phone, w.partySize || 1, w.status || 'waiting', w.dateAdded);
        });
      }

      // 10. Orders
      if (db.orders && Array.isArray(db.orders)) {
        const insertOrder = sqlDB.prepare(`
          INSERT OR REPLACE INTO orders (
            id, ticketNumber, status, paymentStatus, cashierName, clientName, clientPhone, 
            deliveryType, tableNumber, guestCount, activeSeat, items, subtotal, tax, total, 
            cardTip, dateCreated, courtesyApprovedBy, notes, crossBillDetails, paymentMethod, 
            datePaid, splitDetails, dateRefunded, voidReason, voidAuthorizedBy, dateVoided, 
            refundReason, refundAuthorizedBy, shelfLocation, locationLoggedBy, locationLoggedAt, courtesyApprovedReason
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.orders.forEach(o => {
          insertOrder.run(
            o.id,
            o.ticketNumber,
            o.status || 'pendiente',
            o.paymentStatus || 'unpaid',
            o.cashierName || '',
            o.clientName || '',
            o.clientPhone || '',
            o.deliveryType || 'walkin',
            o.tableNumber || '',
            o.guestCount || 1,
            o.activeSeat || '',
            JSON.stringify(o.items || []),
            o.subtotal || 0,
            o.tax || 0,
            o.total || 0,
            o.cardTip || 0,
            o.dateCreated,
            o.courtesyApprovedBy || '',
            o.notes || '',
            JSON.stringify(o.crossBillDetails || {}),
            o.paymentMethod || '',
            o.datePaid || '',
            JSON.stringify(o.splitDetails || {}),
            o.dateRefunded || '',
            o.voidReason || '',
            o.voidAuthorizedBy || '',
            o.dateVoided || '',
            o.refundReason || '',
            o.refundAuthorizedBy || '',
            o.shelfLocation || '',
            o.locationLoggedBy || '',
            o.locationLoggedAt || '',
            o.courtesyApprovedReason || ''
          );
        });
      }

      // 11. Shifts
      if (db.shifts && Array.isArray(db.shifts)) {
        const insertShift = sqlDB.prepare(`
          INSERT OR REPLACE INTO shifts (id, cashierName, status, openingCash, details, dateOpened, dateClosed, closingCash, closingDetails, closingCashier, summary)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.shifts.forEach(s => {
          insertShift.run(
            s.id,
            s.cashierName,
            s.status || 'closed',
            s.openingCash || 0,
            JSON.stringify(s.details || {}),
            s.dateOpened,
            s.dateClosed || '',
            s.closingCash || 0,
            JSON.stringify(s.closingDetails || {}),
            s.closingCashier || '',
            JSON.stringify(s.summary || {})
          );
        });
      }

      // 12. Alcohol Products
      if (db.alcoholProducts && Array.isArray(db.alcoholProducts)) {
        const insertAlcohol = sqlDB.prepare(`
          INSERT OR REPLACE INTO alcohol_products (id, barcode, brand, model, fullWeight, emptyWeight, liquidOunces, shotSize, gramsPerOunce, currentVolumeOunces)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.alcoholProducts.forEach(a => {
          insertAlcohol.run(
            a.id,
            a.barcode || '',
            a.brand || '',
            a.model || '',
            a.fullWeight || 0,
            a.emptyWeight || 0,
            a.liquidOunces || 0,
            a.shotSize || 0,
            a.gramsPerOunce || 0,
            a.currentVolumeOunces || 0
          );
        });
      }

      // 13. Bartender Shifts
      if (db.bartenderShifts && Array.isArray(db.bartenderShifts)) {
        const insertBartenderShift = sqlDB.prepare(`
          INSERT OR REPLACE INTO bartender_shifts (id, status, dateStarted, dateEnded, bartenderName, startDiscrepancyOunces, expectedEndOunces, soldOunces, endWeight, endOunces, discrepancyOunces, inventory)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        db.bartenderShifts.forEach(bs => {
          insertBartenderShift.run(
            bs.id,
            bs.status || 'closed',
            bs.dateStarted,
            bs.dateEnded || '',
            bs.bartenderName || '',
            bs.startDiscrepancyOunces || 0,
            bs.expectedEndOunces || 0,
            bs.soldOunces || 0,
            bs.endWeight || 0,
            bs.endOunces || 0,
            bs.discrepancyOunces || 0,
            JSON.stringify(bs.inventory || [])
          );
        });
      }

      // 14. Departments
      if (db.departments && Array.isArray(db.departments)) {
        const insertDept = sqlDB.prepare(`
          INSERT OR REPLACE INTO departments (id, name, "order")
          VALUES (?, ?, ?)
        `);
        db.departments.forEach(d => {
          insertDept.run(d.id, d.name, d.order || 0);
        });
      }
    });

    runMigration();
    console.log('Migration committed successfully!');

    // Safety backup rename
    const backupPath = path.join(__dirname, 'db_backup.json');
    if (fs.existsSync(backupPath)) {
      fs.unlinkSync(backupPath);
    }
    fs.renameSync(DB_FILE, backupPath);
    console.log('db.json renamed to db_backup.json for safety.');

  } catch (err) {
    console.error('Migration failed:', err);
  }
}

// Execute database schemas and migration on startup
initSQLiteSchema();
migrateFromJSON();

  // Auto-clean any double-encoded modifierGroups in products table
  try {
    const badProds = sqlDB.prepare('SELECT id, modifierGroups FROM products WHERE modifierGroups LIKE \'"%\'').all();
    if (badProds && badProds.length > 0) {
      const updateStmt = sqlDB.prepare("UPDATE products SET modifierGroups = ? WHERE id = ?");
      sqlDB.transaction(() => {
        for (const p of badProds) {
          let clean = [];
          try {
            clean = JSON.parse(p.modifierGroups);
            if (typeof clean === 'string') clean = JSON.parse(clean);
          } catch(e) {}
          if (!Array.isArray(clean)) clean = [];
          updateStmt.run(JSON.stringify(clean), p.id);
        }
      })();
      console.log(`[MIGRATION] Repaired ${badProds.length} products with double-encoded modifierGroups.`);
    }
  } catch(e) {
    console.warn("Migration modifierGroups check error:", e.message);
  }


const database = {
  // --- PRODUCTS ---
  getProducts: () => {
    try {
      const rows = sqlDB.prepare('SELECT * FROM products').all();
      const groupsRows = sqlDB.prepare('SELECT * FROM modifier_groups').all();
      const latestGroupsMap = {};
      groupsRows.forEach(g => {
        let opts = [];
        try {
          opts = typeof g.options === 'string' ? JSON.parse(g.options || '[]') : (g.options || []);
          if (typeof opts === 'string') opts = JSON.parse(opts);
        } catch(e) {}
        latestGroupsMap[g.id] = {
          ...g,
          options: Array.isArray(opts) ? opts : []
        };
      });

      return rows.map(r => {
        let parsedGroups = [];
        try {
          parsedGroups = typeof r.modifierGroups === 'string' ? JSON.parse(r.modifierGroups || '[]') : (r.modifierGroups || []);
          if (typeof parsedGroups === 'string') {
            parsedGroups = JSON.parse(parsedGroups);
          }
        } catch (e) {
          parsedGroups = [];
        }
        if (!Array.isArray(parsedGroups)) parsedGroups = [];

        parsedGroups = parsedGroups.map(g => {
          if (!g) return null;
          const groupId = typeof g === 'string' ? g : (g.id || g.groupId);
          let latest = latestGroupsMap[groupId];
          if (!latest && typeof g === 'object' && g.name) {
            const cleanName = g.name.trim().toLowerCase();
            latest = Object.values(latestGroupsMap).find(x => (x.name || '').trim().toLowerCase() === cleanName);
          }
          if (latest) {
            return {
              ...latest,
              required: (typeof g === 'object' && g.required !== undefined) ? g.required : (latest.minSelection > 0 || latest.required),
              min: (typeof g === 'object' && g.min !== undefined) ? g.min : latest.minSelection,
              max: (typeof g === 'object' && g.max !== undefined) ? g.max : latest.maxSelection
            };
          }
          if (typeof g === 'string') {
            return { id: g, name: g, options: [] };
          }
          return g;
        }).filter(Boolean);

        return {
          ...r,
          isTaxable: r.isTaxable !== 0,
          modifierGroups: parsedGroups,
          trackStock: r.trackStock !== 0,
          boxSize: r.boxSize !== null && r.boxSize !== undefined ? r.boxSize : 12,
          palletSize: r.palletSize !== null && r.palletSize !== undefined ? r.palletSize : 200,
          image: r.image || '',
          printerId: r.printerId || ''
        };
      });
    } catch (err) {
      console.error("Error in getProducts:", err);
      return [];
    }
  },
  saveProduct: (product) => {
    if (!product.id) {
      product.id = 'p_' + Date.now();
    }
    if (product.modifierGroupIds && Array.isArray(product.modifierGroupIds)) {
      let finalGroups = [];
      product.modifierGroupIds.forEach(id => {
        const groupRow = sqlDB.prepare('SELECT * FROM modifier_groups WHERE id = ?').get(id);
        if (groupRow) {
          finalGroups.push({
            ...groupRow,
            options: JSON.parse(groupRow.options || '[]')
          });
        }
      });
      product.modifierGroups = finalGroups;
    }
    sqlDB.prepare(`
      INSERT OR REPLACE INTO products (id, name, category, price, barcode, ingredients, isTaxable, modifierGroups, trackStock, stockQuantity, boxSize, palletSize, image, printerId, subCategory, canPrice, canBarcode, bucketPrice, bucketSize)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      product.id,
      product.name,
      product.category || 'varios',
      product.price || 0,
      product.barcode || '',
      product.ingredients || '',
      product.isTaxable !== false ? 1 : 0,
      JSON.stringify(product.modifierGroups || []),
      product.trackStock ? 1 : 0,
      product.stockQuantity || 0,
      product.boxSize !== undefined ? product.boxSize : 12,
      product.palletSize !== undefined ? product.palletSize : 200,
      product.image || '',
      product.printerId || '',
      product.subCategory || '',
      product.canPrice !== undefined && product.canPrice !== null && product.canPrice !== '' ? parseFloat(product.canPrice) : null,
      product.canBarcode || '',
      product.bucketPrice !== undefined && product.bucketPrice !== null && product.bucketPrice !== '' ? parseFloat(product.bucketPrice) : null,
      product.bucketSize !== undefined && product.bucketSize !== null && product.bucketSize !== '' ? parseInt(product.bucketSize, 10) : 5
    );
    return product;
  },
  deleteProduct: (id) => {
    const info = sqlDB.prepare('DELETE FROM products WHERE id = ?').run(id);
    return info.changes > 0;
  },
  importProducts: (productsArray) => {
    let importedCount = 0;
    const insertProduct = sqlDB.prepare(`
      INSERT OR REPLACE INTO products (id, name, category, price, barcode, ingredients, isTaxable, modifierGroups, trackStock, stockQuantity, boxSize, palletSize, image, printerId, subCategory)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    sqlDB.transaction(() => {
      productsArray.forEach(newP => {
        if (!newP.name || !newP.price) return;
        
        let existingId = null;
        if (newP.id) {
          const row = sqlDB.prepare('SELECT id FROM products WHERE id = ?').get(newP.id);
          if (row) existingId = row.id;
        }
        if (!existingId && newP.barcode) {
          const row = sqlDB.prepare('SELECT id FROM products WHERE barcode = ?').get(String(newP.barcode).trim());
          if (row) existingId = row.id;
        }
        
        const id = existingId || newP.id || 'p_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
        insertProduct.run(
          id,
          newP.name,
          newP.category || 'varios',
          parseFloat(newP.price) || 0,
          newP.barcode ? String(newP.barcode).trim() : '',
          newP.ingredients || '',
          newP.isTaxable !== false ? 1 : 0,
          JSON.stringify(newP.modifierGroups || []),
          newP.trackStock ? 1 : 0,
          newP.stockQuantity || 0,
          newP.boxSize !== undefined ? newP.boxSize : 12,
          newP.palletSize !== undefined ? newP.palletSize : 200,
          newP.image || '',
          newP.printerId || '',
          newP.subCategory || ''
        );
        importedCount++;
      });
    })();
    return importedCount;
  },

  // --- GLOBAL MODIFIER GROUPS ---
  getModifierGroups: () => {
    const rows = sqlDB.prepare('SELECT * FROM modifier_groups').all();
    return rows.map(r => ({
      ...r,
      options: JSON.parse(r.options || '[]')
    }));
  },
  saveModifierGroup: (group) => {
    if (!group.id) {
      group.id = 'g_' + Date.now();
    }
    sqlDB.prepare(`
      INSERT OR REPLACE INTO modifier_groups (id, name, minSelection, maxSelection, options)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      group.id,
      group.name,
      group.minSelection || 0,
      group.maxSelection || 0,
      JSON.stringify(group.options || [])
    );
    return group;
  },
  deleteModifierGroup: (id) => {
    const info = sqlDB.prepare('DELETE FROM modifier_groups WHERE id = ?').run(id);
    return info.changes > 0;
  },

  // --- ORDERS ---
    getOrder: (id) => {
    if (!id) return null;
    try {
      const cleanId = String(id).trim();
      const numVal = !isNaN(Number(cleanId)) ? Number(cleanId) : -1;
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ? OR ticketNumber = ?').get(cleanId, numVal);
      if (!row) return null;
      try {
        row.items = JSON.parse(row.items || '[]');
      } catch (e) {
        row.items = [];
      }
      return row;
    } catch (err) {
      console.error("Error in database.getOrder:", err);
      try {
        const all = sqlDB.prepare('SELECT * FROM orders').all();
        const found = all.find(r => String(r.id) === String(id) || String(r.ticketNumber) === String(id));
        if (found) {
          try { found.items = JSON.parse(found.items || '[]'); } catch (e) { found.items = []; }
          return found;
        }
      } catch (e2) {}
      return null;
    }
  },
  getOrders: () => {
    const rows = sqlDB.prepare('SELECT * FROM orders').all();
    return rows.map(r => ({
      ...r,
      items: JSON.parse(r.items || '[]'),
      crossBillDetails: JSON.parse(r.crossBillDetails || '{}'),
      splitDetails: JSON.parse(r.splitDetails || '{}'),
      roundHistory: JSON.parse(r.roundHistory || '[]')
    }));
  },
  saveOrder: (order) => {
    // 1. Check if this is a sub-round / add-on order linked to a parent check
    if (order.parentOrderId) {
      try {
        const parentRow = sqlDB.prepare('SELECT ticketNumber, cashierName, clientName, tableName, tableNumber FROM orders WHERE id = ?').get(order.parentOrderId);
        if (parentRow) {
          order.parentTicketNumber = parentRow.ticketNumber;
          const countRow = sqlDB.prepare("SELECT COUNT(*) as cnt FROM orders WHERE parentOrderId = ?").get(order.parentOrderId);
          const roundIndex = countRow ? countRow.cnt : 0;
          const letter = String.fromCharCode(65 + (roundIndex % 26)); // A, B, C...
          order.roundLetter = order.roundLetter || letter;
          order.ticketDisplay = `${parentRow.ticketNumber}-${order.roundLetter}`;
          order.ticketNumber = `${parentRow.ticketNumber}-${order.roundLetter}`;
          if (!order.orderOrigin) {
            order.orderOrigin = order.cashierName || 'Cashier';
          }
          if (!order.clientName && parentRow.clientName) order.clientName = parentRow.clientName;
          if (!order.tableName && parentRow.tableName) order.tableName = parentRow.tableName;
          if (!order.tableNumber && parentRow.tableNumber) order.tableNumber = parentRow.tableNumber;

          // Append sub-round to parent order's roundHistory
          try {
            let parentHistory = JSON.parse(parentRow.roundHistory || '[]');
            parentHistory.push({
              roundLetter: order.roundLetter,
              ticketDisplay: order.ticketDisplay,
              timestamp: order.dateCreated || new Date().toISOString(),
              orderOrigin: order.orderOrigin || order.cashierName || 'Cashier',
              items: Array.isArray(order.items) ? order.items : JSON.parse(order.items || '[]')
            });
            sqlDB.prepare('UPDATE orders SET roundHistory = ? WHERE id = ?').run(JSON.stringify(parentHistory), order.parentOrderId);
          } catch(e) {
            console.error('Error appending sub-round to parent roundHistory:', e);
          }
        }
      } catch (err) {
        console.error("Error looking up parent order in saveOrder:", err);
      }
    }

    // 2. Standalone order consecutive counter (only counts base parent tickets, avoids text suffixes)
    if (!order.ticketNumber) {
      const row = sqlDB.prepare("SELECT ticketNumber FROM orders WHERE CAST(ticketNumber AS INTEGER) > 0 AND (parentOrderId IS NULL OR parentOrderId = '') ORDER BY CAST(ticketNumber AS INTEGER) DESC LIMIT 1").get();
      let nextTicketNumber = 1001;
      if (row && row.ticketNumber) {
        const parsed = parseInt(row.ticketNumber, 10);
        if (!isNaN(parsed) && parsed >= 1000) {
          nextTicketNumber = parsed + 1;
        }
      }
      order.ticketNumber = nextTicketNumber;
      order.ticketDisplay = String(nextTicketNumber);
    } else if (!order.ticketDisplay) {
      order.ticketDisplay = String(order.ticketNumber);
    }
    
    if (!order.parentOrderId && Array.isArray(order.items) && order.items.length > 0 && (!order.roundHistory || order.roundHistory === '[]' || (Array.isArray(order.roundHistory) && order.roundHistory.length === 0))) {
      const phone = order.clientPhone || order.phone || '';
      const initialOrigin = order.orderOrigin || (phone ? `Customer Phone: ${phone}` : (order.cashierName || 'Cashier'));
      order.roundHistory = [{
        roundLetter: 'A',
        ticketDisplay: String(order.ticketNumber || ''),
        timestamp: order.dateCreated || new Date().toISOString(),
        orderOrigin: initialOrigin,
        customerPhone: phone,
        items: order.items
      }];
    }
    order.id = order.id || ('o_' + Date.now());
    order.dateCreated = order.dateCreated || new Date().toISOString();
    order.dateUpdated = order.dateUpdated || order.dateCreated;
    order.status = order.status || 'pendiente';
    order.shelfLocation = order.shelfLocation || null;
    order.locationLoggedBy = null;
    order.locationLoggedAt = null;
    order.deliveryPlatform = order.deliveryPlatform || 'pos';
    order.externalOrderId = order.externalOrderId || '';
    order.pickupCode = order.pickupCode || '';
    order.driverInfo = order.driverInfo || '';
    order.handoverCashier = order.handoverCashier || '';
    order.dateHandedOver = order.dateHandedOver || '';
    order.parentOrderId = order.parentOrderId || '';
    order.parentTicketNumber = order.parentTicketNumber || 0;
    order.roundLetter = order.roundLetter || '';
    order.orderOrigin = order.orderOrigin || (order.cashierName || '');
    order.roundHistory = order.roundHistory || [];
    order.tableName = order.tableName || '';

    // Auto-calcular subtotal e impuesto si faltan para asegurar desglose en recibos
    if ((!order.subtotal || order.subtotal === 0) && Array.isArray(order.items) && order.items.length > 0) {
      order.subtotal = order.items.reduce((acc, it) => acc + ((Number(it.price) || 0) * (Number(it.quantity) || 1)), 0);
    }
    if ((!order.tax || order.tax === 0) && Number(order.total) > Number(order.subtotal)) {
      order.tax = Number((Number(order.total) - Number(order.subtotal)).toFixed(2));
    }
    
    sqlDB.prepare(`
      INSERT INTO orders (
        id, ticketNumber, status, paymentStatus, cashierName, clientName, clientPhone, 
        deliveryType, tableNumber, tableName, guestCount, activeSeat, items, subtotal, tax, total, 
        cardTip, dateCreated, dateUpdated, courtesyApprovedBy, notes, crossBillDetails, paymentMethod, 
        datePaid, splitDetails, dateRefunded, voidReason, voidAuthorizedBy, dateVoided, 
        refundReason, refundAuthorizedBy, shelfLocation, locationLoggedBy, locationLoggedAt, courtesyApprovedReason,
        deliveryPlatform, externalOrderId, pickupCode, driverInfo, handoverCashier, dateHandedOver,
        parentOrderId, parentTicketNumber, roundLetter, ticketDisplay, orderOrigin, roundHistory,
        cashReceived, changeGiven, changeDue, tipAmount, isOpenTabAuthorized, authorizedBy
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      order.id,
      order.ticketNumber,
      order.status,
      order.paymentStatus || 'unpaid',
      order.cashierName || '',
      order.clientName || '',
      order.clientPhone || '',
      order.deliveryType || order.type || 'walkin',
      order.tableNumber || '',
      order.tableName || '',
      order.guestCount || 1,
      order.activeSeat || '',
      JSON.stringify(order.items || []),
      order.subtotal || 0,
      order.tax || 0,
      order.total || 0,
      order.cardTip || 0,
      order.dateCreated,
      order.dateUpdated,
      order.courtesyApprovedBy || '',
      order.notes || '',
      JSON.stringify(order.crossBillDetails || {}),
      order.paymentMethod || '',
      order.datePaid || '',
      JSON.stringify(order.splitDetails || {}),
      order.dateRefunded || '',
      order.voidReason || '',
      order.voidAuthorizedBy || '',
      order.dateVoided || '',
      order.refundReason || '',
      order.refundAuthorizedBy || '',
      order.shelfLocation || '',
      order.locationLoggedBy || '',
      order.locationLoggedAt || '',
      order.courtesyApprovedReason || '',
      order.deliveryPlatform,
      order.externalOrderId,
      order.pickupCode,
      order.driverInfo,
      order.handoverCashier,
      order.dateHandedOver,
      order.parentOrderId,
      order.parentTicketNumber,
      order.roundLetter,
      order.ticketDisplay,
      order.orderOrigin,
      JSON.stringify(order.roundHistory || []),
      order.cashReceived || 0,
      order.changeGiven || order.changeDue || 0,
      order.changeDue || order.changeGiven || 0,
      order.tipAmount || 0,
          order.isOpenTabAuthorized ? 1 : 0,
          order.authorizedBy || ''
        );
    return order;
  },
  deleteOrder: (id) => {
    try {
      return sqlDB.prepare('DELETE FROM orders WHERE id = ?').run(id);
    } catch (e) {
      console.error('Error deleting order:', e);
      return null;
    }
  },
  getOrderByDeliveryCode: (code) => {
    if (!code) return null;
    const clean = String(code).trim();
    const isNum = !isNaN(Number(clean)) && Number(clean) > 0;
    const numVal = isNum ? Number(clean) : -999999;
    try {
      const row = sqlDB.prepare(`
        SELECT * FROM orders 
        WHERE pickupCode = ? 
           OR externalOrderId = ? 
           OR ticketNumber = ? 
           OR id = ?
           OR UPPER(externalOrderId) = UPPER(?)
           OR UPPER(pickupCode) = UPPER(?)
        ORDER BY dateCreated DESC
        LIMIT 1
      `).get(clean, clean, numVal, clean, clean, clean);
      if (!row) return null;
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}')
      };
    } catch (err) {
      console.error("Error in getOrderByDeliveryCode:", err);
      return null;
    }
  },
  handoverDeliveryOrder: (orderId, cashierName) => {
    const now = new Date().toISOString();
    try {
      sqlDB.prepare(`
        UPDATE orders 
        SET status = 'entregado', handoverCashier = ?, dateHandedOver = ?
        WHERE id = ?
      `).run(cashierName || 'Cajero', now, orderId);
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      if (!row) return null;
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}')
      };
    } catch (err) {
      console.error("Error in handoverDeliveryOrder:", err);
      return null;
    }
  },
  updateOrderStatus: (orderId, newStatus) => {
    const now = new Date().toISOString();
    const cleanId = String(orderId || '').trim();
    const numVal = !isNaN(Number(cleanId)) ? Number(cleanId) : -1;
    let info;
    try {
      info = sqlDB.prepare('UPDATE orders SET status = ?, dateUpdated = ? WHERE id = ? OR ticketNumber = ? OR ticketDisplay = ?').run(newStatus, now, cleanId, numVal, cleanId);
    } catch (e) {
      info = sqlDB.prepare('UPDATE orders SET status = ? WHERE id = ? OR ticketNumber = ? OR ticketDisplay = ?').run(newStatus, cleanId, numVal, cleanId);
    }
    if (info && info.changes > 0) {
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ? OR ticketNumber = ? OR ticketDisplay = ?').get(cleanId, numVal, cleanId);
      if (row) {
        return {
          ...row,
          items: JSON.parse(row.items || '[]'),
          crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
          splitDetails: JSON.parse(row.splitDetails || '{}')
        };
      }
    }
    return null;
  },
  updateOrder: (orderId, orderData) => {
    const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
    if (!row) return null;
    
    const current = {
      ...row,
      items: JSON.parse(row.items || '[]'),
      crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
      splitDetails: JSON.parse(row.splitDetails || '{}'),
      roundHistory: JSON.parse(row.roundHistory || '[]')
    };
    
    const updated = { ...current, ...orderData };
    updated.dateUpdated = new Date().toISOString();
    updated.tableName = updated.tableName !== undefined ? updated.tableName : (current.tableName || '');
    
    // Auto-calcular subtotal e impuesto si faltan para asegurar desglose en recibos
    if ((!updated.subtotal || updated.subtotal === 0) && Array.isArray(updated.items) && updated.items.length > 0) {
      updated.subtotal = updated.items.reduce((acc, it) => acc + ((Number(it.price) || 0) * (Number(it.quantity) || 1)), 0);
    }
    if ((!updated.tax || updated.tax === 0) && Number(updated.total) > Number(updated.subtotal)) {
      updated.tax = Number((Number(updated.total) - Number(updated.subtotal)).toFixed(2));
    }
    
    sqlDB.prepare(`
      UPDATE orders SET
        status = ?, paymentStatus = ?, cashierName = ?, clientName = ?, clientPhone = ?, 
        deliveryType = ?, tableNumber = ?, tableName = ?, guestCount = ?, activeSeat = ?, items = ?, 
        subtotal = ?, tax = ?, total = ?, cardTip = ?, dateUpdated = ?, courtesyApprovedBy = ?, notes = ?, 
        crossBillDetails = ?, paymentMethod = ?, datePaid = ?, splitDetails = ?, 
        dateRefunded = ?, voidReason = ?, voidAuthorizedBy = ?, dateVoided = ?, 
        refundReason = ?, refundAuthorizedBy = ?, shelfLocation = ?, locationLoggedBy = ?, 
        locationLoggedAt = ?, courtesyApprovedReason = ?, roundHistory = ?,
        cashReceived = ?, changeGiven = ?, changeDue = ?, tipAmount = ?,
        isOpenTabAuthorized = ?, authorizedBy = ?
      WHERE id = ?
    `).run(
      updated.status,
      updated.paymentStatus,
      updated.cashierName || '',
      updated.clientName || '',
      updated.clientPhone || '',
      updated.deliveryType || updated.type || 'walkin',
      updated.tableNumber || '',
      updated.tableName || '',
      updated.guestCount || 1,
      updated.activeSeat || '',
      JSON.stringify(updated.items || []),
      updated.subtotal || 0,
      updated.tax || 0,
      updated.total || 0,
      updated.cardTip || 0,
      updated.dateUpdated,
      updated.courtesyApprovedBy || '',
      updated.notes || '',
      JSON.stringify(updated.crossBillDetails || {}),
      updated.paymentMethod || '',
      updated.datePaid || '',
      JSON.stringify(updated.splitDetails || {}),
      updated.dateRefunded || '',
      updated.voidReason || '',
      updated.voidAuthorizedBy || '',
      updated.dateVoided || '',
      updated.refundReason || '',
      updated.refundAuthorizedBy || '',
      updated.shelfLocation || '',
      updated.locationLoggedBy || '',
      updated.locationLoggedAt || '',
      updated.courtesyApprovedReason || '',
      JSON.stringify(updated.roundHistory || []),
      updated.cashReceived || 0,
      updated.changeGiven || updated.changeDue || 0,
      updated.changeDue || updated.changeGiven || 0,
      updated.tipAmount || 0,
      updated.isOpenTabAuthorized ? 1 : 0,
      updated.authorizedBy || '',
      orderId
    );
    if (updated.paymentStatus === 'paid') {
      try {
        sqlDB.prepare("UPDATE orders SET paymentStatus = 'paid' WHERE parentOrderId = ?").run(orderId);
      } catch (e) {}
    }
    return updated;
  },
  updateOrderPaymentStatus: (orderId, newPaymentStatus) => {
    const now = new Date().toISOString();
    let info;
    try {
      info = sqlDB.prepare('UPDATE orders SET paymentStatus = ?, dateUpdated = ? WHERE id = ?').run(newPaymentStatus, now, orderId);
    } catch (e) {
      info = sqlDB.prepare('UPDATE orders SET paymentStatus = ? WHERE id = ?').run(newPaymentStatus, orderId);
    }
    if (newPaymentStatus === 'paid') {
      try {
        sqlDB.prepare("UPDATE orders SET paymentStatus = 'paid' WHERE parentOrderId = ?").run(orderId);
      } catch (e) {}
    }
    if (info.changes > 0) {
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}'),
        roundHistory: JSON.parse(row.roundHistory || '[]')
      };
    }
    return null;
  },
  voidOrder: (orderId, reason, authorizedBy) => {
    const info = sqlDB.prepare(`
      UPDATE orders SET status = 'void', voidReason = ?, voidAuthorizedBy = ?, dateVoided = ? WHERE id = ?
    `).run(reason, authorizedBy, new Date().toISOString(), orderId);
    
    if (info.changes > 0) {
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}')
      };
    }
    return null;
  },
  refundOrder: (orderId, reason, authorizedBy) => {
    const info = sqlDB.prepare(`
      UPDATE orders SET status = 'refunded', refundReason = ?, refundAuthorizedBy = ?, dateRefunded = ? WHERE id = ?
    `).run(reason, authorizedBy, new Date().toISOString(), orderId);
    
    if (info.changes > 0) {
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}')
      };
    }
    return null;
  },
  clearAbandonedUnpaidTabs: (employeeName = 'Manager') => {
    // PROTECTED: Only marks unpaid, abandoned or test orders as void to keep UI clean.
    // Real completed / paid sales are NEVER touched and remain in historical records.
    const result = sqlDB.prepare(`
      UPDATE orders 
      SET status = 'void', 
          paymentStatus = 'void',
          voidReason = 'Limpieza de cuenta abandonada / Inactive tab cleared',
          voidAuthorizedBy = ?,
          dateVoided = ?
      WHERE paymentStatus = 'unpaid' AND status NOT IN ('completed', 'void', 'refunded')
    `).run(employeeName, new Date().toISOString());

    return {
      success: true,
      clearedCount: result.changes,
      message: `Se limpiaron ${result.changes} cuentas no pagadas. Todas las ventas cobradas y turnos fiscales permanecen 100% inmutables y protegidos.`
    };
  },
  resetDatabase: (employeeName = 'Manager') => {
    // BLINDADO: Ya no se borran órdenes ni turnos de la base de datos.
    // Solo se limpian cuentas no pagadas / abandonadas para ordenar la pantalla.
    return database.clearAbandonedUnpaidTabs(employeeName);
  },
  resetAllToVirgin: (bypassKey) => {
    if (bypassKey !== 'DEVELOPER-BYPASS-CLEAR-ALL-2026') {
      return { 
        success: false, 
        error: 'ACCESO DENEGADO: El reseteo de fábrica requiere clave maestra de desarrollador. Los registros fiscales y transacciones están protegidos por ley.' 
      };
    }
    sqlDB.transaction(() => {
      sqlDB.prepare('DELETE FROM key_value_store').run();
      sqlDB.prepare('DELETE FROM orders').run();
      sqlDB.prepare('DELETE FROM shifts').run();
      sqlDB.prepare('DELETE FROM products').run();
      sqlDB.prepare('DELETE FROM departments').run();
      sqlDB.prepare('DELETE FROM modifier_groups').run();
      sqlDB.prepare('DELETE FROM single_modifiers').run();
      sqlDB.prepare('DELETE FROM waitlist').run();
      sqlDB.prepare('DELETE FROM alcohol_products').run();
      sqlDB.prepare('DELETE FROM bartender_shifts').run();
      sqlDB.prepare('DELETE FROM employees').run();
      
      const insertEmployee = sqlDB.prepare(`
        INSERT OR REPLACE INTO employees (id, name, passcode, cardCode, role, punchHistory)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      insertEmployee.run("e1", "manager", "1234", "1111", "manager", "[]");
      insertEmployee.run("e2", "admin", "2026", "2222", "admin", "[]");
    })();
    return { success: true };
  },
  updateOrderLocation: (orderId, shelfLocation, employeeName) => {
    const info = sqlDB.prepare(`
      UPDATE orders SET shelfLocation = ?, locationLoggedBy = ?, locationLoggedAt = ? WHERE id = ?
    `).run(shelfLocation, employeeName, new Date().toISOString(), orderId);
    
    if (info.changes > 0) {
      const row = sqlDB.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
      return {
        ...row,
        items: JSON.parse(row.items || '[]'),
        crossBillDetails: JSON.parse(row.crossBillDetails || '{}'),
        splitDetails: JSON.parse(row.splitDetails || '{}')
      };
    }
    return null;
  },

  getEmployees: () => {
    const rows = sqlDB.prepare('SELECT * FROM employees').all();
    return rows.map(r => ({
      ...r,
      punchHistory: JSON.parse(r.punchHistory || '[]'),
      fingerprintRegistered: r.fingerprintRegistered !== 0,
      fingerprintTemplate: r.fingerprintTemplate || null,
      phone: r.phone ? String(r.phone).trim() : '',
      address: r.address ? String(r.address).trim() : '',
      tasks: r.tasks ? String(r.tasks).trim() : ''
    }));
  },
  saveEmployee: (emp) => {
    if (!emp.id) {
      emp.id = 'e_' + Date.now();
      emp.punchHistory = [];
    }
    let existingHistory = '[]';
    const row = sqlDB.prepare('SELECT punchHistory FROM employees WHERE id = ?').get(emp.id);
    if (row) {
      existingHistory = row.punchHistory;
    }
    const historyStr = emp.punchHistory ? JSON.stringify(emp.punchHistory) : existingHistory;
    
    const phoneVal = String(emp.phone || '').trim();
    let passcodeVal = String(emp.passcode || '').trim();

    // Si no se proporcionó passcode pero sí teléfono, usar automáticamente los últimos 4 dígitos
    if (!passcodeVal && phoneVal) {
      const digits = phoneVal.replace(/\D/g, '');
      if (digits.length >= 4) {
        passcodeVal = digits.slice(-4);
      }
    }
    
    sqlDB.prepare(`
      INSERT OR REPLACE INTO employees (id, name, passcode, cardCode, role, punchHistory, fingerprintRegistered, fingerprintTemplate, phone, address, tasks)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      emp.id,
      emp.name,
      passcodeVal,
      emp.cardCode ? String(emp.cardCode).trim() : '',
      emp.role || 'cashier',
      historyStr,
      emp.fingerprintRegistered ? 1 : 0,
      emp.fingerprintTemplate || null,
      phoneVal,
      emp.address ? String(emp.address).trim() : '',
      emp.tasks ? String(emp.tasks).trim() : ''
    );
    emp.phone = phoneVal;
    emp.passcode = passcodeVal;
    return emp;
  },
  deleteEmployee: (empId) => {
    const info = sqlDB.prepare('DELETE FROM employees WHERE id = ?').run(empId);
    return info.changes > 0;
  },
  // --- EMERGENCY MANAGER PIN (10 USES / 48H SELF-DESTRUCTING BACKDOOR) ---
  getEmergencyPinConfig: () => {
    try {
      const row = sqlDB.prepare("SELECT value FROM key_value_store WHERE key = 'emergency_pin_config'").get();
      if (row) {
        const cfg = JSON.parse(row.value);
        if (cfg.pin === '9110') {
          cfg.pin = '9111';
        }
        if (!cfg.expiresAt) {
          cfg.expiresAt = Date.now() + 48 * 3600 * 1000;
        }
        if (Date.now() > cfg.expiresAt || cfg.usesLeft <= 0) {
          cfg.enabled = false;
        }
        return cfg;
      }
    } catch (e) {}
    const defaultCfg = {
      pin: '9111',
      maxUses: 10,
      usesLeft: 10,
      enabled: true,
      expiresAt: Date.now() + 48 * 3600 * 1000,
      createdAt: new Date().toISOString()
    };
    try {
      sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('emergency_pin_config', ?)")
        .run(JSON.stringify(defaultCfg));
    } catch (e) {}
    return defaultCfg;
  },
  useEmergencyPin: () => {
    const cfg = database.getEmergencyPinConfig();
    const isExpiredTime = cfg.expiresAt && Date.now() > cfg.expiresAt;
    if (!cfg.enabled || cfg.usesLeft <= 0 || isExpiredTime) {
      cfg.enabled = false;
      sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('emergency_pin_config', ?)")
        .run(JSON.stringify(cfg));
      return { success: false, usesLeft: 0, maxUses: cfg.maxUses, error: isExpiredTime ? 'time_expired' : 'uses_expired' };
    }
    cfg.usesLeft = Math.max(0, cfg.usesLeft - 1);
    if (cfg.usesLeft <= 0) {
      cfg.enabled = false;
    }
    sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('emergency_pin_config', ?)")
      .run(JSON.stringify(cfg));
    return { success: true, usesLeft: cfg.usesLeft, maxUses: cfg.maxUses, expiresAt: cfg.expiresAt };
  },
  resetEmergencyPin: (pin = '9111', maxUses = 10, hours = 48) => {
    const cfg = {
      pin,
      maxUses,
      usesLeft: maxUses,
      enabled: true,
      expiresAt: Date.now() + hours * 3600 * 1000,
      createdAt: new Date().toISOString()
    };
    sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('emergency_pin_config', ?)")
      .run(JSON.stringify(cfg));
    return cfg;
  },
  punchTime: (employeeIdOrCard, type) => {
    const emp = sqlDB.prepare('SELECT * FROM employees WHERE id = ? OR cardCode = ? OR passcode = ?')
      .get(employeeIdOrCard, employeeIdOrCard, employeeIdOrCard);
    if (emp) {
      const punch = { type, time: new Date().toISOString() };
      const history = JSON.parse(emp.punchHistory || '[]');
      history.push(punch);
      sqlDB.prepare('UPDATE employees SET punchHistory = ? WHERE id = ?')
        .run(JSON.stringify(history), emp.id);
      return { employeeName: emp.name, punch };
    }
    return null;
  },

  // --- LOYALTY PROGRAM ---
  getLoyaltyPoints: (phone) => {
    const row = sqlDB.prepare('SELECT * FROM loyalty WHERE phone = ?').get(phone);
    return row || null;
  },
  addLoyaltyPoints: (phone, name, pointsToAdd) => {
    let client = sqlDB.prepare('SELECT * FROM loyalty WHERE phone = ?').get(phone);
    if (client) {
      const newPoints = client.points + pointsToAdd;
      sqlDB.prepare('UPDATE loyalty SET points = ? WHERE phone = ?').run(newPoints, phone);
      client.points = newPoints;
    } else {
      client = { phone, name: name || 'Cliente Nuevo', points: pointsToAdd, type: 'individual', companyName: '', address: '' };
      sqlDB.prepare(`
        INSERT INTO loyalty (phone, name, points, type, companyName, address)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(phone, client.name, client.points, client.type, client.companyName, client.address);
    }
    return client;
  },
  saveClient: (clientData) => {
    let client = sqlDB.prepare('SELECT * FROM loyalty WHERE phone = ?').get(clientData.phone);
    if (client) {
      client.name = clientData.name || client.name;
      client.type = clientData.type || client.type || 'individual';
      client.companyName = clientData.companyName !== undefined ? clientData.companyName : client.companyName;
      client.address = clientData.address !== undefined ? clientData.address : client.address;
      
      sqlDB.prepare(`
        UPDATE loyalty SET name = ?, type = ?, companyName = ?, address = ? WHERE phone = ?
      `).run(client.name, client.type, client.companyName, client.address, clientData.phone);
    } else {
      client = {
        phone: clientData.phone,
        name: clientData.name || 'New Client',
        points: clientData.points || 0,
        type: clientData.type || 'individual',
        companyName: clientData.companyName || '',
        address: clientData.address || ''
      };
      sqlDB.prepare(`
        INSERT INTO loyalty (phone, name, points, type, companyName, address)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(client.phone, client.name, client.points, client.type, client.companyName, client.address);
    }
    return client;
  },
  getAllClients: () => {
    return sqlDB.prepare('SELECT * FROM loyalty').all();
  },

  // --- GIFT CARDS ---
  getGiftCard: (code) => {
    const row = sqlDB.prepare('SELECT * FROM gift_cards WHERE code = ? AND active = 1').get(code);
    if (row) {
      return {
        ...row,
        active: row.active !== 0
      };
    }
    return null;
  },
  useGiftCard: (code, amountToUse) => {
    const card = sqlDB.prepare('SELECT * FROM gift_cards WHERE code = ? AND active = 1').get(code);
    if (card && card.balance >= amountToUse) {
      const newBalance = card.balance - amountToUse;
      sqlDB.prepare('UPDATE gift_cards SET balance = ? WHERE code = ?').run(newBalance, code);
      return {
        code,
        balance: newBalance,
        active: true
      };
    }
    return null;
  },

  // --- SETTINGS ---
  getSettings: () => {
    const row = sqlDB.prepare("SELECT value FROM key_value_store WHERE key = 'settings'").get();
    let settings = row ? JSON.parse(row.value) : {};
    
    // Automatically initialize unique machine ID and 30-day demo trial for fresh installations
    let changed = false;
    if (!settings.machineId) {
      const crypto = require('crypto');
      settings.machineId = 'IMP-' + crypto.randomBytes(8).toString('hex').toUpperCase();
      changed = true;
    }
    if (!settings.licenseStatus || !settings.trialExpiration) {
      settings.licenseStatus = 'demo';
      settings.licenseType = '15-Day Free Trial';
      settings.licenseKey = '';
      
      const todayStr = new Date().toISOString().split('T')[0];
      const trialExpiry = new Date();
      trialExpiry.setDate(trialExpiry.getDate() + 15);
      const trialExpStr = trialExpiry.toISOString().split('T')[0];
      settings.trialStartDate = settings.trialStartDate || todayStr;
      settings.trialExpiration = settings.trialExpiration || trialExpStr;
      settings.licenseExpiration = settings.licenseExpiration || trialExpStr;
      changed = true;
    }
    if (!settings.licenseBarHubStatus) {
      settings.licenseBarHubStatus = 'demo';
      settings.licenseBarHubType = 'Bar Hub Demo 15-Days';
      settings.licenseBarHubKey = '';
      
      const trialExpiry = new Date();
      trialExpiry.setDate(trialExpiry.getDate() + 15);
      settings.licenseBarHubExpiration = trialExpiry.toISOString().split('T')[0];
      changed = true;
    }

    if (settings.onlineMode === undefined) {
      settings.onlineMode = true;
      changed = true;
    }
    if (!settings.cloudDomain) {
      settings.cloudDomain = 'impossiblepos.com';
      changed = true;
    }
    if (settings.clientSubdomain === undefined) {
      settings.clientSubdomain = '';
      changed = true;
    }
    if (!settings.language) {
      settings.language = 'en';
      changed = true;
    }
    if (settings.licenseMaxDevices === undefined) {
      settings.licenseMaxDevices = 1;
      changed = true;
    }
    if (settings.licenseMaxMobileWaitresses === undefined) {
      settings.licenseMaxMobileWaitresses = 1;
      changed = true;
    }
    if (settings.enableMultiGuest === undefined) {
      const bType = String(settings.businessType || '').toLowerCase();
      settings.enableMultiGuest = bType.includes('restaurant') || bType.includes('taco') || bType.includes('bar');
      changed = true;
    }
    if (settings.enableLoyalty === undefined) {
      settings.enableLoyalty = false;
      changed = true;
    }
    const fs = require('fs');
    const path = require('path');
    const logoPngPath = path.join(__dirname, 'public', 'logo.png');
    const logoBinPath = path.join(__dirname, 'public', 'logo_escpos.bin');
    if (fs.existsSync(logoPngPath) || fs.existsSync(logoBinPath)) {
      if (settings.printLogoOnReceipts === undefined || settings.printLogoOnReceipts === null) {
        settings.printLogoOnReceipts = true;
        changed = true;
      }
    }
    
    if (!Array.isArray(settings.posStations) || settings.posStations.length === 0) {
      settings.posStations = [
        { id: '1', name: 'Caja 1 (Main POS)', type: 'computer', role: 'cashier', isDefault: true }
      ];
      changed = true;
    }
    
    if (changed) {
      sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('settings', ?)")
        .run(JSON.stringify(settings));
    }
    
    return settings;
  },
  saveSettings: (newSettings) => {
    const current = database.getSettings();
    const updated = { ...current, ...newSettings };
    sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('settings', ?)")
      .run(JSON.stringify(updated));
    return updated;
  },
  updateSettings: (newSettings) => {
    return database.saveSettings(newSettings);
  },
  getStations: () => {
    const s = database.getSettings();
    return s.posStations || [];
  },
  saveStations: (stations) => {
    return database.saveSettings({ posStations: stations });
  },

  // --- CASHIER SHIFTS (DUAL CASH DRAWER & MULTI-CASHIER READY) ---
  getActiveShifts: () => {
    try {
      const rows = sqlDB.prepare("SELECT * FROM shifts WHERE status = 'open'").all();
      return rows.map(row => ({
        ...row,
        details: JSON.parse(row.details || '{}'),
        closingDetails: JSON.parse(row.closingDetails || '{}'),
        summary: JSON.parse(row.summary || '{}'),
        drawerNumber: row.drawerNumber || 1
      }));
    } catch (e) {
      console.error("Error fetching active shifts:", e);
      return [];
    }
  },
  getActiveShift: (cashierName = null, drawerNumber = null) => {
    // Auto-cleanup any residual open shifts under Pedro Gomez
    try {
      sqlDB.prepare("DELETE FROM shifts WHERE cashierName LIKE '%Pedro Gomez%' AND status = 'open'").run();
      sqlDB.prepare("DELETE FROM shifts WHERE cashierName LIKE '%Pedro Gómez%' AND status = 'open'").run();
    } catch (e) {
      console.error("Error cleaning up residual Pedro Gomez shifts:", e);
    }

    let row = null;
    if (cashierName && String(cashierName).trim()) {
      row = sqlDB.prepare("SELECT * FROM shifts WHERE status = 'open' AND LOWER(cashierName) = LOWER(?) LIMIT 1").get(String(cashierName).trim());
    } else if (drawerNumber) {
      row = sqlDB.prepare("SELECT * FROM shifts WHERE status = 'open' AND drawerNumber = ? LIMIT 1").get(parseInt(drawerNumber));
    } else {
      row = sqlDB.prepare("SELECT * FROM shifts WHERE status = 'open' ORDER BY dateOpened DESC LIMIT 1").get();
    }

    if (row) {
      return {
        ...row,
        details: JSON.parse(row.details || '{}'),
        closingDetails: JSON.parse(row.closingDetails || '{}'),
        summary: JSON.parse(row.summary || '{}'),
        drawerNumber: row.drawerNumber || 1
      };
    }
    return null;
  },
  getActiveDrawers: () => {
    try {
      const rows = sqlDB.prepare("SELECT id, cashierName, drawerNumber, dateOpened FROM shifts WHERE status = 'open'").all();
      return rows.map(r => ({
        shiftId: r.id,
        cashierName: r.cashierName,
        drawerNumber: r.drawerNumber || 1,
        dateOpened: r.dateOpened
      }));
    } catch (e) {
      return [];
    }
  },
  openShift: (cashier, openingCash, details, drawerNumber = 1) => {
    const cleanCashier = (cashier || 'Cashier').trim();
    const drv = parseInt(drawerNumber) || 1;

    // Si esta cajera ya tiene un turno abierto, lo retornamos
    const existingCashierShift = database.getActiveShift(cleanCashier);
    if (existingCashierShift) return existingCashierShift;

    // Verificar si el cajón solicitado ya está ocupado por otra cajera
    const existingDrawerShift = database.getActiveShift(null, drv);
    if (existingDrawerShift) {
      throw new Error(`Drawer ${drv} is already in use by ${existingDrawerShift.cashierName}`);
    }

    const newShift = {
      id: 's_' + Date.now(),
      cashierName: cleanCashier,
      drawerNumber: drv,
      status: 'open',
      openingCash: parseFloat(openingCash) || 0,
      details: details || {},
      dateOpened: new Date().toISOString(),
      dateClosed: null,
      closingCash: null,
      closingDetails: {},
      closingCashier: '',
      summary: {}
    };
    
    sqlDB.prepare(`
      INSERT INTO shifts (id, cashierName, drawerNumber, status, openingCash, details, dateOpened, dateClosed, closingCash, closingDetails, closingCashier, summary)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      newShift.id,
      newShift.cashierName,
      newShift.drawerNumber,
      newShift.status,
      newShift.openingCash,
      JSON.stringify(newShift.details),
      newShift.dateOpened,
      '',
      0,
      '{}',
      '',
      '{}'
    );
    return newShift;
  },
  closeShift: (cashier, closingCash, details) => {
    // Buscar turno activo de esta cajera específicamente (o el último abierto si no se especifica)
    const active = database.getActiveShift(cashier);
    if (active) {
      const orders = database.getOrders();
      // Filtrar órdenes que corresponden a este cajero en este turno
      const shiftOrders = orders.filter(o => {
        const matchesCashier = !active.cashierName || (o.cashierName && o.cashierName.trim().toLowerCase() === active.cashierName.trim().toLowerCase());
        const isCreatedInShift = o.status === 'completed' && new Date(o.dateCreated) >= new Date(active.dateOpened);
        const isPaidInShift = o.paymentStatus === 'paid' && o.datePaid && new Date(o.datePaid) >= new Date(active.dateOpened);
        return matchesCashier && (isCreatedInShift || isPaidInShift);
      });
      
      let totalSales = 0;
      let cashSales = 0;
      let cardSales = 0;
      
      shiftOrders.forEach(o => {
        totalSales += o.total;
        if (o.paymentMethod === 'cash') {
          cashSales += o.total;
        } else if (o.paymentMethod === 'card') {
          cardSales += o.total;
        } else if (o.paymentMethod === 'split') {
          cashSales += (o.splitDetails ? o.splitDetails.cashAmount : 0);
          cardSales += (o.splitDetails ? o.splitDetails.cardAmount : 0);
        }
      });
      
      const shiftRefunds = orders.filter(o => 
        o.status === 'refunded' && 
        (!active.cashierName || (o.cashierName && o.cashierName.trim().toLowerCase() === active.cashierName.trim().toLowerCase())) &&
        new Date(o.dateRefunded) >= new Date(active.dateOpened)
      );
      let cashRefunds = 0;
      shiftRefunds.forEach(o => {
        if (o.paymentMethod === 'cash') {
          cashRefunds += o.total;
        } else if (o.paymentMethod === 'split') {
          cashRefunds += (o.splitDetails ? o.splitDetails.cashAmount : 0);
        }
      });
      
      const expectedCash = active.openingCash + cashSales - cashRefunds;
      const discrepancy = parseFloat(closingCash) - expectedCash;
      
      active.status = 'closed';
      active.closingCash = parseFloat(closingCash) || 0;
      active.closingDetails = details || {};
      active.closingCashier = cashier || active.cashierName;
      active.dateClosed = new Date().toISOString();
      active.summary = {
        drawerNumber: active.drawerNumber || 1,
        totalSales,
        cashSales,
        cardSales,
        cashRefunds,
        expectedCash,
        discrepancy,
        transactionCount: shiftOrders.length
      };
      
      sqlDB.prepare(`
        UPDATE shifts SET 
          status = 'closed', closingCash = ?, closingDetails = ?, closingCashier = ?, dateClosed = ?, summary = ?, cloudSynced = 0
        WHERE id = ?
      `).run(
        active.closingCash,
        JSON.stringify(active.closingDetails),
        active.closingCashier,
        active.dateClosed,
        JSON.stringify(active.summary),
        active.id
      );
      return active;
    }
    return null;
  },

  getPendingCloudShifts: () => {
    try {
      const rows = sqlDB.prepare("SELECT * FROM shifts WHERE status = 'closed' AND (cloudSynced = 0 OR cloudSynced IS NULL)").all();
      return rows.map(r => ({
        ...r,
        details: JSON.parse(r.details || '{}'),
        closingDetails: JSON.parse(r.closingDetails || '{}'),
        summary: JSON.parse(r.summary || '{}')
      }));
    } catch (e) {
      console.error("Error fetching pending cloud shifts:", e);
      return [];
    }
  },

  markShiftCloudSynced: (shiftId) => {
    try {
      sqlDB.prepare("UPDATE shifts SET cloudSynced = 1 WHERE id = ?").run(shiftId);
    } catch (e) {
      console.error("Error marking shift cloud synced:", e);
    }
  },

  // Creates the default departments of any business type that was newly selected (never touches existing ones)
  applyBusinessTypePresets: (oldType, newType) => {
    const before = new Set(parseBusinessTypes(oldType));
    const added = parseBusinessTypes(newType).filter(t => !before.has(t));
    if (added.length === 0) return [];
    const existing = new Set(sqlDB.prepare('SELECT id FROM departments').all().map(r => r.id));
    let order = (sqlDB.prepare('SELECT COALESCE(MAX("order"), 0) AS m FROM departments').get().m || 0);
    const created = [];
    const ins = sqlDB.prepare('INSERT OR IGNORE INTO departments (id, name, "order") VALUES (?, ?, ?)');
    added.forEach(t => BUSINESS_TYPE_PRESETS[t].forEach(([id, name]) => {
      if (existing.has(id)) return;
      order += 1;
      ins.run(id, name, order);
      existing.add(id);
      created.push({ id, name, order });
    }));
    return created;
  },

  // --- DEPARTMENTS / CATEGORIES ---
  getDepartments: () => {
    const rows = sqlDB.prepare('SELECT * FROM departments ORDER BY "order" ASC').all();
    return rows;
  },
  saveDepartment: (dept) => {
    sqlDB.prepare('INSERT OR REPLACE INTO departments (id, name, "order") VALUES (?, ?, ?)')
      .run(dept.id, dept.name, dept.order || 0);
    return dept;
  },
  deleteDepartment: (id) => {
    const info = sqlDB.prepare('DELETE FROM departments WHERE id = ?').run(id);
    return info.changes > 0;
  },

  // --- WAITLIST / LOBBY QUEUE ---
  getWaitlist: () => {
    const rows = sqlDB.prepare('SELECT * FROM waitlist').all();
    return rows;
  },
  addToWaitlist: (entry) => {
    const exists = sqlDB.prepare('SELECT id FROM waitlist WHERE phone = ?').get(entry.phone);
    if (!exists) {
      sqlDB.prepare(`
        INSERT INTO waitlist (id, name, phone, partySize, status, dateAdded, orderType, hasCake, dedication, notes, lang)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        entry.id,
        entry.name,
        entry.phone,
        entry.partySize || 1,
        entry.status || 'waiting',
        entry.dateAdded,
        entry.orderType || 'cake',
        entry.hasCake ? 1 : 0,
        entry.dedication || '',
        entry.notes || '',
        entry.lang || 'en'
      );
    } else {
      sqlDB.prepare(`
        UPDATE waitlist SET name = ?, partySize = ?, orderType = ?, hasCake = ?, dedication = ?, notes = ?, lang = ?
        WHERE phone = ?
      `).run(
        entry.name,
        entry.partySize || 1,
        entry.orderType || 'cake',
        entry.hasCake ? 1 : 0,
        entry.dedication || '',
        entry.notes || '',
        entry.lang || 'en',
        entry.phone
      );
    }
    return database.getWaitlist();
  },
  removeFromWaitlist: (id) => {
    sqlDB.prepare('DELETE FROM waitlist WHERE id = ?').run(id);
    return database.getWaitlist();
  },
  
  // --- TABLES MAP LAYOUT ---
  getTables: () => {
    const row = sqlDB.prepare("SELECT value FROM key_value_store WHERE key = 'tables'").get();
    return row ? JSON.parse(row.value) : [];
  },
  saveTables: (tablesArray) => {
    sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('tables', ?)")
      .run(JSON.stringify(tablesArray));
    return tablesArray;
  },
  
  // --- TELEGRAM PHONE-CHAT MAPPING PERSISTENCE ---
  getTelegramPhoneMap: () => {
    try {
      const row = sqlDB.prepare("SELECT value FROM key_value_store WHERE key = 'telegram_phone_map'").get();
      return row ? JSON.parse(row.value) : {};
    } catch(e) {
      return {};
    }
  },
  saveTelegramPhoneMap: (map) => {
    try {
      sqlDB.prepare("INSERT OR REPLACE INTO key_value_store (key, value) VALUES ('telegram_phone_map', ?)")
        .run(JSON.stringify(map || {}));
    } catch(e) {
      console.error('[DB TELEGRAM MAP SAVE ERR]', e.message);
    }
    return map;
  },
  
  // --- FLOATING MOBILE WAITRESS SESSIONS (CONCURRENT BYOD) ---
  getActiveWaitressSessions: (maxInactivityMinutes = 45) => {
    try {
      const now = Date.now();
      const cutoff = new Date(now - (maxInactivityMinutes * 60 * 1000)).toISOString();
      sqlDB.prepare('DELETE FROM active_waitress_sessions WHERE last_activity < ?').run(cutoff);
      return sqlDB.prepare('SELECT * FROM active_waitress_sessions ORDER BY connected_at DESC').all();
    } catch(e) {
      console.error('[DB ACTIVE WAITRESS ERR]', e.message);
      return [];
    }
  },
  registerWaitressSession: (sessionId, deviceId, employeeId, employeeName, deviceName) => {
    try {
      const now = new Date().toISOString();
      sqlDB.prepare(`
        INSERT OR REPLACE INTO active_waitress_sessions 
        (session_id, device_id, employee_id, employee_name, device_name, connected_at, last_activity)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).run(sessionId, deviceId, employeeId, employeeName, deviceName || 'Smartphone', now, now);
      return true;
    } catch(e) {
      console.error('[DB REG WAITRESS ERR]', e.message);
      return false;
    }
  },
  touchWaitressSession: (sessionId) => {
    try {
      const now = new Date().toISOString();
      sqlDB.prepare('UPDATE active_waitress_sessions SET last_activity = ? WHERE session_id = ?').run(now, sessionId);
    } catch(e) {}
  },
  removeWaitressSession: (sessionId) => {
    try {
      sqlDB.prepare('DELETE FROM active_waitress_sessions WHERE session_id = ? OR employee_id = ?').run(sessionId, sessionId);
      return true;
    } catch(e) {
      return false;
    }
  },
  clearAllWaitressSessions: () => {
    try {
      sqlDB.prepare('DELETE FROM active_waitress_sessions').run();
      return true;
    } catch(e) {
      return false;
    }
  },
  
  // --- SINGLE MODIFIERS ---
  getSingleModifiers: () => {
    const rows = sqlDB.prepare('SELECT * FROM single_modifiers').all();
    return rows;
  },
  saveSingleModifier: (name, price, color = 'default') => {
    const trimmed = name.trim();
    const parsedPrice = parseFloat(price) || 0;
    if (trimmed) {
      sqlDB.prepare('REPLACE INTO single_modifiers (name, price, color) VALUES (?, ?, ?)').run(trimmed, parsedPrice, color);
    }
    return database.getSingleModifiers();
  },
  deleteSingleModifier: (name, price) => {
    const parsedPrice = parseFloat(price) || 0;
    sqlDB.prepare('DELETE FROM single_modifiers WHERE name = ? AND ABS(price - ?) < 0.001').run(name, parsedPrice);
    return database.getSingleModifiers();
  },

  // --- ALCOHOL INVENTORY SYSTEM ---
  getAlcoholProducts: () => {
    const rows = sqlDB.prepare('SELECT * FROM alcohol_products').all();
    return rows;
  },
  saveAlcoholProduct: (prod) => {
    if (!prod.id) {
      prod.id = 'alc_' + Date.now();
    }
    sqlDB.prepare(`
      INSERT OR REPLACE INTO alcohol_products (id, barcode, brand, model, fullWeight, emptyWeight, liquidOunces, shotSize, gramsPerOunce, currentVolumeOunces)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      prod.id,
      prod.barcode || '',
      prod.brand || '',
      prod.model || '',
      prod.fullWeight || 0,
      prod.emptyWeight || 0,
      prod.liquidOunces || 0,
      prod.shotSize || 0,
      prod.gramsPerOunce || 0,
      prod.currentVolumeOunces || 0
    );
    return prod;
  },
  deleteAlcoholProduct: (id) => {
    const info = sqlDB.prepare('DELETE FROM alcohol_products WHERE id = ?').run(id);
    return info.changes > 0;
  },
  deductAlcoholInventory: (items) => {
    if (!items || !Array.isArray(items)) return;
    sqlDB.transaction(() => {
      items.forEach(item => {
        if (!item) return;
        const alcId = item.alcoholId;
        if (!alcId) return;
        const alc = sqlDB.prepare('SELECT * FROM alcohol_products WHERE id = ?').get(alcId);
        if (!alc) return;
        
        const qty = parseFloat(item.quantity) || 1;
        const serveType = item.serveType || 'shot';
        
        if (serveType === 'bottle') {
          const curBottles = parseInt(alc.sealedBottleCount) || 0;
          const newBottles = Math.max(0, curBottles - qty);
          sqlDB.prepare('UPDATE alcohol_products SET sealedBottleCount = ? WHERE id = ?').run(newBottles, alcId);
        } else {
          let shotOz = parseFloat(alc.shotSize) || 1.5;
          if (item.isDouble || serveType === 'double') {
            shotOz = shotOz * 2;
          }
          const totalOzToDeduct = shotOz * qty;
          const curOz = parseFloat(alc.currentVolumeOunces) || 0;
          let newOz = curOz - totalOzToDeduct;
          let sealed = parseInt(alc.sealedBottleCount) || 0;
          const bottleCapOz = parseFloat(alc.liquidOunces) || 25.4;
          while (newOz < 0 && sealed > 0) {
            sealed--;
            newOz += bottleCapOz;
          }
          newOz = Math.max(0, newOz);
          sqlDB.prepare('UPDATE alcohol_products SET currentVolumeOunces = ?, sealedBottleCount = ? WHERE id = ?')
            .run(newOz, sealed, alcId);
        }
      });
    })();
  },
  
  getActiveBartenderShift: () => {
    const row = sqlDB.prepare("SELECT * FROM bartender_shifts WHERE status = 'open'").get();
    if (row) {
      return {
        ...row,
        inventory: JSON.parse(row.inventory || '[]')
      };
    }
    return null;
  },
  startBartenderShift: (bartenderName, inventory) => {
    sqlDB.prepare("UPDATE bartender_shifts SET status = 'closed' WHERE status = 'open'").run();
    
    const shift = {
      id: 'bs_' + Date.now(),
      bartenderName,
      status: 'open',
      dateStarted: new Date().toISOString(),
      dateEnded: null,
      inventory: inventory.map(item => {
        const netWeight = item.startWeight - item.emptyWeight;
        const startOunces = netWeight > 0 ? (netWeight / item.gramsPerOunce) : 0;
        const scannedWeight = item.scannedWeight !== undefined ? item.scannedWeight : null;
        let startDiscrepancyOunces = 0;
        if (scannedWeight !== null) {
          startDiscrepancyOunces = (scannedWeight - item.startWeight) / item.gramsPerOunce;
        }
        return {
          ...item,
          startOunces,
          scannedWeight,
          startDiscrepancyOunces,
          soldOunces: 0,
          expectedEndOunces: startOunces,
          endWeight: 0,
          endOunces: 0,
          discrepancyOunces: 0
        };
      })
    };
    
    sqlDB.prepare(`
      INSERT INTO bartender_shifts (id, status, dateStarted, dateEnded, bartenderName, startDiscrepancyOunces, expectedEndOunces, soldOunces, endWeight, endOunces, discrepancyOunces, inventory)
      VALUES (?, 'open', ?, ?, ?, 0, 0, 0, 0, 0, 0, ?)
    `).run(
      shift.id,
      shift.dateStarted,
      '',
      shift.bartenderName,
      JSON.stringify(shift.inventory)
    );
    return shift;
  },
  closeBartenderShift: (inventoryData) => {
    const active = database.getActiveBartenderShift();
    if (!active) return null;
    
    active.status = 'closed';
    active.dateEnded = new Date().toISOString();
    
    const orders = database.getOrders();
    const shiftOrders = orders.filter(o => {
      if (o.status === 'void' || o.status === 'refunded') return false;
      const orderTime = new Date(o.dateCreated).getTime();
      const startTime = new Date(active.dateStarted).getTime();
      const endTime = new Date(active.dateEnded).getTime();
      return orderTime >= startTime && orderTime <= endTime;
    });
    
    active.inventory.forEach(item => {
      let totalSoldUnits = 0;
      
      shiftOrders.forEach(order => {
        order.items.forEach(orderItem => {
          const nameLower = orderItem.name.toLowerCase();
          const brandLower = item.brand.toLowerCase();
          const modelLower = item.model.toLowerCase();
          
          if (nameLower.includes(brandLower) && nameLower.includes(modelLower)) {
            totalSoldUnits += orderItem.quantity;
          }
        });
      });
      
      const soldOunces = totalSoldUnits * item.shotSize;
      item.soldOunces = soldOunces;
      item.expectedEndOunces = Math.max(0, item.startOunces - soldOunces);
      
      const input = inventoryData.find(inv => inv.id === item.id);
      if (input) {
        item.endWeight = input.endWeight || 0;
        const netEndWeight = item.endWeight - item.emptyWeight;
        item.endOunces = netEndWeight > 0 ? (netEndWeight / item.gramsPerOunce) : 0;
        
        const physicalConsumption = Math.max(0, item.startOunces - item.endOunces);
        item.discrepancyOunces = physicalConsumption - soldOunces;
      }
      
      sqlDB.prepare('UPDATE alcohol_products SET currentVolumeOunces = ? WHERE id = ?')
        .run(item.endOunces, item.id);
    });
    
    sqlDB.prepare(`
      UPDATE bartender_shifts SET
        status = 'closed', dateEnded = ?, inventory = ?
      WHERE id = ?
    `).run(
      active.dateEnded,
      JSON.stringify(active.inventory),
      active.id
    );
    return active;
  },
  getBartenderShifts: () => {
    const rows = sqlDB.prepare('SELECT * FROM bartender_shifts').all();
    return rows.map(r => ({
      ...r,
      inventory: JSON.parse(r.inventory || '[]')
    }));
  },
  deductStockForOrder: (order) => {
    if (!order || !order.items || !Array.isArray(order.items)) return;
    sqlDB.transaction(() => {
      order.items.forEach(item => {
        const cleanProductId = item.id.split('_c')[0];
        const prod = sqlDB.prepare('SELECT trackStock, stockQuantity FROM products WHERE id = ?').get(cleanProductId);
        if (prod && prod.trackStock !== 0) {
          const qty = parseFloat(item.quantity) || 1;
          const newQty = prod.stockQuantity - qty;
          sqlDB.prepare('UPDATE products SET stockQuantity = ? WHERE id = ?').run(newQty, cleanProductId);
        }
      });
    })();
  },
  restoreStockForOrder: (order) => {
    if (!order || !order.items || !Array.isArray(order.items)) return;
    sqlDB.transaction(() => {
      order.items.forEach(item => {
        const cleanProductId = item.id.split('_c')[0];
        const prod = sqlDB.prepare('SELECT trackStock, stockQuantity FROM products WHERE id = ?').get(cleanProductId);
        if (prod && prod.trackStock !== 0) {
          const qty = parseFloat(item.quantity) || 1;
          const newQty = prod.stockQuantity + qty;
          sqlDB.prepare('UPDATE products SET stockQuantity = ? WHERE id = ?').run(newQty, cleanProductId);
        }
      });
    })();
  },
  getReservations: () => {
    return sqlDB.prepare('SELECT * FROM reservations ORDER BY dateTime ASC').all();
  },
  saveReservation: (resObj) => {
    sqlDB.prepare(`
      INSERT OR REPLACE INTO reservations (id, customerName, customerPhone, dateTime, pax, tableNum, status, source, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      resObj.id,
      resObj.customerName,
      resObj.customerPhone,
      resObj.dateTime,
      resObj.pax || 1,
      resObj.tableNum || '',
      resObj.status || 'pending',
      resObj.source || 'local',
      resObj.createdAt || new Date().toISOString()
    );
    return resObj;
  },
  updateReservationStatus: (id, status) => {
    sqlDB.prepare('UPDATE reservations SET status = ? WHERE id = ?').run(status, id);
    return sqlDB.prepare('SELECT * FROM reservations WHERE id = ?').get(id);
  },
  assignReservationTable: (id, tableNum) => {
    sqlDB.prepare('UPDATE reservations SET tableNum = ? WHERE id = ?').run(tableNum, id);
    return sqlDB.prepare('SELECT * FROM reservations WHERE id = ?').get(id);
  },
  loadDatabase: () => {
    return {
      orders: database.getOrders(),
      employees: database.getEmployees(),
      products: database.getProducts(),
      loyalty: sqlDB.prepare('SELECT * FROM loyalty').all().map(r => ({
        ...r,
        points: parseInt(r.points) || 0
      }))
    };
  },
  saveDatabase: (db) => {
    if (db && db.orders && Array.isArray(db.orders)) {
      sqlDB.transaction(() => {
        db.orders.forEach(order => {
          const existing = sqlDB.prepare('SELECT id FROM orders WHERE id = ?').get(order.id);
          if (existing) {
            sqlDB.prepare(`
              UPDATE orders SET 
                status = ?, paymentStatus = ?, cashierName = ?, clientName = ?, clientPhone = ?, 
                deliveryType = ?, tableNumber = ?, guestCount = ?, activeSeat = ?, items = ?, 
                subtotal = ?, tax = ?, total = ?, cardTip = ?, courtesyApprovedBy = ?, notes = ?, 
                crossBillDetails = ?, paymentMethod = ?, datePaid = ?, splitDetails = ?, 
                dateRefunded = ?, voidReason = ?, voidAuthorizedBy = ?, dateVoided = ?, 
                refundReason = ?, refundAuthorizedBy = ?, shelfLocation = ?, locationLoggedBy = ?, 
                locationLoggedAt = ?, courtesyApprovedReason = ?
              WHERE id = ?
            `).run(
              order.status,
              order.paymentStatus,
              order.cashierName,
              order.clientName,
              order.clientPhone,
              order.deliveryType,
              order.tableNumber,
              order.guestCount,
              order.activeSeat,
              JSON.stringify(order.items),
              order.subtotal,
              order.tax,
              order.total,
              order.cardTip,
              order.courtesyApprovedBy,
              order.notes,
              JSON.stringify(order.crossBillDetails || {}),
              order.paymentMethod,
              order.datePaid,
              JSON.stringify(order.splitDetails || {}),
              order.dateRefunded,
              order.voidReason,
              order.voidAuthorizedBy,
              order.dateVoided,
              order.refundReason,
              order.refundAuthorizedBy,
              order.shelfLocation,
              order.locationLoggedBy,
              order.locationLoggedAt,
              order.courtesyApprovedReason,
              order.id
            );
          }
        });
      })();
    }
  },

  // --- CLOUD SYNC QUEUE HELPERS ---
  enqueueCloudSync: (payloadType, payloadData) => {
    try {
      const now = new Date().toISOString();
      const json = typeof payloadData === 'string' ? payloadData : JSON.stringify(payloadData);
      const info = sqlDB.prepare(`
        INSERT INTO cloud_sync_queue (payloadType, payloadJson, createdAt, attempts)
        VALUES (?, ?, ?, 0)
      `).run(payloadType, json, now);
      return info.lastInsertRowid;
    } catch (err) {
      console.error('Error enqueuing cloud sync payload:', err);
      return null;
    }
  },

  getPendingCloudSyncQueue: (limit = 50) => {
    try {
      return sqlDB.prepare('SELECT * FROM cloud_sync_queue ORDER BY id ASC LIMIT ?').all(limit);
    } catch (err) {
      return [];
    }
  },

  removeCloudSyncQueueItems: (ids) => {
    if (!ids || ids.length === 0) return;
    try {
      const placeholders = ids.map(() => '?').join(',');
      sqlDB.prepare(`DELETE FROM cloud_sync_queue WHERE id IN (${placeholders})`).run(...ids);
    } catch (err) {
      console.error('Error removing cloud sync queue items:', err);
    }
  },

  getCloudSyncQueueCount: () => {
    try {
      const row = sqlDB.prepare('SELECT count(*) as c FROM cloud_sync_queue').get();
      return row ? row.c : 0;
    } catch (err) {
      return 0;
    }
  },

  logIncomingCall: (callData) => {
    try {
      const stmt = sqlDB.prepare(`
        INSERT INTO call_logs (phone, customerName, customerAddress, points, isRegistered, status, orderId, timestamp)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const ts = callData.timestamp || new Date().toISOString();
      const info = stmt.run(
        callData.phone,
        callData.name || callData.customerName || 'Unknown',
        callData.address || callData.customerAddress || '',
        callData.points || 0,
        callData.isRegistered ? 1 : 0,
        callData.status || 'received',
        callData.orderId || null,
        ts
      );
      return { id: info.lastInsertRowid, ...callData, timestamp: ts };
    } catch (err) {
      console.error('Error logging incoming call:', err);
      return null;
    }
  },

  getCallLogs: ({ date, startDate, endDate, limit = 300 } = {}) => {
    try {
      if (date) {
        return sqlDB.prepare(`SELECT * FROM call_logs WHERE date(timestamp) = date(?) ORDER BY timestamp DESC LIMIT ?`).all(date, limit);
      }
      if (startDate && endDate) {
        return sqlDB.prepare(`SELECT * FROM call_logs WHERE timestamp >= ? AND timestamp <= ? ORDER BY timestamp DESC LIMIT ?`).all(startDate, endDate, limit);
      }
      return sqlDB.prepare(`SELECT * FROM call_logs ORDER BY timestamp DESC LIMIT ?`).all(limit);
    } catch (err) {
      console.error('Error fetching call logs:', err);
      return [];
    }
  },

  updateCallLogStatus: (phone, status, orderId = null) => {
    try {
      if (orderId) {
        sqlDB.prepare(`UPDATE call_logs SET status = ?, orderId = ? WHERE phone = ? ORDER BY id DESC LIMIT 1`).run(status, orderId, phone);
      } else {
        sqlDB.prepare(`UPDATE call_logs SET status = ? WHERE phone = ? ORDER BY id DESC LIMIT 1`).run(status, phone);
      }
    } catch (err) {
      console.error('Error updating call log status:', err);
    }
  },

  getLastOrderByCustomer: (identifier) => {
    if (!identifier) return null;
    try {
      const cleanPhone = String(identifier).replace(/\D/g, '');
      let row = null;
      if (cleanPhone.length >= 7) {
        row = sqlDB.prepare(`
          SELECT id, ticketNumber, ticketDisplay, clientName, clientPhone, items, subtotal, tax, total, dateCreated, datePaid, status
          FROM orders 
          WHERE (REPLACE(REPLACE(REPLACE(REPLACE(clientPhone, '-', ''), ' ', ''), '(', ''), ')', '') LIKE ? OR clientPhone LIKE ?)
            AND status NOT IN ('void', 'cancelled')
          ORDER BY dateCreated DESC LIMIT 1
        `).get(`%${cleanPhone}%`, `%${cleanPhone}%`);
      }
      if (!row && String(identifier).trim().length >= 2) {
        row = sqlDB.prepare(`
          SELECT id, ticketNumber, ticketDisplay, clientName, clientPhone, items, subtotal, tax, total, dateCreated, datePaid, status
          FROM orders 
          WHERE LOWER(clientName) = LOWER(?) AND status NOT IN ('void', 'cancelled')
          ORDER BY dateCreated DESC LIMIT 1
        `).get(String(identifier).trim());
      }
      if (row) {
        try {
          row.items = JSON.parse(row.items || '[]');
        } catch (e) {
          row.items = [];
        }
      }
      return row;
    } catch (err) {
      console.error('Error in getLastOrderByCustomer:', err);
      return null;
    }
  },

  savePinAuditLog: (log) => {
    try {
      const stmt = db.prepare(`
        INSERT INTO pin_audit_logs (
          createdAt, actorName, actorRole, targetEmployeeId, targetEmployeeName, targetEmployeeRole, actionResult, method, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const info = stmt.run(
        log.createdAt || new Date().toISOString(),
        log.actorName || 'Unknown',
        log.actorRole || 'staff',
        log.targetEmployeeId || '',
        log.targetEmployeeName || '',
        log.targetEmployeeRole || '',
        log.actionResult || 'REVEALED',
        log.method || 'DIRECT',
        log.notes || ''
      );
      return { success: true, id: info.lastInsertRowid };
    } catch (err) {
      console.error('Error in savePinAuditLog:', err);
      return { success: false, error: err.message };
    }
  },

  getPinAuditLogs: (filters = {}) => {
    try {
      let query = `SELECT * FROM pin_audit_logs WHERE 1=1`;
      const params = [];

      // Role isolation:
      // Manager role strictly filters out any logs involving the Admin account
      if (filters.role === 'manager') {
        query += ` AND LOWER(actorRole) != 'admin' AND LOWER(targetEmployeeRole) != 'admin'`;
      }

      if (filters.startDate) {
        query += ` AND createdAt >= ?`;
        params.push(filters.startDate);
      }
      if (filters.endDate) {
        query += ` AND createdAt <= ?`;
        params.push(filters.endDate);
      }
      if (filters.actionResult) {
        query += ` AND actionResult = ?`;
        params.push(filters.actionResult);
      }

      query += ` ORDER BY id DESC LIMIT ?`;
      params.push(filters.limit || 500);

      return db.prepare(query).all(...params);
    } catch (err) {
      console.error('Error in getPinAuditLogs:', err);
      return [];
    }
  }
};

module.exports = database;



