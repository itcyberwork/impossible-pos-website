@echo off
setlocal EnableDelayedExpansion
title Install All Kiosk Stations - Impossible POS
color 0E

echo ======================================================================
echo   IMPOSSIBLE POS - INSTALL ALL STATIONS ON THE DESKTOP
echo ======================================================================
echo.
echo This wizard installs the desktop shortcuts for every station
echo (Kitchen, Bakery, Bar, Photo Hub, Lobby TV, Runner, Hostess, Secondary Register).
echo.
pause

call "%~dp01_INSTALL_KITCHEN_KDS.bat"
call "%~dp02_INSTALL_BAKERY_SPECIAL_ORDERS.bat"
call "%~dp03_INSTALL_BAR_KDS.bat"
call "%~dp04_INSTALL_PHOTO_HUB.bat"
call "%~dp05_INSTALL_LOBBY_TV.bat"
call "%~dp06_INSTALL_RUNNER.bat"
call "%~dp07_INSTALL_HOSTESS.bat"
call "%~dp08_INSTALL_SECONDARY_REGISTER.bat"

echo.
echo ======================================================================
echo   ALL STATIONS WERE INSTALLED SUCCESSFULLY ON YOUR DESKTOP!
echo ======================================================================
pause

if exist "%USERPROFILE%\Desktop\Google Chrome.lnk" del /f /q "%USERPROFILE%\Desktop\Google Chrome.lnk" >nul 2>&1
if exist "%PUBLIC%\Desktop\Google Chrome.lnk" del /f /q "%PUBLIC%\Desktop\Google Chrome.lnk" >nul 2>&1
