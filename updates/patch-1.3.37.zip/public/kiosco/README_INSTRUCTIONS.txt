======================================================================
IMPOSSIBLE POS - HARDWARE STATIONS AND DISPLAY SETUP
======================================================================

This folder provides all tools to connect kitchen displays (KDS), bar screens,
lobby TVs, customer self-ordering kiosks, and thermal printers to your
Central Cash Register Server.

METHOD 1: UNIVERSAL HARDWARE SETUP (RECOMMENDED)
----------------------------------------------------------------------
Simply run:
   Impossible_POS_Hardware_Setup.bat

It presents a clean, numbered menu where you pick your station:
   [1]  Kitchen Display 1 (Hot Food / Grill KDS)
   [2]  Kitchen Display 2 (Cold Prep / Bakery KDS)
   [3]  Bar Display (Cocktails & Beverages KDS)
   [4]  Special Orders Display (Custom Cakes & Catering)
   [5]  Photo Hub (Cake & Custom Order Photos)
   [6]  Lobby TV (Customer Queue & Waitlist Display)
   [7]  Runner Hub (Order Expediter & Dispatch)
   [8]  Hostess Hub (Table Seating & Reception)
   [9]  Self-Ordering Kiosk (Customer Ordering Station)
   [10] Secondary Register (Cashier POS Terminal 2)
   [11] Setup Thermal Printers and Cash Drawer Service
   [12] Smart Screen Pairing (4-Digit Code)
   [13] Install All Station Shortcuts

The setup script automatically:
1. Discovers the Central Register Server on your local network (<20ms).
2. Configures the official Windows Desktop shortcut with high-resolution icon.
3. Optionally enables auto-boot on computer startup.
4. Launches the display immediately in full-screen industrial Kiosk mode.

METHOD 2: SMART TV / 4-DIGIT CODE SCREEN PAIRING
----------------------------------------------------------------------
If you are using a tablet or smart monitor:
1. Open Google Chrome or Microsoft Edge on the screen.
2. Navigate to: http://[SERVER_IP]:3000/pair.html
3. The screen displays a 4-digit code (e.g. 7421).
4. On your Main Cash Register, an instant notification appears:
   "New Screen Detected (Code: 7421). Accept & Connect?"
5. Tap "Accept and Connect". The screen unlocks instantly and opens full-screen.

METHOD 3: INDIVIDUAL INSTALLER SCRIPTS
----------------------------------------------------------------------
You can also run specific scripts directly:
   - 1_INSTALL_KITCHEN_KDS.bat            -> Main Kitchen Display
   - 2_INSTALL_BAKERY_SPECIAL_ORDERS.bat  -> Bakery & Special Orders Kitchen
   - 3_INSTALL_BAR_KDS.bat                -> Bar & Drinks Display
   - 4_INSTALL_PHOTO_HUB.bat              -> Photo Viewer
   - 5_INSTALL_LOBBY_TV.bat               -> Customer Queue / Waiting Display
   - 6_INSTALL_RUNNER.bat                 -> Order Dispatch Display
   - 7_INSTALL_HOSTESS.bat                -> Reception & Table Floor Plan
   - 8_INSTALL_SECONDARY_REGISTER.bat     -> Secondary Checkout Terminal
   - 9_INSTALL_ALL_STATIONS.bat           -> Installs all station shortcuts

NETWORK SELF-HEALING:
All station launchers include automatic UDP DHCP self-discovery.
Even if your internet provider or router reassigns IP addresses, all screens
automatically locate and reconnect to the Central Server without any manual
configuration.
======================================================================
