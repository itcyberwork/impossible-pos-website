const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let barProductsCache = {};

async function fetchBarProducts() {
  try {
    const res = await fetch(`${SERVER_URL}/api/products`);
    if (res.ok) {
      const prods = await res.json();
      if (Array.isArray(prods)) {
        barProductsCache = {};
        prods.forEach(p => {
          if (p && p.id) barProductsCache[p.id] = p;
        });
      }
    }
  } catch(e) {}
}
fetchBarProducts();
setInterval(fetchBarProducts, 30000);

let currentPage = 0;
let showPastOrders = false;
let activeWebSocket = null;
let selectedCardKey = '1';
let kdsNumpadBuffer = '';
let kdsBufferTimer = null;

document.addEventListener('DOMContentLoaded', async () => {
  await checkBarKdsLicense();
  initWebSocket();
  loadOrders();
  setupEventListeners();
  announceStationOnline();
});

async function announceStationOnline() {
  try {
    await fetch(`${SERVER_URL}/api/stations/announce`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ station: 'bar', name: 'Bar KDS' })
    });
  } catch (e) {}
}

async function checkBarKdsLicense() {
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/status`);
    if (res.ok) {
      return true;
    }
  } catch (e) {
    console.warn("License check bypassed:", e);
  }
  return true;
}

async function loadOrders() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      orders = await res.json();
      renderKDS();
    } else {
      setTimeout(loadOrders, 2000);
    }
  } catch (err) {
    console.error("Failed to load orders:", err);
    setTimeout(loadOrders, 2000);
  }
}

function initWebSocket() {
  try {
    activeWebSocket = new WebSocket(WS_URL);
    activeWebSocket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        const t = (msg.type || '').toUpperCase();
        if (t === 'NEW_ORDER' || t === 'ORDER_UPDATED' || t === 'DELIVERY_ORDER_ARRIVED' || t === 'ORDERS_UPDATED') {
          playAlertSound();
          loadOrders();
        }
      } catch (e) {
        console.error("WS parse error:", e);
      }
    };
    activeWebSocket.onclose = () => {
      setTimeout(initWebSocket, 5000);
    };
  } catch (e) {
    console.error("WS init error:", e);
    setTimeout(initWebSocket, 5000);
  }
}

function playAlertSound() {
  try {
    const audio = new Audio('/icons/bell.mp3');
    audio.play().catch(() => {});
  } catch (e) {}
}

function setupEventListeners() {
  const btnActive = document.getElementById('btnActiveOrders');
  if (btnActive) {
    btnActive.addEventListener('click', () => {
      showPastOrders = false;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPast = document.getElementById('btnPastOrders');
  if (btnPast) {
    btnPast.addEventListener('click', () => {
      showPastOrders = true;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPrev = document.getElementById('btnKdsScrollBack');
  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      if (currentPage > 0) {
        currentPage--;
        renderKDS();
      }
    });
  }

  const btnNext = document.getElementById('btnKdsScrollNext');
  if (btnNext) {
    btnNext.addEventListener('click', () => {
      const activeOrders = getFilteredOrders();
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderKDS();
      }
    });
  }

  // Keyboard controls for USB Numpad and Bump Bar
  window.addEventListener('keydown', (e) => {
    let key = e.key;

    // Normalize Numpad codes
    if (e.code && e.code.startsWith('Numpad')) {
      const numMatch = e.code.match(/Numpad([0-9])/);
      if (numMatch) key = numMatch[1];
      else if (e.code === 'NumpadDecimal') key = 'Delete';
      else if (e.code === 'NumpadEnter') key = 'Enter';
      else if (e.code === 'NumpadMultiply') key = '*';
      else if (e.code === 'NumpadAdd') key = '+';
      else if (e.code === 'NumpadSubtract') key = '-';
    }

    // Modal navigation
    const modal = document.getElementById('modalWorkSheetPreview');
    const isModalOpen = modal && modal.style.display === 'flex';

    if (key === 'Escape' || (isModalOpen && key === 'Backspace')) {
      if (isModalOpen) {
        e.preventDefault();
        closeWorkSheetModal();
        return;
      }
    }

    if (key === 'Enter') {
      e.preventDefault();
      if (isModalOpen) {
        closeWorkSheetModal();
        return;
      }
      const selectedCard = document.querySelector('.kds-card.selected-kds-card') || document.querySelector('.kds-card');
      if (selectedCard) {
        const orderId = selectedCard.getAttribute('data-order-id');
        if (orderId) openWorkSheetModal(orderId);
      }
      return;
    }

    if (key === '*') {
      e.preventDefault();
      const selectedCard = document.querySelector('.kds-card.selected-kds-card') || document.querySelector('.kds-card');
      if (selectedCard) {
        const orderId = selectedCard.getAttribute('data-order-id');
        if (orderId) printBarTicket(orderId);
      }
      return;
    }

    // 1. Numeric keys 0-9: Select card and buffer ticket number
    if (key >= '0' && key <= '9') {
      e.preventDefault();
      if (kdsBufferTimer) clearTimeout(kdsBufferTimer);
      kdsNumpadBuffer += key;

      if (kdsNumpadBuffer.length === 1) {
        selectCardByKey(key === '0' ? '10' : key);
      } else {
        // Multi-digit ticket number matching
        const cards = Array.from(document.querySelectorAll('.kds-card'));
        const matched = cards.find(c => {
          const tNum = c.getAttribute('data-ticket-number') || '';
          return tNum === kdsNumpadBuffer || (c.innerText || '').includes('#' + kdsNumpadBuffer);
        });
        if (matched) {
          cards.forEach(c => c.classList.remove('selected-kds-card'));
          matched.classList.add('selected-kds-card');
          selectedCardKey = matched.getAttribute('data-bump-key') || '1';
          matched.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }

      kdsBufferTimer = setTimeout(() => {
        kdsNumpadBuffer = '';
      }, 2500);
      return;
    }

    // 2. Delete or Decimal (.): Bump order
    if (key === 'Delete' || key === '.') {
      e.preventDefault();
      if (kdsNumpadBuffer && kdsNumpadBuffer.length > 0) {
        const target = kdsNumpadBuffer;
        kdsNumpadBuffer = '';
        if (kdsBufferTimer) clearTimeout(kdsBufferTimer);
        bumpOrder(target);
        return;
      }
      const selectedCard = document.querySelector('.kds-card.selected-kds-card') || document.querySelector('.kds-card');
      if (selectedCard) {
        const orderId = selectedCard.getAttribute('data-order-id');
        if (orderId) bumpOrder(orderId);
      }
      return;
    }

    // 3. Tab: Switch page or toggle Active/Past
    if (key === 'Tab') {
      e.preventDefault();
      const activeOrders = getFilteredOrders();
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderKDS();
      } else {
        showPastOrders = !showPastOrders;
        currentPage = 0;
        renderKDS();
      }
      return;
    }

    // 4. + / - : Next / Previous card
    if (key === '+') {
      e.preventDefault();
      selectNextCard();
      return;
    }
    if (key === '-') {
      e.preventDefault();
      selectPrevCard();
      return;
    }
  });

  const btnKiosk = document.getElementById('btnDownloadKioskDirect');
  if (btnKiosk) {
    btnKiosk.onclick = (e) => {
      e.preventDefault();
      downloadKioskShortcutBar();
    };
  }
}

function selectCardByKey(numStr) {
  selectedCardKey = String(numStr);
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  let found = false;
  cards.forEach(c => {
    if (c.getAttribute('data-bump-key') === selectedCardKey) {
      c.classList.add('selected-kds-card');
      c.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      found = true;
    } else {
      c.classList.remove('selected-kds-card');
    }
  });
  if (!found && cards.length > 0) {
    cards[0].classList.add('selected-kds-card');
    selectedCardKey = cards[0].getAttribute('data-bump-key') || '1';
  }
}

function selectNextCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  if (cards.length === 0) return;
  const idx = cards.findIndex(c => c.classList.contains('selected-kds-card'));
  if (idx >= 0 && idx < cards.length - 1) {
    selectCardByKey(cards[idx + 1].getAttribute('data-bump-key'));
  } else {
    selectCardByKey(cards[0].getAttribute('data-bump-key'));
  }
}

function selectPrevCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  if (cards.length === 0) return;
  const idx = cards.findIndex(c => c.classList.contains('selected-kds-card'));
  if (idx > 0) {
    selectCardByKey(cards[idx - 1].getAttribute('data-bump-key'));
  } else {
    selectCardByKey(cards[cards.length - 1].getAttribute('data-bump-key'));
  }
}

function cleanDrinkName(name) {
  if (!name) return 'Drink';
  return name
    .replace(/\[\s*(?:DOBLE|DOUBLE)\s*\]\s*/gi, '')
    .replace(/\s*\((?:Double|Doble|2X)\)/gi, '')
    .trim();
}

function isBarDrinkItem(item) {
  if (!item) return false;
  if (item.isDrink === true || item.sendToBar === true) return true;
  
  // Lookup product definition in cache
  if (item.id && barProductsCache[item.id]) {
    const prod = barProductsCache[item.id];
    const pCat = (prod.category || '').toLowerCase();
    const pDept = (prod.department || prod.dept || '').toLowerCase();
    if (['liquor', 'licor', 'drinks', 'bebidas', 'bar', 'beer', 'cerveza', 'wine', 'vino'].includes(pCat)) return true;
    if (['bar', 'drinks', 'bebidas'].includes(pDept)) return true;
  }
  
  const text = `${item.department || ''} ${item.dept || ''} ${item.category || ''} ${item.subCategory || ''} ${item.name || ''}`.toLowerCase();
  
  const drinkKeywords = [
    'bebida', 'drink', 'bar', 'beer', 'cerveza', 'wine', 'vino', 'liquor', 'licor',
    'cocktail', 'coctel', 'cocteleria', 'alcohol', 'beverage', 'refresco', 'soda',
    'trago', 'tequila', 'vodka', 'whiskey', 'whisky', 'rum', 'ron', 'jugo', 'juice', 'water',
    'agua', 'te', 'tea', 'cafe', 'coffee', 'latte', 'cappuccino', 'espresso', 'bottle',
    'botella', 'can', 'lata', 'draft', 'tap', 'corona', 'bud light', 'heineken',
    'michelob', 'modelo', 'pacifico', 'victoria', 'stella', 'guinness', 'coca', 'sprite',
    'fanta', 'jarrito', 'topo chico', 'mineral',
    'remy', 'martin', 'vsop', 'cognac', 'brandy', 'hennessy', 'don julio', 'patron',
    'casamigos', 'herradura', '1800', 'cazadores', 'jimador', 'buchanan', 'black label',
    'red label', 'chivas', 'jameson', 'jack daniel', 'crown royal', 'grey goose',
    'tito', 'absolut', 'smirnoff', 'bacardi', 'captain morgan', 'malibu', 'baileys',
    'kahlua', 'jagermeister', 'fireball', 'bourbon', 'scotch', 'gin', 'mezcal',
    'shot', 'copa', 'cordial', 'liqueur', 'spirit'
  ];

  return drinkKeywords.some(kw => text.includes(kw));
}

function getFilteredOrders() {
  return orders.filter(o => {
    if (o.status === 'void' || o.status === 'refunded' || o.status === 'cancelado') return false;
    
    // Filter out parent orders if their items are dispatched as separate child round tickets
    const hasChildRounds = orders.some(child => child.parentOrderId === o.id);
    if (hasChildRounds) return false;

    // Filter orders containing bar drinks
    const hasDrinks = o.items && o.items.some(item => (item.quantity > 0 || (item.sentQuantity || 0) > 0) && isBarDrinkItem(item));
    if (!hasDrinks) return false;

    const isDone = o.barPrepared === true || o.status === 'listo' || o.status === 'completado' || o.status === 'entregado';
    if (showPastOrders) {
      return isDone;
    } else {
      return !isDone;
    }
  }).sort((a, b) => new Date(b.dateCreated || b.dateUpdated || 0) - new Date(a.dateCreated || a.dateUpdated || 0));
}

function renderKDS() {
  const container = document.getElementById('kdsContainer');
  if (!container) return;
  container.innerHTML = '';

  const btnActive = document.getElementById('btnActiveOrders');
  const btnPast = document.getElementById('btnPastOrders');
  if (btnActive && btnPast) {
    if (showPastOrders) {
      btnPast.style.backgroundColor = 'var(--accent-color)';
      btnPast.style.color = '#000';
      btnActive.style.backgroundColor = 'var(--bg-tertiary)';
      btnActive.style.color = '#fff';
    } else {
      btnActive.style.backgroundColor = 'var(--accent-color)';
      btnActive.style.color = '#000';
      btnPast.style.backgroundColor = 'var(--bg-tertiary)';
      btnPast.style.color = '#fff';
    }
  }

  const activeOrders = getFilteredOrders();

  if (activeOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">${showPastOrders ? 'No past drinks' : 'No drinks in queue'}</div>`;
    const lblPage = document.getElementById('lblKdsPageIndicator');
    if (lblPage) lblPage.innerText = `Page 1 of 1`;
    return;
  }

  const totalCount = activeOrders.length;
  const maxPage = Math.max(0, Math.ceil(totalCount / 20) - 1);
  if (currentPage > maxPage) currentPage = maxPage;

  const lblPage = document.getElementById('lblKdsPageIndicator');
  if (lblPage) lblPage.innerText = `Page ${currentPage + 1} of ${maxPage + 1}`;

  const startIndex = currentPage * 20;
  const pageOrders = activeOrders.slice(startIndex, startIndex + 20);

  pageOrders.forEach((o, index) => {
    const card = document.createElement('div');
    card.className = `kds-card type-${(o.type || 'comer').toLowerCase()}`;
    card.setAttribute('data-order-id', o.id);
    card.setAttribute('data-ticket-number', String(o.ticketNumber || o.ticketDisplay || ''));
    const bumpKey = String(index + 1);
    card.setAttribute('data-bump-key', bumpKey);

    if (bumpKey === selectedCardKey || (!selectedCardKey && index === 0)) {
      card.classList.add('selected-kds-card');
      selectedCardKey = bumpKey;
    }
    
    const minsOld = Math.floor((Date.now() - new Date(o.dateCreated).getTime()) / 60000);
    if (minsOld >= 5 && !showPastOrders) {
      card.classList.add('priority');
    }

    const elapsedText = showPastOrders ? 'DONE' : `${minsOld}m`;
    const bumpNumber = index + 1;

    let itemsHtml = '';
    (o.items || []).forEach(item => {
      if (isBarDrinkItem(item)) {
        let modText = '';
        if (item.selectedModifiers && item.selectedModifiers.length > 0) {
          modText = `<div class="kds-item-specs">(${item.selectedModifiers.map(m=>m.name).join(', ')})</div>`;
        }
        const isDouble = !!(item.isDouble || (item.name && (item.name.includes('DOBLE') || item.name.includes('DOUBLE'))));
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            ${isDouble ? '<span style="background: #af52de; color: #fff; font-size: 11px; font-weight: 900; padding: 2px 6px; border-radius: 4px; margin-right: 4px; letter-spacing: 0.5px;">DOBLE</span>' : ''}<span class="kds-item-name">${cleanDrinkName(item.name)}</span>
            ${modText}
          </div>
        `;
      }
    });

    // If order has no specific drink items flagged, show all items
    if (!itemsHtml) {
      (o.items || []).forEach(item => {
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            <span class="kds-item-name">${cleanDrinkName(item.name)}</span>
          </div>
        `;
      });
    }

    // Clean Table and Customer header formatting
    let tableText = 'Walk In';
    if (o.tableNumber && String(o.tableNumber).trim() && String(o.tableNumber).toLowerCase() !== 'walk in') {
      tableText = `Table ${o.tableNumber}`;
    } else if (o.tableName && String(o.tableName).trim() && String(o.tableName).toLowerCase() !== 'walk in') {
      tableText = o.tableName;
    } else {
      const delType = (o.deliveryType || o.type || 'walkin').toLowerCase();
      if (delType === 'llevar' || delType === 'togo') tableText = 'To Go';
      else if (delType === 'delivery') tableText = 'Delivery';
      else tableText = 'Walk In';
    }

    let customerHtml = '';
    if (o.clientName && String(o.clientName).trim() && String(o.clientName).toLowerCase() !== 'walk in' && String(o.clientName) !== String(o.tableNumber)) {
      customerHtml = `<div><strong>Customer:</strong> ${o.clientName}</div>`;
    }

    card.innerHTML = `
      <span class="bump-index-badge">${bumpNumber}</span>
      <div class="kds-card-header">
        <span class="kds-card-num">#${o.ticketNumber || o.id || 'N/A'}</span>
        <span class="kds-card-time">${elapsedText}</span>
      </div>
      <div class="kds-card-body">
        <div class="kds-client-info">
          <div><strong>${tableText}</strong></div>
          ${customerHtml}
          <div><strong>Server:</strong> ${o.cashierName || 'Staff'}</div>
        </div>
        <div style="margin-top: 5px;">
          ${itemsHtml}
        </div>
      </div>
      <div class="kds-card-footer" style="display: flex; gap: 4px; padding: 4px 6px;">
        <button class="btn-kds" onclick="openWorkSheetModal('${o.id}')" style="background-color: #0a84ff; color: #fff; flex: 1; padding: 5px 3px; font-size: 10px; font-weight: bold; border-radius: 4px; border: none; cursor: pointer;">View [Enter]</button>
        <button class="btn-kds" onclick="printBarTicket('${o.id}')" style="background-color: #ffd60a; color: #000; flex: 1; padding: 5px 3px; font-size: 10px; font-weight: bold; border-radius: 4px; border: none; cursor: pointer;">Print [*]</button>
        ${showPastOrders ? `
          <button class="btn-kds" onclick="bumpOrder('${o.id}')" style="background-color: #ff9f0a; color: #000; flex: 1; padding: 5px 3px; font-size: 10px; font-weight: bold; border-radius: 4px; border: none; cursor: pointer;">Recall [Del]</button>
        ` : `
          <button class="btn-kds bump" onclick="bumpOrder('${o.id}')" style="background-color: #30d158; color: #000; flex: 1; padding: 5px 3px; font-size: 10px; font-weight: bold; border-radius: 4px; border: none; cursor: pointer;">Bump [Del]</button>
        `}
      </div>
    `;

    container.appendChild(card);
  });

  // Ensure one card is always selected
  const hasSelected = container.querySelector('.kds-card.selected-kds-card');
  if (!hasSelected) {
    const firstCard = container.querySelector('.kds-card');
    if (firstCard) {
      firstCard.classList.add('selected-kds-card');
      selectedCardKey = firstCard.getAttribute('data-bump-key') || '1';
    }
  }
}

function openWorkSheetModal(orderId) {
  const cleanId = String(orderId || '').trim();
  const order = orders.find(o => String(o.id) === cleanId || String(o.ticketNumber) === cleanId || String(o.ticketDisplay) === cleanId);
  if (!order) return;

  const modal = document.getElementById('modalWorkSheetPreview');
  const modalBody = document.getElementById('workSheetModalBody');
  const titleEl = document.getElementById('lblWorkSheetModalTitle');
  const printBtn = document.getElementById('btnPrintWorkSheetFromModal');

  if (titleEl) titleEl.innerText = `Order #${order.ticketNumber || order.id}`;
  if (printBtn) printBtn.onclick = () => printBarTicket(order.id);

  let itemsHtml = (order.items || []).map(item => {
    const isDrink = isBarDrinkItem(item);
    const isDouble = !!(item.isDouble || (item.name && /DOBLE|DOUBLE/i.test(item.name)));
    const mods = (item.selectedModifiers && item.selectedModifiers.length > 0)
      ? `<div style="font-size: 11px; color: #8b949e; margin-left: 14px;">(${item.selectedModifiers.map(m=>m.name).join(', ')})</div>`
      : '';
    return `
      <div style="padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between; align-items: center;">
        <div>
          <span style="font-weight: 900; color: #00f0ff; margin-right: 6px;">${item.quantity || 1}x</span>
          ${isDouble ? '<span style="background: #af52de; color: #fff; font-size: 10px; font-weight: 900; padding: 1px 5px; border-radius: 3px; margin-right: 4px;">DOBLE</span>' : ''}
          <span style="font-weight: bold; color: ${isDrink ? '#fff' : '#8b949e'};">${cleanDrinkName(item.name)}</span>
          ${mods}
        </div>
        <span style="font-weight: 700; color: #30d158;">$${((item.price || 0) * (item.quantity || 1)).toFixed(2)}</span>
      </div>
    `;
  }).join('');

  const tableStr = (order.tableName && order.tableName.toLowerCase() !== 'walk in') ? order.tableName : (order.tableNumber ? `Table ${order.tableNumber}` : 'Walk In');
  const dateStr = new Date(order.dateCreated || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  if (modalBody) {
    modalBody.innerHTML = `
      <div style="background: #161b22; border-radius: 8px; padding: 12px; margin-bottom: 12px; font-size: 13px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span><strong>Ticket:</strong> #${order.ticketNumber || order.id}</span>
          <span style="color: #00f0ff; font-weight: bold;">${dateStr}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
          <span><strong>Area:</strong> ${tableStr}</span>
          <span><strong>Server:</strong> ${order.cashierName || 'Staff'}</span>
        </div>
        ${(order.clientName && order.clientName.toLowerCase() !== 'walk in' && order.clientName !== order.tableNumber) ? `<div><strong>Customer:</strong> ${order.clientName}</div>` : ''}
        ${order.notes ? `<div style="margin-top: 6px; color: #ffd60a; background: rgba(255,214,10,0.1); padding: 4px 8px; border-radius: 4px;"><strong>Notes:</strong> ${order.notes}</div>` : ''}
      </div>
      <div style="background: #161b22; border-radius: 8px; padding: 12px;">
        <div style="font-weight: bold; color: #8b949e; font-size: 11px; text-transform: uppercase; margin-bottom: 8px;">Items Ordered</div>
        ${itemsHtml}
      </div>
    `;
  }
  if (modal) modal.style.display = 'flex';
}
window.openWorkSheetModal = openWorkSheetModal;

function closeWorkSheetModal() {
  const modal = document.getElementById('modalWorkSheetPreview');
  if (modal) modal.style.display = 'none';
}
window.closeWorkSheetModal = closeWorkSheetModal;

async function printBarTicket(orderId) {
  try {
    showToast('Sending ticket to printer...', 'info');
    const res = await fetch(`${SERVER_URL}/api/printer/print-kitchen/${orderId}?station=bar`, {
      method: 'POST'
    });
    if (res.ok) {
      showToast('Ticket sent to bar printer!', 'success');
    } else {
      await fetch(`${SERVER_URL}/api/printer/print-receipt/${orderId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isCheck: true })
      });
      showToast('Ticket printed successfully!', 'success');
    }
  } catch (e) {
    console.error('Print ticket error:', e);
    showToast('Printer communication error', 'error');
  }
}
window.printBarTicket = printBarTicket;

async function bumpOrder(targetIdentifier) {
  try {
    const cleanTarget = String(targetIdentifier || '').trim();
    const order = orders.find(o => String(o.id) === cleanTarget || String(o.ticketNumber) === cleanTarget || String(o.ticketDisplay) === cleanTarget);
    if (!order) {
      console.warn("Order not found for bump:", targetIdentifier);
      return;
    }

    const isCurrentlyDone = order.status === 'listo' || order.status === 'completado' || order.barPrepared === true;
    const newStatus = isCurrentlyDone ? 'pendiente' : 'listo';

    // 0ms instant optimistic UI removal
    order.status = newStatus;
    order.barPrepared = (newStatus === 'listo');
    showToast(newStatus === 'listo' ? "Order served / Bumped" : "Order recalled to active", "success");
    renderKDS();

    const res = await fetch(`${SERVER_URL}/api/orders/${order.id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (!res.ok) {
      showToast("Error updating order status on server", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error connecting to server", "error");
  }
}
window.bumpOrder = bumpOrder;

function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  if (!toast || !toastText) return;
  
  toastText.textContent = text;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.className = toast.className.replace('show', '');
  }, 2000);
}

function downloadKioskShortcutBar() {
  window.location.href = '/download-hardware-setup';
}
