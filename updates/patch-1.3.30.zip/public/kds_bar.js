const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let currentPage = 0;
let showPastOrders = false;
let activeWebSocket = null;

document.addEventListener('DOMContentLoaded', async () => {
  await checkBarKdsLicense();
  initWebSocket();
  loadOrders();
  setupEventListeners();
  announceStationOnline();
});

async function announceStationOnline() {
  try {
    await fetch(`${SERVER_URL}/api/stations/announce`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ station: 'bar', name: 'Bar KDS' })
    });
  } catch (e) {}
}

async function checkBarKdsLicense() {
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/status`);
    if (res.ok) {
      const data = await res.json();
      return true;
    }
  } catch (e) {
    console.warn("License check bypassed:", e);
  }
  return true;
}

async function loadOrders() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      orders = await res.json();
      renderKDS();
    } else {
      setTimeout(loadOrders, 2000);
    }
  } catch (err) {
    console.error("Failed to load orders:", err);
    setTimeout(loadOrders, 2000);
  }
}

function initWebSocket() {
  try {
    activeWebSocket = new WebSocket(WS_URL);
    activeWebSocket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        const t = (msg.type || '').toUpperCase();
        if (t === 'NEW_ORDER' || t === 'ORDER_UPDATED' || t === 'DELIVERY_ORDER_ARRIVED' || t === 'ORDERS_UPDATED') {
          playAlertSound();
          loadOrders();
        }
      } catch (e) {
        console.error("WS parse error:", e);
      }
    };
    activeWebSocket.onclose = () => {
      setTimeout(initWebSocket, 5000);
    };
  } catch (e) {
    console.error("WS init error:", e);
    setTimeout(initWebSocket, 5000);
  }
}

function playAlertSound() {
  try {
    const audio = new Audio('/icons/bell.mp3');
    audio.play().catch(() => {});
  } catch (e) {}
}

function setupEventListeners() {
  const btnActive = document.getElementById('btnActiveOrders');
  if (btnActive) {
    btnActive.addEventListener('click', () => {
      showPastOrders = false;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPast = document.getElementById('btnPastOrders');
  if (btnPast) {
    btnPast.addEventListener('click', () => {
      showPastOrders = true;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPrev = document.getElementById('btnKdsScrollBack');
  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      if (currentPage > 0) {
        currentPage--;
        renderKDS();
      }
    });
  }

  const btnNext = document.getElementById('btnKdsScrollNext');
  if (btnNext) {
    btnNext.addEventListener('click', () => {
      const activeOrders = getFilteredOrders();
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderKDS();
      }
    });
  }

  // Keyboard shortcut listener for Bump Bar (keys 1 to 9)
  window.addEventListener('keydown', (e) => {
    if (e.key >= '1' && e.key <= '9') {
      const index = parseInt(e.key) - 1;
      const activeOrders = getFilteredOrders();
      const pageStartIndex = currentPage * 20;
      const targetOrder = activeOrders[pageStartIndex + index];
      if (targetOrder) {
        bumpOrder(targetOrder.id);
      }
    }
  });

  const btnKiosk = document.getElementById('btnDownloadKioskDirect');
  if (btnKiosk) {
    btnKiosk.onclick = (e) => {
      e.preventDefault();
      downloadKioskShortcutBar();
    };
  }
}

function isBarDrinkItem(item) {
  if (!item) return false;
  if (item.isDrink === true || item.sendToBar === true) return true;
  
  const text = `${item.department || ''} ${item.dept || ''} ${item.category || ''} ${item.subCategory || ''} ${item.name || ''}`.toLowerCase();
  
  const drinkKeywords = [
    'bebida', 'drink', 'bar', 'beer', 'cerveza', 'wine', 'vino', 'liquor', 'licor',
    'cocktail', 'coctel', 'cocteleria', 'alcohol', 'beverage', 'refresco', 'soda',
    'trago', 'tequila', 'vodka', 'whiskey', 'rum', 'ron', 'jugo', 'juice', 'water',
    'agua', 'te', 'tea', 'cafe', 'coffee', 'latte', 'cappuccino', 'espresso', 'bottle',
    'botella', 'can', 'lata', 'draft', 'tap', 'corona', 'bud light', 'heineken',
    'michelob', 'modelo', 'pacifico', 'victoria', 'stella', 'guinness', 'coca', 'sprite',
    'fanta', 'jarrito', 'topo chico', 'mineral'
  ];

  return drinkKeywords.some(kw => text.includes(kw));
}

function getFilteredOrders() {
  return orders.filter(o => {
    if (o.status === 'void' || o.status === 'refunded') return false;
    
    // Filter orders containing bar drinks
    const hasDrinks = o.items && o.items.some(isBarDrinkItem);
    if (!hasDrinks) return false;

    if (showPastOrders) {
      return o.barPrepared === true || o.status === 'completado' || o.status === 'entregado';
    } else {
      return !o.barPrepared && o.status !== 'completado' && o.status !== 'entregado';
    }
  }).sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
}

function renderKDS() {
  const container = document.getElementById('kdsContainer');
  if (!container) return;
  container.innerHTML = '';

  const btnActive = document.getElementById('btnActiveOrders');
  const btnPast = document.getElementById('btnPastOrders');
  if (btnActive && btnPast) {
    if (showPastOrders) {
      btnPast.style.backgroundColor = 'var(--accent-color)';
      btnPast.style.color = '#000';
      btnActive.style.backgroundColor = 'var(--bg-tertiary)';
      btnActive.style.color = '#fff';
    } else {
      btnActive.style.backgroundColor = 'var(--accent-color)';
      btnActive.style.color = '#000';
      btnPast.style.backgroundColor = 'var(--bg-tertiary)';
      btnPast.style.color = '#fff';
    }
  }

  const activeOrders = getFilteredOrders();

  if (activeOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">No drinks in queue</div>`;
    const lblPage = document.getElementById('lblKdsPageIndicator');
    if (lblPage) lblPage.innerText = `Page 1 of 1`;
    return;
  }

  const totalCount = activeOrders.length;
  const maxPage = Math.max(0, Math.ceil(totalCount / 20) - 1);
  if (currentPage > maxPage) currentPage = maxPage;

  const lblPage = document.getElementById('lblKdsPageIndicator');
  if (lblPage) lblPage.innerText = `Page ${currentPage + 1} of ${maxPage + 1}`;

  const startIndex = currentPage * 20;
  const pageOrders = activeOrders.slice(startIndex, startIndex + 20);

  pageOrders.forEach((o, index) => {
    const card = document.createElement('div');
    card.className = `kds-card type-${(o.type || 'comer').toLowerCase()}`;
    
    const minsOld = Math.floor((Date.now() - new Date(o.dateCreated).getTime()) / 60000);
    if (minsOld >= 5 && !showPastOrders) {
      card.classList.add('priority');
    }

    const elapsedText = showPastOrders ? 'DONE' : `${minsOld}m`;
    const bumpNumber = index + 1;

    let itemsHtml = '';
    (o.items || []).forEach(item => {
      if (isBarDrinkItem(item)) {
        let modText = '';
        if (item.selectedModifiers && item.selectedModifiers.length > 0) {
          modText = `<div class="kds-item-specs">(${item.selectedModifiers.map(m=>m.name).join(', ')})</div>`;
        }
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            ${(item.isDouble || (item.name && (item.name.includes('DOBLE') || item.name.includes('DOUBLE')))) ? '<span style="background: #af52de; color: #fff; font-size: 13px; font-weight: 900; padding: 2px 7px; border-radius: 4px; margin-right: 6px; letter-spacing: 0.5px;">DOBLE</span>' : ''}<span class="kds-item-name">${(item.name || 'Drink').replace(/\[\s*(DOBLE|DOUBLE)\s*\]\s*/gi, '')}</span>
            ${modText}
          </div>
        `;
      }
    });

    // If order has no specific drink items flagged, show all items
    if (!itemsHtml) {
      (o.items || []).forEach(item => {
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            <span class="kds-item-name">${item.name || 'Item'}</span>
          </div>
        `;
      });
    }

    card.innerHTML = `
      <span class="bump-index-badge">${bumpNumber}</span>
      <div class="kds-card-header">
        <span class="kds-card-num">#${o.ticketNumber || o.id || 'N/A'}</span>
        <span class="kds-card-time">${elapsedText}</span>
      </div>
      <div class="kds-card-body">
        <div class="kds-client-info">
          <strong>Table / Type:</strong> ${o.tableName || o.deliveryType || o.type || 'Bar'}<br>
          <strong>Customer:</strong> ${o.clientName || 'Walk In'}<br>
          <strong>Server:</strong> ${o.cashierName || 'Cashier'}
        </div>
        <div style="margin-top: 5px;">
          ${itemsHtml}
        </div>
      </div>
      <div class="kds-card-footer">
        <button class="btn-kds bump" onclick="bumpOrder('${o.id}')">${showPastOrders ? 'Re-open' : 'Done / Bump'}</button>
      </div>
    `;

    container.appendChild(card);
  });
}

async function bumpOrder(orderId) {
  try {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    order.barPrepared = !order.barPrepared;

    const res = await fetch(`${SERVER_URL}/api/orders/${orderId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });

    if (res.ok) {
      showToast(order.barPrepared ? "Order served / Bumped" : "Order recalled", "success");
      loadOrders();
    } else {
      showToast("Error updating order status", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error connecting to server", "error");
  }
}
window.bumpOrder = bumpOrder;

function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  if (!toast || !toastText) return;
  
  toastText.textContent = text;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.className = toast.className.replace('show', '');
  }, 2000);
}

function downloadKioskShortcutBar() {
  window.location.href = '/download-hardware-setup';
}
