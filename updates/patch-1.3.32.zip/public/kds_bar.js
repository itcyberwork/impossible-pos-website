const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

let orders = [];
let currentPage = 0;
let showPastOrders = false;
let activeWebSocket = null;
let selectedCardKey = '1';
let kdsNumpadBuffer = '';
let kdsBufferTimer = null;

document.addEventListener('DOMContentLoaded', async () => {
  await checkBarKdsLicense();
  initWebSocket();
  loadOrders();
  setupEventListeners();
  announceStationOnline();
});

async function announceStationOnline() {
  try {
    await fetch(`${SERVER_URL}/api/stations/announce`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ station: 'bar', name: 'Bar KDS' })
    });
  } catch (e) {}
}

async function checkBarKdsLicense() {
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/status`);
    if (res.ok) {
      return true;
    }
  } catch (e) {
    console.warn("License check bypassed:", e);
  }
  return true;
}

async function loadOrders() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      orders = await res.json();
      renderKDS();
    } else {
      setTimeout(loadOrders, 2000);
    }
  } catch (err) {
    console.error("Failed to load orders:", err);
    setTimeout(loadOrders, 2000);
  }
}

function initWebSocket() {
  try {
    activeWebSocket = new WebSocket(WS_URL);
    activeWebSocket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        const t = (msg.type || '').toUpperCase();
        if (t === 'NEW_ORDER' || t === 'ORDER_UPDATED' || t === 'DELIVERY_ORDER_ARRIVED' || t === 'ORDERS_UPDATED') {
          playAlertSound();
          loadOrders();
        }
      } catch (e) {
        console.error("WS parse error:", e);
      }
    };
    activeWebSocket.onclose = () => {
      setTimeout(initWebSocket, 5000);
    };
  } catch (e) {
    console.error("WS init error:", e);
    setTimeout(initWebSocket, 5000);
  }
}

function playAlertSound() {
  try {
    const audio = new Audio('/icons/bell.mp3');
    audio.play().catch(() => {});
  } catch (e) {}
}

function setupEventListeners() {
  const btnActive = document.getElementById('btnActiveOrders');
  if (btnActive) {
    btnActive.addEventListener('click', () => {
      showPastOrders = false;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPast = document.getElementById('btnPastOrders');
  if (btnPast) {
    btnPast.addEventListener('click', () => {
      showPastOrders = true;
      currentPage = 0;
      renderKDS();
    });
  }

  const btnPrev = document.getElementById('btnKdsScrollBack');
  if (btnPrev) {
    btnPrev.addEventListener('click', () => {
      if (currentPage > 0) {
        currentPage--;
        renderKDS();
      }
    });
  }

  const btnNext = document.getElementById('btnKdsScrollNext');
  if (btnNext) {
    btnNext.addEventListener('click', () => {
      const activeOrders = getFilteredOrders();
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderKDS();
      }
    });
  }

  // Keyboard controls for USB Numpad and Bump Bar
  window.addEventListener('keydown', (e) => {
    let key = e.key;

    // Normalize Numpad codes
    if (e.code && e.code.startsWith('Numpad')) {
      const numMatch = e.code.match(/Numpad([0-9])/);
      if (numMatch) key = numMatch[1];
      else if (e.code === 'NumpadDecimal') key = 'Delete';
      else if (e.code === 'NumpadEnter') key = 'Enter';
      else if (e.code === 'NumpadAdd') key = '+';
      else if (e.code === 'NumpadSubtract') key = '-';
    }

    // 1. Numeric keys 0-9: Select card and buffer ticket number
    if (key >= '0' && key <= '9') {
      e.preventDefault();
      if (kdsBufferTimer) clearTimeout(kdsBufferTimer);
      kdsNumpadBuffer += key;

      if (kdsNumpadBuffer.length === 1) {
        selectCardByKey(key);
      } else {
        // Multi-digit ticket number matching
        const cards = Array.from(document.querySelectorAll('.kds-card'));
        const matched = cards.find(c => {
          const tNum = c.getAttribute('data-ticket-number') || '';
          return tNum === kdsNumpadBuffer || (c.innerText || '').includes('#' + kdsNumpadBuffer);
        });
        if (matched) {
          cards.forEach(c => c.classList.remove('selected-kds-card'));
          matched.classList.add('selected-kds-card');
          selectedCardKey = matched.getAttribute('data-bump-key') || '1';
          matched.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }

      kdsBufferTimer = setTimeout(() => {
        kdsNumpadBuffer = '';
      }, 2500);
      return;
    }

    // 2. Delete or Decimal (.): Bump order
    if (key === 'Delete' || key === '.') {
      e.preventDefault();
      if (kdsNumpadBuffer && kdsNumpadBuffer.length > 0) {
        const target = kdsNumpadBuffer;
        kdsNumpadBuffer = '';
        if (kdsBufferTimer) clearTimeout(kdsBufferTimer);
        bumpOrder(target);
        return;
      }
      const selectedCard = document.querySelector('.kds-card.selected-kds-card') || document.querySelector('.kds-card');
      if (selectedCard) {
        const orderId = selectedCard.getAttribute('data-order-id');
        if (orderId) bumpOrder(orderId);
      }
      return;
    }

    // 3. Tab: Switch page or toggle Active/Past
    if (key === 'Tab') {
      e.preventDefault();
      const activeOrders = getFilteredOrders();
      const maxPage = Math.max(0, Math.ceil(activeOrders.length / 20) - 1);
      if (currentPage < maxPage) {
        currentPage++;
        renderKDS();
      } else {
        showPastOrders = !showPastOrders;
        currentPage = 0;
        renderKDS();
      }
      return;
    }

    // 4. + / - : Next / Previous card
    if (key === '+') {
      e.preventDefault();
      selectNextCard();
      return;
    }
    if (key === '-') {
      e.preventDefault();
      selectPrevCard();
      return;
    }
  });

  const btnKiosk = document.getElementById('btnDownloadKioskDirect');
  if (btnKiosk) {
    btnKiosk.onclick = (e) => {
      e.preventDefault();
      downloadKioskShortcutBar();
    };
  }
}

function selectCardByKey(numStr) {
  selectedCardKey = numStr;
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  cards.forEach(c => {
    if (c.getAttribute('data-bump-key') === numStr) {
      c.classList.add('selected-kds-card');
      c.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      c.classList.remove('selected-kds-card');
    }
  });
}

function selectNextCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  if (cards.length === 0) return;
  const idx = cards.findIndex(c => c.classList.contains('selected-kds-card'));
  if (idx >= 0 && idx < cards.length - 1) {
    selectCardByKey(cards[idx + 1].getAttribute('data-bump-key'));
  } else {
    selectCardByKey(cards[0].getAttribute('data-bump-key'));
  }
}

function selectPrevCard() {
  const cards = Array.from(document.querySelectorAll('.kds-card'));
  if (cards.length === 0) return;
  const idx = cards.findIndex(c => c.classList.contains('selected-kds-card'));
  if (idx > 0) {
    selectCardByKey(cards[idx - 1].getAttribute('data-bump-key'));
  } else {
    selectCardByKey(cards[cards.length - 1].getAttribute('data-bump-key'));
  }
}

function isBarDrinkItem(item) {
  if (!item) return false;
  if (item.isDrink === true || item.sendToBar === true) return true;
  
  const text = `${item.department || ''} ${item.dept || ''} ${item.category || ''} ${item.subCategory || ''} ${item.name || ''}`.toLowerCase();
  
  const drinkKeywords = [
    'bebida', 'drink', 'bar', 'beer', 'cerveza', 'wine', 'vino', 'liquor', 'licor',
    'cocktail', 'coctel', 'cocteleria', 'alcohol', 'beverage', 'refresco', 'soda',
    'trago', 'tequila', 'vodka', 'whiskey', 'rum', 'ron', 'jugo', 'juice', 'water',
    'agua', 'te', 'tea', 'cafe', 'coffee', 'latte', 'cappuccino', 'espresso', 'bottle',
    'botella', 'can', 'lata', 'draft', 'tap', 'corona', 'bud light', 'heineken',
    'michelob', 'modelo', 'pacifico', 'victoria', 'stella', 'guinness', 'coca', 'sprite',
    'fanta', 'jarrito', 'topo chico', 'mineral'
  ];

  return drinkKeywords.some(kw => text.includes(kw));
}

function getFilteredOrders() {
  return orders.filter(o => {
    if (o.status === 'void' || o.status === 'refunded' || o.status === 'cancelado') return false;
    
    // Filter orders containing bar drinks
    const hasDrinks = o.items && o.items.some(isBarDrinkItem);
    if (!hasDrinks) return false;

    const isDone = o.barPrepared === true || o.status === 'listo' || o.status === 'completado' || o.status === 'entregado';
    if (showPastOrders) {
      return isDone;
    } else {
      return !isDone;
    }
  }).sort((a, b) => new Date(b.dateCreated || b.dateUpdated || 0) - new Date(a.dateCreated || a.dateUpdated || 0));
}

function renderKDS() {
  const container = document.getElementById('kdsContainer');
  if (!container) return;
  container.innerHTML = '';

  const btnActive = document.getElementById('btnActiveOrders');
  const btnPast = document.getElementById('btnPastOrders');
  if (btnActive && btnPast) {
    if (showPastOrders) {
      btnPast.style.backgroundColor = 'var(--accent-color)';
      btnPast.style.color = '#000';
      btnActive.style.backgroundColor = 'var(--bg-tertiary)';
      btnActive.style.color = '#fff';
    } else {
      btnActive.style.backgroundColor = 'var(--accent-color)';
      btnActive.style.color = '#000';
      btnPast.style.backgroundColor = 'var(--bg-tertiary)';
      btnPast.style.color = '#fff';
    }
  }

  const activeOrders = getFilteredOrders();

  if (activeOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); width: 100%; margin-top: 100px; font-size: 20px;">${showPastOrders ? 'No past drinks' : 'No drinks in queue'}</div>`;
    const lblPage = document.getElementById('lblKdsPageIndicator');
    if (lblPage) lblPage.innerText = `Page 1 of 1`;
    return;
  }

  const totalCount = activeOrders.length;
  const maxPage = Math.max(0, Math.ceil(totalCount / 20) - 1);
  if (currentPage > maxPage) currentPage = maxPage;

  const lblPage = document.getElementById('lblKdsPageIndicator');
  if (lblPage) lblPage.innerText = `Page ${currentPage + 1} of ${maxPage + 1}`;

  const startIndex = currentPage * 20;
  const pageOrders = activeOrders.slice(startIndex, startIndex + 20);

  pageOrders.forEach((o, index) => {
    const card = document.createElement('div');
    card.className = `kds-card type-${(o.type || 'comer').toLowerCase()}`;
    card.setAttribute('data-order-id', o.id);
    card.setAttribute('data-ticket-number', String(o.ticketNumber || o.ticketDisplay || ''));
    const bumpKey = String(index + 1);
    card.setAttribute('data-bump-key', bumpKey);

    if (bumpKey === selectedCardKey) {
      card.classList.add('selected-kds-card');
    }
    
    const minsOld = Math.floor((Date.now() - new Date(o.dateCreated).getTime()) / 60000);
    if (minsOld >= 5 && !showPastOrders) {
      card.classList.add('priority');
    }

    const elapsedText = showPastOrders ? 'DONE' : `${minsOld}m`;
    const bumpNumber = index + 1;

    let itemsHtml = '';
    (o.items || []).forEach(item => {
      if (isBarDrinkItem(item)) {
        let modText = '';
        if (item.selectedModifiers && item.selectedModifiers.length > 0) {
          modText = `<div class="kds-item-specs">(${item.selectedModifiers.map(m=>m.name).join(', ')})</div>`;
        }
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            ${(item.isDouble || (item.name && (item.name.includes('DOBLE') || item.name.includes('DOUBLE')))) ? '<span style="background: #af52de; color: #fff; font-size: 13px; font-weight: 900; padding: 2px 7px; border-radius: 4px; margin-right: 6px; letter-spacing: 0.5px;">DOBLE</span>' : ''}<span class="kds-item-name">${(item.name || 'Drink').replace(/[s*(DOBLE|DOUBLE)s*]s*/gi, '')}</span>
            ${modText}
          </div>
        `;
      }
    });

    // If order has no specific drink items flagged, show all items
    if (!itemsHtml) {
      (o.items || []).forEach(item => {
        itemsHtml += `
          <div class="kds-item">
            <span class="kds-item-qty">${item.quantity || 1}x</span>
            <span class="kds-item-name">${item.name || 'Item'}</span>
          </div>
        `;
      });
    }

    card.innerHTML = `
      <span class="bump-index-badge">${bumpNumber}</span>
      <div class="kds-card-header">
        <span class="kds-card-num">#${o.ticketNumber || o.id || 'N/A'}</span>
        <span class="kds-card-time">${elapsedText}</span>
      </div>
      <div class="kds-card-body">
        <div class="kds-client-info">
          <strong>Table / Type:</strong> ${o.tableName || o.deliveryType || o.type || 'Bar'}<br>
          <strong>Customer:</strong> ${o.clientName || 'Walk In'}<br>
          <strong>Server:</strong> ${o.cashierName || 'Cashier'}
        </div>
        <div style="margin-top: 5px;">
          ${itemsHtml}
        </div>
      </div>
      <div class="kds-card-footer">
        <button class="btn-kds bump" onclick="bumpOrder('${o.id}')">${showPastOrders ? 'Re-open / Recall' : 'Done / Bump [Del]'}</button>
      </div>
    `;

    container.appendChild(card);
  });
}

async function bumpOrder(targetIdentifier) {
  try {
    const cleanTarget = String(targetIdentifier || '').trim();
    const order = orders.find(o => String(o.id) === cleanTarget || String(o.ticketNumber) === cleanTarget || String(o.ticketDisplay) === cleanTarget);
    if (!order) {
      console.warn("Order not found for bump:", targetIdentifier);
      return;
    }

    const isCurrentlyDone = order.status === 'listo' || order.status === 'completado' || order.barPrepared === true;
    const newStatus = isCurrentlyDone ? 'pendiente' : 'listo';

    const res = await fetch(`${SERVER_URL}/api/orders/${order.id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (res.ok) {
      order.status = newStatus;
      order.barPrepared = (newStatus === 'listo');
      showToast(newStatus === 'listo' ? "Order served / Bumped" : "Order recalled to active", "success");
      renderKDS();
      // Background full reload
      setTimeout(loadOrders, 300);
    } else {
      showToast("Error updating order status", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error connecting to server", "error");
  }
}
window.bumpOrder = bumpOrder;

function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  if (!toast || !toastText) return;
  
  toastText.textContent = text;
  toast.className = `toast show ${type}`;
  
  setTimeout(() => {
    toast.className = toast.className.replace('show', '');
  }, 2000);
}

function downloadKioskShortcutBar() {
  window.location.href = '/download-hardware-setup';
}
