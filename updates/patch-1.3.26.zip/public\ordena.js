// --- CUSTOMER CARSIDE SELF-ORDERING CONTROLLER ---

const SERVER_URL = window.location.origin;
const WS_PORT = window.location.port ? `:${window.location.port}` : '';
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}${WS_PORT}`;

let products = [];
let cart = [];
let taxRate = 6.0; // Loaded from settings
let activeCategory = 'all';
let currentModProduct = null;
let currentModQty = 1;
let currentModActiveIndex = 0;
let currentModSelections = [ {} ];
let ws = null;
let currentOrderId = null;
let currentTicketNumber = null;
let configuredBotUsername = '';
let configuredNotificationProvider = '';
let lastSubmittedCustomerPhone = '';

document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  await loadCatalog();
  setupEventListeners();

  try {
    const urlParams = new URLSearchParams(window.location.search);
    const tableParam = urlParams.get('mesa') || urlParams.get('table') || '';
    if (tableParam) {
      const cleanNum = String(tableParam).replace(/\D/g, '');
      const subtitleEl = document.querySelector('.subtitle');
      if (subtitleEl) {
        subtitleEl.innerHTML = `<span style="background: var(--accent-color); color: #000; font-weight: 800; padding: 2px 8px; border-radius: 4px; font-size: 12px; letter-spacing: 0.5px;">TABLE / MESA ${tableParam}</span>`;
      }
      if (cleanNum) {
        checkAndInitTableSession(cleanNum);
      }
    }
  } catch(e) {}
});

// Load tax rate & notification settings from POS settings
async function loadSettings() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      const data = await res.json();
      taxRate = parseFloat(data.taxRate) || 6.0;
      if (data.notificationProvider === 'telegram' && data.telegramBotUsername) {
        configuredBotUsername = data.telegramBotUsername.replace(/^@/, '');
        configuredNotificationProvider = 'telegram';
      }
    }
  } catch (err) {
    console.error("Error loading tax settings:", err);
  }
}

// Load products catalog from POS server
async function loadCatalog() {
  try {
    const res = await fetch(`${SERVER_URL}/api/products`);
    if (res.ok) {
      const data = await res.json();
      const allProducts = Array.isArray(data) ? data : (data.products || []);
      // Filter active and non-deleted products
      products = allProducts.filter(p => p.active !== false).map(p => ({
        ...p,
        modifiers: p.modifiers || p.modifierGroups || []
      }));
      
      renderCategoryTabs();
      renderCatalogList();
    } else {
      throw new Error(`HTTP ${res.status}`);
    }
  } catch (err) {
    console.error("Error loading products catalog:", err);
    document.getElementById('menuList').innerHTML = `<p style="color:var(--danger-color); text-align:center; font-size:13px; padding:20px;">Error al conectar con el servidor. Por favor reintenta.</p>`;
  }
}

// Render categories horizontally
function renderCategoryTabs() {
  const bar = document.getElementById('categoriesBar');
  bar.innerHTML = `<div class="category-tab ${activeCategory === 'all' ? 'active' : ''}" onclick="filterCategory('all')">Todos / All</div>`;
  
  // Extract unique categories
  const categories = [...new Set(products.map(p => p.category))].filter(Boolean);
  
  categories.forEach(cat => {
    const tab = document.createElement('div');
    tab.className = `category-tab ${activeCategory === cat ? 'active' : ''}`;
    // Capitalize category name
    const label = cat.charAt(0).toUpperCase() + cat.slice(1);
    tab.innerText = label;
    tab.onclick = () => filterCategory(cat);
    bar.appendChild(tab);
  });
}

// Filter active category view
function filterCategory(cat) {
  activeCategory = cat;
  renderCategoryTabs();
  renderCatalogList();
}

// Render grouped products list
function renderCatalogList() {
  const container = document.getElementById('menuList');
  container.innerHTML = '';

  // Get categories to render
  let categories = [...new Set(products.map(p => p.category))].filter(Boolean);
  if (activeCategory !== 'all') {
    categories = [activeCategory];
  }

  categories.forEach(cat => {
    const catProducts = products.filter(p => p.category === cat);
    if (catProducts.length === 0) return;

    const section = document.createElement('div');
    section.style.display = 'flex';
    section.style.flexDirection = 'column';
    section.style.gap = '10px';

    const title = document.createElement('h3');
    title.className = 'category-section-title';
    title.innerText = cat.charAt(0).toUpperCase() + cat.slice(1);
    section.appendChild(title);

    const grid = document.createElement('div');
    grid.className = 'products-grid';

    catProducts.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      
      // Stock validation
      const isOutOfStock = p.trackStock && (p.stockQuantity || 0) <= 0;

      const desc = p.description || p.ingredients || '';

      card.innerHTML = `
        <div class="product-details">
          <span class="product-name">${p.name} ${isOutOfStock ? '<span style="color:var(--danger-color); font-size:10px; font-weight:bold;">[AGOTADO]</span>' : ''}</span>
          ${desc ? `<span class="product-desc">${desc}</span>` : ''}
          <span class="product-price">$${parseFloat(p.price).toFixed(2)}</span>
        </div>
        ${p.image ? `<div class="product-img" style="background-image: url('${p.image}')"></div>` : ''}
      `;

      card.onclick = () => {
        if (isOutOfStock) {
          alert("Lo sentimos, este producto está agotado por el momento. / Sorry, this item is currently out of stock.");
          return;
        }
        handleProductClick(p);
      };

      grid.appendChild(card);
    });

    section.appendChild(grid);
    container.appendChild(section);
  });
}

// Handle product card click (check modifiers first)
function handleProductClick(product) {
  const mods = product.modifiers || product.modifierGroups || [];
  if (mods && mods.length > 0) {
    currentModProduct = { ...product, modifiers: mods };
    openModifiersSheet(currentModProduct);
  } else {
    // Add directly to cart
    addToCart(product, []);
  }
}

// Batch Modifiers sheet management
function openModifiersSheet(product) {
  currentModProduct = product;
  currentModQty = 1;
  currentModActiveIndex = 0;
  currentModSelections = [ {} ];

  document.getElementById('modItemName').innerText = `Personalizar ${product.name} / Customize`;
  const applyAllChk = document.getElementById('chkModApplyToAll');
  if (applyAllChk) applyAllChk.checked = false;

  renderModifiersModal();
  document.getElementById('modsOverlay').style.display = 'flex';
}

function closeModifiersSheet() {
  document.getElementById('modsOverlay').style.display = 'none';
  currentModProduct = null;
  currentModSelections = [ {} ];
}

function syncApplyToAll() {
  const src = currentModSelections[currentModActiveIndex] || currentModSelections[0] || {};
  for (let i = 0; i < currentModQty; i++) {
    currentModSelections[i] = JSON.parse(JSON.stringify(src));
  }
}

function calculateBatchModTotal() {
  if (!currentModProduct) return 0;
  let total = 0;
  for (let i = 0; i < currentModQty; i++) {
    total += parseFloat(currentModProduct.price) || 0;
    const itemSel = currentModSelections[i] || {};
    Object.keys(itemSel).forEach(grpId => {
      const val = itemSel[grpId];
      if (Array.isArray(val)) {
        val.forEach(o => total += (parseFloat(o.price) || 0));
      } else if (val && val.price) {
        total += (parseFloat(val.price) || 0);
      }
    });
  }

  const btnText = document.getElementById('lblConfirmAddModsText');
  if (btnText) {
    if (currentModQty > 1) {
      btnText.innerText = `Agregar ${currentModQty} al Carrito - $${total.toFixed(2)} / Add to Cart`;
    } else {
      btnText.innerText = `Agregar al Carrito - $${total.toFixed(2)} / Add to Cart`;
    }
  }
  return total;
}

function renderModifiersModal() {
  if (!currentModProduct) return;
  const groups = currentModProduct.modifiers || currentModProduct.modifierGroups || [];

  // Ensure selection array matches quantity
  while (currentModSelections.length < currentModQty) {
    currentModSelections.push({});
  }

  // Update Quantity labels
  const isPlural = currentModQty > 1;
  document.getElementById('lblModQty').innerText = currentModQty;
  const subtext = document.getElementById('lblModQtySubtext');
  if (subtext) {
    subtext.innerText = `${currentModQty} ${currentModProduct.name} ($${(currentModProduct.price * currentModQty).toFixed(2)})`;
  }

  // Handle Apply to All Checkbox visibility
  const wrapperApplyAll = document.getElementById('wrapperModApplyToAll');
  const applyAllChk = document.getElementById('chkModApplyToAll');
  if (wrapperApplyAll) {
    wrapperApplyAll.style.display = isPlural ? 'block' : 'none';
  }

  // Handle Tabs visibility
  const wrapperTabs = document.getElementById('wrapperModTabs');
  const tabsDiv = document.getElementById('divModTabs');
  const activeBadge = document.getElementById('divCurrentModActiveBadge');

  if (isPlural && (!applyAllChk || !applyAllChk.checked)) {
    if (wrapperTabs) wrapperTabs.style.display = 'block';
    tabsDiv.style.display = 'flex';
    tabsDiv.innerHTML = '';
    for (let i = 0; i < currentModQty; i++) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `modifier-tab-btn ${i === currentModActiveIndex ? 'active' : ''}`;
      
      // Determine meat label if selected
      const itemSel = currentModSelections[i] || {};
      let chosenMeatName = '';
      const meatGroup = groups.find(g => g.id === 'g_meat' || (g.name && g.name.toLowerCase().includes('carne')));
      if (meatGroup && itemSel[meatGroup.id]) {
        const m = itemSel[meatGroup.id];
        chosenMeatName = Array.isArray(m) ? (m[0] ? m[0].name.split(' ')[0] : '') : (m.name ? m.name.split(' ')[0] : '');
      }

      const shortName = currentModProduct.name.split(' ')[0];
      const tabLabel = chosenMeatName ? `${shortName} ${i + 1}: ${chosenMeatName}` : `${shortName} ${i + 1}`;
      btn.innerText = tabLabel;
      
      btn.onclick = (e) => {
        e.preventDefault();
        currentModActiveIndex = i;
        renderModifiersModal();
      };
      tabsDiv.appendChild(btn);
    }

    if (activeBadge) {
      activeBadge.style.display = 'block';
      const shortName = currentModProduct.name.split(' ')[0];
      activeBadge.innerText = `Configurando ${shortName} ${currentModActiveIndex + 1} de ${currentModQty} / Customizing ${shortName} ${currentModActiveIndex + 1} of ${currentModQty}:`;
    }
  } else {
    if (wrapperTabs) wrapperTabs.style.display = 'none';
    tabsDiv.style.display = 'none';
    if (activeBadge) {
      activeBadge.style.display = isPlural ? 'block' : 'none';
      if (isPlural) {
        activeBadge.innerText = `Mismas opciones para los ${currentModQty} items / Same options for all ${currentModQty} items:`;
      }
    }
  }

  // Render options list for active index (or index 0 if apply to all)
  const targetIndex = (applyAllChk && applyAllChk.checked) ? 0 : currentModActiveIndex;
  const currentItemSelections = currentModSelections[targetIndex] || {};

  const list = document.getElementById('modsGroupList');
  list.innerHTML = '';

  groups.forEach((group) => {
    const isMulti = (group.maxSelection && group.maxSelection > 1);
    const block = document.createElement('div');
    const subtitle = isMulti 
      ? `(Elige hasta ${group.maxSelection || 'varias'} / Choose up to ${group.maxSelection || 'multiple'})` 
      : '(Elige 1 / Choose 1)';
    block.innerHTML = `<div class="mod-group-title">${group.name} <span style="font-size:11px; font-weight:normal; color:var(--text-secondary); text-transform:none;">${subtitle}</span></div>`;

    const options = group.options || [];
    const groupSelected = currentItemSelections[group.id];

    options.forEach(opt => {
      const row = document.createElement('div');
      row.className = 'mod-option-row';
      row.style.borderBottom = '1px solid rgba(255,255,255,0.03)';
      
      let isSelected = false;
      if (isMulti) {
        isSelected = Array.isArray(groupSelected) && groupSelected.some(x => x.name === opt.name);
      } else {
        isSelected = groupSelected && groupSelected.name === opt.name;
      }

      if (isSelected) {
        row.style.backgroundColor = 'rgba(255, 159, 10, 0.08)';
        row.style.color = 'var(--accent-color)';
      } else {
        row.style.backgroundColor = 'transparent';
        row.style.color = '#fff';
      }

      row.innerHTML = `
        <span class="opt-name">${opt.name}</span>
        <span class="opt-price" style="color: var(--accent-color);">${opt.price > 0 ? '+$' + parseFloat(opt.price).toFixed(2) : ''}</span>
      `;

      row.onclick = () => {
        if (isMulti) {
          if (!Array.isArray(currentItemSelections[group.id])) {
            currentItemSelections[group.id] = [];
          }
          const arr = currentItemSelections[group.id];
          const existsIdx = arr.findIndex(x => x.name === opt.name);
          if (existsIdx > -1) {
            arr.splice(existsIdx, 1);
          } else {
            if (group.maxSelection && arr.length >= group.maxSelection) {
              alert(`Máximo ${group.maxSelection} opciones permitidas / Maximum ${group.maxSelection} options allowed`);
              return;
            }
            arr.push(opt);
          }
        } else {
          currentItemSelections[group.id] = opt;
        }

        // If apply to all is checked, copy to all items
        if (applyAllChk && applyAllChk.checked) {
          syncApplyToAll();
        }

        renderModifiersModal();
      };

      block.appendChild(row);
    });

    list.appendChild(block);
  });

  // Calculate live total for batch
  calculateBatchModTotal();
}

// Add item with modifiers to cart
function addToCart(product, modifiersList) {
  // Compute modifier extra price
  const extraPrice = modifiersList.reduce((sum, m) => sum + (parseFloat(m.price) || 0), 0);
  const finalPrice = parseFloat(product.price) + extraPrice;

  // Create unique cart identifier based on product + selected modifiers
  const modIds = modifiersList.map(m => m.name).sort().join('|');
  const cartKey = `${product.id}_${modIds}`;

  const existing = cart.find(c => c.cartKey === cartKey);
  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      cartKey,
      id: product.id,
      name: product.name,
      price: finalPrice,
      quantity: 1,
      isCustomCake: product.isCustomCake || false,
      modifiers: modifiersList
    });
  }

  showToast(`Agregado / Added: ${product.name}`);
  updateCartUI();
}

// Update Cart Summary Bars
function updateCartUI() {
  const bar = document.getElementById('cartBar');
  const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (totalQty === 0) {
    bar.style.display = 'none';
    return;
  }

  bar.style.display = 'flex';
  document.getElementById('lblCartCount').innerText = `${totalQty} ${totalQty === 1 ? 'ARTÍCULO / ITEM' : 'ARTÍCULOS / ITEMS'}`;

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  document.getElementById('lblCartTotal').innerText = `$${total.toFixed(2)}`;
  
  // Sheet views
  document.getElementById('lblSheetSubtotal').innerText = `$${subtotal.toFixed(2)}`;
  document.getElementById('lblSheetTax').innerText = `$${tax.toFixed(2)}`;
  document.getElementById('lblSheetTotal').innerText = `$${total.toFixed(2)}`;

  renderCartSheetRows();
}

// Render checkout items rows
function renderCartSheetRows() {
  const container = document.getElementById('cartSheetItems');
  container.innerHTML = '';

  cart.forEach(item => {
    const row = document.createElement('div');
    row.className = 'cart-item-row';

    const modsText = item.modifiers.map(m => `+ ${m.name}`).join(', ');

    row.innerHTML = `
      <div class="cart-item-info">
        <span class="cart-item-name">${item.name}</span>
        ${modsText ? `<span class="cart-item-mods">${modsText}</span>` : ''}
        <span class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</span>
      </div>
      <div class="cart-item-actions">
        <button class="btn-qty" onclick="changeQty('${item.cartKey}', -1)">-</button>
        <span style="font-weight: bold; font-size:14px; min-width:20px; text-align:center;">${item.quantity}</span>
        <button class="btn-qty" onclick="changeQty('${item.cartKey}', 1)">+</button>
      </div>
    `;

    container.appendChild(row);
  });
}

window.changeQty = function(cartKey, amt) {
  const idx = cart.findIndex(c => c.cartKey === cartKey);
  if (idx !== -1) {
    cart[idx].quantity += amt;
    if (cart[idx].quantity <= 0) {
      cart.splice(idx, 1);
    }
  }
  updateCartUI();
  if (cart.length === 0) {
    closeCartSheet();
  }
};

// Checkout modal sheets
function openCartSheet() {
  document.getElementById('cartOverlay').style.display = 'flex';
}

function closeCartSheet() {
  document.getElementById('cartOverlay').style.display = 'none';
}

// Checkout Submit Order
async function submitCarOrder() {
  const deliveryType = document.querySelector('input[name="chkDeliveryType"]:checked').value;
  const name = document.getElementById('chkName').value.trim();
  const phone = document.getElementById('chkPhone').value.trim();
  const car = (deliveryType === 'drive-thru') ? document.getElementById('chkCar').value.trim() : "";
  const specialNotes = document.getElementById('chkNotes').value.trim();

  if (!name || !phone || (deliveryType === 'drive-thru' && !car)) {
    alert("Por favor completa los campos requeridos marcados con (*) / Please fill in all required fields (*)");
    return;
  }

  // Double check checkout totals
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * (taxRate / 100);
  const total = subtotal + tax;

  const notesText = (deliveryType === 'drive-thru')
    ? `[Auto-Pedido: ${car}]` + (specialNotes ? ` Notes: ${specialNotes}` : '')
    : `[Pedido en Linea: Recoge en Ventanilla]` + (specialNotes ? ` Notes: ${specialNotes}` : '');

  // Format order items for POS schema
  const orderItems = cart.map(c => {
    return {
      id: c.id,
      name: c.name,
      price: c.price,
      quantity: c.quantity,
      isCustomCake: c.isCustomCake,
      selectedModifiers: c.modifiers || [],
      details: {}
    };
  });

  const urlParams = new URLSearchParams(window.location.search);
  const tableParam = urlParams.get('mesa') || urlParams.get('table') || '';
  const cleanTableNum = String(tableParam).replace(/\D/g, '');

  const selectedPaymentMethod = document.querySelector('input[name="chkPaymentMethod"]:checked')?.value || 'cash';
  let deviceDesc = 'Mobile';
  const ua = navigator.userAgent || '';
  if (/iPhone/i.test(ua)) deviceDesc = 'iPhone';
  else if (/iPad/i.test(ua)) deviceDesc = 'iPad';
  else if (/Android/i.test(ua)) deviceDesc = 'Android';

  const orderOriginString = cleanTableNum 
    ? `Customer Phone: ${phone} (Table ${cleanTableNum})`
    : `Customer Phone: ${phone}`;

  const payload = {
    status: 'pendiente',
    paymentStatus: 'unpaid',
    paymentMethod: selectedPaymentMethod,
    cashierName: cleanTableNum ? `Table QR (Mesa ${cleanTableNum})` : 'Cliente Móvil',
    clientName: name ? (cleanTableNum ? `${name} (Mesa ${cleanTableNum})` : name) : (cleanTableNum ? `Mesa ${cleanTableNum}` : ''),
    clientPhone: phone,
    deliveryType: cleanTableNum ? 'comer' : deliveryType,
    tableName: cleanTableNum ? `Table ${cleanTableNum}` : '',
    tableNumber: cleanTableNum,
    source: cleanTableNum ? 'table_qr' : 'online',
    orderOrigin: orderOriginString,
    guestCount: 1,
    activeSeat: '',
    items: orderItems,
    subtotal: subtotal,
    tax: tax,
    total: total,
    notes: notesText
  };

  const btn = document.getElementById('btnPlaceOrder');
  btn.disabled = true;
  btn.innerText = "Enviando... / Sending...";

  try {
    const res = await fetch(`${SERVER_URL}/api/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const data = await res.json();
      const orderObj = data.order || data;
      currentOrderId = data.id || data.orderId || orderObj.id || ('ord_' + Date.now());
      currentTicketNumber = data.ticketDisplay || data.ticketNumber || orderObj.ticketDisplay || orderObj.ticketNumber || (currentOrderId.length > 4 ? currentOrderId.slice(-4) : currentOrderId);
      
      lastSubmittedCustomerPhone = phone;
      if (cleanTableNum) {
        try { localStorage.setItem('last_table_round_' + cleanTableNum, JSON.stringify(orderItems)); } catch(e) {}
      }
      closeCartSheet();
      cart = [];
      updateCartUI();
      
      showTrackingPanel();
    } else {
      alert("Error al guardar la orden. Por favor reintenta. / Error saving order. Please retry.");
      btn.disabled = false;
      btn.innerText = "Enviar Orden a Cocina / Send Order to Kitchen";
    }
  } catch (err) {
    console.error("Error submitting order:", err);
    alert("Error de conexión con el servidor. / Error connecting to server.");
    btn.disabled = false;
    btn.innerText = "Enviar Orden a Cocina / Send Order to Kitchen";
  }
}

// Show Tracking screen with dynamic barcode rendering
function showTrackingPanel() {
  document.getElementById('mainHeader').style.display = 'none';
  document.getElementById('categoriesBar').style.display = 'none';
  document.getElementById('menuList').style.display = 'none';
  document.getElementById('cartBar').style.display = 'none';
  
  const trackPanel = document.getElementById('trackingPanel');
  document.getElementById('lblTrackTicket').innerText = `#${currentTicketNumber}`;
  document.getElementById('lblTrackStatus').innerText = "En Cocina / Preparing";
  trackPanel.style.display = 'flex';

  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Draw scannable checkout barcode
  try {
    if (window.JsBarcode) {
      JsBarcode("#barcodeCanvas", `O-${currentOrderId}`, {
        format: "CODE128",
        width: 2.2,
        height: 60,
        displayValue: true,
        fontSize: 14,
        background: "#ffffff",
        lineColor: "#000000"
      });
    }
  } catch (e) {
    console.error("Barcode drawing failed:", e);
  }

  // Safe tracking connection
  try {
    initTrackingWebSocket();
  } catch (e) {}
}

function initTrackingWebSocket() {
  try {
    if (ws) ws.close();
    
    // In Vercel serverless cloud, WebSockets are not hosted
    if (window.location.hostname.includes('1ti1.com') || window.location.hostname.includes('vercel.app')) {
      return;
    }

    ws = new WebSocket(WS_URL);
    
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // If cashier changes order status (e.g. to "listo")
        if (data.type === 'ORDER_UPDATED' && data.order && data.order.id === currentOrderId) {
          if (data.order.status === 'listo') {
            document.getElementById('lblTrackStatus').innerText = "¡Listo para Recoger! / Ready for Pickup!";
            document.getElementById('lblTrackStatus').style.color = "var(--success-color)";
          } else if (data.order.status === 'entregado') {
            document.getElementById('lblTrackStatus').innerText = "Completado / Completed";
            document.getElementById('lblTrackStatus').style.color = "var(--text-secondary)";
          }
        }
        
        // Cashier clicked "Call / Llamar" in POS Car Orders tab
        if (data.type === 'CAR_ORDER_CALL' && data.orderId === currentOrderId) {
          triggerMobileReadyCall();
        }
      } catch (e) {
        console.error(e);
      }
    };

    ws.onclose = () => {
      setTimeout(initTrackingWebSocket, 5000);
    };
  } catch (e) {
    console.warn("WebSocket init skipped:", e);
  }
}

// Trigger browser vibrator, sound and flash screen overlay
function triggerMobileReadyCall() {
  document.getElementById('mobileCallOverlay').style.display = 'flex';
  
  if (navigator.vibrate) {
    navigator.vibrate([200, 100, 200, 100, 200]);
  }

  // Synthesize sound chime
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const playNote = (freq, delay, dur) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime + delay);
      gain.gain.setValueAtTime(0, audioCtx.currentTime + delay);
      gain.gain.linearRampToValueAtTime(0.3, audioCtx.currentTime + delay + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + delay + dur);
      osc.start(audioCtx.currentTime + delay);
      osc.stop(audioCtx.currentTime + delay + dur);
    };
    playNote(523.25, 0, 0.4); // C5
    playNote(659.25, 0.15, 0.4); // E5
    playNote(783.99, 0.3, 0.6); // G5
  } catch(e) {}
}

// Setup buttons listeners
function setupEventListeners() {
  document.getElementById('btnOpenCart').onclick = openCartSheet;
  document.getElementById('btnCloseCart').onclick = closeCartSheet;
  
  document.getElementById('btnCloseMods').onclick = closeModifiersSheet;
  
  const decBtn = document.getElementById('btnModQtyDec');
  if (decBtn) {
    decBtn.onclick = (e) => {
      e.preventDefault();
      if (currentModQty > 1) {
        currentModQty--;
        currentModSelections.pop();
        if (currentModActiveIndex >= currentModQty) {
          currentModActiveIndex = currentModQty - 1;
        }
        renderModifiersModal();
      }
    };
  }

  const incBtn = document.getElementById('btnModQtyInc');
  if (incBtn) {
    incBtn.onclick = (e) => {
      e.preventDefault();
      currentModQty++;
      const applyAllChk = document.getElementById('chkModApplyToAll');
      if (applyAllChk && applyAllChk.checked) {
        currentModSelections.push(JSON.parse(JSON.stringify(currentModSelections[0] || {})));
      } else {
        currentModSelections.push({});
      }
      renderModifiersModal();
    };
  }

  const applyAllChk = document.getElementById('chkModApplyToAll');
  if (applyAllChk) {
    applyAllChk.onchange = () => {
      if (applyAllChk.checked) {
        syncApplyToAll();
      }
      renderModifiersModal();
    };
  }

  document.getElementById('btnConfirmAddMods').onclick = () => {
    if (!currentModProduct) return;
    const groups = currentModProduct.modifiers || currentModProduct.modifierGroups || [];
    const applyAllChk = document.getElementById('chkModApplyToAll');
    
    if (applyAllChk && applyAllChk.checked) {
      syncApplyToAll();
    }

    // Validate required options for EVERY item
    for (let i = 0; i < currentModQty; i++) {
      const itemSel = currentModSelections[i] || {};
      for (const group of groups) {
        const isReq = group.required || (group.minSelection > 0);
        const sel = itemSel[group.id];
        if (isReq && (!sel || (Array.isArray(sel) && sel.length === 0))) {
          const shortName = currentModProduct.name.split(' ')[0];
          alert(`Por favor elige una opción de "${group.name}" para el ${shortName} #${i + 1} / Please choose an option for ${shortName} #${i + 1}`);
          currentModActiveIndex = i;
          renderModifiersModal();
          return;
        }
      }
    }

    // Add items to cart (grouping items with identical modifiers together)
    for (let i = 0; i < currentModQty; i++) {
      const itemSel = currentModSelections[i] || {};
      const chosenModifiers = [];
      groups.forEach(g => {
        const sel = itemSel[g.id];
        if (Array.isArray(sel)) {
          chosenModifiers.push(...sel);
        } else if (sel) {
          chosenModifiers.push(sel);
        }
      });

      addToCart(currentModProduct, chosenModifiers);
    }

    closeModifiersSheet();
  };

  document.getElementById('btnPlaceOrder').onclick = submitCarOrder;

  document.getElementById('btnBackToMenu').onclick = () => {
    currentOrderId = null;
    currentTicketNumber = null;
    if (ws) ws.close();
    
    document.getElementById('trackingPanel').style.display = 'none';
    document.getElementById('mainHeader').style.display = 'block';
    document.getElementById('categoriesBar').style.display = 'flex';
    document.getElementById('menuList').style.display = 'flex';
    updateCartUI();
  };

  // Toggle vehicle input based on selection (Carside vs Online Pickup)
  const rads = document.querySelectorAll('input[name="chkDeliveryType"]');
  rads.forEach(rad => {
    rad.addEventListener('change', () => {
      const carGroup = document.getElementById('carGroupContainer');
      const carInput = document.getElementById('chkCar');
      if (rad.value === 'pickup') {
        carGroup.style.display = 'none';
        carInput.required = false;
        carInput.value = '';
      } else {
        carGroup.style.display = 'block';
        carInput.required = true;
      }
    });
  });

  document.getElementById('btnDismissMobileCall').onclick = () => {
    document.getElementById('mobileCallOverlay').style.display = 'none';
  };
}

// Toast alerts helper
function showToast(msg) {
  const box = document.createElement('div');
  box.style.position = 'fixed';
  box.style.bottom = '100px';
  box.style.left = '50%';
  box.style.transform = 'translateX(-50%)';
  box.style.backgroundColor = 'rgba(0,0,0,0.85)';
  box.style.border = '1px solid var(--accent-color)';
  box.style.padding = '8px 16px';
  box.style.borderRadius = '20px';
  box.style.fontSize = '12px';
  box.style.color = '#fff';
  box.style.zIndex = '999';
  box.innerHTML = msg;

  document.body.appendChild(box);
  setTimeout(() => box.remove(), 2000);
}


function updatePaymentInstructionUI() {
  const method = document.querySelector('input[name="chkPaymentMethod"]:checked')?.value || 'cash';
  const instrEl = document.getElementById('lblPaymentInstruction');
  if (!instrEl) return;
  if (method === 'cash') {
    instrEl.innerText = "Una persona viene con su producto ahorita en un momento, páguele a esa persona en efectivo. / A server will bring your order shortly, please pay cash upon delivery.";
  } else {
    instrEl.innerText = "Una persona le llevará la terminal portátil con su orden para cobrarle con tarjeta. / A server will bring the mobile card reader with your order to process your card.";
  }
}
window.updatePaymentInstructionUI = updatePaymentInstructionUI;

async function checkAndInitTableSession(tableNum) {
  try {
    const res = await fetch(`${SERVER_URL}/api/tables/${tableNum}/status`);
    if (res.ok) {
      const status = await res.json();
      if (!status.assigned) {
        // Table is not currently assigned in POS
        const modal = document.getElementById('modalTableWelcome');
        const badge = document.getElementById('lblWelcomeTableBadge');
        if (badge) badge.innerText = `TABLE / MESA ${tableNum}`;
        if (modal) modal.style.display = 'flex';
      } else if (status.hasUnpaidRound) {
        // Show notification that current round is unpaid
        const catContainer = document.getElementById('categoryBar') || document.querySelector('.category-bar');
        if (catContainer && !document.getElementById('bannerTableUnpaidNotice')) {
          const banner = document.createElement('div');
          banner.id = 'bannerTableUnpaidNotice';
          banner.style.cssText = 'background: rgba(255,69,58,0.2); border: 1.5px solid #ff453a; color: #fff; padding: 12px; margin: 10px 16px; border-radius: 8px; font-size: 13px; text-align: center; font-weight: bold; line-height: 1.4;';
          banner.innerHTML = `Su orden actual (#${status.ticketNumber}) está siendo atendida.<br>Por favor liquide su pago con su mesera antes de ordenar otra ronda.<br><span style="font-size: 11px; opacity: 0.85;">Your current order (#${status.ticketNumber}) is being served. Please settle payment with your server before placing another round.</span>`;
          catContainer.parentNode.insertBefore(banner, catContainer);
        }
        const btnPlace = document.getElementById('btnPlaceOrder');
        if (btnPlace) {
          btnPlace.disabled = true;
          btnPlace.style.opacity = '0.5';
          btnPlace.innerText = 'Ronda Pendiente de Pago / Settle with Server';
        }
      } else {
        // Previous round is paid: check if we can offer reordering same round
        const lastSaved = localStorage.getItem('last_table_round_' + tableNum) || (status.lastRoundItems && status.lastRoundItems.length ? JSON.stringify(status.lastRoundItems) : null);
        if (lastSaved) {
          try {
            const reorderItems = JSON.parse(lastSaved);
            if (Array.isArray(reorderItems) && reorderItems.length > 0) {
              showReorderRoundCard(reorderItems, tableNum);
            }
          } catch(e) {}
        }
      }
    }
  } catch(e) {
    console.warn('Error checking table status:', e);
  }
}

function showReorderRoundCard(reorderItems, tableNum) {
  const catContainer = document.getElementById('categoryBar') || document.querySelector('.category-bar');
  if (!catContainer || document.getElementById('cardReorderSameRound')) return;
  const card = document.createElement('div');
  card.id = 'cardReorderSameRound';
  card.style.cssText = 'background: rgba(255,159,10,0.12); border: 2px solid var(--accent-color); color: #fff; padding: 16px; margin: 12px 16px; border-radius: 12px; display: flex; flex-direction: column; gap: 10px;';
  const itemNames = reorderItems.map(it => `${it.quantity || 1}x ${it.name}`).join(', ');
  card.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <span style="font-size: 11px; font-weight: 800; color: var(--accent-color); text-transform: uppercase;">Mesa ${tableNum} • Ronda Anterior</span>
      <button type="button" onclick="document.getElementById('cardReorderSameRound').style.display='none'" style="background:none; border:none; color:var(--text-secondary); font-size:18px; cursor:pointer;">&times;</button>
    </div>
    <div style="font-size: 14.5px; font-weight: 800; color: #fff;">
      ¿Quieres ordenar una ronda igual o prefieres pedir algo diferente?
      <div style="font-size: 11px; font-weight: normal; color: var(--text-secondary); margin-top: 2px;">
        Would you like to order the same round or add different items?
      </div>
    </div>
    <div style="font-size: 12px; color: #cbd5e1; background: rgba(0,0,0,0.3); padding: 8px 10px; border-radius: 6px; border: 1px dashed rgba(255,255,255,0.15);">
      ${itemNames}
    </div>
    <div style="display: flex; gap: 10px; margin-top: 4px;">
      <button type="button" id="btnDoReorderSameRound" style="flex: 1.2; background: var(--accent-color); color: #000; font-weight: 800; font-size: 13px; border: none; padding: 12px 8px; border-radius: 8px; cursor: pointer; text-align: center;">
        Misma Ronda / Same Round
      </button>
      <button type="button" id="btnDoOrderDifferent" style="flex: 1; background: #1f2937; color: #fff; font-weight: 700; font-size: 12px; border: 1px solid #374151; padding: 12px 8px; border-radius: 8px; cursor: pointer; text-align: center;">
        Algo Diferente / Different
      </button>
    </div>
  `;
  catContainer.parentNode.insertBefore(card, catContainer);

  document.getElementById('btnDoReorderSameRound')?.addEventListener('click', () => {
    cart = [...reorderItems];
    updateCartUI();
    openCartSheet();
  });

  document.getElementById('btnDoOrderDifferent')?.addEventListener('click', () => {
    document.getElementById('cardReorderSameRound').style.display = 'none';
  });
}
