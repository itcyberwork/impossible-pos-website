@echo off
setlocal EnableDelayedExpansion
title Install Kitchen KDS (Spanish) - Impossible POS
color 0B

echo ======================================================================
echo   IMPOSSIBLE POS - KIOSK SHORTCUT INSTALLER
echo   Station: Kitchen KDS (Spanish / Espanol)
echo ======================================================================
echo.

set "SERVER_IP="
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"
if "%SERVER_IP%"=="" set "SERVER_IP=127.0.0.1"

set "SHORTCUT_NAME=Impossible POS - Cocina KDS (Espanol).lnk"
set "ICON_NAME=kitchen.ico"
set "APP_DIR=%LOCALAPPDATA%\ImpossiblePOS"
set "ICON_DEST=%APP_DIR%\Icons\%ICON_NAME%"
set "LAUNCH_BAT=%APP_DIR%\launch_kitchen_es.bat"

if not exist "%APP_DIR%\Icons" mkdir "%APP_DIR%\Icons"

:: 1. Copy or download the official icon
echo [1/3] Setting up the official icon...
if exist "%~dp0Icons\%ICON_NAME%" (
    copy /Y "%~dp0Icons\%ICON_NAME%" "%ICON_DEST%" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1
    if not exist "%ICON_DEST%" (
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1
    )
)

:: 2. Copy or download the DHCP auto-discovery script
if exist "%~dp0discover_server.ps1" (
    copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\discover_server.ps1" >nul
) else (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/kiosco/discover_server.ps1', '%APP_DIR%\discover_server.ps1')" >nul 2>&1
    if not exist "%APP_DIR%\discover_server.ps1" (
        curl -s -o "%APP_DIR%\discover_server.ps1" "http://%SERVER_IP%:3000/kiosco/discover_server.ps1" >nul 2>&1
    )
)

echo %SERVER_IP%>"%APP_DIR%\server_ip.txt"

:: 3. Locate a Chromium browser (Edge or Chrome)
echo [2/3] Locating a compatible browser (Edge or Chrome)...
set "BROWSER_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) else if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
)

if "%BROWSER_EXE%"=="" (
    echo ERROR: Neither Microsoft Edge nor Google Chrome was found on this computer.
    pause
    exit /b 1
)

:: 4. Generate the direct kiosk launcher
echo @echo off > "%LAUNCH_BAT%"
echo set "APP_DIR=%%LOCALAPPDATA%%\ImpossiblePOS" >> "%LAUNCH_BAT%"
echo set "SERVER_IP=%SERVER_IP%" >> "%LAUNCH_BAT%"
echo if exist "%%APP_DIR%%\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\server_ip.txt" >> "%LAUNCH_BAT%"
echo if exist "%%APP_DIR%%\discover_server.ps1" for /f "usebackq delims=" %%%%i in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\discover_server.ps1" -LastKnownIp "%%SERVER_IP%%"`^) do if not "%%%%i"=="" set "SERVER_IP=%%%%i" >> "%LAUNCH_BAT%"
echo start "" "%BROWSER_EXE%" --app="http://%%SERVER_IP%%:3000/cocina.html" --kiosk --no-first-run >> "%LAUNCH_BAT%"
echo exit >> "%LAUNCH_BAT%"

:: 5. Create Desktop shortcut and Windows Startup auto-launch
echo [3/3] Creating Desktop shortcut and auto-start configuration...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = 'Main Kitchen Display Spanish (KDS Tickets)'; $shortcut.Save(); $startup = $ws.SpecialFolders('Startup'); $sShortcut = $ws.CreateShortcut($startup + '\%SHORTCUT_NAME%'); $sShortcut.TargetPath = '%LAUNCH_BAT%'; $sShortcut.WorkingDirectory = '%APP_DIR%'; $sShortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $sShortcut.IconLocation = '%ICON_DEST%,0' }; $sShortcut.Save();"

:: 6. Create clean Desktop instructions file in Spanish
set "GUIDE_FILE=%USERPROFILE%\Desktop\INSTRUCCIONES_TECLADO_COCINA.txt"
(
echo ======================================================================
echo   IMPOSSIBLE POS - PANTALLA DE COCINA ^(KDS^)
echo   GUIA RAPIDA DE OPERACION CON TECLADO NUMERICO ^(BUMP BAR^)
echo ======================================================================
echo.
echo 1. ENCENDIDO AUTOMATICO ^(AL PRENDER LA COMPUTADORA^):
echo    - Simplemente presione el boton de encendido de la computadora.
echo    - Windows arranca y abre AUTOMATICAMENTE la Pantalla de Cocina
echo      en pantalla completa. NO necesita mouse ni teclado completo.
echo.
echo 2. COMO MANEJAR LAS COMANDAS CON EL TECLADO NUMERICO:
echo    - [ 1 ] al [ 9 ] : Seleccionar la comanda directamente.
echo    - [ + ]          : Avanzar a la siguiente comanda.
echo    - [ - ]          : Retroceder a la comanda anterior.
echo    - [ ENTER ]      : Abrir y ver la orden / comanda completa.
echo    - [ . ] o [Del]  : Despachar / Terminar comanda ^(la borra de cocina^).
echo    - [ * ]          : Imprimir hoja o comanda de trabajo.
echo    - [ / ]          : Ver foto de referencia ^(pasteles y pedidos^).
echo    - [ Tab ]        : Alternar entre Cocina Activa e Historial de ordenes.
echo    - [ Backspace ]  : Cerrar ventana emergente o volver a la primera orden.
echo.
echo 3. COMO APAGAR LA COMPUTADORA AL TERMINAR EL DIA:
echo    - Presione la tecla [ 0 ] dos veces rapido: [ 0 ] [ 0 ]
echo    - Aparecera una pantalla roja preguntando si desea apagar el equipo.
echo    - Presione [ ENTER ] para confirmar y la computadora se apagara sola.
echo    - ^(Si se presiono por error, presione cualquier otra tecla para cancelar^).
echo.
echo 4. SI EL PROGRAMA SE CIERRA POR ACCIDENTE:
echo    - Abra el acceso directo "Impossible POS - Cocina KDS" en el escritorio.
echo ======================================================================
) > "%GUIDE_FILE%"

echo.
echo ======================================================================
echo   SUCCESS: Kitchen KDS (Spanish) configured on this computer:
echo.
echo   - Desktop Shortcut: "%SHORTCUT_NAME%"
echo   - Auto-Start on Boot: ENABLED (Starts automatically on power-on)
echo   - Keypad Guide: "INSTRUCCIONES_TECLADO_COCINA.txt" on Desktop
echo   - Mode: Full-Screen Kiosk (DHCP auto-discovery active)
echo   - URL:  http://%SERVER_IP%:3000/cocina.html?lang=es
echo   - Language: Spanish (Espanol)
echo ======================================================================
echo.
echo Starting Kitchen KDS (Spanish) in full screen...
start "" "%LAUNCH_BAT%"
timeout /t 2 >nul
exit
