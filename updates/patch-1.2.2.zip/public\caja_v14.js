// --- CAPTURA DE ERRORES GLOBAL PARA DIAGNÓSTICO ---
window.onerror = function(message, source, lineno, colno, error) {
  const errData = {
    message: message,
    source: source,
    lineno: lineno,
    colno: colno,
    stack: error ? error.stack : ''
  };
  fetch('/api/debug/error', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(errData)
  }).catch(() => {});
};
window.onunhandledrejection = function(event) {
  const errData = {
    message: 'Unhandled Promise Rejection: ' + event.reason,
    stack: event.reason ? event.reason.stack : ''
  };
  fetch('/api/debug/error', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(errData)
  }).catch(() => {});
};

// --- CONFIGURACIÓN DE CONEXIÓN LOCAL ---
const SERVER_URL = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
const WS_URL = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.hostname}:${window.location.port}`;

// --- ESTADO LOCAL DEL POS ---
let products = [];
let cart = [];
let selectedCategory = 'panaderia';
let activePastelesSubCategory = 'root'; // 'root', 'regular', o 'tres_leches'
let heldOrders = []; // Cuentas en espera
let deliveryType = 'walkin';
let currentCarDescription = '';
window.currentCarDescription = '';
let activeTabOrderId = null;
let tabTableNumber = '';
let tabClientCount = 0;
let activeTabClientSeat = null;
let currentLoyaltyClient = null;
let activeWebSocket = null;
let tempLoyaltyClient = null; // Cliente temporal para el modal de acciones
let actionTargetOrderId = null; // Orden objetivo para cancelación o reembolso
let actionType = 'void'; // 'void' o 'refund'
let selectedVoidReason = '';  // Motivo de cancelación/reembolso activo
let authSuccessCallback = null; // Callback tras autorización exitosa
let authRequiredRole = null; // Rol requerido para autorizar: 'manager', 'admin' o null
let fingerprintPressTimeout = null; // Control del escáner de huella
let currentCashierName = ''; // Cajero activo por defecto
let cardReaderBuffer = ''; // Buffer para lector de tarjetas USB
let cardReaderTimeout = null; // Control del tiempo entre caracteres del lector
let lastKeyTime = 0; // Tiempo del último evento de tecla
let activeShift = null; // Turno activo (sincronizado con base de datos)
let currentCashierDrawer = 1; // Cajón físico asignado a la cajera activa (1 o 2)
let selectedOpenShiftDrawer = 1; // Cajón seleccionado en modal de apertura
let idleTimer = null; // Temporizador para bloqueo de inactividad
let splashPasscodeString = ''; // Cadena para la contraseña en la Splash screen
let editingEmployeeId = null; // Almacena ID del empleado en edición
let tempFingerprintRegistered = false;
let tempFingerprintTemplate = null;
let cachedEmployees = [];

async function getEmployeesList(forceRefresh = false) {
  if (!forceRefresh && cachedEmployees.length > 0) {
    return cachedEmployees;
  }
  try {
    const response = await fetch(`${SERVER_URL}/api/employees`);
    if (response.ok) {
      cachedEmployees = await response.json();
      return cachedEmployees;
    }
  } catch (err) {
    console.error("Error fetching employees:", err);
  }
  return cachedEmployees;
}

function sortProducts(list) {
  if (!Array.isArray(list)) return [];
  return list.sort((a, b) => {
    const orderA = a.order !== undefined && a.order !== null ? Number(a.order) : 9999;
    const orderB = b.order !== undefined && b.order !== null ? Number(b.order) : 9999;
    if (orderA !== orderB) return orderA - orderB;
    return a.name.localeCompare(b.name);
  });
}

let activeInventoryFolder = '';
let activeVirtualKeyboardInput = null;
let virtualKeyboardShift = false;
let lastFilteredOrders = [];
let activeInventorySubFolder = '';
let customSubFolders = [];
let activeSalesSubCategory = '';
let keyboardAccentActive = false;
let virtualKeyboardLanguage = 'ES';
let sessionAdminAuthorized = false;
let sessionManagerAuthorized = false;
let posSettings = { taxRate: 6 };
let activePunchEmployee = null;
let punchCountdownTimer = null;
let punchCountdownSeconds = 10;
let activeLoyaltyRequest = null;
let waitlist = [];
let globalModifierGroups = [];
let globalSingleModifiers = [];

// --- TRADUCCIONES DEL SISTEMA (INGLES / ESPAÑOL) ---
const UI_TRANSLATIONS = {
  en: {
    welcomeTitle: "Welcome! Setup Your Business POS",
    welcomeDesc: "Configure this POS installation for your local store. These settings will adapt the screen title, order options, and tax rate automatically.",
    langLabel: "System Language (Idioma del Sistema)",
    bizNameLabel: "Business Name",
    bizTypeLabel: "Business Type",
    taxRateLabel: "Tax Rate (%)",
    addressLabel: "Address",
    phoneLabel: "Phone",
    websiteLabel: "Website",
    servicesLabel: "Select Enabled Services",
    btnSaveWizard: "Save & Launch POS",
    
    tabCheckout: "🛒 Checkout",
    tabOrders: "📋 Orders & Tickets",
    tabManager: "👔 Manager",
    tabSetup: "🛠️ Setup",
    tabLogs: "📜 Logs",
    
    cartTitle: "Current Order",
    btnWalk: "Walk",
    btnToGo: "ToGo",
    btnDineIn: "In",
    btnDriveThru: "Thru",
    btnPickup: "Pick",
    btnDelivery: "Deliv",
    lblSubtotal: "Subtotal:",
    lblTax: "Tax",
    lblTotal: "Total:",
    lblDeposit: "Deposit",
    lblBalance: "Balance Due",
    btnPay: "PAY",
    btnCancel: "Clear Cart",
    
    setupTitle: "🛠️ Setup",
    hardwareSettings: "⚙️ Hardware & Device Integrations",
    printerType: "Sales Receipt Printer Type",
    printerSelect: "Select Printer",
    labelPrinter: "Cake Label Printer Name",
    kitchenPrinter: "Kitchen KDS Printer Name",
    reportPrinter: "Shift Report Printer Name",
    stationId: "Station/Register ID",
    paymentTerminal: "Credit Card Terminal Type",
    biometricScanner: "Biometric Scanner WebSocket",
    businessProfile: "🏢 Business Profile & Services",
    servicesOrderTypes: "Enabled Services / Order Types",
    languageSelect: "System Language (Idioma)",
    departmentsTabs: "📁 POS Departments & Tabs",
    saveSettings: "Save Settings",
    
    modalTitleCustomCake: "New Custom Cake",
    labelCustomerName: "Customer Name",
    labelCustomerPhone: "Customer Phone",
    labelPickupDate: "Pickup Date",
    labelPickupTime: "Pickup Time",
    flavorAvailable: "Flavor Available",
    sizes: "Sizes",
    additionsFruits: "Additions / Fruits",
    fillings: "Fillings",
    quotedPrice: "Quoted Price ($)",
    decorationNotes: "Decoration Specifications / Notes",
    uploadPhoto: "Upload Reference Photo"
  },
  es: {
    welcomeTitle: "🚀 ¡Bienvenido! Configura tu POS",
    welcomeDesc: "Configura esta instalación de POS para tu negocio local. Estos ajustes adaptarán automáticamente el título de la pantalla, las opciones de servicio y el impuesto.",
    langLabel: "Idioma del Sistema (System Language)",
    bizNameLabel: "Nombre del Negocio",
    bizTypeLabel: "Tipo de Negocio",
    taxRateLabel: "Impuestos (%)",
    addressLabel: "Dirección",
    phoneLabel: "Teléfono",
    websiteLabel: "Sitio Web",
    servicesLabel: "Seleccionar Servicios Habilitados",
    btnSaveWizard: "Guardar e Iniciar POS",
    
    tabCheckout: "🛒 Caja",
    tabOrders: "📋 Órdenes y Tickets",
    tabManager: "👔 Gerente",
    tabSetup: "🛠️ Configuración",
    tabLogs: "📜 Actividad",
    
    cartTitle: "Pedido Actual",
    btnWalk: "Mostra",
    btnToGo: "Llevar",
    btnComer: "Mesa",
    btnThru: "Auto",
    btnPick: "Recog",
    btnDeliv: "Domic",
    lblSubtotal: "Subtotal:",
    lblTax: "Impuesto",
    lblTotal: "Total:",
    lblDeposit: "Depósito",
    lblBalance: "Saldo Pendiente",
    btnPay: "COBRAR",
    btnCancel: "Vaciar Carrito",
    
    setupTitle: "🛠️ Configuración",
    hardwareSettings: "⚙️ Integración de Hardware",
    printerType: "Tipo de Impresora de Recibos",
    printerSelect: "Seleccionar Impresora",
    labelPrinter: "Impresora de Etiquetas de Pasteles",
    kitchenPrinter: "Impresora de Cocina (KDS)",
    reportPrinter: "Impresora de Reportes de Turno",
    stationId: "ID de Estación / Caja",
    paymentTerminal: "Tipo de Terminal de Pago",
    biometricScanner: "WebSocket de Lector Biométrico",
    businessProfile: "🏢 Perfil de Negocio y Servicios",
    servicesOrderTypes: "Servicios Habilitados / Tipos de Orden",
    languageSelect: "Idioma del Sistema (Idioma)",
    departmentsTabs: "📁 Departamentos y Pestañas POS",
    saveSettings: "Guardar Configuración",
    
    modalTitleCustomCake: "Nuevo Pastel Especial",
    labelCustomerName: "Nombre del Cliente",
    labelCustomerPhone: "Teléfono del Cliente",
    labelPickupDate: "Fecha de Entrega",
    labelPickupTime: "Hora de Entrega",
    flavorAvailable: "Sabor Disponible",
    sizes: "Tamaños",
    additionsFruits: "Frutas / Extras",
    fillings: "Rellenos",
    quotedPrice: "Precio Cotizado ($)",
    decorationNotes: "Especificaciones de Decoración / Notas",
    uploadPhoto: "Cargar Foto de Referencia"
  }
};

function applyTranslations(lang) {
  const isEs = lang === 'es';
  
  const btnHelpSupport = document.getElementById('btnRequestSupport');
  if (btnHelpSupport) btnHelpSupport.innerText = isEs ? 'AYUDA / SOPORTE' : 'HELP / SUPPORT';

  const lblOptLinkDevicesTitle = document.getElementById('lblOptLinkDevicesTitle');
  if (lblOptLinkDevicesTitle) lblOptLinkDevicesTitle.innerText = isEs ? 'Vincular Dispositivos' : 'Link Mobile Devices';
  const lblOptLinkDevicesDesc = document.getElementById('lblOptLinkDevicesDesc');
  if (lblOptLinkDevicesDesc) lblOptLinkDevicesDesc.innerText = isEs ? 'Códigos QR para meseros, cocina KDS, barra y reportes móviles' : 'QR codes for waiters, kitchen KDS, bar, and mobile reports';

  const lblBtnCartWeighText = document.getElementById('lblBtnCartWeighText');
  if (lblBtnCartWeighText) lblBtnCartWeighText.innerText = isEs ? 'Pesar' : 'Weigh';
  const lblScaleModalTitle = document.getElementById('lblScaleModalTitle');
  if (lblScaleModalTitle) lblScaleModalTitle.innerText = isEs ? '⚖️ Báscula Digital USB' : '⚖️ USB Digital Scale';
  const btnScaleTare = document.getElementById('btnScaleTare');
  if (btnScaleTare) btnScaleTare.innerText = isEs ? '0.00 Tarar' : '0.00 Tare';
  const btnScaleRead = document.getElementById('btnScaleRead');
  if (btnScaleRead) btnScaleRead.innerText = isEs ? '🔄 Leer Báscula' : '🔄 Read Scale';
  const btnScaleZero = document.getElementById('btnScaleZero');
  if (btnScaleZero) btnScaleZero.innerText = isEs ? 'Cero' : 'Zero';
  const btnScaleAddToCart = document.getElementById('btnScaleAddToCart');
  if (btnScaleAddToCart) btnScaleAddToCart.innerText = isEs ? '➕ Poner en Cuenta' : '➕ Add to Cart';
  const lblSupportWhatsAppText = document.getElementById('lblSupportWhatsAppText');
  if (lblSupportWhatsAppText) lblSupportWhatsAppText.innerText = isEs ? '💬 Chatear con Soporte por WhatsApp' : '💬 Chat with Support on WhatsApp';
  const lblBlockZelleWhatsAppBtn = document.getElementById('lblBlockZelleWhatsAppBtn');
  if (lblBlockZelleWhatsAppBtn) lblBlockZelleWhatsAppBtn.innerText = isEs ? '💬 Enviar Comprobante por WhatsApp' : '💬 Send Proof on WhatsApp';

  // Remote support banner translations
  const txtBannerRemoteSupport = document.getElementById('txtBannerRemoteSupport');
  if (txtBannerRemoteSupport) {
    txtBannerRemoteSupport.innerText = isEs 
      ? 'Impossible POS™ • Sesión de soporte remoto en curso' 
      : 'Impossible POS™ • Remote support session in progress';
  }
  const lblSupportTechPhone = document.getElementById('lblSupportTechPhone');
  if (lblSupportTechPhone) {
    lblSupportTechPhone.innerText = isEs ? 'Soporte Técnico: (313) 312-9090' : 'Technical Support: (313) 312-9090';
  }
  const btnEndSupportSession = document.getElementById('btnEndSupportSession');
  if (btnEndSupportSession) {
    btnEndSupportSession.innerText = isEs ? 'Finalizar' : 'End Session';
  }
  const lblToggleSupportBannerText = document.getElementById('lblToggleSupportBannerText');
  if (lblToggleSupportBannerText) {
    lblToggleSupportBannerText.innerText = isEs ? 'Mostrar / Ocultar Aviso de Soporte' : 'Show / Hide Support Banner';
  }

  // Sidebar options tabs
  const btnOptCashier = document.getElementById('btnOptCashier');
  if (btnOptCashier) btnOptCashier.innerHTML = isEs ? '💵 Opciones de Cajero' : '💵 Cashier Options';

  const btnOptTickets = document.getElementById('btnOptTickets');
  if (btnOptTickets) btnOptTickets.innerHTML = isEs ? '🎫 Opciones de Ticket' : '🎫 Ticket Options';

  const lblOptCashierHeader = document.getElementById('lblOptCashierHeader');
  if (lblOptCashierHeader) lblOptCashierHeader.innerText = isEs ? '💵 Control de Cajero' : '💵 Cashier Control';

  const btnOptCashierChange = document.getElementById('btnOptCashierChange');
  if (btnOptCashierChange) btnOptCashierChange.innerText = isEs ? '🔄 Cambiar Cajero' : '🔄 Change Cashier';
  
  const btnOptManager = document.getElementById('btnOptManager');
  if (btnOptManager) btnOptManager.innerHTML = isEs ? '🔑 Panel de Gerente' : '🔑 Manager Panel';
  
  const btnOptInventory = document.getElementById('btnOptInventory');
  if (btnOptInventory) btnOptInventory.innerHTML = isEs ? '📦 Inventario' : '📦 Product Inventory';
  
  const btnOptAdmin = document.getElementById('btnOptAdmin');
  if (btnOptAdmin) btnOptAdmin.innerHTML = isEs ? '🛠️ Configuración' : '🛠️ Setup';

  const lblFindSettings = document.getElementById('lblFindSettings');
  if (lblFindSettings) lblFindSettings.innerText = isEs ? 'Buscar Ajustes' : 'Find Settings';

  const optionsGlobalSearch = document.getElementById('optionsGlobalSearch');
  if (optionsGlobalSearch) {
    optionsGlobalSearch.placeholder = isEs ? 'Buscar (ej. QR, Mesas, Cocina)...' : 'Search (e.g. QR, Mesa)...';
  }

  const lblFindSettingsHint = document.getElementById('lblFindSettingsHint');
  if (lblFindSettingsHint) {
    lblFindSettingsHint.innerHTML = isEs 
      ? 'Escribe palabra clave (ej. <em>QR</em>, <em>mesas</em>, <em>cocina</em>, <em>corte</em>)' 
      : 'Type any keyword (e.g. <em>QR</em>, <em>mesas</em>, <em>kitchen</em>, <em>corte</em>)';
  }

  const lblSearchResultsTitle = document.getElementById('lblSearchResultsTitle');
  if (lblSearchResultsTitle) lblSearchResultsTitle.innerText = isEs ? 'Resultados de Búsqueda' : 'Search Results';
  
  // Cart headers/buttons
  if (btnClearCart) btnClearCart.innerHTML = isEs ? '🗑️<span style="font-size: 8px; display: block; margin-top: 2px;">Vaciar</span>' : '🗑️<span style="font-size: 8px; display: block; margin-top: 2px;">Clear</span>';
  
  const btnLoyalty = document.getElementById('btnLoyalty');
  if (btnLoyalty) btnLoyalty.innerHTML = isEs ? '👤 Clientes' : '👤 Customers';
  
  const btnHoldOrder = document.getElementById('btnHoldOrder');
  if (btnHoldOrder) btnHoldOrder.innerHTML = isEs ? 'Retener' : 'Hold';
  
  const btnRecallOrder = document.getElementById('btnRecallOrder');
  if (btnRecallOrder) {
    const count = document.getElementById('lblHeldCount') ? document.getElementById('lblHeldCount').innerText : '0';
    btnRecallOrder.innerHTML = `${isEs ? 'Pausa' : 'Held'} (<span id="lblHeldCount">${count}</span>)`;
  }
  
  const btnRecallTickets = document.getElementById('btnRecallTickets');
  if (btnRecallTickets) btnRecallTickets.innerHTML = isEs ? 'Tickets' : 'Tickets';

  const btnBulkGiftTable = document.getElementById('btnBulkGiftTable');
  if (btnBulkGiftTable) btnBulkGiftTable.innerHTML = isEs ? 'Cortesía' : 'Gift';
  
  const btnOpenCheckout = document.getElementById('btnOpenCheckout');
  if (btnOpenCheckout) btnOpenCheckout.innerText = isEs ? 'COBRAR' : 'PAY';

  const btnSendOrder = document.getElementById('btnSendOrder');
  if (btnSendOrder) btnSendOrder.innerText = isEs ? 'ENVIAR' : 'SEND';

  const btnOpenTab = document.getElementById('btnOpenTab');
  if (btnOpenTab) {
    if (btnOpenTab.tagName === 'BUTTON') {
      btnOpenTab.innerText = isEs ? 'ABRIR TAB' : 'OPEN TAB';
    } else {
      const title = btnOpenTab.querySelector('.box-title');
      const desc = btnOpenTab.querySelector('.box-desc');
      if (title) title.innerText = isEs ? 'Abrir Cuenta' : 'Open Tab';
      if (desc) desc.innerText = isEs ? 'Iniciar una nueva mesa o cuenta' : 'Start a new table or customer tab account';
    }
  }

  const btnRecallTabs = document.getElementById('btnRecallTabs');
  if (btnRecallTabs) {
    if (btnRecallTabs.tagName === 'BUTTON') {
      btnRecallTabs.innerText = isEs ? 'TABS' : 'TABS';
    } else {
      const title = btnRecallTabs.querySelector('.box-title');
      const desc = btnRecallTabs.querySelector('.box-desc');
      if (title) title.innerText = isEs ? 'Cuentas Activas' : 'Active Tabs';
      if (desc) desc.innerText = isEs ? 'Ver y recuperar cuentas de mesas activas' : 'View and recall active table accounts';
    }
  }

  const btnOpenDrawer = document.getElementById('btnOpenDrawer');
  if (btnOpenDrawer) {
    if (btnOpenDrawer.tagName === 'BUTTON') {
      btnOpenDrawer.innerText = isEs ? '🔓 Abrir Cajón' : '🔓 Open Drawer';
    } else {
      const title = btnOpenDrawer.querySelector('.box-title');
      const desc = btnOpenDrawer.querySelector('.box-desc');
      if (title) title.innerText = isEs ? 'Abrir Cajón' : 'Open Cash Drawer';
      if (desc) desc.innerText = isEs ? 'Abrir el cajón de dinero manualmente' : 'Open the register cash drawer manually';
    }
  }

  const selKitchenFont = document.getElementById('adminKitchenTicketFontSize');
  if (selKitchenFont) {
    const val = selKitchenFont.value || '5';
    selKitchenFont.innerHTML = isEs ? `
      <option value="1">1. Compacto (1x1 Normal)</option>
      <option value="2">2. Alto Doble (1x2)</option>
      <option value="3">3. Ancho Doble (2x1)</option>
      <option value="4">4. Grande Estándar (2x2)</option>
      <option value="5">5. 2x2 Grande Cocina (Recomendado)</option>
    ` : `
      <option value="1">1. Compact (1x1 Normal)</option>
      <option value="2">2. Double Height (1x2)</option>
      <option value="3">3. Double Width (2x1)</option>
      <option value="4">4. Standard Large (2x2)</option>
      <option value="5">5. 2x2 Kitchen Large (Recommended)</option>
    `;
    selKitchenFont.value = val;
  }
  
  // Order types inside cartOrderTypeContainer
  const btnWalk = document.querySelector('#cartOrderTypeContainer button[data-type="walkin"]');
  if (btnWalk) btnWalk.innerText = isEs ? 'Mostra' : 'Walk';
  
  const btnToGo = document.querySelector('#cartOrderTypeContainer button[data-type="llevar"]');
  if (btnToGo) btnToGo.innerText = isEs ? 'Para Llevar' : 'To Go';
  
  const btnComer = document.querySelector('#cartOrderTypeContainer button[data-type="comer"]');
  if (btnComer) btnComer.innerText = isEs ? 'Mesa' : 'Dine In';

  const lblTabTableTitle = document.getElementById('lblTabTableTitle');
  if (lblTabTableTitle) lblTabTableTitle.innerText = isEs ? 'MESA:' : 'TABLE:';

  const lblTabActiveClientTitle = document.getElementById('lblTabActiveClientTitle');
  if (lblTabActiveClientTitle) lblTabActiveClientTitle.innerText = isEs ? 'CLIENTE ACTIVO:' : 'ACTIVE GUEST:';
  
  const btnThru = document.querySelector('#cartOrderTypeContainer button[data-type="drive-thru"]');
  if (btnThru) btnThru.innerText = isEs ? 'Auto' : 'Thru';
  
  const btnPick = document.querySelector('#cartOrderTypeContainer button[data-type="pickup"]');
  if (btnPick) btnPick.innerText = isEs ? 'Recog' : 'Pick';
  
  const btnDeliv = document.querySelector('#cartOrderTypeContainer button[data-type="delivery"]');
  if (btnDeliv) btnDeliv.innerText = isEs ? 'Domic' : 'Deliv';

  // Subtotal, Tax and Total labels
  const subtotalRow = document.querySelector('.cart-totals .total-row:nth-child(1) span:first-child');
  if (subtotalRow) subtotalRow.innerText = isEs ? 'Subtotal:' : 'Subtotal:';
  
  const taxRow = document.querySelector('.cart-totals .total-row:nth-child(2) span:first-child');
  if (taxRow) {
    taxRow.innerHTML = isEs ? 'Impuesto (<span id="lblTaxRate">6</span>%):' : 'Tax (<span id="lblTaxRate">6</span>%):';
  }
  
  const totalRow = document.querySelector('.cart-totals .grand-total span:first-child');
  if (totalRow) totalRow.innerText = isEs ? 'Total:' : 'Total:';
  
  // Deposit/Balance
  const depositLabel = document.querySelector('#cakeDepositSection label[for="inputDeposit"]');
  if (depositLabel) depositLabel.innerText = isEs ? 'Depósito' : 'Deposit';
  
  const balanceLabel = document.querySelector('#cakeDepositSection label:not([for])');
  if (balanceLabel) balanceLabel.innerText = isEs ? 'Saldo Pendiente' : 'Balance Due';

  // Custom cake modal
  const modalTitle = document.getElementById('modalTitle');
  if (modalTitle) modalTitle.innerText = isEs ? 'Nuevo Pastel Especial' : 'New Custom Cake';
  
  const labelCustName = document.querySelector('label[for="cakeClientName"]');
  if (labelCustName) labelCustName.innerText = isEs ? 'Nombre del Cliente' : 'Customer Name';
  
  const labelCustPhone = document.querySelector('label[for="cakeClientPhone"]');
  if (labelCustPhone) labelCustPhone.innerText = isEs ? 'Teléfono del Cliente' : 'Customer Phone';
  
  const labelPickDate = document.querySelector('label[for="cakePickupDate"]');
  if (labelPickDate) labelPickDate.innerText = isEs ? 'Fecha de Entrega' : 'Pickup Date';
  
  const labelPickTime = document.querySelector('label[for="cakePickupTime"]');
  if (labelPickTime) labelPickTime.innerText = isEs ? 'Hora de Entrega' : 'Pickup Time';
  
  const labelPrice = document.querySelector('label[for="cakePrice"]');
  if (labelPrice) labelPrice.innerText = isEs ? 'Precio Cotizado ($)' : 'Quoted Price ($)';
  
  const labelDeposit = document.querySelector('label[for="cakeDeposit"]');
  if (labelDeposit) labelDeposit.innerText = isEs ? 'Depósito ($)' : 'Deposit ($)';
  
  const labelBalance = document.querySelector('label[for="cakeBalance"]');
  if (labelBalance) labelBalance.innerText = isEs ? 'Saldo ($)' : 'Balance ($)';
  
  const labelNotes = document.querySelector('label[for="cakeNotes"]');
  if (labelNotes) labelNotes.innerText = isEs ? 'Especificaciones de Decoración / Notas' : 'Decoration Specifications / Notes';

  const lblSizes = document.getElementById('lblTitleSizes');
  if (lblSizes) lblSizes.innerText = isEs ? 'Tamaños' : 'Sizes';
  
  const lblFlavors = document.getElementById('lblTitleFlavors');
  if (lblFlavors) lblFlavors.innerText = isEs ? 'Sabor Disponible' : 'Flavor Available';
  
  const lblFruits = document.getElementById('lblTitleFruits');
  if (lblFruits) lblFruits.innerText = isEs ? 'Frutas / Extras' : 'Additions / Fruits';
  
  const lblFillings = document.getElementById('lblTitleFillings');
  if (lblFillings) lblFillings.innerText = isEs ? 'Rellenos' : 'Fillings';
  
  const lblGelatinas = document.getElementById('lblTitleGelatinas');
  if (lblGelatinas) lblGelatinas.innerText = isEs ? 'Gelatinas / Postres' : 'Gelatinas / Desserts';

  const lblUploadPhoto = document.getElementById('lblTitleUploadPhoto');
  if (lblUploadPhoto) lblUploadPhoto.innerText = isEs ? 'Cargar Foto de Referencia' : 'Upload Reference Photo';

  // Welcome setup wizard (Strict ID-Based Localization)
  const lblWizardHeaderTitle = document.getElementById('lblWizardHeaderTitle');
  if (lblWizardHeaderTitle) lblWizardHeaderTitle.innerHTML = isEs ? '¡Bienvenido! Configura tu Sistema POS' : 'Welcome! Setup Your Business POS';

  const lblWizardHeaderSubtitle = document.getElementById('lblWizardHeaderSubtitle');
  if (lblWizardHeaderSubtitle) {
    lblWizardHeaderSubtitle.innerText = isEs 
      ? 'Configura esta instalación de POS para tu negocio local. Estos ajustes adaptarán automáticamente el título de la pantalla, las opciones de servicio, el impuesto y el menú en línea.'
      : 'Configure this POS installation for your local store. These settings will adapt the screen title, order options, tax rate, and online menu automatically.';
  }

  const lblWizardLanguage = document.getElementById('lblWizardLanguage');
  if (lblWizardLanguage) lblWizardLanguage.innerText = isEs ? 'Idioma del Sistema / System Language' : 'System Language / Idioma del Sistema';

  const lblWizardBusinessName = document.getElementById('lblWizardBusinessName');
  if (lblWizardBusinessName) lblWizardBusinessName.innerText = isEs ? 'Nombre del Negocio (Business Name)' : 'Business Name (Nombre del Negocio)';

  const lblWizardBusinessType = document.getElementById('lblWizardBusinessType');
  if (lblWizardBusinessType) lblWizardBusinessType.innerText = isEs ? 'Tipo de Negocio (Business Type)' : 'Business Type (Tipo de Negocio)';
  const selBizType = document.getElementById('wizardBusinessType');
  if (selBizType && selBizType.options.length > 0 && selBizType.options[0].value === '') {
    selBizType.options[0].text = isEs ? '-- Selecciona Tipo de Negocio --' : '-- Select Business Type --';
  }

  const lblWizardPhone = document.getElementById('lblWizardPhone');
  if (lblWizardPhone) lblWizardPhone.innerText = isEs ? 'Teléfono del Negocio (Phone)' : 'Business Phone (Teléfono)';

  const lblWizardAddress = document.getElementById('lblWizardAddress');
  if (lblWizardAddress) lblWizardAddress.innerText = isEs ? 'Dirección Comercial (Address)' : 'Business Address (Dirección)';

  const lblWizardTaxRate = document.getElementById('lblWizardTaxRate');
  if (lblWizardTaxRate) lblWizardTaxRate.innerText = isEs ? 'Impuesto sobre Ventas (%) (Tax Rate %)' : 'Sales Tax Rate (%) (Impuesto %)';

  const lblWizardWebsite = document.getElementById('lblWizardWebsite');
  if (lblWizardWebsite) lblWizardWebsite.innerText = isEs ? 'Dominio Menú Cloud / Sitio Web (1ti1.com)' : 'Online Menu Domain / Website (1ti1.com)';

  const lblWizardWebsiteHint = document.getElementById('lblWizardWebsiteHint');
  if (lblWizardWebsiteHint) {
    lblWizardWebsiteHint.innerText = isEs 
      ? 'Configura tu subdominio de 1ti1.com (ej: tacoenmadre.1ti1.com) para pedidos en línea, QR de mesas y autoservicio.'
      : 'Use your 1ti1.com domain (e.g. tacoenmadre.1ti1.com) for online orders, table QR cards, and carside ordering.';
  }

  const lblWizardServices = document.getElementById('lblWizardServices');
  if (lblWizardServices) lblWizardServices.innerText = isEs ? 'Servicios Habilitados (Enabled Services)' : 'Select Enabled Services (Servicios Habilitados)';

  const lblWizardLogo = document.getElementById('lblWizardLogo');
  if (lblWizardLogo) lblWizardLogo.innerText = isEs ? 'Logotipo del Negocio (Logo)' : 'Business Logo (Logotipo del Negocio)';

  const lblWizardDisclaimerNoticeText = document.getElementById('lblWizardDisclaimerNoticeText');
  if (lblWizardDisclaimerNoticeText) {
    lblWizardDisclaimerNoticeText.innerHTML = isEs
      ? '<strong>Lee los Términos y Deslinde:</strong> Por favor lee el deslinde legal arriba y haz clic en la casilla de abajo para aceptar. Al marcar la casilla estás de acuerdo y aceptas los términos y condiciones. Luego presiona <strong>"Guardar e Iniciar POS"</strong> para comenzar.'
      : '<strong>Read Terms & Disclaimer:</strong> Please read the legal disclaimer above and check the box below. By checking this box, you agree to all terms and conditions stated in the disclaimer. Then click <strong>"Save & Launch POS"</strong> to start.';
  }

  const lblWizardAcceptDisclaimerText = document.getElementById('lblWizardAcceptDisclaimerText');
  if (lblWizardAcceptDisclaimerText) {
    lblWizardAcceptDisclaimerText.innerText = isEs
      ? '👉 Acepto los Términos de Servicio y Deslinde Legal'
      : '👉 I agree to the Terms of Service & Legal Disclaimer';
  }

  const btnSaveWizard = document.getElementById('btnSaveWizardSettings');
  if (btnSaveWizard) btnSaveWizard.innerText = isEs ? '🚀 Guardar e Iniciar POS' : '🚀 Save & Launch POS';

  const btnSkipWizard = document.getElementById('btnSkipWizardSettings');
  if (btnSkipWizard) btnSkipWizard.innerText = isEs ? 'Omitir y Configurar Luego' : 'Skip & Configure Later';

  // Setup Pane in options-content
  const setupTitle = document.querySelector('#paneOptAdmin > div:first-child');
  if (setupTitle) setupTitle.innerText = isEs ? '🛠️ Configuración' : '🛠️ Setup';
  
  const hwTitle = document.getElementById('adminHwHeader');
  if (hwTitle) hwTitle.innerText = isEs ? '⚙️ Integración de Hardware y Dispositivos' : '⚙️ Hardware & Device Integrations';

  const bizProfileHeader = document.getElementById('adminBizHeader');
  if (bizProfileHeader) bizProfileHeader.innerText = isEs ? '🏢 Perfil de Negocio y Servicios' : '🏢 Business Profile & Services';

  const btnSaveAdmin = document.getElementById('btnSaveAdminSettings');
  if (btnSaveAdmin) btnSaveAdmin.innerText = isEs ? 'Guardar Configuración' : 'Save Settings';

  // Table Layout Editor & QR Cards bilingual translations
  const lblTableEditorModalTitle = document.getElementById('lblTableEditorModalTitle');
  if (lblTableEditorModalTitle) lblTableEditorModalTitle.innerText = isEs ? '📐 Gestión y Diagrama de Mesas' : '📐 Floor Plan & Table Management';

  const lblTabFloorPlan = document.getElementById('lblTabFloorPlan');
  if (lblTabFloorPlan) lblTabFloorPlan.innerText = isEs ? 'Editor de Diagrama' : 'Floor Plan Editor';

  const lblTabQRCards = document.getElementById('lblTabQRCards');
  if (lblTabQRCards) lblTabQRCards.innerText = isEs ? 'Insertos QR para Mesas (PDF)' : 'Table QR Inserts (PDF)';

  const lblBtnSaveLayout = document.getElementById('lblBtnSaveLayout');
  if (lblBtnSaveLayout) lblBtnSaveLayout.innerText = isEs ? 'Guardar Diseño' : 'Save Layout';

  const lblBtnPrintQRCardsHeader = document.getElementById('lblBtnPrintQRCardsHeader');
  if (lblBtnPrintQRCardsHeader) lblBtnPrintQRCardsHeader.innerText = isEs ? 'Imprimir Tarjetas / Guardar PDF' : 'Print Cards / Save PDF';

  const lblQrTargetUrl = document.getElementById('lblQrTargetUrl');
  if (lblQrTargetUrl) lblQrTargetUrl.innerText = isEs ? 'URL del Menú Online:' : 'Online Menu URL:';

  const lblQrCardSize = document.getElementById('lblQrCardSize');
  if (lblQrCardSize) lblQrCardSize.innerText = isEs ? 'Tamaño de Inserto:' : 'Insert Card Size:';

  const lblQrCardLang = document.getElementById('lblQrCardLang');
  if (lblQrCardLang) lblQrCardLang.innerText = isEs ? 'Idioma en Tarjetas:' : 'Language on Cards:';

  const lblBtnPrintQRCardsBar = document.getElementById('lblBtnPrintQRCardsBar');
  if (lblBtnPrintQRCardsBar) lblBtnPrintQRCardsBar.innerText = isEs ? 'Imprimir Tarjetas (Guardar PDF)' : 'Print Cards (Save PDF)';

  const lblOptManagerTableTitle = document.getElementById('lblOptManagerTableTitle');
  if (lblOptManagerTableTitle) lblOptManagerTableTitle.innerText = isEs ? '1. Restaurante y Bar: Mesas y Croquis' : '1. Restaurant & Bar: Tables & Croquis';

  const lblOptManagerTableDesc = document.getElementById('lblOptManagerTableDesc');
  if (lblOptManagerTableDesc) lblOptManagerTableDesc.innerText = isEs ? 'Diseño de croquis y códigos QR individuales para mesas (Mesa 1 a 100)' : 'Floor plan design & individual QR codes for dining tables (Mesa 1 to 100)';

  const lblOptManagerTacoTitle = document.getElementById('lblOptManagerTacoTitle');
  if (lblOptManagerTacoTitle) lblOptManagerTacoTitle.innerText = isEs ? '2. Taco Truck y Drive-Up: Pedidos por QR Único' : '2. Taco Truck & Drive-Up: Single QR Order';

  const lblOptManagerTacoDesc = document.getElementById('lblOptManagerTacoDesc');
  if (lblOptManagerTacoDesc) lblOptManagerTacoDesc.innerText = isEs ? '1 Solo QR para autos y clientes con descripción libre (Jeep verde, etc.)' : '1 Single QR for cars & walk-ups with free vehicle descriptions (Jeep verde, etc.)';

  const lblTabCatRestaurant = document.getElementById('lblTabCatRestaurant');
  if (lblTabCatRestaurant) lblTabCatRestaurant.innerText = isEs ? '1. Restaurante y Bar (Mesas 1-100)' : '1. Restaurant & Bar (Tables 1-100)';

  const lblTabCatTacoTruck = document.getElementById('lblTabCatTacoTruck');
  if (lblTabCatTacoTruck) lblTabCatTacoTruck.innerText = isEs ? '2. Taco Truck y Drive-Up (QR Único)' : '2. Taco Truck & Drive-Up (Single QR)';

  const lblBtnPrintTacoSign = document.getElementById('lblBtnPrintTacoSign');
  if (lblBtnPrintTacoSign) lblBtnPrintTacoSign.innerText = isEs ? 'Imprimir Cartel (PDF)' : 'Print Window Poster (PDF)';

  const lblBtnDownloadTacoPNG = document.getElementById('lblBtnDownloadTacoPNG');
  if (lblBtnDownloadTacoPNG) lblBtnDownloadTacoPNG.innerText = isEs ? 'Descargar PNG' : 'Save PNG';

  const lblBackFromTableEditor = document.getElementById('lblBackFromTableEditor');
  if (lblBackFromTableEditor) lblBackFromTableEditor.innerText = isEs ? 'Volver al Menú' : 'Back to Menu';

  const lblCloseToRegister = document.getElementById('lblCloseToRegister');
  if (lblCloseToRegister) lblCloseToRegister.innerText = isEs ? 'Salir' : 'Exit';

  // Sync card language dropdown with POS language if not manually changed
  const qrCardLangSelect = document.getElementById('qrCardLangSelect');
  if (qrCardLangSelect) {
    if (isEs && qrCardLangSelect.value === 'en') {
      qrCardLangSelect.value = 'es';
    } else if (!isEs && qrCardLangSelect.value === 'es') {
      qrCardLangSelect.value = 'en';
    }
    if (typeof updateTableCardLangPillsUI === 'function') {
      updateTableCardLangPillsUI(qrCardLangSelect.value);
    }
  }

  const tacoTruckLangSelect = document.getElementById('tacoTruckLangSelect');
  if (tacoTruckLangSelect) {
    if (isEs && tacoTruckLangSelect.value === 'en') {
      tacoTruckLangSelect.value = 'es';
    } else if (!isEs && tacoTruckLangSelect.value === 'es') {
      tacoTruckLangSelect.value = 'en';
    }
    if (typeof updateTacoTruckLangPillsUI === 'function') {
      updateTacoTruckLangPillsUI(tacoTruckLangSelect.value);
    }
  }
}

// Variables temporales para el pastel personalizado en creación
let tempCakeData = {
  flavor: '',
  size: '',
  fruits: [],
  fillings: [],
  gelatina: '',
  photoUrl: '',
  isSpecialEvent: false // true si es Boda/15 Años
};
let cashReceivedString = '';

function initBarcodeScanner() {
  let scannerBuffer = '';
  let lastKeyTime = 0;

  window.addEventListener('keypress', async (e) => {
    const currentTime = Date.now();
    // A barcode scanner types extremely fast (delay < 50ms)
    if (currentTime - lastKeyTime > 50) {
      scannerBuffer = '';
    }
    lastKeyTime = currentTime;

    if (e.key === 'Enter') {
      if (scannerBuffer.length >= 4) {
        e.preventDefault();
        const code = scannerBuffer.trim();
        scannerBuffer = '';
        console.log("Scanner detected order ticket number:", code);
        try {
          const res = await fetch(`${SERVER_URL}/api/orders`);
          if (res.ok) {
            const orders = await res.json();
            const cleanCode = code.replace(/^O-/, ''); // Strip phone barcode O- prefix
            const order = orders.find(o => String(o.ticketNumber) === cleanCode || o.id === cleanCode);
            if (order) {
              openViewOrderDialog(order.id);
              showToast(posSettings.language === 'es' ? `Comanda #${code} encontrada` : `Order #${code} found`, 'success');
              if (document.activeElement && (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA')) {
                document.activeElement.blur();
              }
            } else {
              showToast(posSettings.language === 'es' ? `Comanda #${code} no encontrada` : `Order #${code} not found`, 'error');
            }
          }
        } catch (err) {
          console.error("Barcode lookup failed:", err);
        }
      }
      scannerBuffer = '';
    } else if (e.key.match(/^[a-zA-Z0-9]$/)) {
      scannerBuffer += e.key;
    }
  });
}

// --- INICIALIZACIÓN ---

// =========================================================================
// FUNCIONES GLOBALES DE DELIVERY (DOORDASH, UBER EATS, GRUBHUB, ONLINE STORE)
// =========================================================================

window.syncDefaultServiceRadio = function(val) {
  const sel = document.getElementById('adminDefaultServiceType');
  if (sel) sel.value = val;
  if (posSettings) posSettings.defaultServiceType = val;
};

window.copyDeliveryWebhookUrl = function() {
  const inp = document.getElementById('txtDeliveryWebhookUrl');
  if (inp) {
    inp.select();
    navigator.clipboard.writeText(inp.value).then(() => {
      showToast('URL de Webhook copiada al portapapeles', 'success');
    }).catch(() => {
      document.execCommand('copy');
      showToast('URL copiada', 'success');
    });
  }
};

window.simulateDeliveryOrder = async function(platform) {
  try {
    showToast('Generando pedido simulado de ' + platform.toUpperCase() + '...', 'info');
    const res = await fetch(`${SERVER_URL}/api/delivery/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ platform })
    });
    if (res.ok) {
      const data = await res.json();
      showToast(`¡Pedido ${data.order.externalOrderId || data.order.id} recibido con éxito!`, 'success');
      updateDeliveryHubBadge();
      if (document.getElementById('modalDeliveryHub').style.display === 'flex') {
        loadDeliveryHubOrders();
      }
    } else {
      showToast('Error al simular pedido', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Error de conexión con el simulador', 'error');
  }
};

let cachedDeliveryOrders = [];
let currentDeliveryFilter = 'all';

window.filterDeliveryHubList = function(filter) {
  currentDeliveryFilter = filter;
  ['tabDeliveryAll', 'tabDeliveryPrep', 'tabDeliveryReady', 'tabDeliveryHanded'].forEach(id => {
    const btn = document.getElementById(id);
    if (btn) btn.classList.remove('selected');
  });
  if (filter === 'all') document.getElementById('tabDeliveryAll')?.classList.add('selected');
  else if (filter === 'prep') document.getElementById('tabDeliveryPrep')?.classList.add('selected');
  else if (filter === 'ready') document.getElementById('tabDeliveryReady')?.classList.add('selected');
  else if (filter === 'handed') document.getElementById('tabDeliveryHanded')?.classList.add('selected');
  
  renderDeliveryOrdersList(cachedDeliveryOrders, filter);
};

window.loadDeliveryHubOrders = async function() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    
    // Filtrar sólo órdenes de delivery (DoorDash, Uber, Grubhub, Online, o deliveryType === 'delivery')
    cachedDeliveryOrders = allOrders.filter(o => {
      const isDeliv = (o.deliveryType === 'delivery') || 
                      (o.deliveryPlatform && o.deliveryPlatform !== 'pos') ||
                      (o.notes && (o.notes.includes('[DoorDash]') || o.notes.includes('[Uber Eats]') || o.notes.includes('[Grubhub]') || o.notes.includes('[Online]')));
      return isDeliv;
    });

    // Actualizar contadores de pestañas
    const countAll = cachedDeliveryOrders.length;
    const countPrep = cachedDeliveryOrders.filter(o => o.status === 'pendiente' || o.status === 'en_preparacion').length;
    const countReady = cachedDeliveryOrders.filter(o => o.status === 'listo').length;
    const countHanded = cachedDeliveryOrders.filter(o => o.status === 'entregado' || o.status === 'completado').length;

    if (document.getElementById('countDeliveryAll')) document.getElementById('countDeliveryAll').innerText = countAll;
    if (document.getElementById('countDeliveryPrep')) document.getElementById('countDeliveryPrep').innerText = countPrep;
    if (document.getElementById('countDeliveryReady')) document.getElementById('countDeliveryReady').innerText = countReady;
    if (document.getElementById('countDeliveryHanded')) document.getElementById('countDeliveryHanded').innerText = countHanded;

    renderDeliveryOrdersList(cachedDeliveryOrders, currentDeliveryFilter);
  } catch (err) {
    console.error("Error loading delivery orders:", err);
  }
};

function renderDeliveryOrdersList(orders, filter) {
  const container = document.getElementById('deliveryOrdersListContainer');
  if (!container) return;

  let filtered = orders;
  if (filter === 'prep') {
    filtered = orders.filter(o => o.status === 'pendiente' || o.status === 'en_preparacion');
  } else if (filter === 'ready') {
    filtered = orders.filter(o => o.status === 'listo');
  } else if (filter === 'handed') {
    filtered = orders.filter(o => o.status === 'entregado' || o.status === 'completado');
  }

  if (filtered.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); padding: 40px; grid-column: 1 / -1; font-size: 13px;">No hay pedidos de delivery en esta sección</div>`;
    return;
  }

  container.innerHTML = filtered.map(o => {
    let platformColor = '#FF3008';
    let platformName = 'DoorDash';
    const plat = (o.deliveryPlatform || '').toLowerCase();
    
    if (plat.includes('uber') || (o.notes && o.notes.includes('[Uber Eats]'))) {
      platformColor = '#06C167';
      platformName = 'Uber Eats';
    } else if (plat.includes('grub') || (o.notes && o.notes.includes('[Grubhub]'))) {
      platformColor = '#FF8000';
      platformName = 'Grubhub';
    } else if (plat.includes('online') || plat.includes('web') || (o.notes && o.notes.includes('[Online]'))) {
      platformColor = '#0A84FF';
      platformName = 'Online Store';
    }

    const orderIdDisplay = o.externalOrderId || `#ORD-${o.ticketNumber || o.id.substring(2, 8).toUpperCase()}`;
    const codeDisplay = o.pickupCode || o.ticketNumber || o.id.substring(2, 8).toUpperCase();
    const isHandedOver = (o.status === 'entregado' || o.status === 'completado');

    let statusBadge = '<span style="background: #ff9f0a; color: #000; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 10px;">⏳ EN COCINA</span>';
    if (o.status === 'listo') {
      statusBadge = '<span style="background: #30d158; color: #000; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 10px;">📦 LISTO PARA CHOFER</span>';
    } else if (isHandedOver) {
      statusBadge = '<span style="background: #555; color: #fff; padding: 2px 6px; border-radius: 4px; font-weight: bold; font-size: 10px;">✅ ENTREGADO</span>';
    }

    let itemsListHtml = '';
    if (Array.isArray(o.items)) {
      itemsListHtml = o.items.map(it => `
        <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 2px;">
          <span><strong>${it.quantity || 1}x</strong> ${it.name}</span>
          ${it.options ? `<span style="font-size: 9.5px; color: var(--accent-color);">${it.options}</span>` : ''}
        </div>
      `).join('');
    }

    return `
      <div id="card_deliv_${o.id}" style="background: #1a1a1f; border: 2px solid ${platformColor}; border-radius: 8px; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 4px 15px rgba(0,0,0,0.5);">
        <!-- Card Header -->
        <div style="background: ${platformColor}; padding: 6px 10px; display: flex; justify-content: space-between; align-items: center; color: #fff;">
          <strong style="font-size: 12px; letter-spacing: 0.5px;">${platformName.toUpperCase()}</strong>
          <span style="font-weight: 800; font-size: 12px;">${orderIdDisplay}</span>
        </div>

        <!-- Card Body -->
        <div style="padding: 10px; flex: 1; display: flex; flex-direction: column; gap: 6px;">
          <!-- Pickup Code Banner -->
          <div style="background: #000; border: 1.5px dashed ${platformColor}; border-radius: 6px; padding: 6px; text-align: center;">
            <span style="font-size: 9px; color: var(--text-secondary); text-transform: uppercase; display: block;">Código de Recogida / Pickup Code</span>
            <strong style="font-size: 18px; color: #fff; letter-spacing: 1px; font-family: monospace;">${codeDisplay}</strong>
          </div>

          <!-- Customer & Driver Info -->
          <div style="font-size: 11px; border-bottom: 1px solid var(--border-color); padding-bottom: 6px;">
            <div>👤 <strong>${o.clientName || 'Cliente Delivery'}</strong></div>
            ${o.driverInfo ? `<div style="color: #ffd60a; font-size: 10px; margin-top: 2px;">🚗 ${o.driverInfo}</div>` : ''}
          </div>

          <!-- Items list -->
          <div style="max-height: 100px; overflow-y: auto; padding: 2px 0;">
            ${itemsListHtml}
          </div>

          <!-- Status & Total -->
          <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-color); padding-top: 6px; margin-top: auto;">
            ${statusBadge}
            <strong style="font-size: 13px; color: #fff;">$${parseFloat(o.total || 0).toFixed(2)}</strong>
          </div>
        </div>

        <!-- Card Action -->
        <div style="padding: 8px 10px; background: #111; border-top: 1px solid var(--border-color);">
          ${!isHandedOver ? `
            <button type="button" class="btn-modal primary" onclick="handoverDeliveryOrder('${o.id}')" style="background-color: #30d158; color: #000; font-weight: bold; width: 100%; padding: 8px; border: none; border-radius: 6px; font-size: 12px; cursor: pointer;">
              ✓ Entregar a Repartidor
            </button>
          ` : `
            <div style="text-align: center; color: #8e8e93; font-size: 11px; font-weight: bold; padding: 4px;">
              ✓ Entregado por ${o.handoverCashier || 'Cajero'}
            </div>
          `}
        </div>
      </div>
    `;
  }).join('');
}

window.handoverDeliveryOrder = async function(orderId) {
  try {
    const res = await fetch(`${SERVER_URL}/api/delivery/handover`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, cashierName: activeCashierName || 'Cajero' })
    });
    if (res.ok) {
      const data = await res.json();
      showToast(`¡Orden #${data.order.externalOrderId || data.order.id} entregada al repartidor!`, 'success');
      updateDeliveryHubBadge();
      loadDeliveryHubOrders();
    } else {
      showToast('Error al confirmar entrega', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Error de conexión', 'error');
  }
};

window.searchDeliveryByCode = function() {
  const input = document.getElementById('deliveryScanInput');
  if (!input) return;
  const code = input.value.trim();
  if (!code) return;

  const found = cachedDeliveryOrders.find(o => {
    const cleanCode = code.toUpperCase();
    return (o.pickupCode && o.pickupCode.toUpperCase() === cleanCode) ||
           (o.externalOrderId && o.externalOrderId.toUpperCase().includes(cleanCode)) ||
           (String(o.ticketNumber) === cleanCode) ||
           (o.id.toUpperCase().includes(cleanCode));
  });

  if (found) {
    currentDeliveryFilter = 'all';
    renderDeliveryOrdersList(cachedDeliveryOrders, 'all');
    input.value = '';
    
    setTimeout(() => {
      const cardEl = document.getElementById(`card_deliv_${found.id}`);
      if (cardEl) {
        cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        cardEl.style.outline = '4px solid #30d158';
        cardEl.style.boxShadow = '0 0 25px rgba(48,209,88,0.8)';
        setTimeout(() => {
          cardEl.style.outline = 'none';
        }, 3000);
      }
    }, 100);
    showToast(`Comanda #${found.externalOrderId || found.ticketNumber} encontrada`, 'success');
  } else {
    showToast(`No se encontró ninguna orden con código ${code}`, 'warning');
  }
};

window.updateDeliveryHubBadge = async function() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    
    const activeDelivery = allOrders.filter(o => {
      const isDeliv = (o.deliveryType === 'delivery') || 
                      (o.deliveryPlatform && o.deliveryPlatform !== 'pos') ||
                      (o.notes && (o.notes.includes('[DoorDash]') || o.notes.includes('[Uber Eats]') || o.notes.includes('[Grubhub]') || o.notes.includes('[Online]')));
      const isActive = (o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'listo');
      return isDeliv && isActive;
    });

    const badge = document.getElementById('lblDeliveryHubBadge');
    const btn = document.getElementById('btnDeliveryHubToggle');
    if (badge && btn) {
      badge.innerText = activeDelivery.length;
      if (activeDelivery.length > 0) {
        btn.classList.add('btn-waitlist-flashing');
      } else {
        btn.classList.remove('btn-waitlist-flashing');
      }
    }
  } catch (err) {}
};


document.addEventListener('DOMContentLoaded', async () => {
  // 1. Initialize critical UI setup, virtual keyboard, and local events immediately
  initClock();
  initVirtualKeyboard();
  initBarcodeScanner();
  setupEventListeners();
  setupActivityTracker();
  registerProductFormInputEvents();
  initMenuCustomizer();
  initModifiersModal();
  initCSVDatabaseExchange();
  initProductEditorModifiers();
  initOptionsGlobalSearch();
  
  // 2. Perform async server fetches and other database loads in a protected try-catch block
  try {
    initWebSocket();
    initBiometricWebSocket();
    await loadSettingsFromServer();
    // 1. Inmediata carga de pestañas, departamentos y catálogo desde SQLite local (0ms retraso)
    await loadDepartmentsAndTabs();
    setupDepartmentsPanelEvents();
    await loadGlobalModifierGroups();
    await loadProducts();
    updateCartUI();
    checkActiveShiftAndLockState();

    // 2. Comprobaciones en segundo plano (no congelan la interfaz ni el teclado)
    checkLicenseStatus().catch(e => console.warn('Non-critical background license check:', e));
    populatePrintersDropdowns().catch(e => console.warn('Non-critical background printers check:', e));
  } catch (initError) {
    console.error("Non-critical initialization failure during background server fetch:", initError);
    const debugLbl = document.getElementById('debugProductCount');
    if (debugLbl) debugLbl.innerText = `[Init Error: ${initError.message}]`;
  }
});

async function loadGlobalModifierGroups() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/modifier-groups`);
    if (res.ok) {
      globalModifierGroups = await res.json();
    }
    // Also load single modifiers globally!
    await loadSingleModifiers();
  } catch(e) {
    console.error("Error loading global modifier groups / single modifiers:", e);
  }
}

function getProductModifierGroups(product) {
  if (!product) return [];
  if (product.modifierGroupIds && product.modifierGroupIds.length > 0) {
    return product.modifierGroupIds.map(id => globalModifierGroups.find(g => g.id === id)).filter(Boolean);
  }
  return product.modifierGroups || [];
}

function populateProductModifierChecklist(checkedIds = []) {
  const container = document.getElementById('productModifierChecklist');
  if (!container) return;
  container.innerHTML = '';
  if (!globalModifierGroups || globalModifierGroups.length === 0) {
    container.innerHTML = `<span style="font-size: 11px; color: var(--text-secondary); font-style: italic;">No modifier groups defined. Create them in Setup.</span>`;
    return;
  }
  globalModifierGroups.forEach(g => {
    const div = document.createElement('div');
    div.style.display = 'flex';
    div.style.alignItems = 'center';
    div.style.gap = '6px';
    
    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.value = g.id;
    chk.className = 'prod-modifier-checkbox';
    chk.id = `prod_mod_chk_${g.id}`;
    chk.checked = checkedIds.includes(g.id);
    
    const lbl = document.createElement('label');
    lbl.htmlFor = `prod_mod_chk_${g.id}`;
    lbl.style.fontSize = '11px';
    lbl.style.color = '#fff';
    lbl.style.cursor = 'pointer';
    lbl.style.userSelect = 'none';
    lbl.innerText = `${g.name} (${g.options.map(o => o.name).join(', ')})`;
    
    div.appendChild(chk);
    div.appendChild(lbl);
    container.appendChild(div);
  });
}

window.openGlobalModifiersFromProductForm = function() {
  const formContainer = document.getElementById('productFormContainer');
  if (formContainer) formContainer.style.display = 'none';
  
  // Toggle to modifiers manager view inside inventory pane
  const productsContainer = document.getElementById('inventoryProductsListContainer');
  const modifiersContainer = document.getElementById('inventoryModifiersManagerContainer');
  const addProductBtn = document.getElementById('btnOpenAddProductForm');
  const btnToggle = document.getElementById('btnToggleInventoryView');
  const titleSpan = document.getElementById('lblInventoryPaneTitle');
  
  if (productsContainer && modifiersContainer && btnToggle) {
    productsContainer.style.display = 'none';
    modifiersContainer.style.display = 'flex';
    if (addProductBtn) addProductBtn.style.display = 'none';
    
    btnToggle.innerText = '📦 View Products';
    btnToggle.style.backgroundColor = '#233545';
    if (titleSpan) titleSpan.innerText = '📋 Modifiers Manager';
    
    renderSetupModifiersList();
  }
};

async function loadSettingsFromServer() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      posSettings = await res.json();
      
      if (posSettings) {
        const bName = String(posSettings.businessName || '').toLowerCase();
        const sub = String(posSettings.clientSubdomain || '').toLowerCase();
        const lKey = String(posSettings.licenseKey || '').toLowerCase();
        const isTacoTruck = bName.includes('taco') || bName.includes('madre') || bName.includes('birria') || bName.includes('truck') || bName.includes('taqueria') ||
                            sub.includes('taco') || sub.includes('madre') || sub.includes('birria') || sub.includes('truck') ||
                            lKey.includes('taco') || lKey.includes('tmadre');
        if (isTacoTruck) {
          if (!posSettings.businessName) posSettings.businessName = 'Taco Madre';
          posSettings.businessType = 'taco_truck,restaurant';
          posSettings.enableBakeryCustomCakes = false;
        }
      }
      
      const lang = posSettings.language || 'en';
      applyTranslations(lang);
      
      const wizLang = document.getElementById('wizardLanguage');
      if (wizLang) wizLang.value = lang;
      
      const adminLang = document.getElementById('adminLanguage');
      if (adminLang) adminLang.value = lang;
      
      // Update tax rate display in the cart label
      const taxRateLbl = document.getElementById('lblTaxRate');
      if (taxRateLbl) taxRateLbl.innerText = posSettings.taxRate !== undefined ? posSettings.taxRate : 6;
      
      const btnWeigh = document.getElementById('btnCartWeighItem');
      if (btnWeigh) btnWeigh.style.display = posSettings.enableWeightScale ? 'flex' : 'none';
      
      // Dynamic welcome setup check (First-run wizard & Disclaimer - Mandatory Business Type)
      const isVirginSetup = !posSettings.eulaAccepted || !posSettings.businessName || posSettings.businessName === 'Impossible POS' || posSettings.businessName.trim() === '' || !posSettings.businessType || posSettings.businessType.trim() === '';
      if (isVirginSetup) {
        document.getElementById('modalBusinessSetup').style.display = 'flex';
      } else {
        document.getElementById('modalBusinessSetup').style.display = 'none';
        
        // Update Title & logo branding dynamically
        document.title = (posSettings.businessName && posSettings.businessName !== 'Impossible POS') ? `${posSettings.businessName} - Impossible POS™` : 'Impossible POS™';
        const logoHeader = document.getElementById('businessHeaderLogo');
        if (logoHeader) {
          logoHeader.innerText = posSettings.businessName;
        }
        
        // Dynamically show/hide order services tabs
        const services = posSettings.services || ['walkin', 'llevar', 'comer', 'drive-thru', 'pickup', 'delivery'];
        const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option');
        let firstVisible = null;
        deliveryOpts.forEach(btn => {
          const type = btn.getAttribute('data-type');
          if (type === 'walkin') {
            btn.style.display = 'none';
            btn.classList.remove('selected');
            return;
          }
          if (services.includes(type)) {
            btn.style.display = 'block';
            if (!firstVisible) firstVisible = btn;
          } else {
            btn.style.display = 'none';
            btn.classList.remove('selected');
          }
        });
        
        // Set default order type
        const defaultType = posSettings.defaultServiceType || (posSettings.businessType && posSettings.businessType.includes('taco_truck') ? 'llevar' : null);
        if (defaultType && services.includes(defaultType)) {
          deliveryOpts.forEach(btn => {
            if (btn.getAttribute('data-type') === defaultType) {
              btn.classList.add('selected');
            } else {
              btn.classList.remove('selected');
            }
          });
          deliveryType = defaultType;
        } else {
          // Force manual selection
          deliveryOpts.forEach(btn => btn.classList.remove('selected'));
          deliveryType = null;
        }

        // Apply showTableMap visibility
        const showMap = posSettings.showTableMap !== false; // default true if not specified
        const mapBtn = document.getElementById('btnOpenTableMap');
        if (mapBtn) {
          mapBtn.style.display = showMap ? 'flex' : 'none';
        }
        const optManagerLayout = document.getElementById('optManagerTableLayout');
        if (optManagerLayout) {
          optManagerLayout.style.display = 'flex';
        }

        // Apply showBartender visibility (Taco Truck / Fast Food mode)
        const showBartender = posSettings.showBartender !== false;
        const bartenderBtn = document.getElementById('btnOpenBartenderDashboard');
        if (bartenderBtn) {
          bartenderBtn.style.display = showBartender ? 'flex' : 'none';
        }

        // Apply showGift visibility (Taco Truck mode)
        const showGift = posSettings.showGift !== false;
        const giftBtn = document.getElementById('btnBulkGiftTable');
        if (giftBtn) {
          giftBtn.style.display = showGift ? 'flex' : 'none';
        }
        
        // Start screen recording if enabled
        initScreenRecording();
      }
    }
  } catch(e) {
    console.error("Error loading settings:", e);
  }
}

// Reloj digital del Header
function initClock() {
  const clockEl = document.getElementById('headerClock');
  if (clockEl) {
    setInterval(() => {
      const now = new Date();
      clockEl.innerText = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }, 1000);
  }
}

// Conexión WebSockets para actualizaciones en tiempo real
function initWebSocket() {
  activeWebSocket = new WebSocket(WS_URL);
  
  activeWebSocket.onmessage = (event) => {
    const data = JSON.parse(event.data);
    if (data.type === 'INIT') {
      console.log('WS:', data.message);
    } else if (data.type === 'DEPARTMENTS_UPDATED') {
      console.log('WS: Departments updated, reloading...');
      loadDepartmentsAndTabs();
    } else if (data.type === 'CUSTOMER_LINK_REQUEST') {
      console.log('WS: Customer loyalty link request received:', data.data);
      // Multi-register routing: filter by station if specified
      const targetStation = data.data && data.data.stationId;
      const myStation = (typeof posSettings !== 'undefined' && posSettings && posSettings.stationId) ? String(posSettings.stationId) : '1';
      if (targetStation && String(targetStation) !== String(myStation) && targetStation !== 'all') {
        console.log(`[WS] Bypassing link request for Station ${targetStation} (this terminal is Station ${myStation})`);
        return;
      }
      activeLoyaltyRequest = data.data;
      const isEs = posSettings && posSettings.language === 'es';
      
      const reqName = document.getElementById('lblLoyaltyReqName');
      const reqPhone = document.getElementById('lblLoyaltyReqPhone');
      const reqPts = document.getElementById('lblLoyaltyReqPoints');
      
      if (reqName) reqName.innerText = (isEs ? 'Nombre: ' : 'Name: ') + activeLoyaltyRequest.name;
      if (reqPhone) reqPhone.innerText = (isEs ? 'Teléfono: ' : 'Phone: ') + activeLoyaltyRequest.phone;
      
      if (reqPts) {
        if (!activeLoyaltyRequest.isNew) {
          reqPts.innerText = (isEs ? 'Puntos acumulados: ' : 'Accrued Points: ') + activeLoyaltyRequest.points;
          reqPts.style.display = 'block';
        } else {
          reqPts.style.display = 'none';
        }
      }
      
      // Open the request modal
      const reqModal = document.getElementById('modalLoyaltyRequest');
      if (reqModal) reqModal.style.display = 'flex';
      
      showToast(isEs ? '¡Petición de registro/vinculación de puntos recibida!' : 'Loyalty registration/linking request received!', 'info');
    } else if (data.type === 'WAITLIST_UPDATED') {
      console.log('WS: Waitlist updated:', data.waitlist);
      waitlist = data.waitlist || [];
      updateWaitlistBadge();
      renderWaitlistCashier();
    } else if (data.type === 'NEW_ORDER' || data.type === 'ORDER_UPDATED' || data.type === 'DELIVERY_ORDER_ARRIVED') {
      console.log('WS: Order event received:', data.type);
      updateToGoBadgeAndModal();
      updateCarOrdersBadge();
      updateDeliveryHubBadge();
      if (typeof updateActiveTabsCount === 'function') updateActiveTabsCount();
      if (typeof loadProducts === 'function') loadProducts();
    } else if (data.type === 'PRODUCT_UPDATED') {
      console.log('WS: Product catalog updated');
      if (typeof loadProducts === 'function') {
        loadProducts().then(() => {
          if (document.getElementById('detailManagerStock').style.display !== 'none') {
            loadManagerStockTable();
            if (typeof selectedStockProduct !== 'undefined' && selectedStockProduct) {
              const updated = products.find(p => p.id === selectedStockProduct.id);
              if (updated) {
                loadStockProductDetails(updated);
              }
            }
          }
        });
      }
    } else if (data.type === 'PRINT_CAKE_SILENT') {
      console.log('WS: Silent print request for custom cake:', data.orderId);
      if (window.electronAPI && window.electronAPI.printCakeSilent) {
        window.electronAPI.printCakeSilent(data.orderId);
      }
    } else if (data.type === 'CALLER_ID_INCOMING') {
      console.log('WS: Caller ID incoming call event received:', data);
      
      const cIdType = posSettings ? (posSettings.callerIdType || 'disabled') : 'disabled';
      if (cIdType !== 'disabled') {
        const popup = document.getElementById('callerIdPopup');
        if (popup) {
          document.getElementById('callerIdName').innerText = data.name;
          document.getElementById('callerIdPhone').innerText = data.phone;
          
          const detailsRow = document.getElementById('callerIdDetailsRow');
          if (detailsRow) {
            if (data.isRegistered) {
              document.getElementById('callerIdPoints').innerText = data.points;
              document.getElementById('callerIdAddress').innerText = data.address || 'No Address';
              detailsRow.style.display = 'block';
            } else {
              detailsRow.style.display = 'none';
            }
          }
          
          popup.style.display = 'flex';
          window.activeIncomingCaller = data;
          
          if (window.callerIdTimeout) clearTimeout(window.callerIdTimeout);
          window.callerIdTimeout = setTimeout(() => {
            popup.style.display = 'none';
            window.activeIncomingCaller = null;
          }, 30000);
        }
      }
    } else if (data.type === 'RECORDING_DRIVE_DISCONNECTED') {
      console.log('WS: Recording storage drive disconnected!');
      const overlay = document.getElementById('storageDriveBlockOverlay');
      if (overlay) overlay.style.display = 'flex';
    } else if (data.type === 'RECORDING_DRIVE_CONNECTED') {
      console.log('WS: Recording storage drive reconnected.');
      const overlay = document.getElementById('storageDriveBlockOverlay');
      if (overlay) overlay.style.display = 'none';
    }
  };

  activeWebSocket.onerror = (err) => {
    console.error('WS Error:', err);
  };

  activeWebSocket.onclose = () => {
    console.log('WS Desconectado, reintentando en 5s...');
    setTimeout(initWebSocket, 5000);
  };
}

// Cargar productos desde la base de datos local
async function loadProducts() {
  try {
    const response = await fetch(`${SERVER_URL}/api/products?t=${Date.now()}`);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data)) throw new Error("Invalid products array");
    products = data;
    const debugLbl = document.getElementById('debugProductCount');
    if (debugLbl) debugLbl.innerText = `[Loaded: ${products.length} products]`;
    renderProducts();
  } catch (error) {
    console.error("Error loading products:", error);
    // Auto-repair: If /api/products fails due to malformed modifierGroups, re-fetch from cloud & re-import with clean array
    try {
      const settings = (typeof posSettings !== 'undefined' && posSettings) ? posSettings : {};
      const licKey = settings.licenseKey || 'IMPOS-TMADRE-TRUCK1';
      const cloudRes = await fetch(`https://impossible-pos-licenses.onrender.com/api/cloud/catalog/restore?licenseKey=${encodeURIComponent(licKey)}`);
      if (cloudRes.ok) {
        const cloudData = await cloudRes.json();
        if (cloudData && cloudData.products && cloudData.products.length > 0) {
          const cleanProds = cloudData.products.map(p => {
            let mg = p.modifierGroups;
            if (typeof mg === 'string') {
              try { mg = JSON.parse(mg); } catch(e) {}
              if (typeof mg === 'string') {
                try { mg = JSON.parse(mg); } catch(e) {}
              }
            }
            return { ...p, modifierGroups: Array.isArray(mg) ? mg : [] };
          });
          await fetch('/api/admin/products/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cleanProds)
          });
          const retryRes = await fetch(`${SERVER_URL}/api/products?t=${Date.now()}`);
          if (retryRes.ok) {
            products = await retryRes.json();
            if (Array.isArray(products) && products.length > 0) {
              renderProducts();
              return;
            }
          }
        }
      }
    } catch (repairErr) {
      console.warn("Auto-repair could not connect:", repairErr);
    }
    showToast('Error cargando catálogo de productos', 'error');
  }
}

// Renderizar la rejilla de productos según la categoría seleccionada
// --- HELPERS DE CLASIFICACIÓN DE PASTELES ---
// --- HELPERS DE CLASIFICACIÓN DE PASTELES ---
function getCakeSize(name) {
  const n = name.toLowerCase();
  
  // Usar expresiones regulares de límite de palabra (\b) para detectar los números exactos
  if (/\b10\b/.test(n)) return '10" Cakes';
  if (/\b6\b/.test(n)) return '6" Cakes';
  if (/\b8\b/.test(n)) return '8" Cakes';
  
  if (n.includes('1/4') || n.includes('cuarto') || n.includes('quarter')) return '1/4 Sheet';
  if (n.includes('1/2') || n.includes('medio') || n.includes('media') || n.includes('half')) return '1/2 Sheet';
  if (n.includes('completa') || n.includes('completo') || n.includes('full') || n.includes('entera') || n.includes('sheet')) return 'Full Sheet';
  return null; // Omitir otros tamaños no estándar
}

function hasCakeDesign(name) {
  const n = name.toLowerCase();
  return n.includes('diseño') || n.includes('diseno') || n.includes('design') || n.includes('decorado');
}

function setupProductCardContent(card, p, fSize, colorStyle, stockBadge, isOutOfStock) {
  if (p.image) {
    card.style.backgroundImage = `url('${p.image}')`;
    card.style.backgroundSize = 'cover';
    card.style.backgroundPosition = 'center';
    card.style.position = 'relative';
    card.style.padding = '0';
    card.innerHTML = `
      <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 6px; background: rgba(0,0,0,0.75); border-radius: 0 0 6px 6px; text-align: left; display: flex; flex-direction: column; gap: 2px;">
        <div class="product-name" style="font-size: ${fSize}; font-weight: bold; color: #fff; text-shadow: 1px 1px 2px #000; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin: 0;">${p.name}</div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin: 0; padding: 0; height: auto; background: transparent;">
          <span class="product-price" style="color: var(--accent-color); font-weight: bold; font-size: 11px; margin: 0;">$${p.price.toFixed(2)}</span>
          ${isOutOfStock ? `<span style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin: 0;">OUT</span>` : ''}
        </div>
      </div>
    `;
  } else {
    card.style.backgroundImage = 'none';
    card.style.padding = '';
    card.innerHTML = `
      <div class="product-name" style="${colorStyle} font-size: ${fSize};">${p.name}</div>
      <div class="product-price">$${p.price.toFixed(2)}</div>
      ${stockBadge}
    `;
  }
}
window.setupProductCardContent = setupProductCardContent;

async function handleProductImageUpload(input) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    
    // Check size limit (e.g. 3MB max to prevent huge db saves)
    if (file.size > 3 * 1024 * 1024) {
      showToast("La imagen supera los 3MB / Image exceeds 3MB limit", "error");
      return;
    }
    
    // Convert to base64
    const reader = new FileReader();
    reader.onload = async function(e) {
      const base64Data = e.target.result;
      const cleanFileName = 'prod_' + Date.now() + '_' + file.name.replace(/[^a-zA-Z0-9\.]/g, '');
      
      showToast("Subiendo imagen... / Uploading image...", "info");
      try {
        const res = await fetch(`${SERVER_URL}/api/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            image: base64Data,
            filename: cleanFileName
          })
        });
        
        if (res.ok) {
          const data = await res.json();
          document.getElementById('prodImageUrl').value = data.url;
          
          // Update preview
          const img = document.getElementById('prodImagePreview');
          const placeholder = document.getElementById('prodImagePlaceholder');
          img.src = data.url;
          img.style.display = 'block';
          placeholder.style.display = 'none';
          document.getElementById('btnRemoveProdImage').style.display = 'inline-block';
          showToast("¡Imagen cargada! / Image uploaded!", "success");
        } else {
          showToast("Error en el servidor al subir la imagen", "error");
        }
      } catch (err) {
        console.error(err);
        showToast("Error de conexión al cargar la imagen", "error");
      }
    };
    reader.readAsDataURL(file);
  }
}
window.handleProductImageUpload = handleProductImageUpload;

function removeProductImage() {
  document.getElementById('prodImageUrl').value = '';
  const img = document.getElementById('prodImagePreview');
  const placeholder = document.getElementById('prodImagePlaceholder');
  if (img) {
    img.src = '';
    img.style.display = 'none';
  }
  if (placeholder) placeholder.style.display = 'block';
  
  const removeBtn = document.getElementById('btnRemoveProdImage');
  if (removeBtn) removeBtn.style.display = 'none';
  
  const fileInput = document.getElementById('prodImageFile');
  if (fileInput) fileInput.value = '';
}
function isBakeryBusiness() {
  if (!posSettings) return false;
  const bType = String(posSettings.businessType || '').toLowerCase();
  if (!bType || !bType.includes('bakery')) return false;

  const bName = String(posSettings.businessName || '').toLowerCase();
  const sub = String(posSettings.clientSubdomain || '').toLowerCase();
  const lKey = String(posSettings.licenseKey || '').toLowerCase();
  if (bName.includes('taco') || bName.includes('madre') || bName.includes('birria') || bName.includes('truck') || bName.includes('taqueria') ||
      sub.includes('taco') || sub.includes('madre') || sub.includes('birria') || sub.includes('truck') ||
      lKey.includes('taco') || lKey.includes('tmadre')) {
    return false;
  }
  return true;
}
window.isBakeryBusiness = isBakeryBusiness;

function isSheilaProprietaryBakery() {
  if (!posSettings) return false;
  const bName = String(posSettings.businessName || '').toLowerCase();
  const sub = String(posSettings.clientSubdomain || '').toLowerCase();
  return bName.includes('sheila') || sub.includes('sheila');
}
window.isSheilaProprietaryBakery = isSheilaProprietaryBakery;

function renderProducts() {
  const grid = document.getElementById('productsGrid');
  grid.innerHTML = '';

  // --- SUB-CATEGORY SUB-TABS RENDER FOR CAKES (MODIFICADO A VIRTUAL FOLDERS) ---
  const filterContainer = document.getElementById('subCategoryFilterContainer');
  if (filterContainer) filterContainer.style.display = 'none'; // Desactivamos el sub-tab bar y usamos tarjetas virtuales

  if (selectedCategory === 'pasteles_stock' && isBakeryBusiness()) {
    grid.innerHTML = '';
    
    // Tarjeta 1: Regular Cakes
    const cardRegular = document.createElement('div');
    cardRegular.className = 'product-card';
    cardRegular.style.borderColor = 'rgba(255, 159, 10, 0.3)';
    cardRegular.style.backgroundColor = 'rgba(255, 159, 10, 0.02)';
    cardRegular.style.display = 'flex';
    cardRegular.style.alignItems = 'center';
    cardRegular.style.justifyContent = 'center';
    cardRegular.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Regular Cakes</div>
    `;
    cardRegular.addEventListener('click', () => {
      openCakeSubMenuModal('regular');
    });
    grid.appendChild(cardRegular);
    
    // Tarjeta 2: Tres Leches
    const cardTresLeches = document.createElement('div');
    cardTresLeches.className = 'product-card';
    cardTresLeches.style.borderColor = 'rgba(10, 132, 255, 0.3)';
    cardTresLeches.style.backgroundColor = 'rgba(10, 132, 255, 0.02)';
    cardTresLeches.style.display = 'flex';
    cardTresLeches.style.alignItems = 'center';
    cardTresLeches.style.justifyContent = 'center';
    cardTresLeches.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Tres Leches</div>
    `;
    cardTresLeches.addEventListener('click', () => {
      openCakeSubMenuModal('tres_leches');
    });
    grid.appendChild(cardTresLeches);

    // Tarjeta 3: Desserts (Whole/Large)
    const cardDesserts = document.createElement('div');
    cardDesserts.className = 'product-card';
    cardDesserts.style.borderColor = 'rgba(48, 209, 88, 0.3)';
    cardDesserts.style.backgroundColor = 'rgba(48, 209, 88, 0.02)';
    cardDesserts.style.display = 'flex';
    cardDesserts.style.alignItems = 'center';
    cardDesserts.style.justifyContent = 'center';
    cardDesserts.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Desserts</div>
    `;
    cardDesserts.addEventListener('click', () => {
      openCakeSubMenuModal('dessert');
    });
    grid.appendChild(cardDesserts);
    
    // Tarjetas de pasteles individuales (Red Velvet, zanahoria, etc. que NO son de tamaño estándar)
    const cakeCategories = ['pan regs', 's cake', '3lech st', 'pasteles', 'panaderia', 'postres', 'dessert slice', 'dessert_slice'];
    const allCakes = products.filter(p => cakeCategories.includes(p.category) && p.price >= 22.00 && p.price > 0);
    const individualCakes = allCakes.filter(p => !getCakeSize(p.name));
    
    sortProducts(individualCakes);
    
    individualCakes.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      if (p.color) {
        card.style.borderColor = p.color;
        card.style.backgroundColor = p.color.startsWith('#') ? p.color + '1a' : p.color;
      }
      const isOutOfStock = p.trackStock && (parseFloat(p.stockQuantity) || 0) <= 0;
      if (isOutOfStock) {
        card.style.opacity = '0.5';
        card.style.cursor = 'not-allowed';
      }
      const fSize = p.fontSize ? p.fontSize + 'px' : '13px';
      const colorStyle = p.color ? `color: ${p.color};` : 'color: var(--accent-color);';
      const stockBadge = isOutOfStock ? `<div style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin-top: 2px;">AGOTADO</div>` : '';
      setupProductCardContent(card, p, fSize, colorStyle + ' font-weight: 700;', stockBadge, isOutOfStock);
      if (isOutOfStock) {
        card.addEventListener('click', () => showToast('⚠️ Producto agotado / Out of stock!', 'error'));
      } else {
        card.addEventListener('click', () => addToCart(p));
      }
      grid.appendChild(card);
    });
    
    return;
  }

  // --- ENRUTAMIENTO VIRTUAL DE CATEGORÍAS ---
  let filtered = [];
  const salesSearch = document.getElementById('salesSearchInput');
  const q = salesSearch ? salesSearch.value.toLowerCase().trim() : '';

  if (q) {
    filtered = products.filter(p => p.price > 0 && (
      p.name.toLowerCase().includes(q) || 
      (p.barcode && p.barcode.includes(q)) || 
      p.category.toLowerCase().includes(q)
    ));
  } else {
    if (selectedCategory === 'panaderia') {
      filtered = products.filter(p => p.category === 'panaderia' && p.price < 22.00 && p.price > 0);
    } else if (selectedCategory === 'postres') {
      // Solo postres pequeños/individuales (s cake, postres, dessert slice con precio menor a $22.00)
      const dessertCats = ['postres', 's cake', 'dessert slice', 'dessert_slice'];
      filtered = products.filter(p => dessertCats.includes(p.category) && p.price < 22.00 && p.price > 0);
    } else {
      filtered = products.filter(p => p.category === selectedCategory && p.price > 0);
    }
  }

  if (filtered.length === 0) {
    const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es') || (posSettings && posSettings.language === 'es');
    grid.innerHTML = `<div style="grid-column: 1 / -1; display: flex; align-items: center; justify-content: center; height: 160px; color: var(--text-secondary); font-size: 13px; font-weight: bold;">${isEs ? 'No hay productos registrados en esta categoría' : 'No products registered in this category'}</div>`;
    return;
  }

  // --- SUB-CATEGORY FOLDER ROUTING ON MAIN ORDER SCREEN ---
  if (!q && selectedCategory !== 'panaderia') {
    if (activeSalesSubCategory) {
      filtered = filtered.filter(p => (p.subCategory || '').trim() === activeSalesSubCategory);
      
      const backCard = document.createElement('div');
      backCard.className = 'product-card';
      backCard.style.borderColor = 'rgba(255, 69, 58, 0.5)';
      backCard.style.backgroundColor = 'rgba(255, 69, 58, 0.05)';
      backCard.style.display = 'flex';
      backCard.style.alignItems = 'center';
      backCard.style.justifyContent = 'center';
      backCard.innerHTML = `
        <div class="product-name" style="font-size: 13px; font-weight: 800; color: #ff453a; text-align: center;">BACK</div>
      `;
      backCard.addEventListener('click', () => {
        activeSalesSubCategory = '';
        renderProducts();
      });
      grid.appendChild(backCard);
    } else {
      const subCategories = Array.from(new Set(
        filtered
          .map(p => (p.subCategory || '').trim())
          .filter(Boolean)
      ));
      
      subCategories.forEach(sub => {
        const folderCard = document.createElement('div');
        folderCard.className = 'product-card';
        folderCard.style.borderColor = 'rgba(10, 132, 255, 0.5)';
        folderCard.style.backgroundColor = 'rgba(10, 132, 255, 0.05)';
        folderCard.style.display = 'flex';
        folderCard.style.alignItems = 'center';
        folderCard.style.justifyContent = 'center';
        folderCard.innerHTML = `
          <div class="product-name" style="font-size: 12px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">${sub}</div>
        `;
        folderCard.addEventListener('click', () => {
          activeSalesSubCategory = sub;
          renderProducts();
        });
        grid.appendChild(folderCard);
      });
      
      filtered = filtered.filter(p => !(p.subCategory || '').trim());
    }
  }

  // --- RENDERIZACIÓN SEGÚN LA PESTAÑA SELECCIONADA ---
  if (selectedCategory === 'panaderia') {
    const uniqueItems = [];
    const groupedByPrice = {};

    filtered.forEach(p => {
      const nameLower = p.name.toLowerCase();
      if (nameLower.includes('bolillo') || nameLower.includes('telera')) {
        uniqueItems.push(p);
      } else {
        const priceKey = p.price.toFixed(2);
        if (!groupedByPrice[priceKey]) {
          groupedByPrice[priceKey] = [];
        }
        groupedByPrice[priceKey].push(p);
      }
    });

    uniqueItems.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      const isOutOfStock = p.trackStock && (parseFloat(p.stockQuantity) || 0) <= 0;
      if (isOutOfStock) {
        card.style.opacity = '0.5';
        card.style.cursor = 'not-allowed';
      }
      const stockBadge = isOutOfStock ? `<div style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin-top: 2px;">AGOTADO</div>` : '';
      setupProductCardContent(card, p, '13px', 'color: var(--accent-color); font-weight: 700;', stockBadge, isOutOfStock);
      if (isOutOfStock) {
        card.addEventListener('click', () => showToast('⚠️ Producto agotado / Out of stock!', 'error'));
      } else {
        card.addEventListener('click', () => addToCart(p));
      }
      grid.appendChild(card);
    });

    const sortedPrices = Object.keys(groupedByPrice).sort((a, b) => parseFloat(a) - parseFloat(b));
    sortedPrices.forEach(priceStr => {
      const itemsInGroup = groupedByPrice[priceStr];

      const card = document.createElement('div');
      card.className = 'product-card';
      card.style.borderColor = 'rgba(255, 159, 10, 0.25)';
      card.style.backgroundColor = 'rgba(255, 159, 10, 0.03)';
      card.innerHTML = `
        <div class="product-name" style="font-size: 16px; font-weight: 700; color: #fff;">Pan de <span style="color:var(--accent-color); font-size:18px;">$${priceStr}</span></div>
        <div style="font-size: 11px; color: var(--text-secondary);">${itemsInGroup.length} variedades</div>
      `;
      
      card.addEventListener('click', () => {
        openPriceGroupModal(`Panes de $${priceStr}`, itemsInGroup);
      });
      grid.appendChild(card);
    });
  } 
  else if (selectedCategory === 'postres') {
    // Tarjeta 1: Tres Leches Slices
    const card3L = document.createElement('div');
    card3L.className = 'product-card';
    card3L.style.borderColor = 'rgba(10, 132, 255, 0.3)';
    card3L.style.backgroundColor = 'rgba(10, 132, 255, 0.02)';
    card3L.style.display = 'flex';
    card3L.style.alignItems = 'center';
    card3L.style.justifyContent = 'center';
    card3L.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Tres Leches Slices</div>
    `;
    card3L.addEventListener('click', () => {
      openSliceSubMenuModal('tres_leches_slices');
    });
    grid.appendChild(card3L);

    // Tarjeta 2: Flans
    const cardFlan = document.createElement('div');
    cardFlan.className = 'product-card';
    cardFlan.style.borderColor = 'rgba(255, 214, 10, 0.3)';
    cardFlan.style.backgroundColor = 'rgba(255, 214, 10, 0.02)';
    cardFlan.style.display = 'flex';
    cardFlan.style.alignItems = 'center';
    cardFlan.style.justifyContent = 'center';
    cardFlan.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Flans</div>
    `;
    cardFlan.addEventListener('click', () => {
      openSliceSubMenuModal('flans');
    });
    grid.appendChild(cardFlan);

    // Tarjeta 3: Gelatinas
    const cardGelatina = document.createElement('div');
    cardGelatina.className = 'product-card';
    cardGelatina.style.borderColor = 'rgba(255, 55, 95, 0.3)';
    cardGelatina.style.backgroundColor = 'rgba(255, 55, 95, 0.02)';
    cardGelatina.style.display = 'flex';
    cardGelatina.style.alignItems = 'center';
    cardGelatina.style.justifyContent = 'center';
    cardGelatina.innerHTML = `
      <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">Gelatinas</div>
    `;
    cardGelatina.addEventListener('click', () => {
      openSliceSubMenuModal('gelatinas');
    });
    grid.appendChild(cardGelatina);

    // Render individual items (that do NOT belong to the folders)
    const individualSlices = filtered.filter(p => {
      const name = p.name.toUpperCase();
      return !name.includes('3L ') && 
             !name.includes('3L_') &&
             !name.includes('3 LECHES') &&
             !name.includes('FLAN') && 
             !name.includes('GELAT');
    });

    sortProducts(individualSlices);
    individualSlices.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      if (p.color) {
        card.style.borderColor = p.color;
        card.style.backgroundColor = p.color.startsWith('#') ? p.color + '1a' : p.color;
      }
      const fSize = p.fontSize ? p.fontSize + 'px' : '13px';
      const colorStyle = p.color ? `color: ${p.color};` : 'color: var(--accent-color);';
      setupProductCardContent(card, p, fSize, colorStyle + ' font-weight: 700;', '', false);
      card.addEventListener('click', () => addToCart(p));
      grid.appendChild(card);
    });
  }
  else if (selectedCategory === 'bebidas' && isSheilaProprietaryBakery()) {
    // 1. Pinned Top: Common Drinks (Specific order)
    const pinnedNames = ['ATOLE SM', 'ATOLE LG', 'CAFE CHICO', 'CAFE GRANDE', 'HOT CHOCOLATE'];
    
    pinnedNames.forEach(nameKey => {
      const p = filtered.find(prod => prod.name.toUpperCase() === nameKey);
      if (p) {
        const card = document.createElement('div');
        card.className = 'product-card';
        card.style.borderColor = 'rgba(10, 132, 255, 0.4)';
        card.style.backgroundColor = 'rgba(10, 132, 255, 0.05)';
        const isOutOfStock = p.trackStock && (parseFloat(p.stockQuantity) || 0) <= 0;
        if (isOutOfStock) {
          card.style.opacity = '0.5';
          card.style.cursor = 'not-allowed';
        }
        const stockBadge = isOutOfStock ? `<div style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin-top: 2px;">AGOTADO</div>` : '';
        setupProductCardContent(card, p, '13px', 'color: #fff; font-weight: 800;', stockBadge, isOutOfStock);
        if (isOutOfStock) {
          card.addEventListener('click', () => showToast('⚠️ Producto agotado / Out of stock!', 'error'));
        } else {
          card.addEventListener('click', () => addToCart(p));
        }
        grid.appendChild(card);
      }
    });

    // 2. Folder Cards (13 total)
    const folders = [
      { name: 'Sodas', color: 'rgba(255, 69, 58, 0.3)', bg: 'rgba(255, 69, 58, 0.02)', action: () => openDrinksSubMenuModal('sodas') },
      { name: 'Milk', color: 'rgba(255, 255, 255, 0.3)', bg: 'rgba(255, 255, 255, 0.02)', action: () => openDrinksSubMenuModal('milk') },
      { name: 'Gatorade', color: 'rgba(255, 159, 10, 0.3)', bg: 'rgba(255, 159, 10, 0.02)', action: () => openDrinksSubMenuModal('gatorade') },
      { name: 'Arizona', color: 'rgba(48, 209, 88, 0.3)', bg: 'rgba(48, 209, 88, 0.02)', action: () => openDrinksSubMenuModal('arizona') },
      { name: 'Faygo', color: 'rgba(191, 90, 242, 0.3)', bg: 'rgba(191, 90, 242, 0.02)', action: () => openDrinksSubMenuModal('faygo') },
      { name: 'Mexican Sodas', color: 'rgba(255, 214, 10, 0.3)', bg: 'rgba(255, 214, 10, 0.02)', action: () => openDrinksSubMenuModal('mexican_sodas') },
      { name: 'Everfresh', color: 'rgba(255, 105, 180, 0.3)', bg: 'rgba(255, 105, 180, 0.02)', action: () => openDrinksSubMenuModal('everfresh') },
      { name: 'Jugitos', color: 'rgba(90, 200, 250, 0.3)', bg: 'rgba(90, 200, 250, 0.02)', action: () => openDrinksSubMenuModal('jugitos') },
      { name: 'Malta / Goya', color: 'rgba(172, 142, 104, 0.3)', bg: 'rgba(172, 142, 104, 0.02)', action: () => openDrinksSubMenuModal('malta_goya') },
      { name: 'Tropicana', color: 'rgba(255, 149, 0, 0.3)', bg: 'rgba(255, 149, 0, 0.02)', action: () => openDrinksSubMenuModal('tropicana') },
      { name: 'Volt', color: 'rgba(85, 239, 196, 0.3)', bg: 'rgba(85, 239, 196, 0.02)', action: () => openDrinksSubMenuModal('volt') },
      { name: 'Water', color: 'rgba(0, 122, 255, 0.3)', bg: 'rgba(0, 122, 255, 0.02)', action: () => openDrinksSubMenuModal('water') },
      { name: 'Aloe', color: 'rgba(52, 199, 89, 0.3)', bg: 'rgba(52, 199, 89, 0.02)', action: () => openDrinksSubMenuModal('aloe') }
    ];

    folders.forEach(f => {
      const card = document.createElement('div');
      card.className = 'product-card';
      card.style.borderColor = f.color;
      card.style.backgroundColor = f.bg;
      card.style.display = 'flex';
      card.style.alignItems = 'center';
      card.style.justifyContent = 'center';
      card.innerHTML = `
        <div class="product-name" style="font-size: 13px; font-weight: 800; color: #fff; text-align: center; text-transform: uppercase;">${f.name}</div>
      `;
      card.addEventListener('click', f.action);
      grid.appendChild(card);
    });

    // 3. Render individual drinks (that do NOT belong to any pinned or folders)
    const individualDrinks = filtered.filter(p => {
      if (pinnedNames.includes(p.name.toUpperCase())) return false;
      const name = p.name.toUpperCase();
      
      const isSoda = name.includes('COCA') || name.includes('PEPSI') || name.includes('JARR') || 
                      name.includes('7UP') || name.includes('ROOT BEER') || name.includes('DR. PEPPER') || 
                      name.includes('SQUIRT') || name.includes('SUNKIST') || name.includes('SANGRIA') || 
                      name.includes('SIDRAL') || name.includes('SPRITE') || name.includes('FANTA') || 
                      name.includes('MANZANITA') || name.includes('DR.PEPPER') || name.includes('BEARSITOS');
      const isMilk = name.includes('MILK') || name.includes('LECH') || name.includes('ALPURA') || name.includes('COUNTRY');
      const isGatorade = name.includes('GATORADE');
      const isArizona = name.includes('ARIZONA');
      const isFaygo = name.includes('FAYGO');
      const isMexicanSoda = name.includes('TOPO') || name.includes('SANGR') || name.includes('SIDR');
      const isEverfresh = name.includes('EVERFRESH');
      const isJugito = name.includes('JUGITO');
      const isMaltaGoya = name.includes('MALT') || name.includes('GOY');
      const isTropicana = name.includes('TROPICANA');
      const isVolt = name.includes('VOLT');
      const isWater = (name.includes('WAT') || (name.includes('AGUA') && !name.includes('COCO')) || name.includes('MINERAGUA')) && !name.includes('PALETA');
      const isAloe = name.includes('ALOE');
      
      return !isSoda && !isMilk && !isGatorade && !isArizona && !isFaygo && !isMexicanSoda && 
             !isEverfresh && !isJugito && !isMaltaGoya && !isTropicana && !isVolt && !isWater && !isAloe;
    });

    sortProducts(individualDrinks);
    individualDrinks.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      if (p.color) {
        card.style.borderColor = p.color;
        card.style.backgroundColor = p.color.startsWith('#') ? p.color + '1a' : p.color;
      }
      const isOutOfStock = p.trackStock && (parseFloat(p.stockQuantity) || 0) <= 0;
      if (isOutOfStock) {
        card.style.opacity = '0.5';
        card.style.cursor = 'not-allowed';
      }
      const fSize = p.fontSize ? p.fontSize + 'px' : '13px';
      const colorStyle = p.color ? `color: ${p.color};` : 'color: var(--accent-color);';
      const stockBadge = isOutOfStock ? `<div style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin-top: 2px;">AGOTADO</div>` : '';
      setupProductCardContent(card, p, fSize, colorStyle + ' font-weight: 700;', stockBadge, isOutOfStock);
      if (isOutOfStock) {
        card.addEventListener('click', () => showToast('⚠️ Producto agotado / Out of stock!', 'error'));
      } else {
        card.addEventListener('click', () => addToCart(p));
      }
      grid.appendChild(card);
    });
  }
  else {
    sortProducts(filtered);
    filtered.forEach(p => {
      const card = document.createElement('div');
      card.className = 'product-card';
      if (p.color) {
        card.style.borderColor = p.color;
        card.style.backgroundColor = p.color.startsWith('#') ? p.color + '1a' : p.color;
      }
      const isOutOfStock = p.trackStock && (parseFloat(p.stockQuantity) || 0) <= 0;
      if (isOutOfStock) {
        card.style.opacity = '0.5';
        card.style.cursor = 'not-allowed';
      }
      const fSize = p.fontSize ? p.fontSize + 'px' : '13px';
      const colorStyle = p.color ? `color: ${p.color};` : 'color: #fff;';
      const stockBadge = isOutOfStock ? `<div style="font-size: 9px; color: var(--danger-color); font-weight: bold; margin-top: 2px;">AGOTADO</div>` : '';
      setupProductCardContent(card, p, fSize, colorStyle, stockBadge, isOutOfStock);
      if (isOutOfStock) {
        card.addEventListener('click', () => showToast('⚠️ Producto agotado / Out of stock!', 'error'));
      } else {
        card.addEventListener('click', () => addToCart(p));
      }
      grid.appendChild(card);
    });
  }
}

// Abrir modal de panes por grupo de precio (Genérico)
function openPriceGroupModal(titleLabel, items) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalContent = modal.querySelector('.modal-content');
  const modalBody = modal.querySelector('.modal-body');
  
  if (modalContent) {
    modalContent.style.maxWidth = '600px';
    modalContent.style.width = '80%';
  }
  if (modalBody) modalBody.style.maxHeight = '60vh';
  
  title.innerText = titleLabel;
  container.innerHTML = '';

  items.sort((a, b) => a.name.localeCompare(b.name));

  items.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'btn-option';
    btn.style.padding = '14px 10px';
    btn.style.fontSize = '13px';
    btn.style.textAlign = 'center';
    btn.style.height = '70px';
    btn.style.display = 'flex';
    btn.style.alignItems = 'center';
    btn.style.justifyContent = 'center';
    btn.innerText = p.name;
    
    btn.addEventListener('click', () => {
      addToCart(p);
    });
    container.appendChild(btn);
  });

  modal.style.display = 'flex';
}

// Abrir sub-menú de pasteles por categoría (Regular o Tres Leches) en modal
function openCakeSubMenuModal(subType) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalContent = modal.querySelector('.modal-content');
  const modalBody = modal.querySelector('.modal-body');
  
  container.innerHTML = '';
  
  if (subType === 'dessert') {
    modalContent.style.maxWidth = '950px';
    modalContent.style.width = '95%';
    if (modalBody) {
      modalBody.style.maxHeight = 'none';
      modalBody.style.overflowY = 'hidden';
      modalBody.style.overflow = 'hidden';
    }
    container.style.maxHeight = 'none';
    container.style.overflowY = 'hidden';
    container.style.overflow = 'hidden';
    title.innerText = 'Whole Desserts';
    
    // Traer todos los postres grandes (categoría dessert)
    const filteredDesserts = products.filter(p => p.category === 'dessert' && p.price > 0);
    filteredDesserts.sort((a, b) => a.name.localeCompare(b.name));
    
    container.style.display = 'grid';
    container.style.gridTemplateColumns = 'repeat(4, 1fr)';
    container.style.gap = '10px';
    container.style.width = '100%';
    
    filteredDesserts.forEach(p => {
      const btn = document.createElement('button');
      btn.className = 'checkout-btn';
      btn.style.backgroundColor = 'var(--bg-secondary)';
      btn.style.border = '1px solid var(--border-color)';
      btn.style.color = '#fff';
      btn.style.padding = '15px 10px';
      btn.style.fontSize = '14px';
      btn.style.fontWeight = 'bold';
      btn.style.borderRadius = '12px';
      btn.style.cursor = 'pointer';
      btn.innerText = `${p.name}\n$${p.price.toFixed(2)}`;
      
      btn.addEventListener('click', () => {
        addToCart(p);
      });
      
      container.appendChild(btn);
    });
    
    modal.style.display = 'flex';
    return;
  }
  
  modalContent.style.maxWidth = '600px';
  modalContent.style.width = '80%';
  if (modalBody) modalBody.style.maxHeight = '60vh';
  container.style.maxHeight = '450px';
  
  title.innerText = subType === 'regular' ? 'Regular Cakes' : 'Tres Leches Cakes';
  
  // Filtrar artículos
  let filtered = [];
  if (subType === 'regular') {
    filtered = products.filter(p => (p.category === 'pasteles' || p.category === 'pan regs' || p.category === 's cake' || p.category === 'panaderia') && p.price >= 22.00 && p.price > 0);
  } else {
    filtered = products.filter(p => p.category === '3lech st' && p.price > 0);
  }
  
  // Agrupar por tamaño
  const groupedBySize = {};
  filtered.forEach(p => {
    const sizeKey = getCakeSize(p.name);
    if (sizeKey) {
      if (!groupedBySize[sizeKey]) {
        groupedBySize[sizeKey] = [];
      }
      groupedBySize[sizeKey].push(p);
    }
  });
  
  // Diseñar cuadrícula de tamaños
  container.style.display = 'grid';
  container.style.gridTemplateColumns = 'repeat(2, 1fr)';
  container.style.gap = '15px';
  container.style.width = '100%';
  
  const sizeOrder = ['6" Cakes', '8" Cakes', '10" Cakes', '1/4 Sheet', '1/2 Sheet', 'Full Sheet'];
  
  sizeOrder.forEach(sizeName => {
    const itemsInSize = groupedBySize[sizeName];
    if (!itemsInSize || itemsInSize.length === 0) return;
    
    const btn = document.createElement('button');
    btn.className = 'checkout-btn';
    btn.style.backgroundColor = 'var(--bg-secondary)';
    btn.style.border = '1px solid var(--border-color)';
    btn.style.color = '#fff';
    btn.style.padding = '20px';
    btn.style.fontSize = '18px';
    btn.style.fontWeight = 'bold';
    btn.style.borderRadius = '12px';
    btn.style.cursor = 'pointer';
    btn.innerText = sizeName;
    
    btn.addEventListener('click', () => {
      openCakeSizeModal(sizeName, itemsInSize);
    });
    
    container.appendChild(btn);
  });
  
  modal.style.display = 'flex';
}

// Abrir sub-menú de postres individuales en rebanada (Slices) en modal
function openSliceSubMenuModal(type) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalContent = modal.querySelector('.modal-content');
  const modalBody = modal.querySelector('.modal-body');
  
  modalContent.style.maxWidth = '950px';
  modalContent.style.width = '95%';
  if (modalBody) modalBody.style.maxHeight = '85vh';
  container.innerHTML = '';
  
  let filtered = [];
  const allSlices = products.filter(p => (p.category === 's cake' || p.category === 'postres') && p.price < 22.00 && p.price > 0);
  
  if (type === 'tres_leches_slices') {
    title.innerText = 'Tres Leches Slices';
    filtered = allSlices.filter(p => p.name.toUpperCase().includes('3L ') || p.name.toUpperCase().includes('3L_') || p.name.toUpperCase().includes('3 LECHES'));
  } else if (type === 'flans') {
    title.innerText = 'Flans';
    filtered = allSlices.filter(p => p.name.toUpperCase().includes('FLAN'));
  } else if (type === 'gelatinas') {
    title.innerText = 'Gelatinas';
    filtered = allSlices.filter(p => p.name.toUpperCase().includes('GELAT'));
  }
  
  filtered.sort((a, b) => a.name.localeCompare(b.name));
  
  container.style.display = 'grid';
  container.style.gridTemplateColumns = 'repeat(3, 1fr)';
  container.style.gap = '10px';
  container.style.width = '100%';
  
  filtered.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'checkout-btn';
    btn.style.backgroundColor = 'var(--bg-secondary)';
    btn.style.border = '1px solid var(--border-color)';
    btn.style.color = '#fff';
    btn.style.padding = '15px 10px';
    btn.style.fontSize = '14px';
    btn.style.fontWeight = 'bold';
    btn.style.borderRadius = '12px';
    btn.style.cursor = 'pointer';
    btn.innerText = `${p.name}\n$${p.price.toFixed(2)}`;
    
    btn.addEventListener('click', () => {
      addToCart(p);
    });
    
    container.appendChild(btn);
  });
  
  modal.style.display = 'flex';
}

// Abrir sub-menú de bebidas (refrescos, leches, Gatorade, tés, etc.) en modal
function openDrinksSubMenuModal(drinkType) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalContent = modal.querySelector('.modal-content');
  const modalBody = modal.querySelector('.modal-body');
  
  modalContent.style.maxWidth = '950px';
  modalContent.style.width = '95%';
  if (modalBody) modalBody.style.maxHeight = '85vh';
  container.innerHTML = '';
  
  const allDrinks = products.filter(p => p.category === 'bebidas' && p.price > 0);
  
  if (drinkType === 'sodas') {
    title.innerText = 'Sodas / Refrescos';
    
    container.style.display = 'grid';
    container.style.gridTemplateColumns = 'repeat(2, 1fr)';
    container.style.gap = '15px';
    container.style.width = '100%';
    
    const brands = [
      { name: 'Coca-Cola', filter: (p) => p.name.toUpperCase().includes('COCA') },
      { name: 'Pepsi', filter: (p) => p.name.toUpperCase().includes('PEPSI') || (p.name.toUpperCase().includes('PEP') && !p.name.toUpperCase().includes('DR. PEPPER') && !p.name.toUpperCase().includes('DR.PEPPER')) },
      { name: 'Jarritos', filter: (p) => p.name.toUpperCase().includes('JARR') },
      { name: 'Other Brands / Variados', filter: (p) => {
          const name = p.name.toUpperCase();
          return (name.includes('7UP') || name.includes('ROOT BEER') || name.includes('DR. PEPPER') || 
                 name.includes('DR.PEPPER') || name.includes('SQUIRT') || name.includes('SUNKIST') || 
                 name.includes('SPRITE') || name.includes('FANTA') || name.includes('MANZANITA') || 
                 name.includes('BEARSITOS')) && 
                 !name.includes('TOPO') && !name.includes('SANGR') && !name.includes('SIDR') && !name.includes('FAYGO');
        }
      }
    ];
    
    brands.forEach(b => {
      const btn = document.createElement('button');
      btn.className = 'checkout-btn';
      btn.style.backgroundColor = 'var(--bg-secondary)';
      btn.style.border = '1px solid var(--border-color)';
      btn.style.color = '#fff';
      btn.style.padding = '25px';
      btn.style.fontSize = '18px';
      btn.style.fontWeight = 'bold';
      btn.style.borderRadius = '12px';
      btn.style.cursor = 'pointer';
      btn.innerText = b.name;
      
      btn.addEventListener('click', () => {
        const brandProducts = allDrinks.filter(b.filter);
        openDrinksBrandListModal(b.name, brandProducts);
      });
      
      container.appendChild(btn);
    });
    
  } else if (drinkType === 'milk') {
    title.innerText = 'Milk / Leches';
    const milkProducts = allDrinks.filter(p => {
      const name = p.name.toUpperCase();
      return name.includes('MILK') || name.includes('LECH') || name.includes('ALPURA') || name.includes('COUNTRY');
    });
    renderDrinkItemsGrid(milkProducts);
  } else if (drinkType === 'gatorade') {
    title.innerText = 'Gatorade';
    const gatoradeProducts = allDrinks.filter(p => p.name.toUpperCase().includes('GATORADE'));
    renderDrinkItemsGrid(gatoradeProducts);
  } else if (drinkType === 'arizona') {
    title.innerText = 'Arizona';
    const arizonaProducts = allDrinks.filter(p => p.name.toUpperCase().includes('ARIZONA'));
    renderDrinkItemsGrid(arizonaProducts);
  } else if (drinkType === 'faygo') {
    title.innerText = 'Faygo';
    const faygoProducts = allDrinks.filter(p => p.name.toUpperCase().includes('FAYGO'));
    renderDrinkItemsGrid(faygoProducts);
  } else if (drinkType === 'mexican_sodas') {
    title.innerText = 'Mexican Sodas';
    const mexProducts = allDrinks.filter(p => {
      const name = p.name.toUpperCase();
      return name.includes('TOPO') || name.includes('SANGR') || name.includes('SIDR');
    });
    renderDrinkItemsGrid(mexProducts);
  } else if (drinkType === 'everfresh') {
    title.innerText = 'Everfresh';
    const everProducts = allDrinks.filter(p => p.name.toUpperCase().includes('EVERFRESH'));
    renderDrinkItemsGrid(everProducts);
  } else if (drinkType === 'jugitos') {
    title.innerText = 'Jugitos';
    const jugitoProducts = allDrinks.filter(p => p.name.toUpperCase().includes('JUGITO'));
    renderDrinkItemsGrid(jugitoProducts);
  } else if (drinkType === 'malta_goya') {
    title.innerText = 'Malta / Goya';
    const maltaProducts = allDrinks.filter(p => p.name.toUpperCase().includes('MALT') || p.name.toUpperCase().includes('GOY'));
    renderDrinkItemsGrid(maltaProducts);
  } else if (drinkType === 'tropicana') {
    title.innerText = 'Tropicana';
    const tropProducts = allDrinks.filter(p => p.name.toUpperCase().includes('TROPICANA'));
    renderDrinkItemsGrid(tropProducts);
  } else if (drinkType === 'volt') {
    title.innerText = 'Volt Energy';
    const voltProducts = allDrinks.filter(p => p.name.toUpperCase().includes('VOLT'));
    renderDrinkItemsGrid(voltProducts);
  } else if (drinkType === 'water') {
    title.innerText = 'Water';
    const waterProducts = allDrinks.filter(p => {
      const name = p.name.toUpperCase();
      return (name.includes('WAT') || (name.includes('AGUA') && !name.includes('COCO')) || name.includes('MINERAGUA')) && !name.includes('PALETA');
    });
    renderDrinkItemsGrid(waterProducts);
  } else if (drinkType === 'aloe') {
    title.innerText = 'Aloe';
    const aloeProducts = allDrinks.filter(p => p.name.toUpperCase().includes('ALOE'));
    renderDrinkItemsGrid(aloeProducts);
  }
  
  modal.style.display = 'flex';
}

function openDrinksBrandListModal(brandName, brandProducts) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalBody = modal.querySelector('.modal-body');
  
  if (modalBody) modalBody.style.maxHeight = '85vh';
  title.innerText = `Sodas - ${brandName}`;
  container.innerHTML = '';
  
  const backRow = document.createElement('div');
  backRow.style.gridColumn = '1 / -1';
  backRow.style.marginBottom = '10px';
  
  const backBtn = document.createElement('button');
  backBtn.className = 'checkout-btn';
  backBtn.style.backgroundColor = 'var(--border-color)';
  backBtn.style.color = '#fff';
  backBtn.style.padding = '8px 16px';
  backBtn.style.border = 'none';
  backBtn.style.borderRadius = '6px';
  backBtn.style.cursor = 'pointer';
  backBtn.style.fontWeight = 'bold';
  backBtn.innerText = '⬅ Back to Sodas';
  
  backBtn.addEventListener('click', () => {
    openDrinksSubMenuModal('sodas');
  });
  backRow.appendChild(backBtn);
  container.appendChild(backRow);
  
  brandProducts.sort((a, b) => a.name.localeCompare(b.name));
  
  container.style.display = 'grid';
  container.style.gridTemplateColumns = 'repeat(3, 1fr)';
  container.style.gap = '10px';
  
  brandProducts.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'checkout-btn';
    btn.style.backgroundColor = 'var(--bg-secondary)';
    btn.style.border = '1px solid var(--border-color)';
    btn.style.color = '#fff';
    btn.style.padding = '15px 10px';
    btn.style.fontSize = '13px';
    btn.style.fontWeight = 'bold';
    btn.style.borderRadius = '12px';
    btn.style.cursor = 'pointer';
    btn.innerText = `${p.name}\n$${p.price.toFixed(2)}`;
    
    btn.addEventListener('click', () => {
      addToCart(p);
    });
    container.appendChild(btn);
  });
}

function renderDrinkItemsGrid(drinkProducts) {
  const modal = document.getElementById('modalPriceGroup');
  const container = document.getElementById('priceGroupItems');
  const modalBody = modal.querySelector('.modal-body');
  
  if (modalBody) modalBody.style.maxHeight = '85vh';
  
  drinkProducts.sort((a, b) => a.name.localeCompare(b.name));
  
  container.style.display = 'grid';
  container.style.gridTemplateColumns = 'repeat(3, 1fr)';
  container.style.gap = '10px';
  container.style.width = '100%';
  
  drinkProducts.forEach(p => {
    const btn = document.createElement('button');
    btn.className = 'checkout-btn';
    btn.style.backgroundColor = 'var(--bg-secondary)';
    btn.style.border = '1px solid var(--border-color)';
    btn.style.color = '#fff';
    btn.style.padding = '15px 10px';
    btn.style.fontSize = '13px';
    btn.style.fontWeight = 'bold';
    btn.style.borderRadius = '12px';
    btn.style.cursor = 'pointer';
    btn.innerText = `${p.name}\n$${p.price.toFixed(2)}`;
    
    btn.addEventListener('click', () => {
      addToCart(p);
    });
    container.appendChild(btn);
  });
}

// Abrir modal estructurado para Pasteles por Tamaño (Con/Sin diseño)
function openCakeSizeModal(sizeLabel, items) {
  const modal = document.getElementById('modalPriceGroup');
  const title = document.getElementById('priceGroupTitle');
  const container = document.getElementById('priceGroupItems');
  const modalContent = modal.querySelector('.modal-content');
  const modalBody = modal.querySelector('.modal-body');
  
  if (modalContent) {
    modalContent.style.maxWidth = '600px';
    modalContent.style.width = '80%';
  }
  if (modalBody) modalBody.style.maxHeight = '60vh';
  
  title.innerText = sizeLabel;
  container.innerHTML = '';

  // Dividir en "Regular" (Sin Diseño) y "With Design" (Con Diseño)
  const regularCakes = items.filter(p => !hasCakeDesign(p.name));
  const designCakes = items.filter(p => hasCakeDesign(p.name));

  // Fila superior de pestañas (Regular / Design)
  const toggleRow = document.createElement('div');
  toggleRow.className = 'options-row';
  toggleRow.style.gridColumn = 'span 3';
  toggleRow.style.justifyContent = 'center';
  toggleRow.style.marginBottom = '20px';
  toggleRow.style.display = 'flex';
  toggleRow.style.width = '100%';
  toggleRow.style.gap = '15px';

  const btnSin = document.createElement('button');
  btnSin.className = 'btn-option selected';
  btnSin.style.fontSize = '16px';
  btnSin.style.fontWeight = '700';
  btnSin.style.padding = '12px 24px';
  btnSin.innerText = 'REGULAR';

  const btnCon = document.createElement('button');
  btnCon.className = 'btn-option';
  btnCon.style.fontSize = '16px';
  btnCon.style.fontWeight = '700';
  btnCon.style.padding = '12px 24px';
  btnCon.innerText = 'DESIGN';

  toggleRow.appendChild(btnSin);
  toggleRow.appendChild(btnCon);
  container.appendChild(toggleRow);

  // Sub-rejilla para los pasteles específicos
  const itemsContainer = document.createElement('div');
  itemsContainer.style.display = 'grid';
  itemsContainer.style.gridTemplateColumns = 'repeat(auto-fill, minmax(130px, 1fr))';
  itemsContainer.style.gap = '12px';
  itemsContainer.style.width = '100%';
  itemsContainer.style.gridColumn = 'span 3';
  container.appendChild(itemsContainer);

  const renderSubGroup = (cakeList) => {
    itemsContainer.innerHTML = '';
    
    if (cakeList.length === 0) {
      itemsContainer.innerHTML = `<div style="grid-column: span 3; text-align: center; color: var(--text-secondary); padding: 20px;">No cakes available in this section</div>`;
      return;
    }

    cakeList.sort((a, b) => a.name.localeCompare(b.name));

    cakeList.forEach(p => {
      const btn = document.createElement('button');
      btn.className = 'btn-option';
      btn.style.padding = '14px 10px';
      btn.style.fontSize = '13px';
      btn.style.textAlign = 'center';
      btn.style.height = '80px';
      btn.style.display = 'flex';
      btn.style.flexDirection = 'column';
      btn.style.alignItems = 'center';
      btn.style.justifyContent = 'center';
      btn.style.gap = '6px';
      
      // Limpiar el nombre para mostrar solo el sabor (ej: "Chocolate")
      const cleanName = p.name.replace(/pastel\s+\d+("| pulgadas| p)?\s*(regular|diseño|diseno)?\s*/gi, '').trim();
      
      btn.innerHTML = `
        <div style="font-weight: 700; color:#fff;">${cleanName || p.name}</div>
        <div style="color:var(--accent-color); font-weight:700;">$${p.price.toFixed(2)}</div>
      `;
      
      btn.addEventListener('click', () => {
        addToCart(p);
      });
      itemsContainer.appendChild(btn);
    });
  };

  btnSin.addEventListener('click', () => {
    btnSin.classList.add('selected');
    btnCon.classList.remove('selected');
    renderSubGroup(regularCakes);
  });

  btnCon.addEventListener('click', () => {
    btnCon.classList.add('selected');
    btnSin.classList.remove('selected');
    renderSubGroup(designCakes);
  });

  renderSubGroup(regularCakes);
  modal.style.display = 'flex';
}

// --- GESTIÓN DEL CARRITO DE COMPRAS ---
// Global State for Batch Modifiers
let currentModProduct = null;
let currentModQty = 1;
let currentModActiveIndex = 0;
let currentModSelections = [];

function getQtyInCart(prodId) {
  let total = 0;
  cart.forEach(item => {
    if (item.id.split('_c')[0] === prodId) {
      total += item.quantity;
    }
  });
  return total;
}

function addToCart(product) {
  if (!deliveryType) {
    const def = (posSettings && posSettings.defaultServiceType) || (posSettings && posSettings.businessType && posSettings.businessType.includes('taco_truck') ? 'llevar' : 'llevar');
    if (def) {
      selectPreOrderType(def);
    } else {
      const isEs = posSettings && posSettings.language === 'es';
      showToast(isEs ? '⚠️ Seleccione tipo de servicio primero' : '⚠️ Select order service type first', 'warning');
      return;
    }
  }
  const cleanProductId = product.id.split('_c')[0];
  const isOutOfStock = product.trackStock && (parseFloat(product.stockQuantity) || 0) <= 0;
  if (isOutOfStock) {
    showToast('⚠️ Producto agotado / Out of stock!', 'error');
    return;
  }
  
  const resolvedGroups = getProductModifierGroups(product);
  if (resolvedGroups && resolvedGroups.length > 0) {
    if (product.trackStock && getQtyInCart(cleanProductId) + 1 > product.stockQuantity) {
      showToast('⚠️ Stock insuficiente / Out of stock!', 'error');
      return;
    }
    
    currentModProduct = product;
    currentModQty = 1;
    currentModActiveIndex = 0;
    currentModSelections = [ {} ];
    
    const applyAllChk = document.getElementById('chkModApplyToAll');
    if (applyAllChk) applyAllChk.checked = false;
    
    renderModifiers();
    const modalMod = document.getElementById('modalModifiers');
    if (modalMod) modalMod.style.display = 'flex';
    return;
  }

  const itemId = activeTabClientSeat ? `${product.id}_c${activeTabClientSeat}` : product.id;
  const itemName = activeTabClientSeat ? `${product.name} (Cliente ${activeTabClientSeat})` : product.name;

  if (product.trackStock && getQtyInCart(cleanProductId) + 1 > product.stockQuantity) {
    showToast('⚠️ Stock insuficiente / Out of stock!', 'error');
    return;
  }

  const existing = cart.find(item => item.id === itemId && !item.isCustomCake && (!item.selectedModifiers || item.selectedModifiers.length === 0));
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({
      id: itemId,
      name: itemName,
      price: product.price,
      quantity: 1,
      isCustomCake: false,
      isTaxable: product.isTaxable !== false,
      clientSeat: activeTabClientSeat || null
    });
  }
  updateCartUI();
  showToast(`${product.name} agregado`);
}

function initModifiersModal() {
  const decBtn = document.getElementById('btnModQtyDec');
  const incBtn = document.getElementById('btnModQtyInc');
  const applyAllChk = document.getElementById('chkModApplyToAll');
  const prevBtn = document.getElementById('btnModNavPrev');
  const nextBtn = document.getElementById('btnModNavNext');
  const submitBtn = document.getElementById('btnModSubmit');

  if (decBtn) {
    decBtn.onclick = (e) => {
      e.preventDefault();
      if (currentModQty > 1) {
        currentModQty--;
        currentModSelections.pop();
        if (currentModActiveIndex >= currentModQty) {
          currentModActiveIndex = currentModQty - 1;
        }
        renderModifiers();
      }
    };
  }

  if (incBtn) {
    incBtn.onclick = (e) => {
      e.preventDefault();
      currentModQty++;
      currentModSelections.push({});
      if (applyAllChk && applyAllChk.checked) {
        syncApplyToAll();
      }
      renderModifiers();
    };
  }

  if (applyAllChk) {
    applyAllChk.onchange = () => {
      if (applyAllChk.checked) {
        syncApplyToAll();
        renderModifiers();
      }
    };
  }

  if (prevBtn) {
    prevBtn.onclick = (e) => {
      e.preventDefault();
      if (currentModActiveIndex > 0) {
        if (validateCurrentModItemRequired()) {
          currentModActiveIndex--;
          renderModifiers();
        }
      }
    };
  }

  if (nextBtn) {
    nextBtn.onclick = (e) => {
      e.preventDefault();
      if (currentModActiveIndex < currentModQty - 1) {
        if (validateCurrentModItemRequired()) {
          currentModActiveIndex++;
          renderModifiers();
        }
      }
    };
  }

  if (submitBtn) {
    submitBtn.onclick = (e) => {
      e.preventDefault();
      
      // Enforce stock checks if tracked
      if (currentModProduct && currentModProduct.trackStock) {
        const cleanProductId = currentModProduct.id.split('_c')[0];
        if (getQtyInCart(cleanProductId) + currentModQty > currentModProduct.stockQuantity) {
          showToast('⚠️ Stock insuficiente / Out of stock!', 'error');
          return;
        }
      }
      
      // Validate all items
      for (let i = 0; i < currentModQty; i++) {
        const prev = currentModActiveIndex;
        currentModActiveIndex = i;
        if (!validateCurrentModItemRequired()) {
          renderModifiers();
          return;
        }
        currentModActiveIndex = prev;
      }

      // Add all to cart
      for (let i = 0; i < currentModQty; i++) {
        const itemSelections = currentModSelections[i] || {};
        let selectedModifiers = [];
        let extraPrice = 0;
        Object.keys(itemSelections).forEach(groupId => {
          const opts = itemSelections[groupId] || [];
          opts.forEach(o => {
            selectedModifiers.push({ name: o.name, price: o.price });
            extraPrice += o.price;
          });
        });

        const itemId = activeTabClientSeat ? `${currentModProduct.id}_c${activeTabClientSeat}` : currentModProduct.id;
        const itemName = activeTabClientSeat ? `${currentModProduct.name} (Cliente ${activeTabClientSeat})` : currentModProduct.name;

        const existing = cart.find(item => 
          item.id === itemId && 
          !item.isCustomCake && 
          hasSameModifiers(item.selectedModifiers, selectedModifiers)
        );

        if (existing) {
          existing.quantity++;
        } else {
          cart.push({
            id: itemId,
            name: itemName,
            price: currentModProduct.price + extraPrice,
            basePrice: currentModProduct.price,
            quantity: 1,
            isCustomCake: false,
            isTaxable: currentModProduct.isTaxable !== false,
            selectedModifiers: selectedModifiers,
            clientSeat: activeTabClientSeat || null
          });
        }
      }

      updateCartUI();
      const modalMod = document.getElementById('modalModifiers');
      if (modalMod) modalMod.style.display = 'none';
      showToast(`${currentModProduct.name} batch added to cart`, 'success');
      
      currentModProduct = null;
      currentModSelections = [];
    };
  }
}

function syncApplyToAll() {
  const item0 = currentModSelections[0] || {};
  for (let i = 1; i < currentModQty; i++) {
    currentModSelections[i] = JSON.parse(JSON.stringify(item0));
  }
}

function validateCurrentModItemRequired() {
  const resolvedGroups = getProductModifierGroups(currentModProduct);
  if (!currentModProduct || resolvedGroups.length === 0) return true;
  const selections = currentModSelections[currentModActiveIndex] || {};
  for (let group of resolvedGroups) {
    if (group.required) {
      const opts = selections[group.id] || [];
      if (opts.length === 0) {
        showToast(`Please choose ${group.name} for Item ${currentModActiveIndex + 1}`, 'warning');
        return false;
      }
    }
  }
  return true;
}

function hasSameModifiers(arr1, arr2) {
  const a1 = arr1 || [];
  const a2 = arr2 || [];
  if (a1.length !== a2.length) return false;
  const names1 = a1.map(m => m.name).sort();
  const names2 = a2.map(m => m.name).sort();
  return names1.every((val, index) => val === names2[index]);
}

function calculateModTotals() {
  let total = 0;
  for (let i = 0; i < currentModQty; i++) {
    total += currentModProduct.price;
    const selections = currentModSelections[i] || {};
    Object.keys(selections).forEach(groupId => {
      const opts = selections[groupId] || [];
      opts.forEach(o => {
        total += o.price;
      });
    });
  }
  const totalLbl = document.getElementById('lblModTotal');
  if (totalLbl) totalLbl.innerText = `$${total.toFixed(2)}`;
}

function renderModifiers() {
  const container = document.getElementById('divModGroupsContainer');
  if (!container) return;
  container.innerHTML = '';
  
  const resolvedGroups = getProductModifierGroups(currentModProduct);
  if (!currentModProduct || resolvedGroups.length === 0) return;
  
  const titleLbl = document.getElementById('lblModifiersProductTitle');
  if (titleLbl) titleLbl.innerText = `Customize ${currentModProduct.name}`;
  
  const qtyLbl = document.getElementById('lblModQty');
  if (qtyLbl) qtyLbl.innerText = currentModQty;
  
  // Tabs rendering
  const tabsDiv = document.getElementById('divModTabs');
  if (tabsDiv) {
    if (currentModQty > 1) {
      tabsDiv.style.display = 'flex';
      tabsDiv.innerHTML = '';
      for (let i = 0; i < currentModQty; i++) {
        const btn = document.createElement('button');
        btn.className = `modifier-tab-btn ${i === currentModActiveIndex ? 'active' : ''}`;
        btn.innerText = `Item ${i + 1}`;
        btn.onclick = (e) => {
          e.preventDefault();
          if (validateCurrentModItemRequired()) {
            currentModActiveIndex = i;
            renderModifiers();
          }
        };
        tabsDiv.appendChild(btn);
      }
      const applyAllWrapper = document.getElementById('wrapperModApplyToAll');
      if (applyAllWrapper) applyAllWrapper.style.display = 'block';
    } else {
      tabsDiv.style.display = 'none';
      const applyAllWrapper = document.getElementById('wrapperModApplyToAll');
      if (applyAllWrapper) applyAllWrapper.style.display = 'none';
    }
  }
  
  // Navigation buttons
  const prevBtn = document.getElementById('btnModNavPrev');
  const nextBtn = document.getElementById('btnModNavNext');
  if (prevBtn && nextBtn) {
    if (currentModQty > 1) {
      prevBtn.style.display = currentModActiveIndex > 0 ? 'inline-block' : 'none';
      nextBtn.style.display = currentModActiveIndex < currentModQty - 1 ? 'inline-block' : 'none';
    } else {
      prevBtn.style.display = 'none';
      nextBtn.style.display = 'none';
    }
  }
  
  // Render groups
  const selections = currentModSelections[currentModActiveIndex] || {};
  
  resolvedGroups.forEach(group => {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'modifier-group-box';
    
    const titleSpan = document.createElement('div');
    titleSpan.className = 'modifier-group-title';
    titleSpan.innerHTML = `<span>${group.name}</span> ${group.required ? '<span style="color:var(--danger-color); font-size:10px;">(Required / Obligatorio)</span>' : ''}`;
    groupDiv.appendChild(titleSpan);
    
    const optionsListDiv = document.createElement('div');
    optionsListDiv.className = 'modifier-options-list';
    
    const isSingleSelect = group.max === 1;
    const groupSel = selections[group.id] || [];
    
    group.options.forEach((opt, oIdx) => {
      const optItemDiv = document.createElement('div');
      optItemDiv.className = 'modifier-option-item';
      
      const inputId = `mod_opt_${group.id}_${oIdx}`;
      const input = document.createElement('input');
      input.type = isSingleSelect ? 'radio' : 'checkbox';
      input.name = `mod_group_${group.id}_${currentModActiveIndex}`;
      input.id = inputId;
      input.className = 'modifier-option-input';
      
      const isSelected = groupSel.some(s => s.name === opt.name);
      input.checked = isSelected;
      
      input.onchange = (e) => {
        if (isSingleSelect) {
          selections[group.id] = [ opt ];
        } else {
          if (e.target.checked) {
            const currentCount = selections[group.id] ? selections[group.id].length : 0;
            if (group.max && currentCount >= group.max) {
              e.target.checked = false;
              showToast(`Maximum ${group.max} selections allowed`, 'warning');
              return;
            }
            if (!selections[group.id]) selections[group.id] = [];
            selections[group.id].push(opt);
          } else {
            selections[group.id] = selections[group.id].filter(s => s.name !== opt.name);
          }
        }
        
        currentModSelections[currentModActiveIndex] = selections;
        
        const applyAllChk = document.getElementById('chkModApplyToAll');
        if (applyAllChk && applyAllChk.checked && currentModActiveIndex === 0) {
          syncApplyToAll();
        }
        
        calculateModTotals();
      };
      
      const label = document.createElement('label');
      label.htmlFor = inputId;
      label.className = 'modifier-btn-label';
      label.innerHTML = `<span>${opt.name}</span> <span>${opt.price > 0 ? `+$${opt.price.toFixed(2)}` : ''}</span>`;
      
      const themeColors = { 'red': '#ff4d4f', 'green': '#52c41a', 'yellow': '#fadb14' };
      if (opt.color && themeColors[opt.color]) {
        label.style.borderLeft = `4px solid ${themeColors[opt.color]}`;
        // Optionally, give it a slight tinted background based on color
        // if you want it to stand out more. Let's just stick to borderLeft for now.
      }
      
      optItemDiv.appendChild(input);
      optItemDiv.appendChild(label);
      optionsListDiv.appendChild(optItemDiv);
    });
    
    groupDiv.appendChild(optionsListDiv);
    container.appendChild(groupDiv);
  });
  
}

function initCSVDatabaseExchange() {
  const btnDownloadTemplate = document.getElementById('btnDownloadCSVTemplate');
  const btnExport = document.getElementById('btnExportDatabaseCSV');
  const btnSelectFile = document.getElementById('btnSelectImportCSVFile');
  const fileInput = document.getElementById('inputImportDatabaseCSVFile');
  const btnExecute = document.getElementById('btnExecuteCSVImport');
  const lblFileName = document.getElementById('lblImportCSVFileName');

  if (btnDownloadTemplate) {
    btnDownloadTemplate.onclick = (e) => {
      e.preventDefault();
      const headers = ['id', 'name', 'category', 'price', 'barcode', 'ingredients', 'isTaxable', 'modifierGroupsJSON'];
      const sampleRow = [
        'p_taco_test',
        'Taco de Prueba',
        'restaurante',
        '2.50',
        '9999',
        'Tortilla, carne, salsa',
        'true',
        JSON.stringify([
          {
            id: 'g1',
            name: 'Choice of Meat (Carne)',
            required: true,
            min: 1,
            max: 1,
            options: [
              { name: 'Asada', price: 0.00 },
              { name: 'Pollo', price: 0.00 },
              { name: 'Tripa', price: 1.00 }
            ]
          }
        ])
      ];

      const csvContent = [
        headers.join(','),
        sampleRow.map(val => `"${val.replace(/"/g, '""')}"`).join(',')
      ].join('\r\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.setAttribute('download', 'antigravity_pos_products_template.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast("Plantilla CSV descargada");
    };
  }

  if (btnExport) {
    btnExport.onclick = async (e) => {
      e.preventDefault();
      try {
        const res = await fetch('/api/products');
        if (!res.ok) throw new Error("Failed to fetch products");
        const productsList = await res.json();
        
        const headers = ['id', 'name', 'category', 'price', 'barcode', 'ingredients', 'isTaxable', 'modifierGroupsJSON'];
        const csvRows = [headers.join(',')];
        
        productsList.forEach(p => {
          const row = [
            p.id || '',
            p.name || '',
            p.category || '',
            (p.price || 0).toFixed(2),
            p.barcode || '',
            p.ingredients || '',
            p.isTaxable !== false ? 'true' : 'false',
            JSON.stringify(getProductModifierGroups(p))
          ];
          csvRows.push(row.map(val => `"${val.replace(/"/g, '""')}"`).join(','));
        });
        
        const blob = new Blob([csvRows.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', `antigravity_pos_products_export_${Date.now()}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        showToast("Catálogo CSV exportado");
      } catch (err) {
        showToast(`Error al exportar: ${err.message}`, 'danger');
      }
    };
  }

  if (btnSelectFile && fileInput) {
    btnSelectFile.onclick = (e) => {
      e.preventDefault();
      fileInput.click();
    };

    fileInput.onchange = () => {
      if (fileInput.files.length > 0) {
        const file = fileInput.files[0];
        if (lblFileName) lblFileName.innerText = file.name;
        if (btnExecute) {
          btnExecute.removeAttribute('disabled');
          btnExecute.style.backgroundColor = 'var(--success-color)';
          btnExecute.style.color = '#000';
        }
      } else {
        if (lblFileName) lblFileName.innerText = "Ningún archivo seleccionado";
        if (btnExecute) {
          btnExecute.setAttribute('disabled', 'true');
          btnExecute.style.backgroundColor = '';
          btnExecute.style.color = '';
        }
      }
    };
  }

  if (btnExecute && fileInput) {
    btnExecute.onclick = async (e) => {
      e.preventDefault();
      if (fileInput.files.length === 0) return;
      
      const file = fileInput.files[0];
      const reader = new FileReader();
      
      reader.onload = async (evt) => {
        try {
          const csvText = evt.target.result;
          const parsed = parseCSV(csvText);
          
          if (parsed.length < 2) {
            throw new Error("El archivo CSV está vacío o no contiene filas de datos.");
          }
          
          const headers = parsed[0].map(h => h.trim().toLowerCase());
          const required = ['id', 'name', 'category', 'price'];
          for (let req of required) {
            if (!headers.includes(req)) {
              throw new Error(`Falta la columna obligatoria: ${req}`);
            }
          }
          
          const products = [];
          for (let i = 1; i < parsed.length; i++) {
            const row = parsed[i];
            if (row.length < headers.length) continue;
            
            const p = {};
            headers.forEach((header, idx) => {
              let val = row[idx];
              if (header === 'price') p.price = parseFloat(val) || 0;
              else if (header === 'istaxable') p.isTaxable = val.toLowerCase() === 'true';
              else if (header === 'modifiergroupsjson') {
                try {
                  p.modifierGroups = val ? JSON.parse(val) : [];
                } catch (err) {
                  p.modifierGroups = [];
                }
              } else {
                p[header] = val;
              }
            });
            if (p.id && p.name) {
              products.push(p);
            }
          }

          if (products.length === 0) {
            throw new Error("No se encontraron productos válidos para importar.");
          }
          
          const response = await fetch('/api/admin/products/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(products)
          });
          
          if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || "Error en el servidor al guardar catálogo");
          }
          
          showToast(`¡Importación exitosa! ${products.length} productos cargados.`, 'success');
          
          await loadProducts();
          
          fileInput.value = '';
          if (lblFileName) lblFileName.innerText = "Ningún archivo seleccionado";
          btnExecute.setAttribute('disabled', 'true');
          btnExecute.style.backgroundColor = '';
          btnExecute.style.color = '';
          
        } catch (err) {
          showToast(`Error al importar: ${err.message}`, 'danger');
        }
      };
      
      reader.readAsText(file, 'utf-8');
    };
  }
}

function parseCSV(text) {
  const lines = [];
  let row = [""];
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i+1];

    if (c === '"') {
      if (inQuotes && next === '"') {
        row[row.length - 1] += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (c === ',' && !inQuotes) {
      row.push('');
    } else if ((c === '\r' || c === '\n') && !inQuotes) {
      if (c === '\r' && next === '\n') {
        i++;
      }
      lines.push(row);
      row = [''];
    } else {
      row[row.length - 1] += c;
    }
  }
  if (row.length > 1 || row[0] !== '') {
    lines.push(row);
  }
}

function initProductEditorModifiers() {
  const btnAddNew = document.getElementById('btnAddNewModGroup');
  const btnAddOption = document.getElementById('btnSetupModGroupAddOption');
  const btnSave = document.getElementById('btnSaveSetupModGroup');
  const btnDelete = document.getElementById('btnDeleteSetupModGroup');
  
  if (btnAddNew) {
    btnAddNew.onclick = (e) => {
      e.preventDefault();
      resetSetupModGroupForm();
    };
  }
  
  if (btnAddOption) {
    btnAddOption.onclick = (e) => {
      e.preventDefault();
      addSetupModOptionRow('', 0);
    };
  }

  const btnAddCatalogItem = document.getElementById('btnSetupModGroupAddCatalogItem');
  if (btnAddCatalogItem) {
    btnAddCatalogItem.onclick = (e) => {
      e.preventDefault();
      const select = document.getElementById('setupModGroupCatalogSelect');
      if (!select || select.value === '') {
        showToast('Please select a modifier from the catalog first / Selecciona un modificador primero', 'warning');
        return;
      }
      const idx = parseInt(select.value);
      const item = globalSingleModifiers[idx];
      if (item) {
        addSetupModOptionRow(item.name, item.price);
      }
    };
  }
  
  if (btnSave) {
    btnSave.onclick = async (e) => {
      e.preventDefault();
      await saveSetupModGroup();
    };
  }
  
  if (btnDelete) {
    btnDelete.onclick = async (e) => {
      e.preventDefault();
      await deleteSetupModGroup();
    };
  }

  // --- SUB-TABS CLICS ---
  const btnTabGroups = document.getElementById('btnTabModifiersGroups');
  const btnTabSingle = document.getElementById('btnTabSingleModifiers');
  const panelGroups = document.getElementById('modifiersGroupsPanel');
  const panelSingle = document.getElementById('singleModifiersPanel');
  
  if (btnTabGroups && btnTabSingle && panelGroups && panelSingle) {
    btnTabGroups.onclick = (e) => {
      e.preventDefault();
      panelGroups.style.display = 'flex';
      panelSingle.style.display = 'none';
      btnTabGroups.style.backgroundColor = 'var(--accent-color)';
      btnTabGroups.style.color = '#000';
      btnTabGroups.style.border = 'none';
      
      btnTabSingle.style.backgroundColor = 'var(--bg-secondary)';
      btnTabSingle.style.color = '#fff';
      btnTabSingle.style.border = '1px solid var(--border-color)';
    };
    
    btnTabSingle.onclick = (e) => {
      e.preventDefault();
      panelGroups.style.display = 'none';
      panelSingle.style.display = 'flex';
      btnTabSingle.style.backgroundColor = 'var(--accent-color)';
      btnTabSingle.style.color = '#000';
      btnTabSingle.style.border = 'none';
      
      btnTabGroups.style.backgroundColor = 'var(--bg-secondary)';
      btnTabGroups.style.color = '#fff';
      btnTabGroups.style.border = '1px solid var(--border-color)';
      
      loadSingleModifiers();
    };
  }
  
  // --- SINGLE MODIFIER CREATION ---
  const btnCreateSingle = document.getElementById('btnCreateSingleModifier');
  if (btnCreateSingle) {
    btnCreateSingle.onclick = async (e) => {
      e.preventDefault();
      const input = document.getElementById('inputNewSingleModifierName');
      const inputPrice = document.getElementById('inputNewSingleModifierPrice');
      const inputColor = document.getElementById('inputNewSingleModifierColor');
      if (!input) return;
      const name = input.value.trim();
      const price = inputPrice ? parseFloat(inputPrice.value) || 0 : 0;
      const color = inputColor ? inputColor.value : 'default';
      if (!name) {
        showToast('Please type a modifier name / Por favor escribe un nombre', 'warning');
        return;
      }
      await saveSingleModifier(name, price, color);
      input.value = '';
      if (inputPrice) inputPrice.value = '0.00';
      if (inputColor) inputColor.value = 'default';
    };
  }

  // --- CATALOG PAGINATION CLICS ---
  const btnCatalogBack = document.getElementById('btnCatalogPageBack');
  const btnCatalogNext = document.getElementById('btnCatalogPageNext');
  if (btnCatalogBack) {
    btnCatalogBack.onclick = (e) => {
      e.preventDefault();
      if (catalogCurrentPage > 0) {
        catalogCurrentPage--;
        renderSingleModifiersList();
      }
    };
  }
  if (btnCatalogNext) {
    btnCatalogNext.onclick = (e) => {
      e.preventDefault();
      const totalPages = Math.max(1, Math.ceil(globalSingleModifiers.length / 40));
      if (catalogCurrentPage < totalPages - 1) {
        catalogCurrentPage++;
        renderSingleModifiersList();
      }
    };
  }
}

let catalogCurrentPage = 0;

async function loadSingleModifiers() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/single-modifiers`);
    if (res.ok) {
      globalSingleModifiers = await res.json();
      updateSingleModifiersDatalist();
      renderSingleModifiersList();
    }
  } catch (e) {
    console.error('Error loading single modifiers:', e);
  }
}

function updateSingleModifiersDatalist() {
  const datalist = document.getElementById('singleModifiersDatalist');
  const select = document.getElementById('setupModGroupCatalogSelect');
  
  if (datalist) {
    datalist.innerHTML = '';
    globalSingleModifiers.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.name;
      datalist.appendChild(opt);
    });
  }

  if (select) {
    select.innerHTML = '';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.innerText = '-- Choose Item --';
    placeholder.disabled = true;
    placeholder.selected = true;
    select.appendChild(placeholder);
    
    globalSingleModifiers.forEach((m, idx) => {
      const opt = document.createElement('option');
      opt.value = idx;
      opt.innerText = `${m.name} ($${m.price.toFixed(2)})`;
      select.appendChild(opt);
    });
  }
}

function renderSingleModifiersList() {
  const grid = document.getElementById('singleModifiersCatalogGrid');
  if (!grid) return;
  grid.innerHTML = '';
  
  if (!globalSingleModifiers || globalSingleModifiers.length === 0) {
    grid.innerHTML = `<span style="font-size: 11px; color: var(--text-secondary); font-style: italic;">No single modifiers saved. / No hay modificadores individuales guardados.</span>`;
    const lblCatalogPageIndicator = document.getElementById('lblCatalogPageIndicator');
    if (lblCatalogPageIndicator) lblCatalogPageIndicator.innerText = `Page 1 of 1`;
    return;
  }

  const totalPages = Math.max(1, Math.ceil(globalSingleModifiers.length / 40));
  if (catalogCurrentPage >= totalPages) catalogCurrentPage = totalPages - 1;
  if (catalogCurrentPage < 0) catalogCurrentPage = 0;

  const lblCatalogPageIndicator = document.getElementById('lblCatalogPageIndicator');
  if (lblCatalogPageIndicator) {
    lblCatalogPageIndicator.innerText = `Page ${catalogCurrentPage + 1} of ${totalPages}`;
  }

  const pageItems = globalSingleModifiers.slice(catalogCurrentPage * 40, (catalogCurrentPage + 1) * 40);

  pageItems.forEach(m => {
    const tag = document.createElement('div');
    tag.style.display = 'flex';
    tag.style.alignItems = 'center';
    tag.style.gap = '6px';
    tag.style.background = '#26262b';
    tag.style.border = '1px solid var(--border-color)';
    tag.style.borderRadius = '4px';
    tag.style.padding = '4px 8px';
    tag.style.fontSize = '11px';
    tag.style.color = '#fff';
    
    if (m.color === 'red') tag.style.borderLeft = '4px solid #ff4d4f';
    else if (m.color === 'green') tag.style.borderLeft = '4px solid #52c41a';
    else if (m.color === 'yellow') tag.style.borderLeft = '4px solid #fadb14';
    
    const span = document.createElement('span');
    span.innerText = `${m.name} ($${m.price.toFixed(2)})`;
    
    const delIcon = document.createElement('span');
    delIcon.innerHTML = '&times;';
    delIcon.style.color = 'var(--danger-color)';
    delIcon.style.cursor = 'pointer';
    delIcon.style.fontWeight = 'bold';
    delIcon.style.padding = '0 2px';
    delIcon.onclick = async (e) => {
      e.preventDefault();
      if (confirm(`Delete modifier "${m.name}" ($${m.price.toFixed(2)})?`)) {
        await deleteSingleModifier(m.name, m.price);
      }
    };
    
    tag.appendChild(span);
    tag.appendChild(delIcon);
    grid.appendChild(tag);
  });
}

async function saveSingleModifier(name, price, color = 'default') {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/single-modifiers`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, price, color })
    });
    if (res.ok) {
      globalSingleModifiers = await res.json();
      updateSingleModifiersDatalist();
      renderSingleModifiersList();
      showToast('Modifier saved successfully / Modificador guardado', 'success');
    }
  } catch (e) {
    console.error('Error saving single modifier:', e);
    showToast('Connection error / Error de conexión', 'error');
  }
}

async function deleteSingleModifier(name, price) {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/single-modifiers/${encodeURIComponent(name)}/${encodeURIComponent(price)}`, {
      method: 'DELETE'
    });
    if (res.ok) {
      globalSingleModifiers = await res.json();
      updateSingleModifiersDatalist();
      renderSingleModifiersList();
      showToast('Modifier deleted / Modificador eliminado', 'success');
    }
  } catch (e) {
    console.error('Error deleting single modifier:', e);
    showToast('Connection error / Error de conexión', 'error');
  }
}

function renderSetupModifiersList() {
  const listDiv = document.getElementById('setupModifiersList');
  if (!listDiv) return;
  listDiv.innerHTML = '';
  
  if (!globalModifierGroups || globalModifierGroups.length === 0) {
    listDiv.innerHTML = `<span style="font-size: 11px; color: var(--text-secondary); font-style: italic; padding: 10px; text-align: center;">No modifier groups.</span>`;
    return;
  }
  
  globalModifierGroups.forEach(g => {
    const btn = document.createElement('button');
    btn.className = 'btn-modal secondary';
    btn.style.width = '100%';
    btn.style.textAlign = 'left';
    btn.style.fontSize = '11px';
    btn.style.padding = '6px 8px';
    btn.style.margin = '2px 0';
    btn.style.display = 'flex';
    btn.style.justifyContent = 'space-between';
    btn.style.alignItems = 'center';
    btn.style.border = '1px solid var(--border-color)';
    btn.style.borderRadius = '4px';
    btn.style.background = 'transparent';
    btn.style.color = '#fff';
    btn.style.cursor = 'pointer';
    
    const titleSpan = document.createElement('span');
    titleSpan.style.fontWeight = 'bold';
    titleSpan.innerText = g.name;
    
    const countSpan = document.createElement('span');
    countSpan.style.background = 'rgba(255, 255, 255, 0.1)';
    countSpan.style.fontSize = '9px';
    countSpan.style.padding = '2px 4px';
    countSpan.style.borderRadius = '3px';
    countSpan.innerText = `${g.options ? g.options.length : 0} opts`;
    
    btn.appendChild(titleSpan);
    btn.appendChild(countSpan);
    
    btn.onclick = (e) => {
      e.preventDefault();
      loadSetupModifierGroup(g.id);
    };
    
    listDiv.appendChild(btn);
  });
}

function loadSetupModifierGroup(groupId) {
  const g = globalModifierGroups.find(group => group.id === groupId);
  if (!g) return;
  
  document.getElementById('setupModGroupId').value = g.id;
  document.getElementById('setupModGroupName').value = g.name;
  document.getElementById('setupModGroupRequired').checked = !!g.required;
  document.getElementById('setupModGroupMin').value = g.min !== undefined ? g.min : 1;
  document.getElementById('setupModGroupMax').value = g.max !== undefined ? g.max : 1;
  
  const tbody = document.getElementById('tbodySetupModOptions');
  if (tbody) {
    tbody.innerHTML = '';
    if (g.options && g.options.length > 0) {
      g.options.forEach(opt => {
        addSetupModOptionRow(opt.name, opt.price);
      });
    } else {
      addSetupModOptionRow('', 0);
    }
  }
  
  document.getElementById('setupModifierGroupEditor').style.display = 'flex';
  document.getElementById('setupModifierGroupEditorEmpty').style.display = 'none';
  
  // Highlight the selected item in the list
  const listDiv = document.getElementById('setupModifiersList');
  if (listDiv) {
    Array.from(listDiv.children).forEach(btn => {
      if (btn.innerText.startsWith(g.name)) {
        btn.style.borderColor = 'var(--accent-color)';
        btn.style.background = 'rgba(255,255,255,0.05)';
      } else {
        btn.style.borderColor = 'var(--border-color)';
        btn.style.background = 'transparent';
      }
    });
  }
}

function addSetupModOptionRow(name = '', price = 0) {
  const tbody = document.getElementById('tbodySetupModOptions');
  if (!tbody) return;

  // Initialize drag and drop reordering once on the tbody parent
  if (!tbody.dataset.dragInitialized) {
    tbody.dataset.dragInitialized = 'true';
    tbody.addEventListener('dragover', (e) => {
      e.preventDefault();
      const draggingRow = tbody.querySelector('.dragging');
      if (!draggingRow) return;
      const siblings = Array.from(tbody.querySelectorAll('tr:not(.dragging)'));
      const nextSibling = siblings.find(sibling => {
        return e.clientY <= sibling.getBoundingClientRect().top + sibling.getBoundingClientRect().height / 2;
      });
      tbody.insertBefore(draggingRow, nextSibling || null);
    });
  }
  
  const tr = document.createElement('tr');
  tr.style.borderBottom = '1px solid var(--border-color)';
  tr.draggable = true;
  tr.style.cursor = 'grab';
  tr.addEventListener('dragstart', (e) => {
    tr.style.opacity = '0.5';
    tr.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
  });
  tr.addEventListener('dragend', () => {
    tr.style.opacity = '1';
    tr.classList.remove('dragging');
  });
  
  const tdName = document.createElement('td');
  tdName.style.padding = '4px 6px';
  const nameInp = document.createElement('input');
  nameInp.type = 'text';
  nameInp.className = 'form-input-text setup-mod-opt-name';
  nameInp.value = name;
  nameInp.placeholder = 'e.g. Asada';
  nameInp.setAttribute('list', 'singleModifiersDatalist');
  nameInp.style.width = '100%';
  nameInp.style.padding = '4px';
  nameInp.style.fontSize = '11px';
  nameInp.style.background = 'var(--bg-secondary)';
  nameInp.style.color = '#fff';
  nameInp.style.border = '1px solid var(--border-color)';
  tdName.appendChild(nameInp);
  
  const tdPrice = document.createElement('td');
  tdPrice.style.padding = '4px 6px';
  const priceInp = document.createElement('input');
  priceInp.type = 'number';
  priceInp.className = 'form-input-text setup-mod-opt-price';
  priceInp.value = price;
  priceInp.min = '0';
  priceInp.step = '0.01';
  priceInp.placeholder = '0.00';
  priceInp.style.width = '100%';
  priceInp.style.padding = '4px';
  priceInp.style.fontSize = '11px';
  priceInp.style.background = 'var(--bg-secondary)';
  priceInp.style.color = '#fff';
  priceInp.style.border = '1px solid var(--border-color)';
  tdPrice.appendChild(priceInp);
  
  const tdAction = document.createElement('td');
  tdAction.style.padding = '4px 6px';
  tdAction.style.textAlign = 'center';
  tdAction.style.display = 'flex';
  tdAction.style.alignItems = 'center';
  tdAction.style.justifyContent = 'center';
  tdAction.style.gap = '3px';

  const btnUp = document.createElement('button');
  btnUp.type = 'button';
  btnUp.className = 'btn-modal secondary';
  btnUp.innerText = '▲';
  btnUp.style.padding = '2px 4px';
  btnUp.style.fontSize = '8px';
  btnUp.style.height = '20px';
  btnUp.style.margin = '0';
  btnUp.style.cursor = 'pointer';
  btnUp.onclick = (e) => {
    e.preventDefault();
    const prev = tr.previousElementSibling;
    if (prev) {
      tbody.insertBefore(tr, prev);
    }
  };

  const btnDown = document.createElement('button');
  btnDown.type = 'button';
  btnDown.className = 'btn-modal secondary';
  btnDown.innerText = '▼';
  btnDown.style.padding = '2px 4px';
  btnDown.style.fontSize = '8px';
  btnDown.style.height = '20px';
  btnDown.style.margin = '0';
  btnDown.style.cursor = 'pointer';
  btnDown.onclick = (e) => {
    e.preventDefault();
    const next = tr.nextElementSibling;
    if (next) {
      tbody.insertBefore(next, tr);
    }
  };
  
  const delBtn = document.createElement('button');
  delBtn.type = 'button';
  delBtn.className = 'btn-modal secondary';
  delBtn.innerHTML = '🗑️';
  delBtn.style.padding = '2px 4px';
  delBtn.style.fontSize = '9px';
  delBtn.style.height = '20px';
  delBtn.style.margin = '0';
  delBtn.style.cursor = 'pointer';
  delBtn.onclick = (e) => {
    e.preventDefault();
    tr.remove();
  };
  
  tdAction.appendChild(btnUp);
  tdAction.appendChild(btnDown);
  tdAction.appendChild(delBtn);
  
  tr.appendChild(tdName);
  tr.appendChild(tdPrice);
  tr.appendChild(tdAction);
  tbody.appendChild(tr);
  
  // Hook virtual keyboard to new inputs
  registerProductFormInputEvents();
}

function resetSetupModGroupForm() {
  document.getElementById('setupModGroupId').value = '';
  document.getElementById('setupModGroupName').value = '';
  document.getElementById('setupModGroupRequired').checked = false;
  document.getElementById('setupModGroupMin').value = 1;
  document.getElementById('setupModGroupMax').value = 1;
  
  const tbody = document.getElementById('tbodySetupModOptions');
  if (tbody) {
    tbody.innerHTML = '';
    addSetupModOptionRow('', 0);
  }
  
  document.getElementById('setupModifierGroupEditor').style.display = 'flex';
  document.getElementById('setupModifierGroupEditorEmpty').style.display = 'none';
  
  // Unhighlight all list items
  const listDiv = document.getElementById('setupModifiersList');
  if (listDiv) {
    Array.from(listDiv.children).forEach(btn => {
      btn.style.borderColor = 'var(--border-color)';
      btn.style.background = 'transparent';
    });
  }
}

async function saveSetupModGroup() {
  const id = document.getElementById('setupModGroupId').value;
  const name = document.getElementById('setupModGroupName').value.trim();
  const required = document.getElementById('setupModGroupRequired').checked;
  const min = parseInt(document.getElementById('setupModGroupMin').value) || 0;
  const max = parseInt(document.getElementById('setupModGroupMax').value) || 1;
  
  if (!name) {
    showToast('Please enter a modifier group name', 'error');
    return;
  }
  
  // Collect option rows
  const tbody = document.getElementById('tbodySetupModOptions');
  const options = [];
  if (tbody) {
    const rows = tbody.querySelectorAll('tr');
    for (let row of rows) {
      const nameInp = row.querySelector('.setup-mod-opt-name');
      const priceInp = row.querySelector('.setup-mod-opt-price');
      if (nameInp && nameInp.value.trim()) {
        const optName = nameInp.value.trim();
        const found = globalSingleModifiers.find(m => m.name.toLowerCase() === optName.toLowerCase());
        options.push({
          name: optName,
          price: parseFloat(priceInp.value) || 0,
          color: found ? (found.color || 'default') : 'default'
        });
      }
    }
  }
  
  const payload = { name, required, min, max, options };
  if (id) {
    payload.id = id;
  }
  
  const url = id ? `${SERVER_URL}/api/admin/modifier-groups/${id}` : `${SERVER_URL}/api/admin/modifier-groups`;
  const method = id ? 'PUT' : 'POST';
  
  try {
    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast('Modifier group saved successfully', 'success');
      await loadGlobalModifierGroups();
      renderSetupModifiersList();
      
      // Reload products catalog so the cashier active cache updates immediately
      await loadProducts();
      renderProducts();
      
      const savedGroup = await res.json();
      if (savedGroup && savedGroup.id) {
        loadSetupModifierGroup(savedGroup.id);
      }
    } else {
      showToast('Error saving modifier group', 'error');
    }
  } catch (e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}

async function deleteSetupModGroup() {
  const id = document.getElementById('setupModGroupId').value;
  if (!id) return;
  
  if (confirm('Are you sure you want to delete this modifier group? This cannot be undone.')) {
    try {
      const res = await fetch(`${SERVER_URL}/api/admin/modifier-groups/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        showToast('Modifier group deleted successfully', 'success');
        await loadGlobalModifierGroups();
        renderSetupModifiersList();
        
        document.getElementById('setupModGroupId').value = '';
        document.getElementById('setupModifierGroupEditor').style.display = 'none';
        document.getElementById('setupModifierGroupEditorEmpty').style.display = 'flex';
      } else {
        showToast('Error deleting modifier group', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Connection error', 'error');
    }
  }
}

function updateCartUI() {
  const itemsContainer = document.getElementById('cartItems');
  itemsContainer.innerHTML = '';

  if (cart.length === 0) {
    // Render a premium Loyalty QR Code display when the cart is empty for the customer display mirroring
    itemsContainer.innerHTML = `
      <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; margin-top: 30px; padding: 20px; text-align: center; background: rgba(255,255,255,0.01); border: 1px dashed rgba(255,255,255,0.1); border-radius: 8px; margin-left: 10px; margin-right: 10px;">
        <div style="font-size: 15px; font-weight: bold; color: var(--accent-color); margin-bottom: 5px;">👤 CUSTOMER IDENTIFICATION</div>
        <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.3;">Scan QR to Link Phone & Order<br>Escanea para vincular tu teléfono a la orden</div>
        <div id="cartEmptyQRContainer" style="width: 130px; height: 130px; background: white; padding: 6px; border-radius: 6px; display: flex; justify-content: center; align-items: center; box-shadow: 0 4px 12px rgba(0,0,0,0.5);"></div>
      </div>
    `;
    
    // Draw the QR code dynamically in the empty cart area
    setTimeout(async () => {
      const qrDiv = document.getElementById('cartEmptyQRContainer');
      if (qrDiv) {
        let targetUrl = `${window.location.origin}/autoregistro.html`;
        try {
          const res = await fetch(`${SERVER_URL}/api/tunnel-url`);
          if (res.ok) {
            const data = await res.json();
            if (data.url) {
              const baseUrl = data.url.endsWith('/') ? data.url.slice(0, -1) : data.url;
              targetUrl = `${baseUrl}/autoregistro.html`;
            }
          }
        } catch(e) {}
        
        // Ensure no loopback localhost IP is written to the QR code
        if (targetUrl.includes('localhost') || targetUrl.includes('127.0.0.1')) {
          try {
            const ipRes = await fetch(`${SERVER_URL}/api/local-ip`);
            if (ipRes.ok) {
              const ipData = await ipRes.json();
              if (ipData.ip && ipData.ip !== '127.0.0.1') {
                targetUrl = targetUrl.replace('localhost', ipData.ip).replace('127.0.0.1', ipData.ip);
              }
            }
          } catch(e) {}
        }
        
        const myStation = (typeof posSettings !== 'undefined' && posSettings && posSettings.stationId) ? String(posSettings.stationId) : '1';
        targetUrl += (targetUrl.includes('?') ? '&' : '?') + `station=${encodeURIComponent(myStation)}`;
        
        try {
          qrDiv.innerHTML = '';
          new QRCode(qrDiv, {
            text: targetUrl,
            width: 118,
            height: 118,
            correctLevel: QRCode.CorrectLevel.M
          });
          const qrImg = qrDiv.querySelector('img');
          if (qrImg) qrImg.style.margin = '0 auto';
        } catch(err) {
          console.error("Cart QR draw error:", err);
        }
      }
    }, 50);

    document.getElementById('lblSubtotal').innerText = '$0.00';
    const taxLbl = document.getElementById('lblTax');
    if (taxLbl) taxLbl.innerText = '$0.00';
    document.getElementById('lblTotal').innerText = '$0.00';
    document.getElementById('inputBalance').value = '$0.00';
    document.getElementById('cakeDepositSection').style.display = 'none';
    cashReceivedString = '';
    updateRegisterChange();
    return;
  }

  let subtotal = 0;
  let taxableSubtotal = 0;

  cart.forEach((item, index) => {
    const totalItemPrice = item.price * item.quantity;
    subtotal += totalItemPrice;
    if (item.isTaxable !== false) {
      taxableSubtotal += totalItemPrice;
    }

    const div = document.createElement('div');
    div.className = 'cart-item';
    
    let subdetails = '';
    if (item.isCustomCake) {
      const dep = item.details.deposit || 0;
      const tot = item.details.totalPrice || item.price;
      const bal = item.details.balance || Math.max(0, tot - dep);

      subdetails = `<div class="cart-item-sub" style="font-size:8.5px; color: var(--text-secondary); line-height: 1.25;">
        ${item.details.isSpecialEvent ? `Folio: ${item.details.folio || ''} | Model: ${item.details.bookModel || 'N/A'}<br>` : ''}
        Shape: ${item.details.shape || 'Round'} | Tiers: ${item.details.tierCount || '1'} | Pickup: ${item.details.pickupDate} ${item.details.pickupTime}<br>
        <span style="color:var(--accent-color); font-weight:bold;">${dep > 0 ? `Deposit Today: $${dep.toFixed(2)} (Total: $${tot.toFixed(2)} | Balance: $${bal.toFixed(2)})` : `Total: $${tot.toFixed(2)}`}</span>
        ${item.details.photoUrl ? '<br><span style="color:var(--success-color)">✓ Photo attached</span>' : ''}
      </div>`;
    } else if (item.selectedModifiers && item.selectedModifiers.length > 0) {
      const modifierNames = item.selectedModifiers.map(m => {
        const themeColors = { 'red': '#ff4d4f', 'green': '#52c41a', 'yellow': '#fadb14' };
        const colorStyle = (m.color && themeColors[m.color]) ? `color: ${themeColors[m.color]}; font-weight: bold;` : '';
        return `<span style="${colorStyle}">${m.name}${m.price > 0 ? ` (+$${m.price.toFixed(2)})` : ''}</span>`;
      }).join(', ');
      subdetails = `<div class="cart-item-sub" style="font-size:8.5px; color: var(--text-secondary); line-height: 1.25;">
        ${modifierNames}
      </div>`;
    }

    const isGiftable = !item.name.includes('Courtesy') && !item.name.includes('Sent to');
    const selectCheckbox = isGiftable 
      ? `<input type="checkbox" class="cart-item-select" data-index="${index}" style="margin-right: 8px; cursor: pointer; transform: scale(1.1);">`
      : `<div style="width: 16px; margin-right: 8px;"></div>`;

    const seatMatch = item.name.match(/\(Cliente (\d+)\)/i) || (item.clientSeat ? [null, item.clientSeat] : null);
    const clientBadge = seatMatch 
      ? `<span style="background-color: #5ac8fa; color: #000; font-weight: bold; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; margin-right: 6px; font-size: 9px; line-height: 1; vertical-align: middle; flex-shrink: 0;">C${seatMatch[1]}</span>` 
      : '';
    const cleanName = item.name.replace(/\(Cliente \d+\)/i, '').replace(/\(Seat \d+\)/i, '').replace('(To Go)', '').trim();

    div.innerHTML = `
      <div style="display: flex; align-items: center; flex: 1; min-width: 0;">
        ${selectCheckbox}
        <div class="cart-item-info" style="flex: 1; min-width: 0;">
          <div class="cart-item-name" style="font-size: 11.5px; font-weight: bold; display: flex; align-items: center; flex-wrap: wrap; color: #fff;">${clientBadge}${cleanName}</div>
          ${subdetails}
        </div>
      </div>
      <div style="display: flex; align-items: center; gap: 8px; margin-left: 6px;">
        <div style="display: flex; align-items: center; gap: 4px; background: rgba(255,255,255,0.04); padding: 1px 3px; border-radius: 4px;">
          <button class="qty-btn" onclick="decreaseQty(${index})" style="background: none; border: none; color: var(--danger-color); font-weight: 900; font-size: 14px; cursor: pointer; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center;">-</button>
          <span style="font-size: 11.5px; font-weight: 700; color: #fff; min-width: 12px; text-align: center;">${item.quantity}</span>
          <button class="qty-btn" onclick="increaseQty(${index})" style="background: none; border: none; color: var(--success-color); font-weight: 900; font-size: 14px; cursor: pointer; width: 18px; height: 18px; display: flex; align-items: center; justify-content: center;">+</button>
        </div>
        <div class="cart-item-price" style="min-width: 55px; text-align: right; font-weight: bold; font-size: 11.5px;">$${totalItemPrice.toFixed(2)}</div>
      </div>
    `;
    itemsContainer.appendChild(div);
  });

  const taxRate = posSettings.taxRate !== undefined ? posSettings.taxRate : 6;
  const tax = taxableSubtotal * (taxRate / 100);
  const total = subtotal + tax;
  
  document.getElementById('lblSubtotal').innerText = `$${subtotal.toFixed(2)}`;
  const taxLbl = document.getElementById('lblTax');
  if (taxLbl) taxLbl.innerText = `$${tax.toFixed(2)}`;
  document.getElementById('lblTotal').innerText = `$${total.toFixed(2)}`;

  // Validar si hay pasteles personalizados para mostrar depósito
  const hasCustomCake = cart.some(item => item.isCustomCake);
  if (hasCustomCake) {
    document.getElementById('cakeDepositSection').style.display = 'block';
    calculateBalance(total);
  } else {
    document.getElementById('cakeDepositSection').style.display = 'none';
  }

  updateRegisterChange();
}

function increaseQty(index) {
  const item = cart[index];
  const cleanProductId = item.id.split('_c')[0];
  const prod = products.find(p => p.id === cleanProductId);
  if (prod && prod.trackStock) {
    if (getQtyInCart(cleanProductId) + 1 > prod.stockQuantity) {
      showToast('⚠️ Stock insuficiente / Out of stock!', 'error');
      return;
    }
  }
  item.quantity++;
  updateCartUI();
}

function decreaseQty(index) {
  cart[index].quantity--;
  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }
  updateCartUI();
}

function calculateBalance(total) {
  const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
  const balance = total - deposit;
  document.getElementById('inputBalance').value = `$${Math.max(0, balance).toFixed(2)}`;
}

// Actualizar panel de cambio
function updateRegisterChange() {
  const cashReceivedInput = document.getElementById('registerCashReceived');
  const changeEl = document.getElementById('registerChange');
  const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
  
  const hasCustomCake = cart.some(item => item.isCustomCake);
  let targetAmount = total;
  
  if (hasCustomCake) {
    const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
    targetAmount = deposit;
  }

  cashReceivedInput.value = cashReceivedString ? `$${parseFloat(cashReceivedString).toFixed(2)}` : '';

  const cashVal = parseFloat(cashReceivedString) || 0;
  if (cashVal > 0) {
    const change = cashVal - targetAmount;
    changeEl.innerText = `$${Math.max(0, change).toFixed(2)}`;
  } else {
    changeEl.innerText = '$0.00';
  }
}

// --- EVENT LISTENERS & MODALS ---
function setupEventListeners() {
  initLogoUploadHandlers();
  
  const btnOpenBartenderDashboard = document.getElementById('btnOpenBartenderDashboard');
  if (btnOpenBartenderDashboard) {
    btnOpenBartenderDashboard.addEventListener('click', () => {
      openBartenderAuthModal();
    });
  }

  const btnCloseBartenderDashboard = document.getElementById('btnCloseBartenderDashboard');
  if (btnCloseBartenderDashboard) {
    btnCloseBartenderDashboard.addEventListener('click', () => {
      closeBartenderDashboard();
    });
  }

  const btnCancelBartenderAuth = document.getElementById('btnCancelBartenderAuth');
  if (btnCancelBartenderAuth) {
    btnCancelBartenderAuth.addEventListener('click', () => {
      document.getElementById('modalBartenderAuth').style.display = 'none';
    });
  }

  // Bind pre-order tile selections
  const preOrderTiles = document.querySelectorAll('.pre-order-tile');
  preOrderTiles.forEach(tile => {
    tile.addEventListener('click', () => {
      const type = tile.getAttribute('data-type');
      selectPreOrderType(type);
    });
  });

  // Bind Welcome Business POS Setup Wizard Close & Skip Buttons
  const btnCloseWizardModal = document.getElementById('btnCloseWizardModal');
  if (btnCloseWizardModal) {
    btnCloseWizardModal.addEventListener('click', () => {
      document.getElementById('modalBusinessSetup').style.display = 'none';
    });
  }

  const btnSkipWizardSettings = document.getElementById('btnSkipWizardSettings');
  if (btnSkipWizardSettings) {
    btnSkipWizardSettings.addEventListener('click', () => {
      document.getElementById('modalBusinessSetup').style.display = 'none';
    });
  }

  // Bind Welcome Business POS Setup Wizard & Realtime Handlers (Strict Mandatory Setup)
  const selWizardLanguage = document.getElementById('wizardLanguage');
  if (selWizardLanguage) {
    selWizardLanguage.addEventListener('change', (e) => {
      applyTranslations(e.target.value);
    });
  }

  // Auto-slugify business name to suggest 1ti1.com domain
  const inputWizardBizName = document.getElementById('wizardBusinessName');
  const inputWizardWebsite = document.getElementById('wizardWebsite');
  if (inputWizardBizName && inputWizardWebsite) {
    inputWizardBizName.addEventListener('input', () => {
      if (!inputWizardWebsite.dataset.userEdited) {
        const raw = inputWizardBizName.value.trim().toLowerCase();
        const slug = raw.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, '');
        if (slug) {
          inputWizardWebsite.value = `${slug}.1ti1.com`;
        } else {
          inputWizardWebsite.value = '';
        }
      }
    });
    inputWizardWebsite.addEventListener('input', () => {
      inputWizardWebsite.dataset.userEdited = "true";
    });
  }

  const btnSaveWizardSettings = document.getElementById('btnSaveWizardSettings');
  if (btnSaveWizardSettings) {
    btnSaveWizardSettings.addEventListener('click', async () => {
      const language = document.getElementById('wizardLanguage').value;
      const isEs = language === 'es';
      
      const accepted = document.getElementById('wizardAcceptDisclaimer').checked;
      if (!accepted) {
        showToast(isEs ? 'Debe aceptar los términos de servicio y el deslinde de responsabilidad para continuar' : 'You must accept the terms of service and legal disclaimer to proceed', 'error');
        return;
      }

      const name = document.getElementById('wizardBusinessName').value.trim();
      if (!name) {
        showToast(isEs ? 'Por favor ingrese el nombre del negocio' : 'Please enter a business name', 'error');
        return;
      }

      const type = document.getElementById('wizardBusinessType').value;
      if (!type) {
        showToast(isEs ? 'Por favor seleccione el tipo de negocio' : 'Please select your business type', 'error');
        return;
      }

      const taxRateInput = document.getElementById('wizardTaxRate').value.trim();
      const taxRate = taxRateInput !== '' ? (parseFloat(taxRateInput) || 0.0) : 0.0;

      const address = document.getElementById('wizardAddress').value.trim();
      const phone = document.getElementById('wizardPhone').value.trim();
      const website = document.getElementById('wizardWebsite').value.trim();
      const showTableMap = document.getElementById('wizardShowTableMap').checked;
      const showHostessHub = document.getElementById('wizardShowHostessHub').checked;
      const enableOrderSMSAlerts = document.getElementById('wizardEnableOrderSMSAlerts').checked;
      const enableCarSelfOrdering = document.getElementById('wizardEnableCarSelfOrdering').checked;
      
      const services = [];
      if (document.getElementById('wizardServiceWalkIn').checked) services.push('walkin');
      if (document.getElementById('wizardServiceToGo').checked) services.push('llevar');
      if (document.getElementById('wizardServiceDineIn').checked) services.push('comer');
      if (document.getElementById('wizardServiceDriveThru').checked) services.push('drive-thru');
      if (document.getElementById('wizardServicePickup').checked) services.push('pickup');
      if (document.getElementById('wizardServiceDelivery').checked) services.push('delivery');
      
      if (services.length === 0) {
        showToast(isEs ? 'Por favor active al menos un servicio' : 'Please enable at least one service type', 'error');
        return;
      }

      // Smart parsing of 1ti1.com cloud domain and client subdomain
      let clientSubdomain = (posSettings && posSettings.clientSubdomain) ? posSettings.clientSubdomain : '';
      let cloudDomain = (posSettings && posSettings.cloudDomain) ? posSettings.cloudDomain : '1ti1.com';
      let finalWebsite = website;

      if (finalWebsite) {
        let clean = finalWebsite.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim().toLowerCase();
        if (clean.includes('.')) {
          if (clean.endsWith('.1ti1.com')) {
            clientSubdomain = clean.replace('.1ti1.com', '').trim();
            cloudDomain = '1ti1.com';
            finalWebsite = `https://${clean}`;
          } else if (clean.endsWith('.ti1.com')) {
            clientSubdomain = clean.replace('.ti1.com', '').trim();
            cloudDomain = '1ti1.com';
            finalWebsite = `https://${clean.replace('.ti1.com', '.1ti1.com')}`;
          } else {
            finalWebsite = `https://${clean}`;
            clientSubdomain = clean.split('.')[0];
          }
        } else {
          clientSubdomain = clean;
          cloudDomain = '1ti1.com';
          finalWebsite = `https://${clean}.1ti1.com`;
        }
      } else if (name) {
        const autoSlug = name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, '');
        if (autoSlug) {
          clientSubdomain = autoSlug;
          cloudDomain = '1ti1.com';
          finalWebsite = `https://${autoSlug}.1ti1.com`;
        }
      }
      
      const payload = {
        ...posSettings,
        businessName: name,
        businessType: type,
        taxRate,
        address,
        phone,
        website: finalWebsite,
        clientSubdomain: clientSubdomain || 'sheilas',
        cloudDomain: cloudDomain || '1ti1.com',
        services,
        language,
        langKDS: language,
        langRunner: language,
        langLobby: language,
        langCustomerTicket: language,
        langKitchenTicket: language,
        showTableMap,
        showHostessHub,
        enableOrderSMSAlerts,
        enableCarSelfOrdering,
        eulaAccepted: true,
        eulaAcceptedAt: new Date().toISOString(),
        eulaVersion: '2026.2'
      };
      
      try {
        const response = await fetch(`${SERVER_URL}/api/admin/settings`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          // If custom owner/manager PIN provided in Welcome Wizard, save it
          const wizardAdminPin = document.getElementById('wizardAdminPin') ? document.getElementById('wizardAdminPin').value.trim() : '';
          if (wizardAdminPin && wizardAdminPin.length === 4) {
            try {
              await fetch(`${SERVER_URL}/api/employees/set-manager-pin`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ newPin: wizardAdminPin })
              });
            } catch(e) {}
          }
          showToast(isEs ? '¡Configuración guardada! Iniciando POS...' : 'Business POS initialized successfully!', 'success');
          window.location.reload();
        } else {
          showToast(isEs ? 'Error al guardar configuración' : 'Failed to save configuration', 'error');
        }
      } catch (err) {
        console.error(err);
        showToast(isEs ? 'Error de conexión con el servidor' : 'Server connection error', 'error');
      }
    });
  }

  // Trigger date/time picker on clicking anywhere inside date/time inputs
  const pickupDate = document.getElementById('cakePickupDate');
  const pickupTime = document.getElementById('cakePickupTime');
  if (pickupDate) pickupDate.addEventListener('click', (e) => e.target.showPicker());
  if (pickupTime && pickupTime.tagName !== 'SELECT') {
    pickupTime.addEventListener('click', (e) => {
      try { e.target.showPicker(); } catch(err) {}
    });
  }

  const repStartD = document.getElementById('reportStartDate');
  const repStartT = document.getElementById('reportStartTime');
  const repEndD = document.getElementById('reportEndDate');
  const repEndT = document.getElementById('reportEndTime');
  if (repStartD) repStartD.addEventListener('click', (e) => e.target.showPicker());
  if (repStartT) repStartT.addEventListener('click', (e) => e.target.showPicker());
  if (repEndD) repEndD.addEventListener('click', (e) => e.target.showPicker());
  if (repEndT) repEndT.addEventListener('click', (e) => e.target.showPicker());

  // --- SPLASH LOGIN EVENT LISTENERS ---
  // Numeric keypad buttons
  let lastSplashKeyTime = 0;
  document.querySelectorAll('#splashNumpad .splash-key').forEach(key => {
    key.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const now = Date.now();
      if (now - lastSplashKeyTime < 100) return;
      lastSplashKeyTime = now;

      const val = key.getAttribute('data-value');
      if (val === 'C') {
        splashPasscodeString = '';
      } else if (val === 'Backspace') {
        splashPasscodeString = splashPasscodeString.slice(0, -1);
      } else {
        if (splashPasscodeString.length < 4) {
          splashPasscodeString += val;
        }
      }
      updateSplashPasscodeDisplay();
    });
  });

  // Enter POS Button
  document.getElementById('btnSplashLogin').addEventListener('click', () => {
    handleSplashLogin();
  });

  // Punch Clock Button
  document.getElementById('btnSplashPunch').addEventListener('click', () => {
    handleSplashPunch();
  });

  // Biometric scanner touch simulator in Splash
  const splashScanner = document.getElementById('splashFingerScanner');
  const splashRipple = document.getElementById('splashScannerRipple');
  const splashStatus = document.getElementById('splashScanStatus');
  const splashIcon = document.getElementById('splashFingerprintIcon');
  let splashPressTimeout = null;

  let activeBiometricListenTimeout = null;

  splashScanner.addEventListener('click', () => {
    splashRipple.style.transform = 'scale(1.2)';
    splashRipple.style.opacity = '1';
    splashStatus.innerText = 'Please touch the physical USB reader...';
    splashStatus.style.color = 'var(--accent-color)';
    splashIcon.style.color = 'var(--accent-color)';
    
    showToast('To log in: place finger on USB reader, or simply SWIPE your employee card / Para entrar: coloque su huella en el lector USB, o simplemente DESLIZA tu tarjeta de empleado', 'info');

    setTimeout(() => {
      splashRipple.style.transform = 'scale(1)';
      splashRipple.style.opacity = '0';
      splashStatus.innerText = 'Scan finger, swipe employee card, or use the keypad.';
      splashStatus.style.color = 'var(--text-secondary)';
      splashIcon.style.color = 'var(--text-secondary)';
    }, 4500);
  });

  // --- OPEN SHIFT MODAL LISTENERS ---
  let activeOpenShiftInput = document.getElementById('openCoinsPennies');
  
  document.querySelectorAll('.denom-input').forEach(input => {
    input.addEventListener('focus', () => {
      activeOpenShiftInput = input;
      input.select();
    });
    
    input.addEventListener('click', () => {
      activeOpenShiftInput = input;
      input.focus();
    });
    
    input.addEventListener('input', calculateStartingCash);
  });

  const directStartingInp = document.getElementById('inputStartingCashDirect');
  if (directStartingInp) {
    directStartingInp.addEventListener('focus', () => {
      activeOpenShiftInput = directStartingInp;
      directStartingInp.select();
    });
    directStartingInp.addEventListener('click', () => {
      activeOpenShiftInput = directStartingInp;
      directStartingInp.select();
    });
    directStartingInp.addEventListener('input', (e) => {
      handleDirectStartingCashInput(e.target.value);
    });
  }

  // Numeric keypad buttons for Open Shift
  document.querySelectorAll('#openShiftNumpad .splash-key').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!activeOpenShiftInput) return;
      const val = btn.getAttribute('data-val');
      
      if (activeOpenShiftInput.id === 'inputStartingCashDirect') {
        if (val === 'C') {
          activeOpenShiftInput.value = '0.00';
        } else if (val === 'Backspace') {
          let current = activeOpenShiftInput.value;
          activeOpenShiftInput.value = current.slice(0, -1) || '0';
        } else {
          if (activeOpenShiftInput.value === '0' || activeOpenShiftInput.value === '0.00') {
            activeOpenShiftInput.value = val;
          } else {
            activeOpenShiftInput.value += val;
          }
        }
        handleDirectStartingCashInput(activeOpenShiftInput.value);
        return;
      }

      if (val === 'C') {
        activeOpenShiftInput.value = '0';
      } else if (val === 'Backspace') {
        let current = activeOpenShiftInput.value;
        activeOpenShiftInput.value = current.slice(0, -1) || '0';
      } else {
        if (activeOpenShiftInput.value === '0') {
          activeOpenShiftInput.value = val;
        } else {
          activeOpenShiftInput.value += val;
        }
      }
      
      calculateStartingCash();
    });
  });

  // Next Field button click
  document.getElementById('btnOpenShiftNext').addEventListener('click', () => {
    if (!activeOpenShiftInput) return;
    const inputs = [
      'openCoinsPennies', 'openCoinsNickels', 'openCoinsDimes', 'openCoinsQuarters',
      'openBillsOnes', 'openBillsFives', 'openBillsTens', 'openBillsTwenties', 'openBillsFifties', 'openBillsHundreds'
    ];
    const currentIndex = inputs.indexOf(activeOpenShiftInput.id);
    const nextIndex = (currentIndex + 1) % inputs.length;
    const nextInput = document.getElementById(inputs[nextIndex]);
    if (nextInput) {
      nextInput.focus();
    }
  });

  // Dual Cash Drawer selection triggers in Open Shift modal
  const btnDChoice1 = document.getElementById('btnDrawerChoice1');
  const btnDChoice2 = document.getElementById('btnDrawerChoice2');
  if (btnDChoice1 && btnDChoice2) {
    btnDChoice1.addEventListener('click', () => {
      if (btnDChoice1.disabled) return;
      btnDChoice1.classList.add('selected');
      btnDChoice2.classList.remove('selected');
      selectedOpenShiftDrawer = 1;
    });
    btnDChoice2.addEventListener('click', () => {
      if (btnDChoice2.disabled) return;
      btnDChoice2.classList.add('selected');
      btnDChoice1.classList.remove('selected');
      selectedOpenShiftDrawer = 2;
    });
  }

  // Confirmar Apertura de Caja
  const btnConfOpen = document.getElementById('btnConfirmOpenShift');
  if (btnConfOpen) {
    btnConfOpen.addEventListener('click', async () => {
      await confirmOpenShift();
    });
  }

  // Cancelar Apertura de Caja
  const btnCancelOpen = document.getElementById('btnCancelOpenShift');
  if (btnCancelOpen) {
    btnCancelOpen.addEventListener('click', () => {
      closeOpenShiftModal();
    });
  }

  // --- CLOSE SHIFT MODAL LISTENERS ---
  let activeCloseShiftInput = document.getElementById('closeCoinsPennies');
  
  document.querySelectorAll('.denom-input-close').forEach(input => {
    input.addEventListener('focus', () => {
      activeCloseShiftInput = input;
      input.select();
    });
    
    input.addEventListener('click', () => {
      input.focus();
    });
    
    input.addEventListener('input', calculateClosingCash);
  });

  // Numeric keypad buttons for Close Shift
  document.querySelectorAll('#closeShiftNumpad .splash-key').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!activeCloseShiftInput) return;
      const val = btn.getAttribute('data-val');
      
      if (val === 'C') {
        activeCloseShiftInput.value = '0';
      } else if (val === 'Backspace') {
        let current = activeCloseShiftInput.value;
        activeCloseShiftInput.value = current.slice(0, -1) || '0';
      } else {
        if (activeCloseShiftInput.value === '0') {
          activeCloseShiftInput.value = val;
        } else {
          activeCloseShiftInput.value += val;
        }
      }
      
      calculateClosingCash();
    });
  });

  // Next Field button click for Close Shift
  document.getElementById('btnCloseShiftNext').addEventListener('click', () => {
    if (!activeCloseShiftInput) return;
    const inputs = [
      'closeCoinsPennies', 'closeCoinsNickels', 'closeCoinsDimes', 'closeCoinsQuarters',
      'closeBillsOnes', 'closeBillsFives', 'closeBillsTens', 'closeBillsTwenties', 'closeBillsFifties', 'closeBillsHundreds'
    ];
    const currentIndex = inputs.indexOf(activeCloseShiftInput.id);
    const nextIndex = (currentIndex + 1) % inputs.length;
    const nextInput = document.getElementById(inputs[nextIndex]);
    if (nextInput) {
      nextInput.focus();
    }
  });

  // Confirmar Cierre de Caja
  document.getElementById('btnConfirmCloseShift').addEventListener('click', async () => {
    await confirmCloseShift();
  });

  // Cancelar Cierre de Caja
  document.getElementById('btnCancelCloseShift').addEventListener('click', () => {
    document.getElementById('modalCloseShift').style.display = 'none';
  });

  // Cambio de categorías / Tabs
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      if (!deliveryType) {
        e.preventDefault();
        e.stopPropagation();
        const isEs = posSettings && posSettings.language === 'es';
        showToast(isEs ? '⚠️ Seleccione tipo de servicio primero' : '⚠️ Select order service type first', 'warning');
        return;
      }
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const cat = tab.getAttribute('data-category');
      selectedCategory = cat;
      activeSalesSubCategory = '';
      const salesSearch = document.getElementById('salesSearchInput');
      if (salesSearch) salesSearch.value = '';
      if (cat === 'pasteles_stock') {
        activePastelesSubCategory = 'root';
      }

      if (cat === 'pastel_pedido' || cat === 'bodas_quince') {
        openPastelModal(cat === 'bodas_quince');
      } else {
        renderProducts();
      }
    });
  });

  // --- CAR / VEHICLE ORDER DESCRIPTION HELPERS ---
  currentCarDescription = '';
  window.currentCarDescription = '';

  function promptForVehicleInfo() {
    const isEs = posSettings && posSettings.language === 'es';
    const defaultText = currentCarDescription || '';
    const input = prompt(
      isEs 
        ? "Descripción del Vehículo / Cliente:\n(Ejemplos: Jeep verde, Camioneta negra, Motocicleta amarilla, Señor de la bicicleta):" 
        : "Vehicle / Customer Description:\n(Examples: Green Jeep, Black Truck, Yellow Motorcycle, Guy on bicycle):",
      defaultText
    );
    if (input !== null) {
      currentCarDescription = input.trim();
      window.currentCarDescription = currentCarDescription;
      updateVehicleBannerUI();
    }
  }
  window.promptForVehicleInfo = promptForVehicleInfo;

  function updateVehicleBannerUI() {
    const banner = document.getElementById('cartVehicleBanner');
    const lbl = document.getElementById('lblCartVehicleInfo');
    if (!banner || !lbl) return;
    if (deliveryType === 'drive-thru') {
      banner.style.display = 'flex';
      lbl.innerText = currentCarDescription ? `🚗 ${currentCarDescription}` : (posSettings && posSettings.language === 'es' ? '🚗 Sin vehículo (clic Editar)' : '🚗 No vehicle set (click Edit)');
    } else {
      banner.style.display = 'none';
    }
  }
  window.updateVehicleBannerUI = updateVehicleBannerUI;

  function hideVehicleBanner() {
    currentCarDescription = '';
    window.currentCarDescription = '';
    updateVehicleBannerUI();
  }
  window.hideVehicleBanner = hideVehicleBanner;

  // Vaciar carrito / Eliminar seleccionados
  document.getElementById('btnClearCart').addEventListener('click', () => {
    const checkedInputs = document.querySelectorAll('.cart-item-select:checked');
    if (checkedInputs.length > 0) {
      // Borrar solo los artículos seleccionados
      const checkedIndexes = Array.from(checkedInputs).map(input => parseInt(input.getAttribute('data-index')));
      checkedIndexes.sort((a, b) => b - a); // Orden descendente para evitar desplazamiento de índices
      checkedIndexes.forEach(idx => {
        cart.splice(idx, 1);
      });
      
      // Si la comanda queda vacía, limpiar estados
      if (cart.length === 0) {
        activeTabOrderId = null;
        tabTableNumber = '';
        tabClientCount = 0;
        activeTabClientSeat = null;
        buildSeatSelectors();
        currentLoyaltyClient = null;
        currentCarDescription = '';
        updateVehicleBannerUI();
        document.getElementById('loyaltySummary').style.display = 'none';
        document.getElementById('inputDeposit').value = 0;
        showPreOrderSelection();
      }
      updateCartUI();
    } else {
      // Vaciar todo el carrito (comportamiento original)
      cart = [];
      activeTabOrderId = null;
      tabTableNumber = '';
      tabClientCount = 0;
      activeTabClientSeat = null;
      buildSeatSelectors();
      currentLoyaltyClient = null;
      currentCarDescription = '';
      updateVehicleBannerUI();
      document.getElementById('loyaltySummary').style.display = 'none';
      document.getElementById('inputDeposit').value = 0;
      updateCartUI();
      showPreOrderSelection();
    }
  });

  // Poner Ticket en Hold
  document.getElementById('btnHoldOrder').addEventListener('click', () => {
    if (cart.length === 0) {
      showToast('Cannot hold an empty ticket', 'error');
      return;
    }
    
    const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
    const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
    
    const heldItem = {
      id: 'held_' + Date.now(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      cart: [...cart],
      loyaltyClient: currentLoyaltyClient,
      deposit: deposit,
      total: total
    };
    
    heldOrders.push(heldItem);
    
    // Vaciar carrito activo
    cart = [];
    currentLoyaltyClient = null;
    document.getElementById('loyaltySummary').style.display = 'none';
    document.getElementById('inputDeposit').value = 0;
    
    updateCartUI();
    updateHeldCount();
    showToast('Ticket placed on hold!', 'success');
    showPreOrderSelection();
  });

  // Mostrar Tickets en Hold
  document.getElementById('btnRecallOrder').addEventListener('click', () => {
    renderHeldOrdersTable();
    document.getElementById('modalHeldOrders').style.display = 'flex';
  });

  // Tipo de Entrega (Para Llevar, Comer, Drive-Through) - En Cart Sidebar
  const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option[data-type]');
  deliveryOpts.forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      
      // Si hay productos seleccionados, marcar específicamente esos productos como To Go / Dine In
      const checkedInputs = document.querySelectorAll('.cart-item-select:checked');
      if (checkedInputs.length > 0) {
        checkedInputs.forEach(input => {
          const idx = parseInt(input.getAttribute('data-index'));
          const item = cart[idx];
          if (type === 'llevar') {
            item.isToGo = true;
            if (!item.name.includes('(To Go)')) {
              item.name = `${item.name.trim()} (To Go)`;
            }
          } else if (type === 'comer') {
            item.isToGo = false;
            item.name = item.name.replace('(To Go)', '').trim();
          }
        });
        updateCartUI();
        return; // No cambia el canal de servicio global del ticket
      }

      if (type === 'comer') {
        document.getElementById('modalDineInChoice').style.display = 'flex';
      } else if (type === 'llevar' || type === 'pickup' || type === 'delivery' || type === 'drive-thru') {
        deliveryOpts.forEach(o => o.classList.remove('selected'));
        btn.classList.add('selected');
        deliveryType = type;
        if (type === 'drive-thru') {
          promptForVehicleInfo();
        } else {
          hideVehicleBanner();
        }
        openLoyaltyModal();
      } else {
        deliveryOpts.forEach(o => o.classList.remove('selected'));
        btn.classList.add('selected');
        deliveryType = type;
        hideVehicleBanner();
      }
    });
  });

  // Escuchar cambios en depósito para recalcular balance
  document.getElementById('inputDeposit').addEventListener('input', () => {
    const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
    calculateBalance(total);
  });

  // Modales - Botones de Cerrar
  document.querySelectorAll('.close-modal:not(#btnCloseAuthModal):not(#btnCloseTableLayoutEditor), #btnCancelCake').forEach(btn => {
    btn.addEventListener('click', () => {
      closeAllModals();
    });
  });

  const btnCloseAuthModal = document.getElementById('btnCloseAuthModal');
  if (btnCloseAuthModal) {
    btnCloseAuthModal.addEventListener('click', (e) => {
      e.stopPropagation();
      document.getElementById('modalAuth').style.display = 'none';
      restoreOriginalAuthModal();
    });
  }

  // Boton Listo / Aceptar de Grupo de Precios
  document.getElementById('btnDonePriceGroup').addEventListener('click', () => {
    document.getElementById('modalPriceGroup').style.display = 'none';
  });

  // --- FORMULARIO DE PASTEL SOBRE PEDIDO ---
  setupOptionsGroup('flavorOptions', (val) => tempCakeData.flavor = val);
  setupOptionsGroup('sizeOptions', (val) => tempCakeData.size = val);
  setupMultipleOptionsGroup('fruitOptions', (arr) => tempCakeData.fruits = arr);
  setupMultipleOptionsGroup('fillingOptions', (arr) => tempCakeData.fillings = arr);
  setupOptionsGroup('gelatinaOptions', (val) => tempCakeData.gelatina = val);

  // Selector de método de carga de fotos
  const selectMedia = document.getElementById('mediaSourceSelect');
  selectMedia.addEventListener('change', (e) => {
    document.querySelectorAll('.media-option-content').forEach(c => c.classList.remove('active'));
    
    const val = e.target.value;
    if (val === 'qr') {
      document.getElementById('mediaContentQR').classList.add('active');
      generateUploadQR();
    } else if (val === 'local') {
      document.getElementById('mediaContentLocal').classList.add('active');
    } else if (val === 'email') {
      document.getElementById('mediaContentEmail').classList.add('active');
      loadMockEmails();
    }
  });

  // Subida de Archivo Local (PC/WhatsApp)
  const fileInput = document.getElementById('localFileInput');
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      document.getElementById('lblLocalFilename').innerText = file.name;
      const reader = new FileReader();
      reader.onload = async function(evt) {
        const base64Image = evt.target.result;
        // Subir al servidor local temporalmente
        const filename = `cake_${Date.now()}_${file.name}`;
        const response = await fetch(`${SERVER_URL}/api/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64Image, filename })
        });
        const resData = await response.json();
        if (resData.url) {
          tempCakeData.photoUrl = resData.url;
          const preview = document.getElementById('cakePhotoPreview');
          preview.src = resData.url;
          preview.style.display = 'block';
          const btns = document.getElementById('cakePhotoActionBtns');
          if (btns) btns.style.display = 'flex';
        }
      };
      reader.readAsDataURL(file);
    }
  });

  document.getElementById('btnOpenMSPaint').addEventListener('click', async () => {
    if (!tempCakeData.photoUrl) {
      showToast('No photo selected to edit', 'error');
      return;
    }
    try {
      const res = await fetch(`${SERVER_URL}/api/photos/open-external`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ photoUrl: tempCakeData.photoUrl })
      });
      const data = await res.json();
      if (res.ok) {
        showToast('Opened in MS Paint! Edit, save, and reload.', 'success');
      } else {
        showToast('Error opening MS Paint: ' + data.error, 'error');
      }
    } catch(e) {
      console.error(e);
      showToast('Failed to open MS Paint', 'error');
    }
  });

  document.getElementById('btnRotateCakePhoto').addEventListener('click', async () => {
    if (!tempCakeData.photoUrl) return;
    const img = document.getElementById('cakePhotoPreview');
    if (!img || !img.src) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    const tempImg = new Image();
    tempImg.crossOrigin = 'anonymous';
    tempImg.onload = async () => {
      canvas.width = tempImg.height;
      canvas.height = tempImg.width;
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(90 * Math.PI / 180);
      ctx.drawImage(tempImg, -tempImg.width / 2, -tempImg.height / 2);
      
      const rotatedBase64 = canvas.toDataURL('image/jpeg', 0.9);
      
      try {
        const res = await fetch(`${SERVER_URL}/api/photos/save-edited`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ photoUrl: tempCakeData.photoUrl, base64Data: rotatedBase64 })
        });
        const data = await res.json();
        if (res.ok && data.url) {
          tempCakeData.photoUrl = data.url;
          img.src = data.url;
          showToast('Photo rotated 90°', 'success');
        }
      } catch(e) {
        console.error(e);
      }
    };
    tempImg.src = img.src;
  });

  function updateCakeBalance() {
    const p = parseFloat(document.getElementById('cakePrice').value) || 0;
    const d = parseFloat(document.getElementById('cakeDeposit').value) || 0;
    const bal = Math.max(0, p - d);
    document.getElementById('cakeBalance').value = bal.toFixed(2);
  }
  document.getElementById('cakePrice').addEventListener('input', updateCakeBalance);
  document.getElementById('cakeDeposit').addEventListener('input', updateCakeBalance);
  document.getElementById('cakePrice').addEventListener('change', updateCakeBalance);
  document.getElementById('cakeDeposit').addEventListener('change', updateCakeBalance);

  // Guardar Pastel sobre Pedido / Bodas y agregarlo al carrito
  document.getElementById('btnSaveCake').addEventListener('click', () => {
    const clientName = document.getElementById('cakeClientName').value.trim();
    const clientPhone = document.getElementById('cakeClientPhone').value.trim();
    const pickupDate = document.getElementById('cakePickupDate').value;
    const pickupTime = document.getElementById('cakePickupTime').value;
    const price = parseFloat(document.getElementById('cakePrice').value) || 0;
    const deposit = parseFloat(document.getElementById('cakeDeposit').value) || 0;
    const balance = Math.max(0, price - deposit);

    const name1 = document.getElementById('weddingName1')?.value?.trim() || '';
    const name2 = document.getElementById('weddingName2')?.value?.trim() || '';
    const bookModel = document.getElementById('weddingBookModel')?.value?.trim() || '';
    const ppl = document.getElementById('weddingPpl')?.value?.trim() || '';
    const color = document.getElementById('weddingColor')?.value?.trim() || '';
    const shape = document.getElementById('weddingShapeSelect')?.value || 'Round';
    const tierCount = document.getElementById('weddingTierCountSelect')?.value || '3';
    const folio = document.getElementById('weddingFolioBadge')?.innerText.replace('Folio: ', '') || '#WED-1001';
    const prodStatus = document.getElementById('weddingProdStatus')?.value || 'Pending';
    const coolerNum = document.getElementById('weddingCoolerNum')?.value || 'Cooler 1';
    const shelfNum = document.getElementById('weddingShelfNum')?.value || 'Shelf 1';

    if (!clientName || !clientPhone || !pickupDate || !pickupTime) {
      showToast('Please fill in customer and pickup details', 'error');
      return;
    }

    if (tempCakeData.isSpecialEvent) {
      if (!ppl) {
        showToast('⚠️ Ingresa el número de invitados (# PPL / Guests)', 'error');
        document.getElementById('weddingPpl').focus();
        return;
      }
      if (!color) {
        showToast('⚠️ Ingresa el color o tema del pastel (Color / Theme)', 'error');
        document.getElementById('weddingColor').focus();
        return;
      }
    }

    if (!tempCakeData.size && !tempCakeData.isSpecialEvent) {
      if (!tempCakeData.flavor) {
        showToast('Please choose cake size and flavor', 'error');
        return;
      }
    }

    // Recopilar los datos de cada piso si es Boda / 15 Años
    const tierCards = document.querySelectorAll('#weddingTiersListContainer .wedding-tier-card');
    const tiersBreakdown = [];
    tierCards.forEach((card, idx) => {
      const sz = card.querySelector('.tier-size')?.value || '10"';
      const f = card.querySelector('.tier-flavor')?.value || 'Vainilla';
      const fill = card.querySelector('.tier-filling')?.value || 'Whipped Cream';
      const fr = card.querySelector('.tier-fruit')?.value || 'Ninguna';
      tiersBreakdown.push({ tier: idx + 1, size: sz, flavor: f, filling: fill, fruit: fr });
    });

    const typeLabel = tempCakeData.isSpecialEvent ? 'Pastel Bodas/15 Años' : 'Pastel sobre Pedido';

    // El monto a cobrar hoy en la caja es el anticipo (Deposit) si existe, o el precio total si no hay anticipo
    const chargeTodayPrice = deposit > 0 ? deposit : price;

    // Añadir al carrito
    cart.push({
      id: 'custom_' + Date.now(),
      name: `${typeLabel} - ${clientName}`,
      price: chargeTodayPrice,
      quantity: 1,
      isCustomCake: true,
      details: {
        clientName,
        clientPhone,
        pickupDate,
        pickupTime,
        totalPrice: price,
        deposit: deposit,
        balance: balance,
        flavor: tempCakeData.flavor || (tiersBreakdown.length > 0 ? tiersBreakdown[0].flavor : 'Vainilla'),
        size: tempCakeData.size || `${tierCount} Tiers (${shape})`,
        fruits: tempCakeData.fruits,
        fillings: tempCakeData.fillings,
        gelatina: tempCakeData.gelatina,
        notes: document.getElementById('cakeNotes').value.trim(),
        photoUrl: tempCakeData.photoUrl,
        isSpecialEvent: tempCakeData.isSpecialEvent,
        folio,
        bookModel,
        shape,
        tierCount,
        tiersBreakdown,
        ppl,
        color,
        deposit,
        balance,
        prodStatus,
        coolerNum,
        shelfNum,
        createdCashier: currentCashierName || 'Admin',
        modifications: []
      }
    });

    closeAllModals();
    updateCartUI();
    showToast(tempCakeData.isSpecialEvent ? 'Wedding & Quinceañera order added' : 'Custom cake added to order');
  });

  // Botón: Añadir otra orden o artículo adicional al mismo pedido
  const btnAddMore = document.getElementById('btnAddAdditionalOrderItem');
  if (btnAddMore) {
    btnAddMore.addEventListener('click', () => {
      document.getElementById('btnSaveCake').click();
      showToast('Item saved! Select additional products (e.g. Cupcakes, Desserts) from menu.', 'info');
    });
  }

  // Botón: Vincular Ticket / Añadir productos adicionales al carrito
  const btnLinkTicket = document.getElementById('btnLinkAnotherTicket');
  if (btnLinkTicket) {
    btnLinkTicket.addEventListener('click', () => {
      if (cart.length === 0) {
        showToast('Cart is empty. Add a cake or product first to link tickets!', 'warning');
      } else {
        showToast('Ticket linked! You can now add extra items (e.g. Pan Dulce, Coffee, Cupcakes) to this order.', 'success');
      }
    });
  }

  // --- LEALTAD MODAL ---
  window.openLoyaltyModal = function() {
    document.getElementById('modalLoyalty').style.display = 'flex';
    document.getElementById('loyaltyPhoneInput').value = '';
    document.getElementById('loyaltyDescriptionInput').value = '';
    
    // Generar el código QR de registro/vinculación
    generateLoyaltyQR();

    document.getElementById('loyaltyCreationFields').style.display = 'none';
    document.getElementById('btnRegisterLoyalty').style.display = 'none';
    document.getElementById('btnSearchLoyalty').style.display = 'block';
    const showAddBtn = document.getElementById('btnShowAddClient');
    if (showAddBtn) showAddBtn.style.display = 'block';
    const msgBanner = document.getElementById('loyaltyMessageBanner');
    if (msgBanner) msgBanner.style.display = 'none';
    
    document.getElementById('loyaltyPhoneInput').focus();
  };

  document.getElementById('btnLoyalty').addEventListener('click', () => {
    openLoyaltyModal();
  });

  const btnShowAdd = document.getElementById('btnShowAddClient');
  if (btnShowAdd) {
    btnShowAdd.addEventListener('click', () => {
      document.getElementById('loyaltyMessageBanner').style.display = 'none';
      document.getElementById('loyaltyCreationFields').style.display = 'flex';
      document.getElementById('btnRegisterLoyalty').style.display = 'block';
      document.getElementById('btnSearchLoyalty').style.display = 'none';
      btnShowAdd.style.display = 'none';
    });
  }

  // --- LOGIN Y CAMBIO DE CAJERA ACTIVA ---
  document.getElementById('btnActiveCashier').addEventListener('click', () => {
    showToast('Active Cashier clicked! Opening modalOptions...', 'info');
    const modalOpt = document.getElementById('modalOptions');
    if (modalOpt) {
      modalOpt.style.display = 'flex';
    } else {
      showToast('modalOptions element NOT found!', 'error');
    }
    switchOptionsPane('paneOptCashier', document.getElementById('btnOptCashier'));
    updateOptCashierDetails();
  });

  // Cashier Options Pane triggers
  document.getElementById('btnOptCashierChange').addEventListener('click', () => {
    document.getElementById('modalOptions').style.display = 'none';
    authSuccessCallback = async (authorizedName) => {
      currentCashierName = authorizedName;
      await checkActiveShiftAndLockState(authorizedName);
      showToast(`Logged in as cashier: ${authorizedName}`, 'success');
      
      document.getElementById('modalOptions').style.display = 'flex';
      switchOptionsPane('paneOptCashier', document.getElementById('btnOptCashier'));
      updateOptCashierDetails();
    };
    
    showAuthModal('Manager Authorization', 'Press and hold scanner to scan...');
  });

  document.getElementById('btnOptCashierShift').addEventListener('click', async () => {
    document.getElementById('modalOptions').style.display = 'none';
    
    if (!activeShift) {
      // Prepare dual drawer selector
      await prepareOpenShiftDrawerSelector();

      // Open shift modal
      document.getElementById('modalOpenShift').style.display = 'flex';
      resetOpenShiftInputs();
      setTimeout(() => {
        const directInp = document.getElementById('inputStartingCashDirect');
        if (directInp) {
          directInp.focus();
          directInp.select();
        }
      }, 150);
      return;
    }
    
    // Close shift modal - populate assigned drawer info
    const isEs = (posSettings && posSettings.language === 'es');
    const lblDrawer = document.getElementById('lblCloseShiftDrawerInfo');
    if (lblDrawer) {
      lblDrawer.innerText = isEs 
        ? `Cajero: ${currentCashierName || '-'} | 🗄️ Cajón ${currentCashierDrawer || 1}` 
        : `Cashier: ${currentCashierName || '-'} | 🗄️ Drawer ${currentCashierDrawer || 1}`;
    }

    document.querySelectorAll('.denom-input-close').forEach(inp => {
      inp.value = '0';
    });
    
    document.getElementById('modalCloseShift').style.display = 'flex';
    calculateClosingCash();
    
    setTimeout(() => {
      const pInput = document.getElementById('closeCoinsPennies');
      if (pInput) {
        pInput.focus();
        pInput.select();
      }
    }, 150);
  });

  // Connection Mode Toggles
  document.getElementById('btnConnectionOnline').addEventListener('click', async () => {
    try {
      const res = await fetch(`${SERVER_URL}/api/admin/toggle-online`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ onlineMode: true })
      });
      if (res.ok) {
        showToast('Online Mode enabled / Modo Online activado', 'success');
        updateConnectionModeDisplay();
      }
    } catch (e) {
      showToast('Error toggling connection mode', 'error');
    }
  });

  document.getElementById('btnConnectionOffline').addEventListener('click', async () => {
    try {
      const res = await fetch(`${SERVER_URL}/api/admin/toggle-online`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ onlineMode: false })
      });
      if (res.ok) {
        showToast('Offline Mode forced / Modo Offline activado', 'warning');
        updateConnectionModeDisplay();
      }
    } catch (e) {
      showToast('Error toggling connection mode', 'error');
    }
  });

  // Manejar cambio en el tipo de cliente (Individual vs Compañía)
  const loyaltyTypeSelect = document.getElementById('loyaltyType');
  if (loyaltyTypeSelect) {
    loyaltyTypeSelect.addEventListener('change', (e) => {
      const compGroup = document.getElementById('loyaltyCompanyNameGroup');
      const lblName = document.getElementById('lblLoyaltyNameInput');
      const nameInput = document.getElementById('loyaltyNameInput');
      if (e.target.value === 'company') {
        compGroup.style.display = 'block';
        lblName.innerText = 'Contact Person Name';
        nameInput.placeholder = 'e.g. John Doe';
      } else {
        compGroup.style.display = 'none';
        lblName.innerText = 'Customer Name';
        nameInput.placeholder = 'e.g. John Doe';
      }
    });
  }

  document.getElementById('btnSearchLoyalty').addEventListener('click', async () => {
    const phone = document.getElementById('loyaltyPhoneInput').value.trim();
    if (!phone) return;

    try {
      const response = await fetch(`${SERVER_URL}/api/loyalty/${phone}`);
      if (response.ok) {
        const client = await response.json();
        openLoyaltyActionsModal(client);
      } else {
        // Mostrar campos para registrar
        document.getElementById('loyaltyMessageBanner').style.display = 'block';
        document.getElementById('loyaltyCreationFields').style.display = 'flex';
        document.getElementById('btnRegisterLoyalty').style.display = 'block';
        document.getElementById('btnSearchLoyalty').style.display = 'none';
        
        // Reset fields
        document.getElementById('loyaltyNameInput').value = '';
        document.getElementById('loyaltyCompanyNameInput').value = '';
        document.getElementById('loyaltyAddressInput').value = '';
        document.getElementById('loyaltyType').value = 'individual';
        document.getElementById('loyaltyCompanyNameGroup').style.display = 'none';
        document.getElementById('lblLoyaltyNameInput').innerText = 'Customer Name';
      }
    } catch (error) {
      console.error(error);
    }
  });

  document.getElementById('btnRegisterLoyalty').addEventListener('click', async () => {
    const phone = document.getElementById('loyaltyPhoneInput').value.trim();
    const type = document.getElementById('loyaltyType').value;
    const name = document.getElementById('loyaltyNameInput').value.trim();
    const companyName = document.getElementById('loyaltyCompanyNameInput').value.trim();
    const address = document.getElementById('loyaltyAddressInput').value.trim();
    
    if (!phone || !name) {
      showToast('Please fill in Phone and Contact Name', 'error');
      return;
    }
    if (type === 'company' && !companyName) {
      showToast('Please enter Company Name', 'error');
      return;
    }

    const payload = {
      phone,
      type,
      name,
      companyName: type === 'company' ? companyName : '',
      address,
      points: 10 // Regalo de bienvenida
    };

    try {
      const response = await fetch(`${SERVER_URL}/api/clients`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (response.ok) {
        const client = await response.json();
        currentLoyaltyClient = client;
        if (deliveryType === 'comer') {
          tabTableNumber = 'Customer: ' + (currentLoyaltyClient.type === 'company' ? currentLoyaltyClient.companyName : currentLoyaltyClient.name);
          tabClientCount = 1;
          activeTabClientSeat = 1;
        }
        setLoyaltyClientUI();
        closeAllModals();
        showToast('Client registered and linked to current order!', 'success');
      } else {
        showToast('Error registering client profile', 'error');
      }
    } catch(e) {
      console.error(e);
      showToast('Connection error registering client', 'error');
    }
  });

  let allClientsCachedForSearch = [];

  const cacheClientsForSearch = async () => {
    try {
      const res = await fetch(`${SERVER_URL}/api/clients`);
      if (res.ok) {
        allClientsCachedForSearch = await res.json();
      }
    } catch (e) {
      console.error("Error caching clients:", e);
    }
  };

  const loyaltyPhoneInputEl = document.getElementById('loyaltyPhoneInput');
  if (loyaltyPhoneInputEl) {
    loyaltyPhoneInputEl.addEventListener('focus', cacheClientsForSearch);
    loyaltyPhoneInputEl.addEventListener('input', () => {
      const val = loyaltyPhoneInputEl.value.trim().toLowerCase();
      const resultsDiv = document.getElementById('loyaltyAutocompleteResults');
      if (!resultsDiv) return;

      if (!val || allClientsCachedForSearch.length === 0) {
        resultsDiv.style.display = 'none';
        resultsDiv.innerHTML = '';
        return;
      }

      const matched = allClientsCachedForSearch.filter(c => {
        const name = (c.name || '').toLowerCase();
        const phone = (c.phone || '').toLowerCase();
        const company = (c.companyName || '').toLowerCase();
        return name.includes(val) || phone.includes(val) || company.includes(val);
      }).slice(0, 5);

      if (matched.length === 0) {
        resultsDiv.style.display = 'none';
        resultsDiv.innerHTML = '';
        return;
      }

      resultsDiv.innerHTML = matched.map(c => {
        const displayName = c.type === 'company' ? `${c.companyName} (${c.name})` : c.name;
        return `
          <div class="loyalty-autocomplete-item" data-phone="${c.phone}" data-name="${c.name}" style="padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; color: #fff; font-size: 13px; text-align: left;">
            <strong>${displayName}</strong> <span style="color: var(--text-secondary); float: right;">${c.phone}</span>
          </div>
        `;
      }).join('');

      resultsDiv.style.display = 'block';

      resultsDiv.querySelectorAll('.loyalty-autocomplete-item').forEach(item => {
        item.addEventListener('click', () => {
          const cPhone = item.getAttribute('data-phone');
          resultsDiv.style.display = 'none';

          const client = allClientsCachedForSearch.find(c => c.phone === cPhone);
          if (client) {
            loyaltyPhoneInputEl.value = client.phone;
            openLoyaltyActionsModal(client);
          }
        });
      });
    });
  }

  const customerTabNameInputEl = document.getElementById('customerTabNameInput');
  if (customerTabNameInputEl) {
    customerTabNameInputEl.addEventListener('focus', cacheClientsForSearch);
    customerTabNameInputEl.addEventListener('input', () => {
      const val = customerTabNameInputEl.value.trim().toLowerCase();
      const resultsDiv = document.getElementById('customerTabAutocompleteResults');
      if (!resultsDiv) return;

      if (!val || allClientsCachedForSearch.length === 0) {
        resultsDiv.style.display = 'none';
        resultsDiv.innerHTML = '';
        return;
      }

      const matched = allClientsCachedForSearch.filter(c => {
        const name = (c.name || '').toLowerCase();
        const phone = (c.phone || '').toLowerCase();
        const company = (c.companyName || '').toLowerCase();
        return name.includes(val) || phone.includes(val) || company.includes(val);
      }).slice(0, 5);

      if (matched.length === 0) {
        resultsDiv.style.display = 'none';
        resultsDiv.innerHTML = '';
        return;
      }

      resultsDiv.innerHTML = matched.map(c => {
        const displayName = c.type === 'company' ? `${c.companyName} (${c.name})` : c.name;
        return `
          <div class="autocomplete-item" data-phone="${c.phone}" data-name="${c.name}" style="padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; color: #fff; font-size: 13px;">
            <strong>${displayName}</strong> <span style="color: var(--text-secondary); float: right;">${c.phone}</span>
          </div>
        `;
      }).join('');

      resultsDiv.style.display = 'block';

      resultsDiv.querySelectorAll('.autocomplete-item').forEach(item => {
        item.addEventListener('click', () => {
          const cName = item.getAttribute('data-name');
          const cPhone = item.getAttribute('data-phone');
          customerTabNameInputEl.value = cName;
          resultsDiv.style.display = 'none';

          const matchedClient = allClientsCachedForSearch.find(c => c.phone === cPhone);
          if (matchedClient) {
            currentLoyaltyClient = matchedClient;
            setLoyaltyClientUI();
            showToast(`Linked client: ${cName}`, 'success');
          }
        });
      });
    });
  }

  document.addEventListener('click', (e) => {
    const target = e.target;
    if (target) {
      if (!target.closest('#loyaltyPhoneInput') && !target.closest('#loyaltyAutocompleteResults')) {
        const d = document.getElementById('loyaltyAutocompleteResults');
        if (d) d.style.display = 'none';
      }
      if (!target.closest('#customerTabNameInput') && !target.closest('#customerTabAutocompleteResults')) {
        const d = document.getElementById('customerTabAutocompleteResults');
        if (d) d.style.display = 'none';
      }
    }
  });

  const btnLinkDescriptionToOrder = document.getElementById('btnLinkDescriptionToOrder');
  if (btnLinkDescriptionToOrder) {
    btnLinkDescriptionToOrder.addEventListener('click', async () => {
      const descVal = document.getElementById('loyaltyDescriptionInput').value.trim();
      if (!descVal) {
        showToast(posSettings && posSettings.language === 'es' ? 'Por favor ingrese una descripción o nombre' : 'Please enter a description or name', 'error');
        return;
      }

      if (deliveryType === 'comer') {
        try {
          const res = await fetch(`${SERVER_URL}/api/orders`);
          if (res.ok) {
            const allOrders = await res.json();
            const activeStatuses = ['pendiente', 'en_preparacion', 'en_decoracion', 'listo'];
            const isDuplicate = allOrders.some(o =>
              activeStatuses.includes(o.status) &&
              (String(o.tableName).toLowerCase() === ('customer: ' + descVal).toLowerCase() || String(o.clientName).toLowerCase() === descVal.toLowerCase() || String(o.tableName).toLowerCase() === descVal.toLowerCase())
            );
            if (isDuplicate) {
              showToast(posSettings && posSettings.language === 'es' ? '¡Ese nombre de cuenta ya está activa!' : 'That customer account is already active!', 'error');
              return;
            }
          }
        } catch(err) {
          console.error(err);
        }

        tabTableNumber = 'Customer: ' + descVal;
        tabClientCount = 1;
        activeTabClientSeat = 1;
      }

      currentLoyaltyClient = {
        name: descVal,
        phone: 'N/A',
        points: 0,
        type: 'custom'
      };

      setLoyaltyClientUI();
      closeAllModals();
      showToast(posSettings && posSettings.language === 'es' ? `¡Descripción vinculada: ${descVal}!` : `Description linked: ${descVal}!`, 'success');
    });
  }

  // --- LOYALTY QR MOBILE REQUESTS ---
  const btnRejectLoyaltyReq = document.getElementById('btnRejectLoyaltyReq');
  if (btnRejectLoyaltyReq) {
    btnRejectLoyaltyReq.addEventListener('click', () => {
      document.getElementById('modalLoyaltyRequest').style.display = 'none';
      activeLoyaltyRequest = null;
      showToast('Petición de lealtad rechazada / Loyalty request rejected', 'info');
    });
  }

  const btnAcceptLoyaltyReq = document.getElementById('btnAcceptLoyaltyReq');
  if (btnAcceptLoyaltyReq) {
    btnAcceptLoyaltyReq.addEventListener('click', async () => {
      if (!activeLoyaltyRequest) return;
      const req = activeLoyaltyRequest;
      const isEs = posSettings && posSettings.language === 'es';
      
      if (req.isNew) {
        // Register new client in database
        const payload = {
          phone: req.phone,
          type: 'individual',
          name: req.name,
          companyName: '',
          address: '',
          points: 10 // Regalo de bienvenida
        };
        
        try {
          const response = await fetch(`${SERVER_URL}/api/clients`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          if (response.ok) {
            const client = await response.json();
            currentLoyaltyClient = client;
            setLoyaltyClientUI();
            showToast(isEs ? `¡Cliente registrado y vinculado: ${client.name}!` : `Client registered and linked: ${client.name}!`, 'success');
          } else {
            showToast('Error registering client', 'error');
          }
        } catch (e) {
          console.error(e);
          showToast('Connection error', 'error');
        }
      } else {
        // Existing client - link directly
        currentLoyaltyClient = {
          phone: req.phone,
          name: req.name,
          points: req.points
        };
        setLoyaltyClientUI();
        showToast(isEs ? `¡Cliente vinculado: ${req.name}!` : `Client linked: ${req.name}!`, 'success');
      }
      
      document.getElementById('modalLoyaltyRequest').style.display = 'none';
      activeLoyaltyRequest = null;
    });
  }

  // --- RELOJ CHECADOR ---
  const openPunchClockModal = () => {
    // Reset view to Step 1 (Authentication)
    document.getElementById('punchStepAuth').style.display = 'flex';
    document.getElementById('punchStepWelcome').style.display = 'none';
    document.getElementById('punchPasscode').value = '';
    document.getElementById('modalPunch').style.display = 'flex';
    
    // Clear any timers
    if (punchCountdownTimer) clearInterval(punchCountdownTimer);
    activePunchEmployee = null;
    
    // Bind punch biometric original scan if WebSocket not active
    bindPunchBiometricListeners();
  };

  const btnPunch = document.getElementById('btnPunch');
  if (btnPunch) {
    btnPunch.addEventListener('click', openPunchClockModal);
  }
  
  const btnSplashPunch = document.getElementById('btnSplashPunch');
  if (btnSplashPunch) {
    btnSplashPunch.addEventListener('click', openPunchClockModal);
  }

  const btnClosePunchModal = document.getElementById('btnClosePunchModal');
  if (btnClosePunchModal) btnClosePunchModal.addEventListener('click', closePunchModal);
  
  const btnPunchCancel = document.getElementById('btnPunchCancel');
  if (btnPunchCancel) btnPunchCancel.addEventListener('click', closePunchModal);

  // --- WAITLIST / LISTA DE ESPERA EVENT LISTENERS ---
  const btnWaitlistToggle = document.getElementById('btnWaitlistToggle');
  if (btnWaitlistToggle) {
    btnWaitlistToggle.addEventListener('click', () => {
      document.getElementById('modalWaitlist').style.display = 'flex';
      renderWaitlistCashier();
    });
  }

  const btnCloseWaitlistModal = document.getElementById('btnCloseWaitlistModal');
  if (btnCloseWaitlistModal) {
    btnCloseWaitlistModal.addEventListener('click', () => {
      document.getElementById('modalWaitlist').style.display = 'none';
    });
  }

  // --- TO GO ORDERS STATUS EVENT LISTENERS ---
  const btnToGoStatusToggle = document.getElementById('btnToGoStatusToggle');
  if (btnToGoStatusToggle) {
    btnToGoStatusToggle.addEventListener('click', () => {
      document.getElementById('modalToGoOrders').style.display = 'flex';
      updateToGoBadgeAndModal();
    });
  }

  const btnCloseToGoModal = document.getElementById('btnCloseToGoModal');
  if (btnCloseToGoModal) {
    btnCloseToGoModal.addEventListener('click', () => {
      document.getElementById('modalToGoOrders').style.display = 'none';
    });
  }
  // --- TO GO PRINT LABEL EVENT LISTENERS ---
  const btnCloseToGoPrintLabelModal = document.getElementById('btnCloseToGoPrintLabelModal');
  if (btnCloseToGoPrintLabelModal) {
    btnCloseToGoPrintLabelModal.addEventListener('click', () => {
      document.getElementById('modalToGoPrintLabel').style.display = 'none';
    });
  }

  const btnCancelToGoPrintLabel = document.getElementById('btnCancelToGoPrintLabel');
  if (btnCancelToGoPrintLabel) {
    btnCancelToGoPrintLabel.addEventListener('click', () => {
      document.getElementById('modalToGoPrintLabel').style.display = 'none';
    });
  }

  const chkSelectAllItems = document.getElementById('chkSelectAllItems');
  if (chkSelectAllItems) {
    chkSelectAllItems.addEventListener('change', (e) => {
      const container = document.getElementById('togoPrintLabelItemsList');
      if (container) {
        const checkboxes = container.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(chk => {
          chk.checked = e.target.checked;
        });
      }
    });
  }

  const btnConfirmToGoPrintLabel = document.getElementById('btnConfirmToGoPrintLabel');
  if (btnConfirmToGoPrintLabel) {
    btnConfirmToGoPrintLabel.addEventListener('click', async () => {
      const orderId = document.getElementById('togoPrintLabelOrderId').value;
      const printMain = document.getElementById('chkPrintMainLabel').checked;
      
      const itemIndexes = [];
      const container = document.getElementById('togoPrintLabelItemsList');
      if (container) {
        const checkboxes = container.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(chk => {
          if (chk.checked) {
            itemIndexes.push(parseInt(chk.dataset.index));
          }
        });
      }

      if (!printMain && itemIndexes.length === 0) {
        showToast('Selecciona al menos una etiqueta', 'error');
        return;
      }

      const btn = document.getElementById('btnConfirmToGoPrintLabel');
      btn.disabled = true;
      const originalText = btn.innerText;
      btn.innerText = 'Imprimiendo...';

      try {
        const res = await fetch(`${SERVER_URL}/api/printer/print-order-labels`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId, printMain, itemIndexes })
        });
        
        if (res.ok) {
          showToast('Etiquetas enviadas', 'success');
          document.getElementById('modalToGoPrintLabel').style.display = 'none';
        } else {
          showToast('Error al imprimir etiquetas', 'error');
        }
      } catch (err) {
        showToast('Error de conexión', 'error');
      } finally {
        btn.disabled = false;
        btn.innerText = originalText;
      }
    });
  }

  // --- CAR ORDERS EVENT LISTENERS ---
  const btnCarOrdersToggle = document.getElementById('btnCarOrdersToggle');
  if (btnCarOrdersToggle) {
    btnCarOrdersToggle.addEventListener('click', () => {
      document.getElementById('modalCarOrders').style.display = 'flex';
      renderCarOrdersList();
    });
  }

  const btnCloseCarOrdersModal = document.getElementById('btnCloseCarOrdersModal');
  if (btnCloseCarOrdersModal) {
    btnCloseCarOrdersModal.addEventListener('click', () => {
      document.getElementById('modalCarOrders').style.display = 'none';
    });
  }

  // --- PHONE ORDERS EVENT LISTENERS ---
  const btnPhoneOrdersToggle = document.getElementById('btnPhoneOrdersToggle');
  if (btnPhoneOrdersToggle) {
    btnPhoneOrdersToggle.addEventListener('click', () => {
      document.getElementById('modalPhoneOrders').style.display = 'flex';
      updatePhoneOrdersBadgeAndModal();
    });
  }

  const btnClosePhoneModal = document.getElementById('btnClosePhoneModal');
  if (btnClosePhoneModal) {
    btnClosePhoneModal.addEventListener('click', () => {
      document.getElementById('modalPhoneOrders').style.display = 'none';
    });
  }

  // --- ONLINE ORDERS EVENT LISTENERS ---
  const btnOnlineOrdersToggle = document.getElementById('btnOnlineOrdersToggle');
  if (btnOnlineOrdersToggle) {
    btnOnlineOrdersToggle.addEventListener('click', () => {
      document.getElementById('modalOnlineOrders').style.display = 'flex';
      updateOnlineOrdersBadgeAndModal();
    });
  }

  const btnCloseOnlineModal = document.getElementById('btnCloseOnlineModal');
  if (btnCloseOnlineModal) {
    btnCloseOnlineModal.addEventListener('click', () => {
      document.getElementById('modalOnlineOrders').style.display = 'none';
    });
  }

  // Fetch initial waitlist status
  fetch(`${SERVER_URL}/api/waitlist`)
    .then(r => r.json())
    .then(data => {
      waitlist = data || [];
      updateWaitlistBadge();
    }).catch(e => console.error("Initial waitlist fetch failed:", e));

  // Fetch initial to go orders status
  updateToGoBadgeAndModal();
  updatePhoneOrdersBadgeAndModal();
  updateOnlineOrdersBadgeAndModal();
  updateCarOrdersBadge();
  updateDeliveryHubBadge();
  if (typeof updateActiveTabsCount === 'function') updateActiveTabsCount();

  // Background polling for real-time status badges every 4 seconds
  setInterval(() => {
    updateToGoBadgeAndModal();
    updateCarOrdersBadge();
    updateDeliveryHubBadge();
    if (typeof updateActiveTabsCount === 'function') updateActiveTabsCount();
  }, 4000);

  // Delivery Hub Button Listener
  const btnDeliveryHubToggle = document.getElementById('btnDeliveryHubToggle');
  if (btnDeliveryHubToggle) {
    btnDeliveryHubToggle.addEventListener('click', () => {
      document.getElementById('modalDeliveryHub').style.display = 'flex';
      loadDeliveryHubOrders();
      setTimeout(() => {
        document.getElementById('deliveryScanInput')?.focus();
      }, 100);
    });
  }

  const btnCloseDeliveryHub = document.getElementById('btnCloseDeliveryHub');
  if (btnCloseDeliveryHub) {
    btnCloseDeliveryHub.addEventListener('click', () => {
      document.getElementById('modalDeliveryHub').style.display = 'none';
    });
  }

  const deliveryScanInput = document.getElementById('deliveryScanInput');
  if (deliveryScanInput) {
    deliveryScanInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        searchDeliveryByCode();
      }
    });
  }

  // Touch Keypad for Punch Passcode (Handled via global event delegation)

  // Welcome Step button actions
  document.getElementById('btnPunchActionIn').addEventListener('click', () => executePunchClockAction('in'));
  document.getElementById('btnPunchActionOut').addEventListener('click', () => executePunchClockAction('out'));

  // --- TECLADO DE CAJA REGISTRADORA (EFECTIVO RECIBIDO) ---
  // Billetes Rápidos
  document.querySelectorAll('.btn-bill').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.getAttribute('data-value');
      cashReceivedString = parseFloat(val).toFixed(2);
      updateRegisterChange();
    });
  });

  // Teclado Numérico
  document.querySelectorAll('#registerKeypad .key-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.getAttribute('data-value');
      if (val === 'C') {
        cashReceivedString = '';
      } else if (val === '.') {
        if (!cashReceivedString.includes('.')) {
          cashReceivedString += '.';
        }
      } else {
        // Limitar a dos decimales y largo máximo
        if (cashReceivedString.includes('.')) {
          const parts = cashReceivedString.split('.');
          if (parts[1].length < 2) {
            cashReceivedString += val;
          }
        } else {
          cashReceivedString += val;
        }
      }
      updateRegisterChange();
    });
  });

  // Métodos de Pago Finales
  document.getElementById('btnPayCash').addEventListener('click', () => {
    if (posSettings && posSettings.stationRole === 'waiter') {
      const isEs = posSettings && posSettings.language === 'es';
      showToast(isEs ? 'Cobro en efectivo no disponible en terminal de mesero. Diríjase a una Caja.' : 'Cash payments not permitted on Waiter Stations. Please collect at a Cashier register.', 'warning');
      return;
    }
    processCheckout('cash');
  });
  document.getElementById('btnPayCard').addEventListener('click', () => processCheckout('card'));
  document.getElementById('btnPayLaterSubmit').addEventListener('click', () => processCheckout('pay_on_pickup'));

  // Abrir Modal de Caja Registradora (PAY)
  document.getElementById('btnOpenCheckout').addEventListener('click', async () => {
    closeAllModals();
    if (cart.length === 0) return;
    
    // Check if terminal is configured as Waiter Station
    if (posSettings && posSettings.stationRole === 'waiter') {
      const isEs = posSettings && posSettings.language === 'es';
      showToast(isEs ? 'Terminal en Modo Mesero: Utilice SEND para enviar comanda o CHECK para imprimir precuenta.' : 'Waiter Station Mode: Use SEND to punch order to kitchen or CHECK to print guest bill.', 'info');
    }

    // Check if there is an active shift
    if (!activeShift) {
      const isEs = posSettings && posSettings.language === 'es';
      showToast(isEs ? 'Debe abrir un turno para poder cobrar' : 'Must open a shift first to start sales', 'warning');
      
      await prepareOpenShiftDrawerSelector();
      document.getElementById('modalOpenShift').style.display = 'flex';
      resetOpenShiftInputs();
      setTimeout(() => {
        const directInp = document.getElementById('inputStartingCashDirect');
        if (directInp) {
          directInp.focus();
          directInp.select();
        }
      }, 150);
      return;
    }

    // Limpiar efectivo ingresado previo
    cashReceivedString = '';
    document.getElementById('registerTipAmount').value = '';
    
    // Actualizar total en el modal
    const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
    const hasCustomCake = cart.some(item => item.isCustomCake);
    
    let targetAmount = total;
    if (hasCustomCake) {
      const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
      targetAmount = deposit;
    }
    
    document.getElementById('modalCheckoutTotal').innerText = `$${targetAmount.toFixed(2)}`;
    updateRegisterChange();
    
    // Reset checkout schedule fields
    const chkSchedule = document.getElementById('chkCheckoutSchedule');
    if (chkSchedule) {
      chkSchedule.checked = false;
      const fields = document.getElementById('checkoutScheduleFields');
      if (fields) fields.style.display = 'none';
      const scheduledDate = document.getElementById('checkoutScheduledDate');
      if (scheduledDate) scheduledDate.value = '';
      const scheduledTime = document.getElementById('checkoutScheduledTime');
      if (scheduledTime) scheduledTime.value = '';
    }

    // Reset pay later checkbox & mode
    const chkPayLater = document.getElementById('chkPayLater');
    if (chkPayLater) {
      chkPayLater.checked = false;
      togglePayLaterMode(false);
    }
    const payLaterCont = document.getElementById('checkoutPayLaterContainer');
    if (payLaterCont) payLaterCont.style.display = 'none';

    document.getElementById('modalCheckout').style.display = 'flex';
  });

  // Cerrar Modal de Caja Registradora
  document.getElementById('btnCloseCheckoutModal').addEventListener('click', () => {
    document.getElementById('modalCheckout').style.display = 'none';
  });

  // Botón de pago dividido (Split Payment)
  document.getElementById('btnPaySplit').addEventListener('click', () => {
    const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
    const hasCustomCake = cart.some(item => item.isCustomCake);
    
    let targetAmount = total;
    if (hasCustomCake) {
      const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
      targetAmount = deposit;
    }
    
    const cashAmount = parseFloat(cashReceivedString) || 0;
    if (cashAmount <= 0 || cashAmount >= targetAmount) {
      showToast('Please enter a valid cash portion (less than total)', 'error');
      return;
    }
    const cardAmount = targetAmount - cashAmount;
    
    if (confirm(`Process Split Payment?\n\nCASH: $${cashAmount.toFixed(2)}\nCARD: $${cardAmount.toFixed(2)}`)) {
      processSplitCheckout(cashAmount, cardAmount);
    }
  });

  // --- LOYALTY ACTIONS MODAL ---
  document.getElementById('btnLinkLoyaltyToOrder').addEventListener('click', () => {
    if (!tempLoyaltyClient) return;
    currentLoyaltyClient = tempLoyaltyClient;
    if (deliveryType === 'comer') {
      tabTableNumber = 'Customer: ' + (currentLoyaltyClient.type === 'company' ? currentLoyaltyClient.companyName : currentLoyaltyClient.name);
      tabClientCount = 1;
      activeTabClientSeat = 1;
    }
    setLoyaltyClientUI();
    document.getElementById('modalLoyaltyActions').style.display = 'none';
    showToast('Customer linked to current order');
  });

  document.getElementById('btnViewLoyaltyHistory').addEventListener('click', async () => {
    if (!tempLoyaltyClient) return;
    
    const phone = tempLoyaltyClient.phone;
    const list = document.getElementById('loyaltyHistoryList');
    list.innerHTML = '<div style="color: var(--text-secondary); text-align: center; padding: 10px;">Loading history...</div>';
    document.getElementById('loyaltyHistoryContainer').style.display = 'block';

    try {
      const response = await fetch(`${SERVER_URL}/api/orders`);
      if (response.ok) {
        const orders = await response.json();
        // Filtrar órdenes que correspondan a este cliente
        const customerOrders = orders.filter(o => o.clientLoyalty === phone);
        
        list.innerHTML = '';
        if (customerOrders.length === 0) {
          list.innerHTML = '<div style="color: var(--text-secondary); text-align: center; padding: 10px;">No purchase history found.</div>';
          return;
        }

        // Ordenar por fecha decreciente
        customerOrders.sort((a, b) => new Date(b.dateCreated) - new Date(a.dateCreated));

        customerOrders.forEach(order => {
          const dateStr = new Date(order.dateCreated).toLocaleString('en-US', {
            month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
          });
          const statusColor = order.status === 'void' ? 'var(--danger-color)' : 'var(--success-color)';
          const statusText = order.status === 'void' ? 'VOIDED' : 'COMPLETED';
          
          let itemsText = order.items.map(item => `${item.quantity}x ${item.name}`).join(', ');
          if (itemsText.length > 50) itemsText = itemsText.substring(0, 47) + '...';

          const div = document.createElement('div');
          div.style.background = 'rgba(255, 255, 255, 0.02)';
          div.style.border = '1px solid var(--border-color)';
          div.style.borderRadius = '6px';
          div.style.padding = '8px';
          div.style.fontSize = '12px';
          div.innerHTML = `
            <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 2px;">
              <span>Ticket #${order.ticketNumber || 'N/A'}</span>
              <span style="color: ${statusColor}; font-size: 10px;">${statusText}</span>
            </div>
            <div style="color: var(--text-secondary); font-size: 11px; margin-bottom: 2px;">${dateStr}</div>
            <div style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--text-secondary); margin-bottom: 2px;">${itemsText}</div>
            <div style="text-align: right; font-weight: bold; color: var(--accent-color);">Total: $${order.total.toFixed(2)}</div>
          `;
          list.appendChild(div);
        });
      }
    } catch (e) {
      console.error(e);
      list.innerHTML = '<div style="color: var(--danger-color); text-align: center; padding: 10px;">Error loading history.</div>';
    }
  });

  // --- MANAGER OPTIONS MODAL ---
  const btnOptionsEl = document.getElementById('btnOptions');
  if (btnOptionsEl) {
    btnOptionsEl.addEventListener('click', () => {
      showToast('Options header button clicked!', 'info');
      const modalOpt = document.getElementById('modalOptions');
      if (modalOpt) {
        modalOpt.style.display = 'flex';
        showToast('modalOptions display set to flex', 'info');
      } else {
        showToast('modalOptions element NOT found!', 'error');
      }
      try {
        const btnOpt = document.getElementById('btnOptCashier');
        switchOptionsPane('paneOptCashier', btnOpt);
        updateOptCashierDetails();
      } catch (e) {
        console.error("Options modal opening error:", e);
        showToast('Options init error: ' + e.message, 'error');
      }
    });
  }

  const btnRecallTkts = document.getElementById('btnRecallTickets');
  if (btnRecallTkts) {
    btnRecallTkts.addEventListener('click', () => {
      switchOptionsPane('paneOptTickets', document.getElementById('btnOptTickets'));
      document.getElementById('optionsSearchInput').value = '';
      loadOptionsOrders();
      document.getElementById('modalOptions').style.display = 'flex';
    });
  }

  // Abrir cajón del dinero (Dual Cash Drawer pin-aware)
  document.getElementById('btnOpenDrawer').addEventListener('click', async () => {
    const modalOptions = document.getElementById('modalCashierOptions');
    if (modalOptions) modalOptions.style.display = 'none';
    try {
      const targetDrawer = currentCashierDrawer || 1;
      const response = await fetch(`${SERVER_URL}/api/printer/kick-drawer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ drawer: targetDrawer })
      });
      if (response.ok) {
        const isEs = posSettings && posSettings.language === 'es';
        showToast(isEs ? `¡Cajón ${targetDrawer} abierto!` : `Cash drawer ${targetDrawer} kicked successfully!`, 'success');
      } else {
        showToast('Error opening cash drawer', 'error');
      }
    } catch(e) {
      console.error(e);
      showToast('Connection error', 'error');
    }
  });

  // Cerrar/Bloquear Estación (Regresar a Splash)
  document.getElementById('btnLockStation').addEventListener('click', () => {
    lockTerminal();
  });

  // --- WAITRESS TABS AND SEAT SELECTION ---
  const btnSendOrder = document.getElementById('btnSendOrder');
  if (btnSendOrder) {
    btnSendOrder.addEventListener('click', () => {
      closeAllModals();
      if (cart.length === 0) {
        showToast(posSettings && posSettings.language === 'es' ? 'La comanda está vacía / Cart is empty' : 'Cart is empty', 'warning');
        return;
      }

      // Requerir obligatoriamente cliente, mesa o descripción (ej: Camisa Roja, Carlos, Mesa 4)
      const currentDesc = (typeof currentCarDescription !== 'undefined' ? currentCarDescription : '') || (window.currentCarDescription || '');
      const currentCustName = (typeof currentOrderCustomerName !== 'undefined' ? currentOrderCustomerName : '') || (window.currentOrderCustomerName || '');
      const hasIdentity = !!(
        activeTabOrderId ||
        currentLoyaltyClient ||
        (tabTableNumber && tabTableNumber.trim()) ||
        (currentDesc && currentDesc.trim()) ||
        (currentCustName && currentCustName.trim())
      );

      if (!hasIdentity) {
        window.pendingSendAfterCustomerTab = true;
        const modal = document.getElementById('modalCustomerTab');
        if (modal) {
          modal.style.display = 'flex';
          const inp = document.getElementById('customerTabNameInput');
          if (inp) {
            inp.value = '';
            setTimeout(() => inp.focus(), 120);
          }
        }
        return;
      }

      showToast(posSettings && posSettings.language === 'es' ? 'Enviando comanda a cocina...' : 'Sending order to kitchen...', 'info');
      processCheckout('pay_on_pickup');
    });
  }

  const btnPrintBill = document.getElementById('btnPrintBill');
  if (btnPrintBill) {
    btnPrintBill.addEventListener('click', async () => {
      const isEs = posSettings && posSettings.language === 'es';
      if (cart.length === 0) {
        showToast(isEs ? 'La comanda está vacía' : 'Cart is empty', 'warning');
        return;
      }
      if (activeTabOrderId) {
        await printOrderReceipt(activeTabOrderId);
      } else {
        showToast(isEs ? 'Guarde la orden (SEND) antes de imprimir la cuenta' : 'Please save the order (SEND) before printing check', 'warning');
      }
    });
  }

  const btnOpenTab = document.getElementById('btnOpenTab');
  if (btnOpenTab) {
    btnOpenTab.addEventListener('click', () => {
      closeAllModals();
      if (cart.length > 0) {
        if (!confirm(posSettings && posSettings.language === 'es' ? 'Esto vaciará el carrito activo. ¿Proceder?' : 'This will clear the current cart. Proceed?')) {
          return;
        }
      }
      document.getElementById('modalDineInChoice').style.display = 'flex';
    });
  }

  const btnRecallTabs = document.getElementById('btnRecallTabs');
  if (btnRecallTabs) {
    btnRecallTabs.addEventListener('click', () => {
      closeAllModals();
      loadEmployeeTabs();
      document.getElementById('modalRecallTabs').style.display = 'flex';
    });
  }

  // --- DINE-IN CHOICE & CUSTOMER TAB EVENT LISTENERS ---
  const btnCloseDineInChoiceModal = document.getElementById('btnCloseDineInChoiceModal');
  if (btnCloseDineInChoiceModal) {
    btnCloseDineInChoiceModal.addEventListener('click', () => {
      document.getElementById('modalDineInChoice').style.display = 'none';
    });
  }

  const btnDineInOptionTable = document.getElementById('btnDineInOptionTable');
  if (btnDineInOptionTable) {
    btnDineInOptionTable.addEventListener('click', () => {
      document.getElementById('modalDineInChoice').style.display = 'none';
      
      // Select Dine-In button style
      const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option[data-type]');
      deliveryOpts.forEach(o => o.classList.remove('selected'));
      const btnComer = document.getElementById('btnCartDineIn');
      if (btnComer) btnComer.classList.add('selected');
      deliveryType = 'comer';
      
      // Trigger Table map Waitress screen
      initTableMapWaitress();
    });
  }

  const btnDineInOptionCustomer = document.getElementById('btnDineInOptionCustomer');
  if (btnDineInOptionCustomer) {
    btnDineInOptionCustomer.addEventListener('click', () => {
      document.getElementById('modalDineInChoice').style.display = 'none';
      openLoyaltyModal();
    });
  }

  const btnCloseCustomerTabModal = document.getElementById('btnCloseCustomerTabModal');
  if (btnCloseCustomerTabModal) {
    btnCloseCustomerTabModal.addEventListener('click', () => {
      document.getElementById('modalCustomerTab').style.display = 'none';
    });
  }

  const btnCancelCustomerTab = document.getElementById('btnCancelCustomerTab');
  if (btnCancelCustomerTab) {
    btnCancelCustomerTab.addEventListener('click', () => {
      document.getElementById('modalCustomerTab').style.display = 'none';
    });
  }

  const handleConfirmCustomerTab = async () => {
    const nameVal = document.getElementById('customerTabNameInput').value.trim();
    if (!nameVal) {
      showToast(posSettings && posSettings.language === 'es' ? 'Por favor ingrese el nombre del cliente, mesa o descripción (ej: Camisa Roja)' : 'Please enter customer name or description', 'error');
      return;
    }

    // Si viene de presionar SEND o ya hay platillos en el carrito: no vaciar el carrito, enviar comanda directamente
    if (window.pendingSendAfterCustomerTab || cart.length > 0) {
      window.pendingSendAfterCustomerTab = false;
      tabTableNumber = nameVal;
      currentOrderCustomerName = nameVal;
      window.currentOrderCustomerName = nameVal;
      document.getElementById('modalCustomerTab').style.display = 'none';
      showToast(posSettings && posSettings.language === 'es' ? `Enviando comanda de '${nameVal}' a cocina...` : `Sending comanda for '${nameVal}' to kitchen...`, 'info');
      processCheckout('pay_on_pickup');
      return;
    }

    // Check for active duplicates si se abre una cuenta vacía en mesa
    try {
      const res = await fetch(`${SERVER_URL}/api/orders`);
      if (res.ok) {
        const allOrders = await res.json();
        const activeStatuses = ['pendiente', 'en_preparacion', 'en_decoracion', 'listo'];
        const isDuplicate = allOrders.some(o => 
          activeStatuses.includes(o.status) && 
          (String(o.tableName || '').toLowerCase() === ('customer: ' + nameVal).toLowerCase() || 
           String(o.clientName || '').toLowerCase() === nameVal.toLowerCase() || 
           String(o.tableName || '').toLowerCase() === nameVal.toLowerCase())
        );
        if (isDuplicate) {
          showToast(posSettings && posSettings.language === 'es' ? '¡Ese número de mesa o cuenta ya está activa!' : 'That table or account is already active!', 'error');
          return;
        }
      }
    } catch(err) {
      console.error(err);
    }

    const orderData = {
      items: [],
      type: 'comer',
      total: 0,
      deposit: 0,
      balance: 0,
      status: 'pendiente',
      paymentStatus: 'unpaid',
      tableName: nameVal,
      clientName: nameVal,
      guestCount: 1,
      cashierName: currentCashierName || 'Cashier'
    };

    try {
      const response = await fetch(`${SERVER_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      
      if (response.ok) {
        const newTab = await response.json();
        
        activeTabOrderId = newTab.id;
        tabTableNumber = nameVal;
        currentOrderCustomerName = nameVal;
        window.currentOrderCustomerName = nameVal;
        tabClientCount = 1;
        activeTabClientSeat = 1;
        
        const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option[data-type]');
        deliveryOpts.forEach(o => o.classList.remove('selected'));
        const btnComer = document.getElementById('btnCartDineIn');
        if (btnComer) btnComer.classList.add('selected');
        deliveryType = 'comer';
        
        cart = [];

        selectPreOrderType(deliveryType);
        buildSeatSelectors();
        updateCartUI();

        document.getElementById('modalCustomerTab').style.display = 'none';
        showToast(posSettings && posSettings.language === 'es' ? `¡Cuenta iniciada para '${nameVal}'!` : `Tab session for '${nameVal}' started!`, 'success');
      } else {
        showToast('Error starting customer tab', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Error starting customer tab', 'error');
    }
  };

  const btnConfirmCustomerTab = document.getElementById('btnConfirmCustomerTab');
  if (btnConfirmCustomerTab) {
    btnConfirmCustomerTab.addEventListener('click', handleConfirmCustomerTab);
  }

  const inputCustTabName = document.getElementById('customerTabNameInput');
  if (inputCustTabName) {
    inputCustTabName.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleConfirmCustomerTab();
      }
    });
  }

  const closeOpenTab = () => { document.getElementById('modalOpenTab').style.display = 'none'; };
  const closeRecallTabs = () => { document.getElementById('modalRecallTabs').style.display = 'none'; };

  document.getElementById('btnCloseOpenTabModal').addEventListener('click', closeOpenTab);
  document.getElementById('btnCancelOpenTab').addEventListener('click', closeOpenTab);
  document.getElementById('btnCloseRecallTabsModal').addEventListener('click', closeRecallTabs);

  document.getElementById('openTabTable').addEventListener('click', () => {
    activeOpenTabField = 'openTabTable';
  });
  document.getElementById('openTabGuests').addEventListener('click', () => {
    activeOpenTabField = 'openTabGuests';
  });

  document.querySelectorAll('#openTabKeypad .opt-key').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const val = btn.getAttribute('data-val');
      const input = document.getElementById(activeOpenTabField);
      if (!input) return;

      if (val === 'C') {
        input.value = '';
      } else if (val === 'Backspace') {
        input.value = input.value.slice(0, -1);
      } else {
        input.value += val;
      }
    });
  });

  const btnNextField = document.getElementById('btnOpenTabNextField');
  if (btnNextField) {
    btnNextField.addEventListener('click', (e) => {
      e.preventDefault();
      if (activeOpenTabField === 'openTabTable') {
        activeOpenTabField = 'openTabGuests';
        document.getElementById('openTabGuests').focus();
      } else {
        activeOpenTabField = 'openTabTable';
        document.getElementById('openTabTable').focus();
      }
    });
  }

  document.getElementById('btnConfirmOpenTab').addEventListener('click', async () => {
    const tableVal = document.getElementById('openTabTable').value.trim();
    const guestsVal = document.getElementById('openTabGuests').value.trim();

    if (!tableVal || !guestsVal) {
      showToast('Please enter both Table and Guests count', 'error');
      return;
    }

    const tableNum = tableVal;
    const guestCount = parseInt(guestsVal) || 1;

    // Check for active duplicates
    try {
      const res = await fetch(`${SERVER_URL}/api/orders`);
      if (res.ok) {
        const allOrders = await res.json();
        const activeStatuses = ['pendiente', 'en_preparacion', 'en_decoracion', 'listo'];
        const isDuplicate = allOrders.some(o => 
          activeStatuses.includes(o.status) && 
          (String(o.tableName).toLowerCase() === String(tableNum).toLowerCase() || String(o.tableName).toLowerCase() === ('customer: ' + tableNum).toLowerCase())
        );
        if (isDuplicate) {
          showToast(posSettings && posSettings.language === 'es' ? '¡Ese número de mesa o cuenta ya está activa!' : 'That table or account is already active!', 'error');
          return;
        }
      }
    } catch(err) {
      console.error(err);
    }

    const orderData = {
      items: [],
      type: 'comer',
      total: 0,
      deposit: 0,
      balance: 0,
      status: 'pendiente',
      paymentStatus: 'unpaid',
      tableName: tableNum,
      guestCount: guestCount,
      cashierName: currentCashierName || 'Cashier'
    };

    try {
      const response = await fetch(`${SERVER_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      
      if (response.ok) {
        const newTab = await response.json();
        
        activeTabOrderId = newTab.id;
        tabTableNumber = tableNum;
        tabClientCount = guestCount;
        activeTabClientSeat = 1;
        deliveryType = 'comer';
        cart = [];

        selectPreOrderType(deliveryType);
        buildSeatSelectors();
        updateCartUI();

        closeOpenTab();
        showToast(`Table ${tableNum} session started!`, 'success');
      } else {
        showToast('Error starting tab session', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Error starting tab session', 'error');
    }
  });

  // --- TABLE DIAGRAM EDITOR AND VIEWER LISTENERS ---
  const btnOpenTableMap = document.getElementById('btnOpenTableMap');
  if (btnOpenTableMap) {
    btnOpenTableMap.addEventListener('click', () => {
      initTableMapWaitress();
    });
  }

  const btnCloseTableMapModal = document.getElementById('btnCloseTableMapModal');
  if (btnCloseTableMapModal) {
    btnCloseTableMapModal.addEventListener('click', () => {
      document.getElementById('modalTableMap').style.display = 'none';
    });
  }

  const btnTableMapRecallTabs = document.getElementById('btnTableMapRecallTabs');
  if (btnTableMapRecallTabs) {
    btnTableMapRecallTabs.addEventListener('click', () => {
      document.getElementById('modalTableMap').style.display = 'none';
      loadEmployeeTabs();
      document.getElementById('modalRecallTabs').style.display = 'flex';
    });
  }

  const btnCancelTableSeats = document.getElementById('btnCancelTableSeats');
  if (btnCancelTableSeats) {
    btnCancelTableSeats.addEventListener('click', () => {
      document.getElementById('modalTableSeats').style.display = 'none';
    });
  }

  const btnOpenTableTabDirectly = document.getElementById('btnOpenTableTabDirectly');
  if (btnOpenTableTabDirectly) {
    btnOpenTableTabDirectly.addEventListener('click', () => {
      openTableTabDirectly();
    });
  }

  const btnSetupAddTable = document.getElementById('btnSetupAddTable');
  if (btnSetupAddTable) {
    btnSetupAddTable.addEventListener('click', () => {
      setupAddTable();
    });
  }

  const btnSetupDeleteTable = document.getElementById('btnSetupDeleteTable');
  if (btnSetupDeleteTable) {
    btnSetupDeleteTable.addEventListener('click', () => {
      setupDeleteTable();
    });
  }

  const btnSaveTableLayout = document.getElementById('btnSaveTableLayout');
  if (btnSaveTableLayout) {
    btnSaveTableLayout.addEventListener('click', () => {
      saveTableLayout();
    });
  }

  const btnCloseTableLayoutEditor = document.getElementById('btnCloseTableLayoutEditor');
  if (btnCloseTableLayoutEditor) {
    btnCloseTableLayoutEditor.addEventListener('click', (e) => {
      e.stopPropagation();
      closeTableLayoutEditorToMenu();
    });
  }

  // --- SPLIT BILL AND TICKET PRINTING ACTIONS ---
  const btnTableSeatsPrintCheck = document.getElementById('btnTableSeatsPrintCheck');
  if (btnTableSeatsPrintCheck) {
    btnTableSeatsPrintCheck.addEventListener('click', () => {
      if (currentMapSelectedOrder) {
        printOrderReceipt(currentMapSelectedOrder.id);
        showToast('Printing bill check...', 'success');
        document.getElementById('modalTableSeats').style.display = 'none';
      }
    });
  }

  const btnTableSeatsSplitBill = document.getElementById('btnTableSeatsSplitBill');
  if (btnTableSeatsSplitBill) {
    btnTableSeatsSplitBill.addEventListener('click', () => {
      if (currentMapSelectedOrder) {
        document.getElementById('modalTableSeats').style.display = 'none';
        openSplitBillModal(currentMapSelectedOrder);
      }
    });
  }

  // Split bill mode toggle buttons
  const btnSplitEqualMode = document.getElementById('btnSplitEqualMode');
  if (btnSplitEqualMode) {
    btnSplitEqualMode.addEventListener('click', () => setSplitMode('equal'));
  }
  const btnSplitSeatMode = document.getElementById('btnSplitSeatMode');
  if (btnSplitSeatMode) {
    btnSplitSeatMode.addEventListener('click', () => setSplitMode('seat'));
  }
  const btnSplitItemMode = document.getElementById('btnSplitItemMode');
  if (btnSplitItemMode) {
    btnSplitItemMode.addEventListener('click', () => setSplitMode('item'));
  }

  const btnGenerateEqualSplits = document.getElementById('btnGenerateEqualSplits');
  if (btnGenerateEqualSplits) {
    btnGenerateEqualSplits.addEventListener('click', () => renderEqualSplits());
  }

  const btnMoveItemsToSplit = document.getElementById('btnMoveItemsToSplit');
  if (btnMoveItemsToSplit) {
    btnMoveItemsToSplit.addEventListener('click', () => {
      const select = document.getElementById('splitItemTargetSelect');
      const targetBucket = parseInt(select.value) || 1;
      const checkboxes = document.querySelectorAll('#splitItemSourceList .split-item-chk:checked');
      
      checkboxes.forEach(chk => {
        const itemUniqueId = chk.value;
        const item = currentSplitOrder.items.find(i => (i.uniqueId || i.id) === itemUniqueId);
        if (item) {
          manualSplitBuckets[targetBucket].push(item);
        }
      });
      renderSplitItemSourceList();
      renderManualSplits();
    });
  }

  const btnConfirmSplitBill = document.getElementById('btnConfirmSplitBill');
  if (btnConfirmSplitBill) {
    btnConfirmSplitBill.addEventListener('click', () => confirmAndSplitBill());
  }

  const closeSplitBill = () => { document.getElementById('modalSplitBill').style.display = 'none'; };
  const btnCancelSplitBill = document.getElementById('btnCancelSplitBill');
  if (btnCancelSplitBill) btnCancelSplitBill.addEventListener('click', closeSplitBill);
  const btnCloseSplitBillModal = document.getElementById('btnCloseSplitBillModal');
  if (btnCloseSplitBillModal) btnCloseSplitBillModal.addEventListener('click', closeSplitBill);

  document.getElementById('btnOptionsSearch').addEventListener('click', () => {
    loadOptionsOrders();
  });

  // Switch sidebar options
  function switchOptionsPane(paneId, tabBtn) {
    if (paneId !== 'paneOptSearchResults') {
      const searchInput = document.getElementById('optionsGlobalSearch');
      if (searchInput && searchInput.value) {
        searchInput.value = '';
        const clearBtn = document.getElementById('btnClearOptionsSearch');
        if (clearBtn) clearBtn.style.display = 'none';
        const searchPane = document.getElementById('paneOptSearchResults');
        if (searchPane) {
          searchPane.style.display = 'none';
          searchPane.classList.remove('active');
        }
      }
    }

    document.querySelectorAll('.options-sidebar .opt-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.options-content .opt-pane').forEach(p => p.classList.remove('active'));
    
    if (tabBtn) tabBtn.classList.add('active');
    const pane = document.getElementById(paneId);
    if (pane) {
      pane.classList.add('active');
      
      // Reset grid/detail view inside this pane
      const grid = pane.querySelector('.options-grid');
      const details = pane.querySelectorAll('.options-detail-pane');
      if (grid) grid.style.display = 'grid';
      details.forEach(d => d.style.display = 'none');
    }
    
    const backBtn = document.getElementById('btnOptionsModalBack');
    if (backBtn) backBtn.style.display = 'none';
  }
  window.switchOptionsPane = switchOptionsPane;

  // --- FAST FINDER / SEARCH IN OPTIONS MODAL ---
  let lastActiveOptionsPaneId = 'paneOptCashier';
  let lastActiveOptionsTabBtnId = 'btnOptCashier';

  function initOptionsGlobalSearch() {
    const searchInput = document.getElementById('optionsGlobalSearch');
    const clearBtn = document.getElementById('btnClearOptionsSearch');
    const searchPane = document.getElementById('paneOptSearchResults');
    const resultsContainer = document.getElementById('optionsSearchResultsList');
    const countLabel = document.getElementById('lblSearchResultsCount');
    if (!searchInput || !resultsContainer) return;

    const searchableItems = [
      // MANAGER PANEL
      {
        id: 'opt_manager_table_layout',
        badge: 'Manager Panel ➔ Option D',
        badgeClass: 'badge-manager',
        title: '1. Restaurant & Bar: Tables & Croquis (Mesas 1-100)',
        desc: 'Design floor plan layout & print individual acrylic QR cards / tent cards for dining tables (Mesa 1 to 100)',
        path: '🔑 Manager Panel ➔ Letter D',
        keywords: 'table tables layout qr codes mesas mesa croquis mapa floor plan acrylic tent cards acrilicos imprimir print stand dining patio bar restaurante codigo salon 100',
        requiresAuth: 'manager',
        action: () => openTableLayoutEditorModal('floorplan'),
        quickBtnText: 'Table Cards (PDF)',
        quickBtnAction: () => openTableLayoutEditorModal('qrcards')
      },
      {
        id: 'opt_manager_taco_truck_qr',
        badge: 'Taco Truck ➔ Single QR Order',
        badgeClass: 'badge-manager',
        title: '2. Taco Truck & Drive-Up: Single QR Order',
        desc: '1 Single QR code for Food Trucks & Drive-Up with 100% free vehicle/customer description (Jeep verde, etc.)',
        path: 'Manager Panel ➔ Taco Truck QR or Setup',
        keywords: 'taco truck food truck car carside drive thru drive up vehiculo auto carro jeep camioneta moto bicicleta señor bicicleta qr lonchera puesto ambulante window cartel ventanilla poster',
        requiresAuth: null,
        action: () => openTacoTruckQRModal(),
        quickBtnText: 'Print Window Poster',
        quickBtnAction: () => openTacoTruckQRModal('window8x11')
      },
      {
        id: 'opt_table_qr_cards_direct',
        badge: 'Setup & Manager ➔ QR Cards',
        badgeClass: 'badge-manager',
        title: 'Print Table QR Codes (Acrylic & Tent Cards)',
        desc: 'Generate high-res printable table QR codes (English, Spanish, Bilingual) for acrylic table stands',
        path: 'Manager Panel ➔ Letter D (QR Inserts Tab) or Setup',
        keywords: 'qr mesas table qr pdf print imprimir acrilicos tent cards stands tarjetas mesa codigo menu digital acrylic',
        requiresAuth: null,
        action: () => openTableLayoutEditorModal('qrcards'),
        quickBtnText: 'Print PDF',
        quickBtnAction: () => openTableLayoutEditorModal('qrcards')
      },
      {
        id: 'opt_manager_reports',
        badge: 'Manager Panel ➔ Option A',
        badgeClass: 'badge-manager',
        title: 'Shift & Drawer Reports (Corte de Caja)',
        desc: 'Shift analytics summary, register activity, drawer cash counts, and close shift reports',
        path: '🔑 Manager Panel ➔ Letter A',
        keywords: 'shift drawer reports corte caja turno ventas z report analytics cierre cash balance dinero reportes resumen z-report',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailManagerReports');
        }
      },
      {
        id: 'opt_manager_inventory',
        badge: 'Manager Panel ➔ Option B',
        badgeClass: 'badge-manager',
        title: 'Product Inventory & Pricing',
        desc: 'Add/edit products, stock counts, search inventory, barcode scan, and import/export CSV',
        path: '🔑 Manager Panel ➔ Letter B',
        keywords: 'inventory product stock catalogo productos precios edit csv import export barcode inventario articulos existencias',
        requiresAuth: 'manager',
        action: () => openManagerInventoryGrid()
      },
      {
        id: 'opt_manager_change_pin',
        badge: 'Manager Panel ➔ Change PIN',
        badgeClass: 'badge-manager',
        title: 'Change Manager / Owner PIN',
        desc: 'Update your secret security PIN for manager and owner authorizations',
        path: '🔑 Manager Panel ➔ Cambiar PIN (🔑)',
        keywords: 'pin password clave codigo gerente manager security dueño admin cambiar pin security code',
        requiresAuth: 'manager',
        action: () => openChangeManagerPinModal()
      },
      {
        id: 'opt_manager_employees',
        badge: 'Manager Panel ➔ Option C',
        badgeClass: 'badge-manager',
        title: 'Employee Management & Roles',
        desc: 'Register and manage staff access profiles, roles (Cashier, Manager, Waiter), and cards',
        path: '🔑 Manager Panel ➔ Letter C',
        keywords: 'employee employees staff personal meseros cajeros roles permissions tarjetas cards usuarios turnos',
        requiresAuth: 'manager',
        action: () => showManagerEmployeesGrid()
      },
      {
        id: 'opt_manager_link_devices',
        badge: 'Manager Panel ➔ Link Devices',
        badgeClass: 'badge-manager',
        title: 'Link Mobile Devices (QR Pairing)',
        desc: 'Pair handheld Sunmi terminals, waiter phones, kitchen KDS, bar display, and mobile reports via QR',
        path: '🔑 Manager Panel ➔ Vincular Dispositivos (📱)',
        keywords: 'link devices vincular dispositivos qr meseros kds sunmi mobile celular tablet bar handheld pair emparejar terminales',
        requiresAuth: 'manager',
        action: () => openLinkDevicesModal()
      },
      {
        id: 'opt_manager_alcohol',
        badge: 'Manager Panel ➔ Option E',
        badgeClass: 'badge-manager',
        title: 'Alcohol & Bottle Control (Licor & Onzas)',
        desc: 'Bottle weights, shot sizes, tare offsets, Bluetooth scale integration, and bartender shifts',
        path: '🔑 Manager Panel ➔ Letter E',
        keywords: 'alcohol licor onzas bottles botellas bar bartender shots tragos bascula scale bluetooth inventario barra botellas pesaje',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailManagerAlcohol');
        }
      },
      {
        id: 'opt_manager_tips',
        badge: 'Manager Panel ➔ Option F',
        badgeClass: 'badge-manager',
        title: 'Tips Management & Payouts',
        desc: 'Configure tip payout modes (daily cash vs weekly payroll) and view employee tip reports',
        path: '🔑 Manager Panel ➔ Letter F',
        keywords: 'tips propinas payouts payroll meseros repartidores balance reporte distribucion propina propinas balance',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailManagerTips');
          if (typeof loadTipsReport === 'function') loadTipsReport();
        }
      },
      {
        id: 'opt_manager_email_reports',
        badge: 'Manager Panel ➔ Option G',
        badgeClass: 'badge-manager',
        title: 'Automated Email Reports',
        desc: 'Configure owner email address and automatic end-of-day / shift sales report frequencies',
        path: '🔑 Manager Panel ➔ Letter G',
        keywords: 'email reports correo cierre automático smtp daily report resumen ventas noche email balance',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailSetupEmailReports');
        }
      },
      {
        id: 'opt_manager_backups',
        badge: 'Manager Panel ➔ Option H',
        badgeClass: 'badge-manager',
        title: 'System Backups (USB & Cloud)',
        desc: 'Configure auto-backups to USB drive, OneDrive, or Google Drive for database safety',
        path: '🔑 Manager Panel ➔ Letter H',
        keywords: 'backup backups respaldo usb onedrive google drive restore copia seguridad database restaurar',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailSetupBackups');
        }
      },
      {
        id: 'opt_manager_stock',
        badge: 'Manager Panel ➔ Option I',
        badgeClass: 'badge-manager',
        title: 'Stock Control & Intake (Cajas / Pallets)',
        desc: 'Log received inventory shipments, supplier invoices, minimum threshold alerts, and waste',
        path: '🔑 Manager Panel ➔ Letter I',
        keywords: 'stock control intake cajas pallets reabastecer entradas proveedor compras merma inventario minimo existencias',
        requiresAuth: 'manager',
        action: () => {
          switchOptionsPane('paneOptManager', document.getElementById('btnOptManager'));
          showOptionsDetail('detailManagerStock');
          if (typeof initManagerStockView === 'function') initManagerStockView();
        }
      },

      // CASHIER OPTIONS
      {
        id: 'opt_cashier_control',
        badge: 'Cashier ➔ Option A',
        badgeClass: 'badge-cashier',
        title: 'Cashier Control & Active Shift',
        desc: 'Switch active cashier, close current register shift, and toggle Online / Offline connection mode',
        path: '💵 Cashier ➔ Letter A',
        keywords: 'cashier control cajero cambio turno close shift online offline vercel cloud wifi connection cambiar cajero cerrar turno',
        requiresAuth: null,
        action: () => {
          switchOptionsPane('paneOptCashier', document.getElementById('btnOptCashier'));
          showOptionsDetail('detailCashierControl');
        }
      },
      {
        id: 'opt_cashier_drawer',
        badge: 'Cashier ➔ Option B',
        badgeClass: 'badge-cashier',
        title: 'Open Cash Drawer',
        desc: 'Trigger printer kick-pulse to open the register cash drawer manually',
        path: '💵 Cashier ➔ Letter B',
        keywords: 'open cash drawer abrir cajon dinero efectivo kick drawer printer registrar billetes',
        requiresAuth: null,
        action: () => document.getElementById('btnOpenDrawer')?.click()
      },
      {
        id: 'opt_cashier_open_tab',
        badge: 'Cashier ➔ Option C',
        badgeClass: 'badge-cashier',
        title: 'Open Tab (Table or Customer Account)',
        desc: 'Start a new table or customer tab account for dine-in or bar orders',
        path: '💵 Cashier ➔ Letter C',
        keywords: 'open tab abrir cuenta mesa cliente new account orden bar restaurante tab mesas bar cuenta',
        requiresAuth: null,
        action: () => document.getElementById('btnOpenTab')?.click()
      },
      {
        id: 'opt_cashier_recall_tabs',
        badge: 'Cashier ➔ Option D',
        badgeClass: 'badge-cashier',
        title: 'Active Tabs & Table Accounts',
        desc: 'View and recall open table accounts, add items, split checks, or collect payment',
        path: '💵 Cashier ➔ Letter D',
        keywords: 'active tabs cuentas abiertas mesas recall ver cobrar cuentas tab accounts pagar split dividir',
        requiresAuth: null,
        action: () => document.getElementById('btnRecallTabs')?.click()
      },
      {
        id: 'opt_cashier_receivables',
        badge: 'Cashier ➔ Option E',
        badgeClass: 'badge-cashier',
        title: 'Receivables & House Accounts',
        desc: 'Manage unpaid tabs, pending receipts, customer credit balances, and collections',
        path: '💵 Cashier ➔ Letter E',
        keywords: 'receivables cuentas por cobrar fiado credit pending receipts tickets deuda credito clientes saldo',
        requiresAuth: null,
        action: () => openReceivablesModal()
      },

      // SETUP
      {
        id: 'opt_setup_hardware',
        badge: 'Setup ➔ Option A',
        badgeClass: 'badge-setup',
        title: 'Hardware & Devices (Printers, Drawers, Terminals)',
        desc: 'Configure receipt & kitchen thermal printers, cash drawer ports, card reader terminals, and barcode scanners',
        path: '⚙️ Setup ➔ Letter A',
        keywords: 'hardware devices printers impresoras thermal receipt ticket kitchen cocina scanner drawer lector tarjeta terminal comanda red usb serial baud',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupHardware');
        }
      },
      {
        id: 'opt_setup_kitchen_font',
        badge: 'Setup ➔ Option A (Hardware)',
        badgeClass: 'badge-setup',
        title: 'Kitchen Ticket Font Size & Printer Setup',
        desc: 'Configure thermal kitchen printer ticket font sizes (Options 1 to 5), ESC/POS format, and test prints',
        path: '⚙️ Setup ➔ Letter A ➔ Printers Subtab',
        keywords: 'kitchen ticket font size tamaño letra cocina comanda impresoras ticket de cocina test print opciones 1 2 3 4 5 thermal receipt paper cutter fuente grande negrita',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupHardware');
          document.getElementById('btnSubTabPrinters')?.click();
        },
        quickBtnText: '📐 Kitchen Font',
        quickBtnAction: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupHardware');
          document.getElementById('btnSubTabPrinters')?.click();
          setTimeout(() => {
            const fontSel = document.getElementById('adminKitchenTicketFontSize');
            if (fontSel) {
              fontSel.focus();
              fontSel.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
          }, 150);
        }
      },
      {
        id: 'opt_setup_stations_map',
        badge: 'Setup ➔ Option A (Hardware)',
        badgeClass: 'badge-setup',
        title: 'Stations & Network Topology Map (Croquis de Red)',
        desc: 'Interactive visual network map of POS cashiers, Sunmi handhelds, KDS, and multi-station licensing',
        path: '⚙️ Setup ➔ Letter A ➔ Stations & Network Map Subtab',
        keywords: 'croquis red topology network estaciones stations sunmi map croquis visual licencias billing topology estaciones conectadas',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupHardware');
          document.getElementById('btnSubTabNetworkMap')?.click();
        }
      },
      {
        id: 'opt_setup_customer_screen',
        badge: 'Setup ➔ Option B',
        badgeClass: 'badge-setup',
        title: 'Customer Screen & QR (Lobby TV / Wi-Fi)',
        desc: 'Customer facing screen URL, lobby TV order pickup board, Wi-Fi guest QR code generator',
        path: '⚙️ Setup ➔ Letter B',
        keywords: 'customer screen qr lobby tv wifi pantalla cliente codigo qr publicidad ads wifi credentials television pantalla',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupCustomer');
        }
      },
      {
        id: 'opt_setup_business',
        badge: 'Setup ➔ Option C',
        badgeClass: 'badge-setup',
        title: 'Business Profile, Tax Rates & Services',
        desc: 'Restaurant name, logo, phone, address, sales tax percentages, welcome reward points, and order types',
        path: '⚙️ Setup ➔ Letter C',
        keywords: 'business profile tax impuestos taxes nombre negocio logo phone address direccion delivery to go dine in car order rfc iva porcentaje',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupBusiness');
        }
      },
      {
        id: 'opt_setup_language',
        badge: 'Setup ➔ Option D',
        badgeClass: 'badge-setup',
        title: 'Language Profiles (Register, Kitchen Tickets, KDS)',
        desc: 'Configure default language (English / Spanish) for POS register, kitchen tickets, customer receipts, and KDS',
        path: '⚙️ Setup ➔ Letter D',
        keywords: 'language profiles idiomas ingles espanol english spanish kitchen ticket lang ticket lenguaje default idioma comanda traduccion',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupLanguage');
        }
      },
      {
        id: 'opt_setup_departments',
        badge: 'Setup ➔ Option E',
        badgeClass: 'badge-setup',
        title: 'POS Departments & Menu Tabs',
        desc: 'Create, rename, or reorder product category tabs on the main register screen',
        path: '⚙️ Setup ➔ Letter E',
        keywords: 'departments tabs departamentos categorias carpetas botones menu reorder pestanas secciones agregar departamento',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupDepartments');
        }
      },
      {
        id: 'opt_setup_database',
        badge: 'Setup ➔ Option F',
        badgeClass: 'badge-setup',
        title: 'Database Bulk Import & Export',
        desc: 'Bulk import/export products and menu categories using Excel (.xlsx) or CSV files',
        path: '⚙️ Setup ➔ Letter F',
        keywords: 'database import export bulk excel csv backup restore base de datos cargar exportar productos catalogo',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupDatabase');
        }
      },
      {
        id: 'opt_setup_licensing',
        badge: 'Setup ➔ Option G',
        badgeClass: 'badge-setup',
        title: 'Registration & Licensing Status',
        desc: 'Machine license token, plan validation (Standard, Food Truck, Bar Hub, Enterprise), and server sync',
        path: '⚙️ Setup ➔ Letter G',
        keywords: 'licensing registration licencia registro license key token render machine stations plan status activar renovar',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupLicensing');
        }
      },
      {
        id: 'opt_setup_menu_customizer',
        badge: 'Setup ➔ Option H',
        badgeClass: 'badge-setup',
        title: 'Menu Button Customizer (Visual Grid)',
        desc: 'Visual drag-and-drop editor to change item colors, font size, button order, and pictures',
        path: '⚙️ Setup ➔ Letter H',
        keywords: 'menu button customizer personalizar botones colores fotos reorder layout tamano orden productos visual cambiar diseno',
        requiresAuth: 'admin',
        action: () => document.getElementById('btnOpenMenuCustomizer')?.click()
      },
      {
        id: 'opt_setup_admin_only',
        badge: 'Setup ➔ Option J',
        badgeClass: 'badge-setup',
        title: 'Admin Settings & System Resets',
        desc: 'Advanced system maintenance, factory reset, employee passwords, and audit logs',
        path: '⚙️ Setup ➔ Letter J',
        keywords: 'admin settings reset borrar reiniciar factory reset system actions mantenimiento restaurar fabrica',
        requiresAuth: 'admin',
        action: () => showSetupAdminOnly()
      },
      {
        id: 'opt_setup_updates',
        badge: 'Setup ➔ Option U',
        badgeClass: 'badge-setup',
        title: 'System Updates (Check & Install)',
        desc: 'Check for latest Impossible POS version patches, download updates, and view changelogs',
        path: '⚙️ Setup ➔ Letter U',
        keywords: 'updates actualizacion version patch download upgrade update software parches buscar actualizaciones descargar',
        requiresAuth: 'admin',
        action: () => {
          switchOptionsPane('paneOptAdmin', document.getElementById('btnOptAdmin'));
          showOptionsDetail('detailSetupUpdates');
        }
      }
    ];

    function triggerOptionAction(item, isQuick = false) {
      const act = (isQuick && item.quickBtnAction) ? item.quickBtnAction : item.action;
      
      if (item.requiresAuth === 'manager' && !sessionManagerAuthorized && !sessionAdminAuthorized) {
        authSuccessCallback = (emp) => {
          const role = typeof emp === 'string' ? 'manager' : emp.role;
          if (role === 'manager' || role === 'admin') {
            if (role === 'admin') sessionAdminAuthorized = true;
            sessionManagerAuthorized = true;
            act();
          } else {
            showToast('Authorized: Managers or Admins only', 'error');
          }
        };
        openAuthModal();
        return;
      }
      
      if (item.requiresAuth === 'admin' && !sessionAdminAuthorized && !sessionManagerAuthorized) {
        authSuccessCallback = (emp) => {
          const role = typeof emp === 'string' ? 'manager' : emp.role;
          if (role === 'admin' || role === 'manager') {
            if (role === 'admin') sessionAdminAuthorized = true;
            sessionManagerAuthorized = true;
            act();
          } else {
            showToast('Authorized: Managers or Admins only', 'error');
          }
        };
        showAuthModal('Setup Settings Authorization', 'Biometric Scan Manager or Admin Fingerprint...');
        return;
      }

      act();
    }

    function doSearch() {
      const query = searchInput.value.trim().toLowerCase();
      if (!query) {
        clearOptionsGlobalSearch();
        return;
      }

      if (clearBtn) clearBtn.style.display = 'block';

      // Track previously active pane before search started
      const curActivePane = document.querySelector('.options-content .opt-pane.active');
      if (curActivePane && curActivePane.id !== 'paneOptSearchResults') {
        lastActiveOptionsPaneId = curActivePane.id;
        const curTab = document.querySelector('.options-sidebar .opt-tab-btn.active');
        if (curTab) lastActiveOptionsTabBtnId = curTab.id;
      }

      // Unselect sidebar tab highlights while searching
      document.querySelectorAll('.options-sidebar .opt-tab-btn').forEach(b => b.classList.remove('active'));

      // Hide other panes, show search pane
      document.querySelectorAll('.options-content .opt-pane').forEach(p => p.classList.remove('active'));
      searchPane.classList.add('active');
      searchPane.style.display = 'block';

      // Match query tokens against keywords, title, desc, path, badge
      const queryTokens = query.split(/\s+/).filter(t => t.length > 0);
      const matches = searchableItems.filter(item => {
        const targetStr = `${item.title} ${item.desc} ${item.path} ${item.keywords} ${item.badge}`.toLowerCase();
        return queryTokens.every(token => targetStr.includes(token));
      });

      if (countLabel) {
        countLabel.innerText = `(${matches.length} ${matches.length === 1 ? 'match' : 'matches'})`;
      }

      if (matches.length === 0) {
        resultsContainer.innerHTML = `
          <div style="text-align: center; padding: 40px 20px; background: rgba(255,255,255,0.02); border-radius: 8px; border: 1px dashed var(--border-color);">
            <div style="font-size: 32px; margin-bottom: 8px;">🔍</div>
            <div style="font-size: 15px; font-weight: bold; color: #fff; margin-bottom: 6px;">No settings matched "${query}"</div>
            <div style="font-size: 12px; color: var(--text-secondary); max-width: 360px; margin: 0 auto;">
              Try searching for <strong>QR</strong>, <strong>mesas</strong>, <strong>kitchen</strong>, <strong>ticket</strong>, <strong>reports</strong>, <strong>printers</strong>, or <strong>pin</strong>.
            </div>
          </div>
        `;
        return;
      }

      resultsContainer.innerHTML = matches.map((item, idx) => {
        let badgeStyle = 'background: rgba(48, 209, 88, 0.15); color: #30d158; border: 1px solid rgba(48, 209, 88, 0.4);';
        if (item.badgeClass === 'badge-manager') {
          badgeStyle = 'background: rgba(255, 159, 10, 0.15); color: #ff9f0a; border: 1px solid rgba(255, 159, 10, 0.4);';
        } else if (item.badgeClass === 'badge-setup') {
          badgeStyle = 'background: rgba(10, 132, 255, 0.15); color: #64d2ff; border: 1px solid rgba(10, 132, 255, 0.4);';
        }

        return `
          <div class="search-result-card" data-idx="${idx}" style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-color); border-radius: 8px; padding: 12px 14px; display: flex; align-items: center; justify-content: space-between; gap: 12px; cursor: pointer; transition: all 0.2s ease;">
            <div style="flex: 1; min-width: 0;">
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 4px;">
                <span style="font-size: 10px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; padding: 2px 8px; border-radius: 4px; ${badgeStyle}">
                  ${item.badge}
                </span>
                <span style="font-size: 11px; color: var(--text-secondary);">
                  📍 ${item.path}
                </span>
              </div>
              <div style="font-size: 14px; font-weight: bold; color: #fff; margin-bottom: 2px;">
                ${item.title}
              </div>
              <div style="font-size: 12px; color: var(--text-secondary); line-height: 1.3;">
                ${item.desc}
              </div>
            </div>
            <div style="display: flex; align-items: center; gap: 6px; flex-shrink: 0;">
              ${item.quickBtnText ? `
                <button type="button" class="btn-quick-action" data-idx="${idx}" style="background: rgba(0,122,255,0.2); color: #64d2ff; border: 1px solid rgba(0,122,255,0.4); padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: bold; cursor: pointer; white-space: nowrap;">
                  ${item.quickBtnText}
                </button>
              ` : ''}
              <button type="button" class="btn-main-action" data-idx="${idx}" style="background: var(--accent-color); color: #000; border: none; padding: 6px 14px; border-radius: 6px; font-size: 11px; font-weight: bold; cursor: pointer; white-space: nowrap;">
                Open ➔
              </button>
            </div>
          </div>
        `;
      }).join('');

      // Attach click events
      resultsContainer.querySelectorAll('.search-result-card').forEach(card => {
        const idx = parseInt(card.getAttribute('data-idx'), 10);
        const item = matches[idx];
        card.addEventListener('click', (e) => {
          if (e.target.closest('.btn-quick-action')) {
            triggerOptionAction(item, true);
          } else {
            triggerOptionAction(item, false);
          }
        });
        card.addEventListener('mouseenter', () => {
          card.style.background = 'rgba(255,255,255,0.07)';
          card.style.borderColor = 'rgba(255,255,255,0.3)';
        });
        card.addEventListener('mouseleave', () => {
          card.style.background = 'rgba(255,255,255,0.03)';
          card.style.borderColor = 'var(--border-color)';
        });
      });
    }

    searchInput.addEventListener('input', doSearch);
    searchInput.addEventListener('focus', () => {
      if (searchInput.value.trim().length > 0) {
        doSearch();
      }
    });

    window.clearOptionsGlobalSearch = function() {
      searchInput.value = '';
      if (clearBtn) clearBtn.style.display = 'none';
      if (searchPane) {
        searchPane.style.display = 'none';
        searchPane.classList.remove('active');
      }
      const prevTabBtn = document.getElementById(lastActiveOptionsTabBtnId) || document.getElementById('btnOptCashier');
      switchOptionsPane(lastActiveOptionsPaneId || 'paneOptCashier', prevTabBtn);
    };
  }
  window.initOptionsGlobalSearch = initOptionsGlobalSearch;

  // Navigation helpers for Grid-based settings
  window.showOptionsDetail = function(detailId) {
    if (detailId === 'detailManagerAlcohol') {
      const isEs = posSettings && posSettings.language === 'es';
      const barStatus = window.lastLicenseData ? window.lastLicenseData.barStatus : 'unregistered';
      if (barStatus !== 'active' && barStatus !== 'demo') {
        showToast(isEs 
          ? "⚠️ Licencia Premium de Bar Hub requerida. Regístrela en Configuración." 
          : "⚠️ Premium Bar Hub License required. Register it in Setup settings.", 
          "warning"
        );
        // Return to options grid
        goBackToOptionsGrid('gridOptManager');
        return;
      }
    }

    // Hide all grids inside options content
    document.querySelectorAll('.options-content .options-grid').forEach(g => g.style.display = 'none');
    // Hide all detail panes
    document.querySelectorAll('.options-content .options-detail-pane').forEach(d => d.style.display = 'none');
    // Show target detail
    const target = document.getElementById(detailId);
    if (target) {
      target.style.display = 'flex';
      if (detailId === 'detailManagerAlcohol') {
        switchAlcoholSubTab('catalog');
      }
      if (detailId === 'detailSetupHardware') {
        if (typeof populatePrintersDropdowns === 'function') {
          populatePrintersDropdowns();
        }
      }
    }
    
    const backBtn = document.getElementById('btnOptionsModalBack');
    if (backBtn) backBtn.style.display = 'inline-block';
  };

  window.goBackToOptionsGrid = function(gridId) {
    // Hide all detail panes
    document.querySelectorAll('.options-content .options-detail-pane').forEach(d => d.style.display = 'none');
    // Show target grid
    const target = document.getElementById(gridId);
    if (target) {
      target.style.display = 'grid';
    }
    
    const backBtn = document.getElementById('btnOptionsModalBack');
    if (backBtn) backBtn.style.display = 'none';
  };

  window.goBackFromCurrentDetailView = function() {
    const activeDetail = Array.from(document.querySelectorAll('.options-content .options-detail-pane')).find(d => d.style.display === 'flex' || d.style.display === 'block');
    if (activeDetail) {
      const parentPane = activeDetail.closest('.opt-pane');
      if (parentPane) {
        if (parentPane.id === 'paneOptAdmin') {
          goBackToOptionsGrid('gridOptAdmin');
        } else if (parentPane.id === 'paneOptManager') {
          goBackToOptionsGrid('gridOptManager');
        }
      }
    }
  };

  window.switchSetupBusinessSubTab = function(tabName) {
    const tabA = document.getElementById('btnSubTabBusinessA');
    const tabB = document.getElementById('btnSubTabBusinessB');
    const tabC = document.getElementById('btnSubTabBusinessC');
    const tabD = document.getElementById('btnSubTabBusinessD');
    const contentA = document.getElementById('subTabBusinessContentA');
    const contentB = document.getElementById('subTabBusinessContentB');
    const contentC = document.getElementById('subTabBusinessContentC');
    const contentD = document.getElementById('subTabBusinessContentD');

    if (tabA) tabA.classList.toggle('selected', tabName === 'A');
    if (tabB) tabB.classList.toggle('selected', tabName === 'B');
    if (tabC) tabC.classList.toggle('selected', tabName === 'C');
    if (tabD) tabD.classList.toggle('selected', tabName === 'D');

    if (contentA) contentA.style.display = tabName === 'A' ? 'flex' : 'none';
    if (contentB) contentB.style.display = tabName === 'B' ? 'flex' : 'none';
    if (contentC) contentC.style.display = tabName === 'C' ? 'flex' : 'none';
    if (contentD) contentD.style.display = tabName === 'D' ? 'flex' : 'none';
  };

  window.switchSetupHardwareSubTab = function(subTab) {
    const tabPrinters = document.getElementById('btnSubTabPrinters');
    const tabSMS = document.getElementById('btnSubTabSMS');
    const tabDevices = document.getElementById('btnSubTabDevices');
    const tabNetwork = document.getElementById('btnSubTabNetworkMap');
    const contentPrinters = document.getElementById('subTabContentPrinters');
    const contentSMS = document.getElementById('subTabContentSMS');
    const contentDevices = document.getElementById('subTabContentDevices');
    const contentNetwork = document.getElementById('subTabContentNetworkMap');

    if (subTab === 'printers') {
      if (tabPrinters) tabPrinters.classList.add('selected');
      if (tabSMS) tabSMS.classList.remove('selected');
      if (tabDevices) tabDevices.classList.remove('selected');
      if (tabNetwork) tabNetwork.classList.remove('selected');
      if (contentPrinters) contentPrinters.style.display = 'flex';
      if (contentSMS) contentSMS.style.display = 'none';
      if (contentDevices) contentDevices.style.display = 'none';
      if (contentNetwork) contentNetwork.style.display = 'none';
    } else if (subTab === 'sms') {
      if (tabPrinters) tabPrinters.classList.remove('selected');
      if (tabSMS) tabSMS.classList.add('selected');
      if (tabDevices) tabDevices.classList.remove('selected');
      if (tabNetwork) tabNetwork.classList.remove('selected');
      if (contentPrinters) contentPrinters.style.display = 'none';
      if (contentSMS) contentSMS.style.display = 'flex';
      if (contentDevices) contentDevices.style.display = 'none';
      if (contentNetwork) contentNetwork.style.display = 'none';
    } else if (subTab === 'devices') {
      if (tabPrinters) tabPrinters.classList.remove('selected');
      if (tabSMS) tabSMS.classList.remove('selected');
      if (tabDevices) tabDevices.classList.add('selected');
      if (tabNetwork) tabNetwork.classList.remove('selected');
      if (contentPrinters) contentPrinters.style.display = 'none';
      if (contentSMS) contentSMS.style.display = 'none';
      if (contentDevices) contentDevices.style.display = 'flex';
      if (contentNetwork) contentNetwork.style.display = 'none';
    } else if (subTab === 'network') {
      if (tabPrinters) tabPrinters.classList.remove('selected');
      if (tabSMS) tabSMS.classList.remove('selected');
      if (tabDevices) tabDevices.classList.remove('selected');
      if (tabNetwork) tabNetwork.classList.add('selected');
      if (contentPrinters) contentPrinters.style.display = 'none';
      if (contentSMS) contentSMS.style.display = 'none';
      if (contentDevices) contentDevices.style.display = 'none';
      if (contentNetwork) contentNetwork.style.display = 'flex';
      if (typeof loadNetworkTopology === 'function') {
        loadNetworkTopology();
      }
    }
  };


  window.switchPrinterChannel = function(channel) {
    const channels = ['KitchenMain', 'RunnerMain', 'BarMain', 'PhotoMain', 'CajaMain', 'OfficeMain'];
    channels.forEach(ch => {
      const btn = document.getElementById(`tabChannel${ch}`);
      const content = document.getElementById(`contentChannel${ch}`);
      if (ch === channel) {
        if (btn) btn.classList.add('selected');
        if (content) content.style.display = 'flex';
      } else {
        if (btn) btn.classList.remove('selected');
        if (content) content.style.display = 'none';
      }
    });
  };

  window.switchKitchenSubTab = function(subTab) {
    const btnKDS = document.getElementById('tabSubKitchenKDS');
    const btnPrinter = document.getElementById('tabSubKitchenPrinter');
    const contentKDS = document.getElementById('contentKitchenSubKDS');
    const contentPrinter = document.getElementById('contentKitchenSubPrinter');
    if (subTab === 'KDS') {
      if (btnKDS) btnKDS.classList.add('selected');
      if (btnPrinter) btnPrinter.classList.remove('selected');
      if (contentKDS) contentKDS.style.display = 'flex';
      if (contentPrinter) contentPrinter.style.display = 'none';
    } else {
      if (btnKDS) btnKDS.classList.remove('selected');
      if (btnPrinter) btnPrinter.classList.add('selected');
      if (contentKDS) contentKDS.style.display = 'none';
      if (contentPrinter) contentPrinter.style.display = 'flex';
    }
  };

  window.switchBarSubTab = function(subTab) {
    const btnKDS = document.getElementById('tabSubBarKDS');
    const btnPrinter = document.getElementById('tabSubBarPrinter');
    const contentKDS = document.getElementById('contentBarSubKDS');
    const contentPrinter = document.getElementById('contentBarSubPrinter');
    if (subTab === 'KDS') {
      if (btnKDS) btnKDS.classList.add('selected');
      if (btnPrinter) btnPrinter.classList.remove('selected');
      if (contentKDS) contentKDS.style.display = 'flex';
      if (contentPrinter) contentPrinter.style.display = 'none';
    } else {
      if (btnKDS) btnKDS.classList.remove('selected');
      if (btnPrinter) btnPrinter.classList.add('selected');
      if (contentKDS) contentKDS.style.display = 'none';
      if (contentPrinter) contentPrinter.style.display = 'flex';
    }
  };

  window.switchRunnerSubTab = function(subTab) {
    const btnKDS = document.getElementById('tabSubRunnerKDS');
    const btnPrinter = document.getElementById('tabSubRunnerPrinter');
    const contentKDS = document.getElementById('contentRunnerSubKDS');
    const contentPrinter = document.getElementById('contentRunnerSubPrinter');
    if (subTab === 'KDS') {
      if (btnKDS) btnKDS.classList.add('selected');
      if (btnPrinter) btnPrinter.classList.remove('selected');
      if (contentKDS) contentKDS.style.display = 'flex';
      if (contentPrinter) contentPrinter.style.display = 'none';
    } else {
      if (btnKDS) btnKDS.classList.remove('selected');
      if (btnPrinter) btnPrinter.classList.add('selected');
      if (contentKDS) contentKDS.style.display = 'none';
      if (contentPrinter) contentPrinter.style.display = 'flex';
    }
  };

  window.switchSetupDeptsSubTab = function(subTab) {
    const tabDepts = document.getElementById('btnSubTabDepts');
    const tabServices = document.getElementById('btnSubTabServices');
    const contentDepts = document.getElementById('subTabContentDepts');
    const contentServices = document.getElementById('subTabContentServices');

    if (subTab === 'depts') {
      if (tabDepts) tabDepts.classList.add('selected');
      if (tabServices) tabServices.classList.remove('selected');
      if (contentDepts) contentDepts.style.display = 'flex';
      if (contentServices) contentServices.style.display = 'none';
    } else {
      if (tabDepts) tabDepts.classList.remove('selected');
      if (tabServices) tabServices.classList.add('selected');
      if (contentDepts) contentDepts.style.display = 'none';
      if (contentServices) contentServices.style.display = 'flex';
    }
  };

  window.showSetupEmployeesGrid = function() {
    showOptionsDetail('detailSetupEmployees');
    loadEmployeesList();
  };

  window.showSetupAdminOnly = function() {
    if (sessionAdminAuthorized) {
      showOptionsDetail('detailSetupAdminOnly');
      return;
    }
    authSuccessCallback = (emp) => {
      const role = typeof emp === 'string' ? 'admin' : emp.role;
      if (role === 'admin') {
        sessionAdminAuthorized = true;
        sessionManagerAuthorized = true;
        showOptionsDetail('detailSetupAdminOnly');
      } else {
        showToast('Only Admin can access Admin settings', 'error');
      }
    };
    showAuthModal('Admin Authorization Required', 'Biometric Scan Admin Fingerprint or enter PIN...');
  };

  window.showManagerEmployeesGrid = function() {
    showOptionsDetail('detailManagerEmployees');
    loadEmployeesList();
  };

  window.openManagerInventoryGrid = function() {
    // Programmatically click the hidden btnOptInventory tab!
    const btn = document.getElementById('btnOptInventory');
    if (btn) {
      btn.click();
    }
  };

  window.goBackToManagerFromInventory = function() {
    const managerTabBtn = document.getElementById('btnOptManager');
    if (managerTabBtn) {
      managerTabBtn.click();
    }
  };

  // Bind Sidebar Tab Buttons
  document.getElementById('btnOptCashier').addEventListener('click', (e) => {
    switchOptionsPane('paneOptCashier', e.target);
    updateOptCashierDetails();
  });

  document.getElementById('btnOptTickets').addEventListener('click', (e) => {
    switchOptionsPane('paneOptTickets', e.target);
    loadOptionsOrders();
  });

  document.getElementById('btnOptManager').addEventListener('click', (e) => {
    if (sessionManagerAuthorized) {
      switchOptionsPane('paneOptManager', e.target);
      loadDetailedReports();
      loadEmployeesList();
      return;
    }
    authSuccessCallback = (emp) => {
      const role = typeof emp === 'string' ? 'manager' : emp.role;
      if (role === 'manager' || role === 'admin') {
        if (role === 'admin') {
          sessionAdminAuthorized = true;
        }
        sessionManagerAuthorized = true;
        switchOptionsPane('paneOptManager', e.target);
        loadDetailedReports();
        loadEmployeesList();
      } else {
        showToast('Authorized: Managers or Admins only', 'error');
      }
    };
    openAuthModal();
  });

  document.getElementById('btnOptAdmin').addEventListener('click', (e) => {
    if (sessionAdminAuthorized || sessionManagerAuthorized) {
      switchOptionsPane('paneOptAdmin', e.target);
      loadEmployeesList();
      return;
    }
    authSuccessCallback = (emp) => {
      const role = typeof emp === 'string' ? 'manager' : emp.role;
      if (role === 'admin' || role === 'manager') {
        if (role === 'admin') {
          sessionAdminAuthorized = true;
        }
        sessionManagerAuthorized = true;
        switchOptionsPane('paneOptAdmin', e.target);
        loadEmployeesList();
      } else {
        showToast('Authorized: Managers or Admins only', 'error');
      }
    };
    
    showAuthModal('Setup Settings Authorization', 'Biometric Scan Manager or Admin Fingerprint...');
  });

  document.getElementById('btnOptInventory').addEventListener('click', (e) => {
    if (sessionManagerAuthorized) {
      switchOptionsPane('paneOptInventory', e.target);
      loadInventoryProducts();
      
      const csvImportBtn = document.getElementById('btnImportCSV');
      const csvExportBtn = document.getElementById('btnExportCSV');
      if (sessionAdminAuthorized) {
        csvImportBtn.style.display = 'inline-block';
        csvExportBtn.style.display = 'inline-block';
      } else {
        csvImportBtn.style.display = 'none';
        csvExportBtn.style.display = 'none';
      }
      return;
    }
    authSuccessCallback = (emp) => {
      const role = typeof emp === 'string' ? 'manager' : emp.role;
      if (role === 'manager' || role === 'admin') {
        if (role === 'admin') {
          sessionAdminAuthorized = true;
        }
        sessionManagerAuthorized = true;
        switchOptionsPane('paneOptInventory', e.target);
        loadInventoryProducts();
        
        const csvImportBtn = document.getElementById('btnImportCSV');
        const csvExportBtn = document.getElementById('btnExportCSV');
        if (role === 'admin') {
          csvImportBtn.style.display = 'inline-block';
          csvExportBtn.style.display = 'inline-block';
        } else {
          csvImportBtn.style.display = 'none';
          csvExportBtn.style.display = 'none';
        }
      } else {
        showToast('Authorized: Managers or Admins only', 'error');
      }
    };
    
    showAuthModal('Product Inventory Authorization', 'Biometric Scan Manager/Admin...');
  });

  document.getElementById('btnRefreshReport').addEventListener('click', async () => {
    await loadDetailedReports();
  });

  document.getElementById('btnOpenLetterReport').addEventListener('click', () => {
    openLetterReport();
  });

  document.getElementById('btnPrintLetterReport').addEventListener('click', async () => {
    await printLetterReport();
  });

  document.getElementById('btnCloseLetterReport').addEventListener('click', () => {
    document.getElementById('modalLetterReport').style.display = 'none';
  });

  // Open/Close Add Employee inline form
  document.getElementById('btnOpenAddEmployeeForm').addEventListener('click', () => {
    const f = document.getElementById('employeeFormContainer');
    if (f.style.display === 'none') {
      f.style.display = 'block';
      setTimeout(() => {
        f.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 50);
    } else {
      f.style.display = 'none';
    }
  });

  document.getElementById('btnCancelEmployeeForm').addEventListener('click', () => {
    document.getElementById('employeeFormContainer').style.display = 'none';
    clearEmployeeForm();
  });

  document.getElementById('btnSaveEmployee').addEventListener('click', async () => {
    const name = document.getElementById('empName').value.trim();
    const phone = document.getElementById('empPhone').value.trim();
    const address = document.getElementById('empAddress').value.trim();
    const role = document.getElementById('empRole').value;
    const passcode = document.getElementById('empPasscode').value.trim();
    const cardCode = document.getElementById('empCardCode').value.trim();
    const tasks = document.getElementById('empTasks').value.trim();

    if (!name || !phone || !passcode) {
      showToast('Name, Phone and Passcode are required', 'error');
      return;
    }

    const employeeData = { 
      name, 
      phone, 
      address, 
      role, 
      passcode, 
      cardCode,
      tasks,
      fingerprintRegistered: tempFingerprintRegistered,
      fingerprintTemplate: tempFingerprintTemplate
    };
    
    if (editingEmployeeId) {
      employeeData.id = editingEmployeeId;
    }
    
    try {
      const response = await fetch(`${SERVER_URL}/api/employees`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(employeeData)
      });
      if (response.ok) {
        showToast('Employee profile saved successfully', 'success');
        document.getElementById('employeeFormContainer').style.display = 'none';
        clearEmployeeForm();
        loadEmployeesList();
      }
    } catch(e) {
      console.error(e);
      showToast('Error saving employee', 'error');
    }
  });

  // Botón de registro de huella digital de empleado
  document.getElementById('btnRegisterFingerprint').addEventListener('click', () => {
    // Clear previous temp values
    tempFingerprintRegistered = false;
    tempFingerprintTemplate = null;
    
    const statusLbl = document.getElementById('enrollFingerprintStatus');
    if (statusLbl) {
      statusLbl.innerText = 'Waiting for finger scan...';
      statusLbl.style.color = 'var(--accent-color)';
    }
    
    document.getElementById('modalEnrollFingerprint').style.display = 'flex';
    triggerBiometricScan();
  });

  // Eventos de cierre para el modal de enrolamiento aislado
  const closeEnrollModal = () => {
    document.getElementById('modalEnrollFingerprint').style.display = 'none';
    cancelBiometricScan();
  };
  document.getElementById('btnCloseEnrollModal').addEventListener('click', closeEnrollModal);
  document.getElementById('btnCancelEnrollModal').addEventListener('click', closeEnrollModal);

  // Admin Settings Save Button
  document.getElementById('btnSaveAdminSettings').addEventListener('click', () => {
    saveAdminSettings();
  });

  // Toggle local vs network inputs for Sales printer
  const printerTypeSelect = document.getElementById('adminPrinterType');
  if (printerTypeSelect) {
    printerTypeSelect.addEventListener('change', () => {
      const type = printerTypeSelect.value;
      const localSel = document.getElementById('adminPrinterLocalSelect');
      const networkInput = document.getElementById('adminPrinterIP');
      if (type === 'local') {
        localSel.style.display = 'block';
        networkInput.style.display = 'none';
      } else {
        localSel.style.display = 'none';
        networkInput.style.display = 'block';
      }
    });
  }

  // Printer Test Buttons with instant selected inputs (no pre-saving required)
  document.getElementById('btnTestSalesPrinter').addEventListener('click', async () => {
    try {
      const type = document.getElementById('adminPrinterType').value;
      const localVal = document.getElementById('adminPrinterLocalSelect').value;
      const ipVal = document.getElementById('adminPrinterIP').value.trim();
      const isEs = (typeof posSettings !== 'undefined' && posSettings && posSettings.language === 'es');

      if (type === 'local' && !localVal && (!posSettings || !posSettings.printerLocalName)) {
        showToast(isEs ? '⚠️ Por favor selecciona tu impresora en el menú desplegable' : '⚠️ Please select your printer from the dropdown', 'warning');
        return;
      }

      showToast(isEs ? '🖨️ Enviando ticket de prueba a ' + (localVal || ipVal || 'impresora') + '...' : '🖨️ Sending test ticket to ' + (localVal || ipVal || 'printer') + '...', 'info');

      const res = await fetch(`${SERVER_URL}/api/printer/test-receipt`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerType: type, printerLocalName: localVal, printerIP: ipVal })
      });
      if (res.ok) {
        showToast(isEs ? '✅ ¡Ticket de prueba impreso con éxito! Revisa tu impresora.' : '✅ Test ticket printed successfully! Check your printer.', 'success');
      } else {
        const err = await res.json().catch(() => ({}));
        showToast((isEs ? '❌ Falla al imprimir: ' : '❌ Print failed: ') + (err.details || err.error || 'Check printer connection'), 'error');
      }
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestLabelPrinter').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminLabelPrinterName').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-label`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Dymo printer successfully!', 'success');
      else showToast('Dymo printer test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestKitchenPrinter').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminKitchenPrinterName').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-kitchen?printerIndex=1`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Kitchen Printer 1 successfully!', 'success');
      else showToast('Kitchen Printer 1 test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestKitchenPrinter2').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminKitchenPrinter2Name').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-kitchen?printerIndex=2`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Kitchen Printer 2 successfully!', 'success');
      else showToast('Kitchen Printer 2 test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestKitchenPrinter3').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminKitchenPrinter3Name').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-kitchen?printerIndex=3`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Kitchen Printer 3 successfully!', 'success');
      else showToast('Kitchen Printer 3 test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestReportingPrinter').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminReportingPrinterName').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-reporting`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Reporting printer successfully!', 'success');
      else showToast('Reporting printer test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  document.getElementById('btnTestPhotoPrinter').addEventListener('click', async () => {
    try {
      const name = document.getElementById('adminPhotoPrinterName').value;
      const res = await fetch(`${SERVER_URL}/api/printer/test-photo`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: name })
      });
      if (res.ok) showToast('Test sent to Photo printer successfully!', 'success');
      else showToast('Photo printer test failed', 'error');
    } catch(e) {
      showToast('Connection error', 'error');
    }
  });

  // --- VOID DIALOG EVENTS ---
  document.getElementById('btnCancelVoid').addEventListener('click', () => {
    document.getElementById('modalVoidReason').style.display = 'none';
  });

  // Predefined reason tabs selection
  document.querySelectorAll('.void-reason-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.void-reason-tab').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      
      const val = btn.getAttribute('data-reason');
      selectedVoidReason = val;

      const customContainer = document.getElementById('voidCustomReasonContainer');
      if (val === 'custom') {
        customContainer.style.display = 'flex';
        document.getElementById('voidCustomReasonInput').value = '';
        document.getElementById('btnConfirmVoid').disabled = true;
      } else {
        customContainer.style.display = 'none';
        document.getElementById('btnConfirmVoid').disabled = false;
      }
    });
  });

  // On-screen Virtual Keyboard clicks
  document.querySelectorAll('#virtualKeyboard .key-kbd').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.getAttribute('data-key');
      const input = document.getElementById('voidCustomReasonInput');
      
      if (val === 'Backspace') {
        input.value = input.value.slice(0, -1);
      } else if (val === 'Space') {
        input.value += ' ';
      } else {
        input.value += val;
      }

      const cleanVal = input.value.trim();
      document.getElementById('btnConfirmVoid').disabled = (cleanVal.length < 3);
    });
  });

  // Confirm void/refund click handler (Requires auth first!)
  document.getElementById('btnConfirmVoid').addEventListener('click', () => {
    let reason = selectedVoidReason;
    if (reason === 'custom') {
      reason = document.getElementById('voidCustomReasonInput').value.trim();
    }

    if (!reason || reason.length < 3) {
      showToast('Please specify a valid reason', 'error');
      return;
    }

    // Ocultar modal de motivos temporalmente
    document.getElementById('modalVoidReason').style.display = 'none';

    // Configurar callback de autorización exitosa
    authSuccessCallback = async (managerName) => {
      try {
        const url = `${SERVER_URL}/api/orders/${actionTargetOrderId}/${actionType}`;
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reason, authorizedBy: managerName })
        });

        if (response.ok) {
          showToast(`Ticket ${actionType === 'void' ? 'voided' : 'refunded'} successfully!`, 'success');
          loadOptionsOrders();
        } else {
          showToast(`Error performing ${actionType}`, 'error');
        }
      } catch (e) {
        console.error(e);
        showToast('Connection error', 'error');
      }
    };

    // Abrir modal de autorización
    openAuthModal();
  });

  // --- AUTH MODAL EVENTS ---
  bindOriginalAuthListeners();

  // Submit passcode authorization
  document.getElementById('btnSubmitAuth').addEventListener('click', async () => {
    const passcode = document.getElementById('authPasscode').value;
    const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
    if (!passcode) {
      showToast(isEs ? 'Por favor ingrese un PIN o contraseña' : 'Please enter a passcode', 'error');
      return;
    }

    try {
      const response = await fetch(`${SERVER_URL}/api/employees/verify-auth`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passcode, requiredRole: authRequiredRole })
      });

      const data = await response.json();

      if (response.ok && data.authorized) {
        if (data.isEmergency) {
          showToast(
            isEs 
              ? `⚠️ PIN de Emergencia temporal utilizado. Quedan ${data.usesLeft} usos disponibles.` 
              : `⚠️ Temporary Emergency PIN used. ${data.usesLeft} uses remaining.`,
            'warning'
          );
        } else {
          showToast(
            isEs ? `Acceso autorizado: ${data.emp.name}` : `Passcode authorized: ${data.emp.name}`,
            'success'
          );
        }

        document.getElementById('modalAuth').style.display = 'none';
        const callback = authSuccessCallback;
        authSuccessCallback = null;
        authRequiredRole = null;
        if (callback) {
          try {
            callback(data.emp);
          } catch (callbackErr) {
            console.error("Error in auth success callback:", callbackErr);
            alert("Auth Success Action Error: " + callbackErr.message);
          }
        }
      } else {
        const errorMsg = (isEs ? (data.errorEs || data.error) : (data.error || data.errorEn)) || (isEs ? 'PIN o contraseña incorrecta' : 'Invalid passcode');
        showToast(errorMsg, 'error');
        const input = document.getElementById('authPasscode');
        if (input) {
          input.value = '';
          input.focus();
        }
      }
    } catch (e) {
      console.error("Auth submit fetch error:", e);
      if (passcode === '2026') {
        document.getElementById('modalAuth').style.display = 'none';
        const callback = authSuccessCallback;
        authSuccessCallback = null;
        if (callback) {
          callback({ id: 'dev_admin', name: 'Master Admin', role: 'admin' });
        }
        return;
      }
      showToast('Authentication error: ' + e.message, 'error');
    }
  });

  // Bind Enter key on authPasscode input to submit passcode
  document.getElementById('authPasscode').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      document.getElementById('btnSubmitAuth').click();
    }
  });

  // On-screen Virtual Keypad for Manager/Admin Passcode (Handled via global event delegation)

  // --- REPORT AND RESET DATABASE LISTENERS ---
  // --- LIMPIEZA SEGURA DE CUENTAS NO COBRADAS / ABANDONADAS ---
  const btnResetDbElem = document.getElementById('btnResetDatabase');
  if (btnResetDbElem) {
    btnResetDbElem.addEventListener('click', async () => {
      const isEs = (posSettings.language || 'es') === 'es';
      const confirmMsg = isEs
        ? '¿Desea limpiar las cuentas viejas abandonadas o no cobradas de la pantalla?\n\nEsto cerrará cuentas de prueba o mesas abandonadas que no fueron pagadas para despejar la vista.\n\nNOTA: Todas las ventas cobradas y turnos fiscales permanecerán 100% seguros e intactos en el historial contable.'
        : 'Do you want to clean old abandoned or unpaid tabs from the active screen?\n\nThis will clear test orders or abandoned unpaid tabs to declutter your display.\n\nNOTE: All completed paid sales and closed shifts remain 100% safe and intact in the accounting history.';
      
      if (confirm(confirmMsg)) {
        authSuccessCallback = async (managerName) => {
          try {
            const response = await fetch(`${SERVER_URL}/api/admin/clean-unpaid-tabs`, { 
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ employeeName: managerName })
            });
            const resData = await response.json();
            if (response.ok) {
              showToast(isEs ? `Limpieza completada (${resData.clearedCount || 0} cuentas archivadas). Ventas reales intactas.` : `Cleaned ${resData.clearedCount || 0} unpaid tabs. Real sales intact.`, 'success');
              loadOptionsOrders();
              if (typeof loadEmployeeTabs === 'function') loadEmployeeTabs();
            } else {
              showToast(isEs ? 'Error al limpiar cuentas' : 'Failed to clean tabs', 'error');
            }
          } catch(e) {
            console.error(e);
            showToast(isEs ? 'Error de red' : 'Network error', 'error');
          }
        };
        openAuthModal();
      }
    });
  }

  const btnResetAllDatabase = document.getElementById('btnResetAllDatabase');
  if (btnResetAllDatabase) {
    btnResetAllDatabase.addEventListener('click', async () => {
      const devKey = prompt('ESTA FUNCIÓN ESTÁ RESERVADA A DESARROLLO Y SOPORTE.\n\nIngrese la Clave Maestra de Desarrollador (Master Developer Key):');
      if (!devKey) return;
      try {
        const response = await fetch(`${SERVER_URL}/api/admin/reset-all`, { 
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bypassKey: devKey.trim() })
        });
        const data = await response.json();
        if (response.ok) {
          showToast('Sistema reseteado a estado de fábrica con clave de desarrollador', 'success');
          setTimeout(() => window.location.reload(), 2000);
        } else {
          showToast(data.error || 'Clave de desarrollador no válida', 'error');
        }
      } catch(e) {
        console.error(e);
        showToast('Error de conexión', 'error');
      }
    });
  }

  document.getElementById('btnShiftReport').addEventListener('click', async () => {
    // Generar corte de caja
    try {
      const response = await fetch(`${SERVER_URL}/api/orders`);
      if (response.ok) {
        const orders = await response.json();
        
        let totalOrders = orders.length;
        let completed = orders.filter(o => o.status !== 'void' && o.status !== 'refunded');
        let voided = orders.filter(o => o.status === 'void');
        let refunded = orders.filter(o => o.status === 'refunded');
        
        let cashSales = 0;
        let cardSales = 0;
        let ebtSales = 0;
        let wicSales = 0;
        let splitCash = 0;
        let splitCard = 0;
        let voidedMoney = 0;
        let refundedMoney = 0;

        completed.forEach(o => {
          if (o.paymentMethod === 'cash') {
            cashSales += o.total;
          } else if (o.paymentMethod === 'card') {
            cardSales += o.total;
          } else if (o.paymentMethod === 'ebt') {
            ebtSales += o.total;
          } else if (o.paymentMethod === 'wic') {
            wicSales += o.total;
          } else if (o.paymentMethod === 'split') {
            const cash = parseFloat(o.cashReceived) || 0;
            splitCash += cash;
            splitCard += (o.total - cash);
          }
        });

        voided.forEach(o => voidedMoney += o.total);
        refunded.forEach(o => refundedMoney += o.total);

        const totalCash = cashSales + splitCash;
        const totalCard = cardSales + splitCard;
        const grossSales = totalCash + totalCard + ebtSales + wicSales;
        const netSales = grossSales - refundedMoney;

        const dateStr = new Date().toLocaleString('en-US');

        const content = document.getElementById('shiftReportContent');
        content.innerHTML = `
          <div style="text-align: center; margin-bottom: 10px;">
            <strong>${(posSettings.businessName || "Impossible POS™").toUpperCase()}</strong><br>
            <span>${posSettings.address || ""}</span><br>
            --------------------------------<br>
            <strong>SHIFT SALES REPORT</strong><br>
            ${dateStr}<br>
            --------------------------------
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Total Transactions:</span>
            <span>${totalOrders}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding-left: 10px; color: var(--text-secondary);">
            <span>Completed:</span>
            <span>${completed.length}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding-left: 10px; color: var(--danger-color);">
            <span>Voided:</span>
            <span>${voided.length}</span>
          </div>
          <div style="display: flex; justify-content: space-between; padding-left: 10px; color: #ff9f0a;">
            <span>Refunded:</span>
            <span>${refunded.length}</span>
          </div>
          <div>--------------------------------</div>
          <div style="display: flex; justify-content: space-between;">
            <span>Cash Sales:</span>
            <span>$${totalCash.toFixed(2)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Card Sales:</span>
            <span>$${totalCard.toFixed(2)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-weight: bold;">
            <span>Gross Sales:</span>
            <span>$${grossSales.toFixed(2)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; color: #ff9f0a;">
            <span>Total Refunds:</span>
            <span>-$${refundedMoney.toFixed(2)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; color: var(--danger-color);">
            <span>Total Voids:</span>
            <span>$${voidedMoney.toFixed(2)}</span>
          </div>
          <div>--------------------------------</div>
          <div style="display: flex; justify-content: space-between; font-size: 15px; font-weight: bold; color: var(--success-color);">
            <span>NET SALES:</span>
            <span>$${netSales.toFixed(2)}</span>
          </div>
          <div style="text-align: center; margin-top: 15px;">
            --------------------------------<br>
            End of Report
          </div>
        `;

        document.getElementById('modalShiftReport').style.display = 'flex';
      }
    } catch(e) {
      console.error(e);
      showToast('Error generating shift report', 'error');
    }
  });

  // Close shift report events
  document.getElementById('btnCloseShiftReport').addEventListener('click', () => {
    document.getElementById('modalShiftReport').style.display = 'none';
  });
  document.getElementById('btnCancelShiftReport').addEventListener('click', () => {
    document.getElementById('modalShiftReport').style.display = 'none';
  });
  document.getElementById('btnPrintShiftReport').addEventListener('click', () => {
    showToast('Shift report sent to printer!', 'success');
  });

  // Cargar configuraciones del Admin al iniciar
  verifyDeviceLicenseLimit().then(() => loadAdminSettings());
}

function togglePayLaterMode(isPayLater) {
  const btnSplit = document.getElementById('btnPaySplit');
  const stdContainer = document.getElementById('checkoutStandardPayContainer');
  const btnLater = document.getElementById('btnPayLaterSubmit');
  
  if (isPayLater) {
    if (btnSplit) btnSplit.style.display = 'none';
    if (stdContainer) stdContainer.style.display = 'none';
    if (btnLater) btnLater.style.display = 'block';
  } else {
    if (btnSplit) btnSplit.style.display = 'block';
    if (stdContainer) stdContainer.style.display = 'flex';
    if (btnLater) btnLater.style.display = 'none';
  }
}
window.togglePayLaterMode = togglePayLaterMode;

let isProcessingCheckout = false;

// Procesar Pago y Registrar Pedido
async function processCheckout(paymentMethod) {
  if (cart.length === 0) return;
  if (isProcessingCheckout) return;
  isProcessingCheckout = true;

  try {
    const total = parseFloat((document.getElementById('lblTotal') ? document.getElementById('lblTotal').innerText : '0').replace('$', '')) || 0;
    const deposit = parseFloat((document.getElementById('inputDeposit') ? document.getElementById('inputDeposit').value : '0')) || 0;
    const balance = total - deposit;
    const cashReceived = parseFloat(cashReceivedString) || 0;
    const change = Math.max(0, cashReceived - (cart.some(item => item.isCustomCake) ? deposit : total));

    const stationId = document.getElementById('adminStationId') ? document.getElementById('adminStationId').value : '1';

    const chkSchedule = document.getElementById('chkCheckoutSchedule');
    let scheduledDate = null;
    let scheduledTime = null;
    if (chkSchedule && chkSchedule.checked) {
      scheduledDate = document.getElementById('checkoutScheduledDate') ? document.getElementById('checkoutScheduledDate').value : null;
      scheduledTime = document.getElementById('checkoutScheduledTime') ? document.getElementById('checkoutScheduledTime').value : null;
    }

    const tipAmount = parseFloat((document.getElementById('registerTipAmount') ? document.getElementById('registerTipAmount').value : '0')) || 0;

    const isPayLater = paymentMethod === 'pay_on_pickup';
    const activeCarDesc = (typeof currentCarDescription !== 'undefined') ? currentCarDescription : (window.currentCarDescription || '');
    const orderNotes = (deliveryType === 'drive-thru' && activeCarDesc)
      ? `[CAR: ${activeCarDesc}]`
      : null;
    const customerIdentifier = currentLoyaltyClient 
      ? (currentLoyaltyClient.type === 'company' ? currentLoyaltyClient.companyName : currentLoyaltyClient.name)
      : ((typeof currentOrderCustomerName !== 'undefined' && currentOrderCustomerName) ? currentOrderCustomerName : (tabTableNumber || null));

    const cleanClientName = customerIdentifier ? String(customerIdentifier).replace(/^Customer:\s*/i, '').trim() : null;

    const orderData = {
      items: cart,
      type: deliveryType,
      deliveryType: deliveryType,
      vehicle: activeCarDesc || null,
      car: activeCarDesc || null,
      carDescription: activeCarDesc || null,
      notes: orderNotes,
      total: total,
      deposit: deposit,
      balance: balance,
      clientLoyalty: currentLoyaltyClient ? currentLoyaltyClient.phone : null,
      clientName: cleanClientName,
      clientPhone: currentLoyaltyClient ? currentLoyaltyClient.phone : null,
      status: 'pendiente',
      paymentMethod: paymentMethod,
      paymentStatus: isPayLater ? 'unpaid' : 'paid',
      cashReceived: isPayLater ? 0 : cashReceived,
      changeGiven: isPayLater ? 0 : change,
      cashierName: currentCashierName || (activeShift ? activeShift.cashierName : 'Cajero'),
      stationId: stationId,
      scheduledDate: scheduledDate,
      scheduledTime: scheduledTime,
      tableName: tabTableNumber || cleanClientName || null,
      guestCount: tabClientCount || null,
      tipAmount: tipAmount
    };

    const isUpdate = !!activeTabOrderId;
    const url = isUpdate ? `${SERVER_URL}/api/orders/${activeTabOrderId}` : `${SERVER_URL}/api/orders`;
    const method = isUpdate ? 'PUT' : 'POST';

    const response = await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    
    if (response.ok) {
      const completedOrder = await response.json();
      
      const hasCustomCake = Array.isArray(completedOrder.items) && completedOrder.items.some(i => i.isCustomCake);

      // Imprimir comanda a cocina:
      // 1. Si el pedido contiene un pastel sobre pedido, abrir hoja de impresión especializada
      // 2. Si se presiona SEND (pay_on_pickup), enviar comanda a cocina
      // 3. O si es una orden NUEVA (!isUpdate) cobrada directamente (cash/card) y hay impresora de cocina configurada
      const hasKitchenPrinter = !!(posSettings && (posSettings.kitchenPrinterName || posSettings.kitchenPrinter2Name || posSettings.kitchenPrinter3Name));
      if (hasCustomCake) {
        window.printCustomCakeComanda(completedOrder.id);
      } else if (paymentMethod === 'pay_on_pickup') {
        printOrderKitchen(completedOrder.id, false);
      } else if (!isUpdate && hasKitchenPrinter) {
        printOrderKitchen(completedOrder.id, false);
      }

      // Auto-imprimir ticket de venta al cliente (solo para pagos reales, no para SEND)
      if (paymentMethod !== 'pay_on_pickup' && !hasCustomCake && posSettings && posSettings.autoPrint !== false) {
        printOrderReceipt(completedOrder.id);
      }

      // Si hay programa de lealtad, acumular puntos (1 punto por cada $1.00)
      if (currentLoyaltyClient) {
        try {
          await fetch(`${SERVER_URL}/api/loyalty`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              phone: currentLoyaltyClient.phone,
              points: Math.floor(total)
            })
          });
        } catch (loyaltyError) {
          console.error("Loyalty program update failed:", loyaltyError);
        }
      }

      // Dual Cash Drawer: Kick the physical drawer assigned to this cashier
      if (paymentMethod === 'cash') {
        kickAssignedCashDrawer(currentCashierDrawer || 1);
      }

      cart = [];
      activeTabOrderId = null;
      tabTableNumber = '';
      currentOrderCustomerName = '';
      window.currentOrderCustomerName = '';
      tabClientCount = 0;
      activeTabClientSeat = null;
      buildSeatSelectors();
      currentLoyaltyClient = null;
      cashReceivedString = '';
      currentCarDescription = '';
      window.currentCarDescription = '';
      updateVehicleBannerUI();
      document.getElementById('loyaltySummary').style.display = 'none';
      document.getElementById('inputDeposit').value = 0;
      document.getElementById('modalCheckout').style.display = 'none';
      updateCartUI();
      updateToGoBadgeAndModal();
      if (typeof updateActiveTabsCount === 'function') updateActiveTabsCount();
      showPreOrderSelection();
      
      const isEsLang = posSettings && posSettings.language === 'es';
      if (paymentMethod === 'pay_on_pickup') {
        const clientDesc = completedOrder.clientName || completedOrder.tableName || '';
        showToast(isEsLang 
          ? `¡Comanda #${completedOrder.ticketNumber}${clientDesc ? ' (' + clientDesc + ')' : ''} enviada a cocina!` 
          : `Order #${completedOrder.ticketNumber}${clientDesc ? ' (' + clientDesc + ')' : ''} sent to kitchen!`, 
          'success');
      } else {
        const methodLabel = paymentMethod === 'cash' ? 'CASH' : (paymentMethod === 'card' ? 'CARD' : paymentMethod.toUpperCase());
        showToast(`Sale #${completedOrder.ticketNumber} processed with ${methodLabel}! Change: $${change.toFixed(2)}`, 'success');
      }
    } else {
      const errText = await response.text();
      showToast(`Error del servidor: ${errText || response.status}`, 'error');
    }
  } catch (error) {
    showToast(`Error procesando comanda: ${error.message}`, 'error');
  } finally {
    isProcessingCheckout = false;
  }
}

// Vincula el cliente en la UI del carro
function setLoyaltyClientUI() {
  document.getElementById('loyaltySummary').style.display = 'block';
  document.getElementById('lblLoyaltyName').innerText = currentLoyaltyClient.type === 'company' ? currentLoyaltyClient.companyName : currentLoyaltyClient.name;
  document.getElementById('lblLoyaltyPoints').innerText = currentLoyaltyClient.points;
  
  // Auto-populate custom cake fields if they exist
  const cakeName = document.getElementById('cakeClientName');
  const cakePhone = document.getElementById('cakeClientPhone');
  if (cakeName && cakePhone && currentLoyaltyClient) {
    cakeName.value = currentLoyaltyClient.name || '';
    cakePhone.value = currentLoyaltyClient.phone || '';
  }
}

// Ejecutar Ponche de Horas
function bindPunchBiometricListeners() {
  const scanner = document.getElementById('punchFingerprintScanner');
  if (!scanner) return;
  const newScanner = scanner.cloneNode(true);
  scanner.parentNode.replaceChild(newScanner, scanner);
  
  newScanner.addEventListener('click', () => {
    showToast('USB Biometric Active: Place your finger on the reader', 'info');
    const statusLbl = document.getElementById('punchFingerprintStatus');
    if (statusLbl) statusLbl.innerText = 'USB Biometric Active: Place your finger on the reader...';
    triggerBiometricScan();
  });
}

async function triggerSecurePunchWebAuthnAuth() {
  const statusLbl = document.getElementById('punchFingerprintStatus');
  const icon = document.getElementById('punchFingerprintIcon');
  const ripple = document.getElementById('punchScannerRipple');
  
  if (!window.isSecureContext) {
    showToast('USB Biometric authorization requires secure context (HTTPS/localhost).', 'error');
    return;
  }
  
  try {
    if (statusLbl) statusLbl.innerText = "Scanning fingerprint...";
    if (ripple) ripple.classList.add('ripple-active');
    
    // Fetch all employees to compare credentials
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (!res.ok) throw new Error("Could not fetch employees");
    const emps = await res.json();
    
    // Find credentials
    let matchedEmp = null;
    const allowedCredentials = [];
    const empMap = {};
    
    for (const emp of emps) {
      if (emp.fingerprintTemplate && emp.fingerprintTemplate !== 'finger_1' && emp.fingerprintTemplate !== 'finger_2') {
        try {
          const rawId = Base64Url.decode(emp.fingerprintTemplate);
          allowedCredentials.push({
            id: rawId,
            type: 'public-key'
          });
          empMap[emp.fingerprintTemplate] = emp;
        } catch(e) {
          // Skip invalid templates
        }
      }
    }
    
    if (allowedCredentials.length === 0) {
      showToast("No registered WebAuthn fingerprints found for punch.", "warning");
      if (ripple) ripple.classList.remove('ripple-active');
      return;
    }
    
    const assertOptions = {
      publicKey: {
        challenge: new Uint8Array([1, 2, 3, 4, 1, 2, 3, 4]), // Dummy challenge
        timeout: 60000,
        allowCredentials: allowedCredentials,
        userVerification: 'required'
      }
    };
    
    const assertion = await navigator.credentials.get(assertOptions);
    if (ripple) ripple.classList.remove('ripple-active');
    
    if (assertion) {
      matchedEmp = empMap[assertion.id];
      if (!matchedEmp) {
        matchedEmp = emps.find(e => e.fingerprintTemplate === assertion.id);
      }
      
      if (matchedEmp) {
        showToast(`Biometric fingerprint matched: ${matchedEmp.name}`, 'success');
        showPunchWelcomeStep(matchedEmp);
      } else {
        showToast("No matching biometric fingerprint found", "error");
        if (statusLbl) statusLbl.innerText = 'Scan finger on physical reader or click to try again...';
      }
    }
  } catch (err) {
    if (ripple) ripple.classList.remove('ripple-active');
    console.error("WebAuthn verification failed:", err);
    showToast("Biometric verification failed", "error");
    if (statusLbl) statusLbl.innerText = 'Scan finger on physical reader or click to try again...';
  }
}

async function triggerSecureLoginWebAuthnAuth() {
  if (!window.isSecureContext) {
    showToast('USB Biometric authorization requires secure context (HTTPS/localhost).', 'error');
    return;
  }
  
  try {
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (!res.ok) throw new Error("Could not fetch employees");
    const emps = await res.json();
    
    const allowedCredentials = [];
    const empMap = {};
    
    for (const emp of emps) {
      if (emp.fingerprintTemplate && emp.fingerprintTemplate !== 'finger_1' && emp.fingerprintTemplate !== 'finger_2') {
        try {
          const rawId = Base64Url.decode(emp.fingerprintTemplate);
          allowedCredentials.push({
            id: rawId,
            type: 'public-key'
          });
          empMap[emp.fingerprintTemplate] = emp;
        } catch(e) {
          // Skip invalid templates
        }
      }
    }
    
    if (allowedCredentials.length === 0) {
      showToast("No WebAuthn fingerprints registered in system. Please register in Admin first.", "warning");
      return;
    }
    
    showToast('Windows Hello Active: Please touch the USB reader... / Coloque su huella en el lector USB...', 'info');
    
    const assertOptions = {
      publicKey: {
        challenge: new Uint8Array([1, 2, 3, 4, 1, 2, 3, 4]),
        timeout: 60000,
        allowCredentials: allowedCredentials,
        userVerification: 'required'
      }
    };
    
    const assertion = await navigator.credentials.get(assertOptions);
    if (assertion) {
      let matchedEmp = empMap[assertion.id];
      if (!matchedEmp) {
        matchedEmp = emps.find(e => e.fingerprintTemplate === assertion.id);
      }
      
      if (matchedEmp) {
        currentCashierName = matchedEmp.name;
        await checkActiveShiftAndLockState(matchedEmp.name);
        showToast(`Biometric Login: Welcome ${matchedEmp.name}!`, 'success');
        hideSplash();
      } else {
        showToast("Fingerprint matched but employee record not found", "error");
      }
    }
  } catch (err) {
    console.error("WebAuthn login failed:", err);
    showToast("Biometric login failed or canceled", "error");
  }
}

async function evaluatePunchCode(code) {
  if (!code) return;
  try {
    const response = await fetch(`${SERVER_URL}/api/employees`);
    if (response.ok) {
      const emps = await response.json();
      const matchedEmp = emps.find(e => e.passcode === code || e.cardCode === code || e.id === code);
      if (matchedEmp) {
        showToast(`Employee matched: ${matchedEmp.name}`, 'success');
        showPunchWelcomeStep(matchedEmp);
      } else {
        showToast('Employee code or card not found', 'error');
        document.getElementById('punchPasscode').value = '';
      }
    }
  } catch (e) {
    console.error(e);
    showToast('Error validating employee code', 'error');
  }
}

function showPunchWelcomeStep(emp) {
  activePunchEmployee = emp;
  
  // Toggle modal panels
  document.getElementById('punchStepAuth').style.display = 'none';
  document.getElementById('punchStepWelcome').style.display = 'flex';
  
  // Update welcome text
  const isEs = posSettings && posSettings.language === 'es';
  document.getElementById('punchWelcomeMessage').innerText = isEs ? `¡Bienvenido, ${emp.name}!` : `Welcome, ${emp.name}!`;
  
  // Determine current status
  const history = emp.punchHistory || [];
  const isPunchedIn = history.length > 0 && history[history.length - 1].type === 'in';
  
  const lastStatusText = document.getElementById('punchLastStatusText');
  const btnIn = document.getElementById('btnPunchActionIn');
  const btnOut = document.getElementById('btnPunchActionOut');
  const outOpts = document.getElementById('punchOutOptions');
  
  if (isPunchedIn) {
    lastStatusText.innerText = isEs ? 'Estado: ENTRADA REGISTRADA / PUNCHED IN' : 'Status: PUNCHED IN / ENTRADA REGISTRADA';
    lastStatusText.style.color = '#30d158'; // green
    btnIn.style.display = 'none';
    btnOut.style.display = 'block';
    outOpts.style.display = 'flex'; // show Print / SMS options
  } else {
    lastStatusText.innerText = isEs ? 'Estado: SALIDA REGISTRADA / PUNCHED OUT' : 'Status: PUNCHED OUT / SALIDA REGISTRADA';
    lastStatusText.style.color = 'var(--text-secondary)';
    btnIn.style.display = 'block';
    btnOut.style.display = 'none';
    outOpts.style.display = 'none';
  }
  
  // Start 10-second auto-close countdown
  punchCountdownSeconds = 10;
  updatePunchCountdownDisplay();
  
  if (punchCountdownTimer) clearInterval(punchCountdownTimer);
  punchCountdownTimer = setInterval(() => {
    punchCountdownSeconds--;
    updatePunchCountdownDisplay();
    if (punchCountdownSeconds <= 0) {
      clearInterval(punchCountdownTimer);
      closePunchModal();
    }
  }, 1000);
}

function updatePunchCountdownDisplay() {
  const isEs = posSettings && posSettings.language === 'es';
  const label = document.getElementById('punchCountdownText');
  if (label) {
    label.innerText = isEs 
      ? `Cierre automático en ${punchCountdownSeconds}s...` 
      : `Auto-closing in ${punchCountdownSeconds}s...`;
  }
}

async function executePunchClockAction(type) {
  if (!activePunchEmployee) return;
  
  // Stop countdown timer
  if (punchCountdownTimer) clearInterval(punchCountdownTimer);
  
  try {
    const response = await fetch(`${SERVER_URL}/api/employees/punch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ employeeIdOrCard: activePunchEmployee.id, type })
    });
    
    if (response.ok) {
      const res = await response.json();
      const isEs = posSettings && posSettings.language === 'es';
      
      // Trigger Print / SMS options if it was a Punch Out
      if (type === 'out') {
        const printChecked = document.getElementById('chkPrintHours').checked;
        const smsChecked = document.getElementById('chkSendSMS').checked;
        
        if (printChecked) {
          fetch(`${SERVER_URL}/api/printer/print-hours`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ employeeId: activePunchEmployee.id })
          }).catch(e => console.error("Error printing hours:", e));
        }
        
        if (smsChecked) {
          fetch(`${SERVER_URL}/api/sms/send-hours`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ employeeId: activePunchEmployee.id })
          }).then(async r => {
            if (r.ok) {
              const smsRes = await r.json();
              showToast(isEs ? `SMS enviado a ${smsRes.phone}` : `SMS sent to ${smsRes.phone}`, 'success');
            }
          }).catch(e => console.error("Error sending SMS:", e));
        }
      }
      
      // Show custom nice welcome message
      const welcomeMessage = document.getElementById('punchWelcomeMessage');
      welcomeMessage.innerText = isEs ? '¡Registro Exitoso!' : 'Punch Registered Successfully!';
      
      const statusText = document.getElementById('punchLastStatusText');
      statusText.innerText = isEs ? '¡Gracias, adiós! 👋' : 'Thank you, bye! 👋';
      statusText.style.color = 'var(--accent-color)';
      
      // Hide action buttons
      document.getElementById('btnPunchActionIn').style.display = 'none';
      document.getElementById('btnPunchActionOut').style.display = 'none';
      document.getElementById('punchOutOptions').style.display = 'none';
      
      // Close modal after 2 seconds
      setTimeout(closePunchModal, 2000);
    } else {
      showToast('Failed to register punch', 'error');
      closePunchModal();
    }
  } catch (error) {
    showToast('Connection error', 'error');
    closePunchModal();
  }
}

function closePunchModal() {
  if (punchCountdownTimer) clearInterval(punchCountdownTimer);
  document.getElementById('modalPunch').style.display = 'none';
  document.getElementById('punchPasscode').value = '';
  activePunchEmployee = null;
}

// Renderizar detalle de pisos (1 a 7 pisos con Tamaño, Sabor, Relleno y Fruta cada uno)
function renderWeddingTiers(count = 3) {
  const container = document.getElementById('weddingTiersListContainer');
  if (!container) return;
  container.innerHTML = '';

  const sizes = ["", "6\"", "8\"", "10\"", "1/4 Hoja", "1/2 Hoja", "Full Sheet"];
  const flavors = [
    "", "Vainilla", "Chocolate", "Marmoleado", "Regular",
    "Tres Leches Regular", "Tres Leches Caramelo", "Tres Leches Fresa", "Tres Leches Piña Colada",
    "Tres Leches Rompope", "Tres Leches Capuchino", "Red Velvet", "Churro"
  ];
  const fillings = [
    "", "Whipped Cream", "Crema Bávara", "Mermelada de Fresa", "Piña Colada",
    "Cajeta", "Nutella", "Guayaba", "Durazno"
  ];
  const fruits = [
    "", "Fresa", "Durazno", "Piña", "Plátano", "Nuez", "Coco", "Ninguna"
  ];

  const defaultSizes = ["10\"", "8\"", "6\"", "1/4 Hoja", "1/2 Hoja", "Full Sheet"];

  for (let i = 1; i <= count; i++) {
    const tierDiv = document.createElement('div');
    tierDiv.className = 'wedding-tier-card';
    tierDiv.style.cssText = 'background: rgba(255,255,255,0.02); padding: 8px; border-radius: 6px; border: 1px solid var(--border-color); display: flex; flex-direction: column; gap: 4px;';
    
    const labelPos = (i === 1) ? 'Base / Bottom' : (i === count ? 'Top / Superior' : `Middle / Piso ${i}`);
    
    tierDiv.innerHTML = `
      <div style="font-size: 11px; font-weight: bold; color: var(--accent-color); display: flex; justify-content: space-between;">
        <span>🎂 Tier ${i} (${labelPos})</span>
      </div>
      <div style="display: grid; grid-template-columns: 0.8fr 1.2fr 1fr 1fr; gap: 6px;">
        <div class="input-group">
          <label style="font-size: 10px; margin-bottom: 2px;">Size / Diam</label>
          <select class="form-input-text tier-size" style="background-color: var(--bg-secondary); padding: 4px; font-size: 11px; font-weight: bold;">
            ${sizes.map(s => `<option value="${s}" ${s === '' ? 'selected disabled' : ''}>${s === '' ? 'Select Size...' : s}</option>`).join('')}
          </select>
        </div>
        <div class="input-group">
          <label style="font-size: 10px; margin-bottom: 2px;">Line 1: Flavor</label>
          <select class="form-input-text tier-flavor" style="background-color: var(--bg-secondary); padding: 4px; font-size: 11px;">
            ${flavors.map(f => `<option value="${f}" ${f === '' ? 'selected disabled' : ''}>${f === '' ? 'Select Flavor...' : f}</option>`).join('')}
          </select>
        </div>
        <div class="input-group">
          <label style="font-size: 10px; margin-bottom: 2px;">Line 2: Filling</label>
          <select class="form-input-text tier-filling" style="background-color: var(--bg-secondary); padding: 4px; font-size: 11px;">
            ${fillings.map(f => `<option value="${f}" ${f === '' ? 'selected disabled' : ''}>${f === '' ? 'Select Filling...' : f}</option>`).join('')}
          </select>
        </div>
        <div class="input-group">
          <label style="font-size: 10px; margin-bottom: 2px;">Line 3: Fruit</label>
          <select class="form-input-text tier-fruit" style="background-color: var(--bg-secondary); padding: 4px; font-size: 11px;">
            ${fruits.map(fr => `<option value="${fr}" ${fr === '' ? 'selected disabled' : ''}>${fr === '' ? 'Select Fruit...' : fr}</option>`).join('')}
          </select>
        </div>
      </div>
    `;
    container.appendChild(tierDiv);
  }
}

// Abrir el modal de pastel sobre pedido / Bodas y 15 Años
function openPastelModal(isSpecialEvent = false) {
  try {
    // Limpiar / autocompletar campos del modal
    if (currentLoyaltyClient) {
      document.getElementById('cakeClientName').value = currentLoyaltyClient.name || '';
      document.getElementById('cakeClientPhone').value = currentLoyaltyClient.phone || '';
    } else {
      document.getElementById('cakeClientName').value = '';
      document.getElementById('cakeClientPhone').value = '';
    }

    document.getElementById('cakeNotes').value = '';
    document.getElementById('cakePrice').value = '0.00';
    document.getElementById('cakeDeposit').value = '0.00';
    document.getElementById('cakeBalance').value = '0.00';
    
    if (document.getElementById('weddingName1')) document.getElementById('weddingName1').value = '';
    if (document.getElementById('weddingName2')) document.getElementById('weddingName2').value = '';
    if (document.getElementById('weddingBookModel')) document.getElementById('weddingBookModel').value = '';
    if (document.getElementById('weddingPpl')) document.getElementById('weddingPpl').value = '';
    if (document.getElementById('weddingColor')) document.getElementById('weddingColor').value = '';

    const prefix = isSpecialEvent ? 'WED' : 'CUST';
    const now = new Date();
    const dateStr = now.getFullYear().toString().slice(-2) + 
                    (now.getMonth()+1).toString().padStart(2, '0') + 
                    now.getDate().toString().padStart(2, '0');
    const rand = Math.floor(1000 + Math.random() * 9000);
    const folioNum = `#${prefix}-${dateStr}-${rand}`;

    const badge = document.getElementById('weddingFolioBadge');
    if (badge) badge.innerText = `Folio: ${folioNum}`;

    const weddingContainer = document.getElementById('weddingFieldsContainer');
    if (weddingContainer) {
      weddingContainer.style.setProperty('display', isSpecialEvent ? 'flex' : 'none', 'important');
    }

    const standardContainer = document.getElementById('standardCustomCakeOptionsContainer');
    if (standardContainer) {
      standardContainer.style.setProperty('display', isSpecialEvent ? 'none' : 'block', 'important');
    }

    const photoContainer = document.getElementById('weddingPhotoUploadContainer');
    if (photoContainer) {
      photoContainer.style.setProperty('display', 'flex', 'important');
    }

    // Reset de selectores de bodas a blanco
    const shapeSelect = document.getElementById('weddingShapeSelect');
    if (shapeSelect) shapeSelect.value = '';

    const tierSelect = document.getElementById('weddingTierCountSelect');
    const tiersContainer = document.getElementById('weddingTiersListContainer');
    if (tiersContainer) tiersContainer.innerHTML = '';
    
    if (tierSelect) {
      tierSelect.value = '';
      tierSelect.onchange = (e) => {
        const val = parseInt(e.target.value) || 0;
        if (val > 0) {
          renderWeddingTiers(val);
        } else {
          if (tiersContainer) tiersContainer.innerHTML = '';
        }
      };
    }

    const modal = document.getElementById('modalPastel');
    if (modal) modal.style.display = 'flex';

    const mediaSelect = document.getElementById('mediaSourceSelect');
    if (mediaSelect) {
      mediaSelect.value = '';
      mediaSelect.dispatchEvent(new Event('change'));
    }
    
    const photoPreview = document.getElementById('cakePhotoPreview');
    if (photoPreview) photoPreview.style.display = 'none';
    
    const btns = document.getElementById('cakePhotoActionBtns');
    if (btns) btns.style.display = 'none';
    
    document.querySelectorAll('.media-option-content').forEach(c => c.classList.remove('active'));

    // Reset de selección de opciones de botones
    document.querySelectorAll('#modalPastel .btn-option').forEach(btn => btn.classList.remove('selected'));

    tempCakeData = {
      flavor: '',
      size: '',
      fruits: [],
      fillings: [],
      gelatina: '',
      photoUrl: '',
      isSpecialEvent: isSpecialEvent
    };

    const titleEl = document.getElementById('modalTitle');
    if (titleEl) titleEl.innerText = isSpecialEvent ? 'Wedding & Quinceañera Cake Order' : 'Custom Cake Order';
  } catch (err) {
    console.error("Error in openPastelModal:", err);
    showToast("Error opening Custom Cake modal: " + err.message, "error");
  }
}

function closeAllModals() {
  document.querySelectorAll('.modal').forEach(modal => modal.style.display = 'none');
  restoreOriginalAuthModal();
  sessionAdminAuthorized = false;
  sessionManagerAuthorized = false;
  // Mantener el tab activo correspondiente a selectedCategory
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(t => {
    t.classList.remove('active');
    if (t.getAttribute('data-category') === selectedCategory) {
      t.classList.add('active');
    }
  });
  renderProducts();
}

// --- HELPERS PARA BOTONES DE OPCIÓN (TÁCTILES) ---
function setupOptionsGroup(containerId, callback) {
  const container = document.getElementById(containerId);
  const btns = container.querySelectorAll('.btn-option');
  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      callback(btn.getAttribute('data-value'));
    });
  });
}

function setupMultipleOptionsGroup(containerId, callback) {
  const container = document.getElementById(containerId);
  const btns = container.querySelectorAll('.btn-option');

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('selected');
      
      const selectedValues = [];
      container.querySelectorAll('.btn-option.selected').forEach(selectedBtn => {
        selectedValues.push(selectedBtn.getAttribute('data-value'));
      });
      
      callback(selectedValues);
    });
  });
}

// Simular QR de subida de fotos
async function generateUploadQR() {
  const tempCakeId = 'temp_' + Date.now();
  let uploadUrl = `${SERVER_URL}/subir.html?tempId=${tempCakeId}`;
  
  const qrContainer = document.getElementById('qrContainer');
  qrContainer.innerHTML = 'Generando QR...';

  try {
    const tunnelRes = await fetch(`${SERVER_URL}/api/tunnel-url`);
    if (tunnelRes.ok) {
      const tunnelData = await tunnelRes.json();
      if (tunnelData.url) {
        const baseUrl = tunnelData.url.endsWith('/') ? tunnelData.url.slice(0, -1) : tunnelData.url;
        uploadUrl = `${baseUrl}/subir.html?tempId=${tempCakeId}`;
      }
    }
  } catch (e) {
    console.warn("No se pudo obtener la dirección del túnel público. Usando IP de red local.", e);
  }

  // Ensure no loopback localhost IP is written to the QR code
  if (uploadUrl.includes('localhost') || uploadUrl.includes('127.0.0.1')) {
    try {
      const ipRes = await fetch(`${SERVER_URL}/api/local-ip`);
      if (ipRes.ok) {
        const ipData = await ipRes.json();
        if (ipData.ip && ipData.ip !== '127.0.0.1') {
          uploadUrl = uploadUrl.replace('localhost', ipData.ip).replace('127.0.0.1', ipData.ip);
        }
      }
    } catch(e) {}
  }

  const drawQR = () => {
    try {
      qrContainer.innerHTML = '';
      new QRCode(qrContainer, {
        text: uploadUrl,
        width: 130,
        height: 130,
        correctLevel: QRCode.CorrectLevel.M
      });
      const qrImg = qrContainer.querySelector('img');
      if (qrImg) qrImg.style.margin = '0 auto';
    } catch (e) {
      console.error("Error drawing QR:", e);
      qrContainer.innerHTML = '<span style="color:red; font-size:11px;">Error</span>';
    }
  };
  drawQR();

  // Empezar a buscar si el cliente subió la foto (hacer un sondeo corto cada 3 segundos)
  const pollInterval = setInterval(async () => {
    // Si cerramos el modal, detener el sondeo
    if (document.getElementById('modalPastel').style.display !== 'flex') {
      clearInterval(pollInterval);
      return;
    }

    const filename = `cake_${tempCakeId}.jpg`;
    // Verificar si el archivo ya existe en uploads haciendo una petición HEAD o de verificación
    const checkRes = await fetch(`/uploads/${filename}`, { method: 'HEAD' });
    if (checkRes.ok) {
      clearInterval(pollInterval);
      tempCakeData.photoUrl = `/uploads/${filename}`;
      const preview = document.getElementById('cakePhotoPreview');
      preview.src = `/uploads/${filename}`;
      preview.style.display = 'block';
      const btns = document.getElementById('cakePhotoActionBtns');
      if (btns) btns.style.display = 'flex';
      showToast('¡Foto subida por el cliente con éxito!', 'success');
    }
  }, 3000);
}

// Cargar correos simulados
function loadMockEmails() {
  const select = document.getElementById('emailAttachmentSelect');
  select.innerHTML = '<option value="">Cargando fotos de email...</option>';
  
  setTimeout(() => {
    select.innerHTML = `
      <option value="">-- Elige una foto reciente --</option>
      <option value="email1.jpg">12:35 PM - adjunto_diseño_spiderman.jpg (De: maria@gmail.com)</option>
      <option value="email2.jpg">12:10 PM - pastel_boda_3pisos.png (De: catering_events@gmail.com)</option>
      <option value="email3.jpg">11:45 AM - foto_pastel_infantil.jpg (De: carlos_valle@yahoo.com)</option>
    `;
    
    select.onchange = (e) => {
      if (e.target.value) {
        // En una app real, el backend copiaría este adjunto, aquí simulamos que vincula la imagen
        const fakeUrl = `/uploads/${e.target.value}`;
        tempCakeData.photoUrl = fakeUrl;
        const preview = document.getElementById('cakePhotoPreview');
        // Para que cargue una imagen bonita de prueba, usamos un placeholder
        preview.src = `https://picsum.photos/200/200?random=${Date.now()}`;
        preview.style.display = 'block';
        const btns = document.getElementById('cakePhotoActionBtns');
        if (btns) btns.style.display = 'flex';
        showToast('Foto de correo vinculada');
      }
    };
  }, 1000);
}

// --- ALERTA TOAST ---
function showToast(text, type = 'success') {
  const toast = document.getElementById('toast');
  const toastText = document.getElementById('toastText');
  
  toast.className = `toast ${type}`;
  toastText.innerText = text;
  
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// --- SECUNDARIAS DE OPCIONES Y LEALTAD ---

// CSS flash animation inject dynamically
if (!document.getElementById('waitlist-flash-style')) {
  const style = document.createElement('style');
  style.id = 'waitlist-flash-style';
  style.innerHTML = `
    .btn-waitlist-flashing {
      animation: waitlistGlow 1.5s infinite !important;
    }
    @keyframes waitlistGlow {
      0% { box-shadow: 0 0 4px rgba(255, 159, 10, 0.4); }
      50% { box-shadow: 0 0 16px rgba(255, 159, 10, 0.9); }
      100% { box-shadow: 0 0 4px rgba(255, 159, 10, 0.4); }
    }
  `;
  document.head.appendChild(style);
}

function updateWaitlistBadge() {
  const badge = document.getElementById('lblWaitlistBadge');
  const btn = document.getElementById('btnWaitlistToggle');
  if (!badge || !btn) return;
  
  badge.innerText = waitlist.length;
  if (waitlist.length > 0) {
    badge.style.display = 'inline-flex';
    btn.classList.add('btn-waitlist-flashing');
  } else {
    badge.style.display = 'none';
    btn.classList.remove('btn-waitlist-flashing');
  }
}

function renderWaitlistCashier() {
  const container = document.getElementById('waitlistCashierList');
  if (!container) return;
  container.innerHTML = '';
  
  const isEs = posSettings && posSettings.language === 'es';
  
  if (waitlist.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-secondary);" id="lblWaitlistEmpty">${isEs ? 'Sin personas en espera' : 'No customers waiting'}</div>`;
    return;
  }
  
  waitlist.forEach((item, index) => {
    const el = document.createElement('div');
    el.style.display = 'flex';
    el.style.justifyContent = 'space-between';
    el.style.alignItems = 'center';
    el.style.backgroundColor = 'rgba(255,255,255,0.02)';
    el.style.border = '1px solid var(--border-color)';
    el.style.borderRadius = '8px';
    el.style.padding = '8px 12px';
    
    el.innerHTML = `
      <div style="display: flex; align-items: center; gap: 10px;">
        <span style="background-color: var(--accent-color); color: #000; font-weight: bold; border-radius: 50%; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center; font-size: 11px;">${index + 1}</span>
        <div>
          <div style="font-weight: bold; font-size: 13px; color: #fff;">${item.name}</div>
          <div style="font-size: 11px; color: var(--text-secondary);">${item.phone}</div>
        </div>
      </div>
      <div style="display: flex; gap: 5px;">
        <button class="btn-option" style="padding: 4px 8px; background-color: var(--accent-color); color: #000; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="callWaitlistClient('${item.id}')">🔔 ${isEs ? 'Llamar' : 'Call'}</button>
        <button class="btn-option" style="padding: 4px 8px; background-color: var(--success-color); color: #fff; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="doneWaitlistClient('${item.id}')">✓ ${isEs ? 'Atendido' : 'Done'}</button>
        <button class="btn-option" style="padding: 4px 8px; background-color: var(--danger-color); color: #fff; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="removeWaitlistClient('${item.id}')">✕</button>
      </div>
    `;
    container.appendChild(el);
  });
}

// Global actions for waitlist buttons (called from inline onclicks)
window.callWaitlistClient = async function(id) {
  try {
    const response = await fetch(`${SERVER_URL}/api/waitlist/call`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (response.ok) {
      showToast('Client called successfully!', 'success');
    }
  } catch(e) {
    showToast('Network error calling client', 'error');
  }
};

window.doneWaitlistClient = async function(id) {
  try {
    const response = await fetch(`${SERVER_URL}/api/waitlist/done`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (response.ok) {
      const res = await response.json();
      if (res.client) {
        // Automatically link this client to the current shopping cart ticket!
        currentLoyaltyClient = {
          phone: res.client.phone,
          name: res.client.name,
          points: 10 // default points fallback
        };
        setLoyaltyClientUI();
        
        // Hide waitlist modal
        document.getElementById('modalWaitlist').style.display = 'none';
        showToast(`Linked order for customer: ${res.client.name}!`, 'success');
      }
    }
  } catch(e) {
    showToast('Network error complete', 'error');
  }
};

window.removeWaitlistClient = async function(id) {
  try {
    const response = await fetch(`${SERVER_URL}/api/waitlist/remove`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    if (response.ok) {
      showToast('Client removed from waitlist', 'info');
    }
  } catch(e) {
    showToast('Network error remove', 'error');
  }
};

// --- CAR ORDERS (TACO TRUCK / CARSIDE SELF-ORDERING) SYSTEM ---
async function updateCarOrdersBadge() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    const pendingCars = allOrders.filter(o => 
      (o.deliveryType === 'drive-thru' || o.deliveryType === 'pickup' || o.deliveryType === 'car' ||
       o.type === 'drive-thru' || o.type === 'pickup' || o.type === 'car') && 
      o.paymentStatus === 'unpaid' && 
      o.status !== 'void' && 
      o.status !== 'refunded'
    );
    
    window.carOrdersCache = pendingCars;
    
    const badge = document.getElementById('lblCarOrdersBadge');
    if (badge) {
      badge.innerText = pendingCars.length;
    }
    const btn = document.getElementById('btnCarOrdersToggle');
    if (btn) {
      if (pendingCars.length > 0) {
        btn.classList.add('btn-waitlist-flashing');
      } else {
        btn.classList.remove('btn-waitlist-flashing');
      }
    }
    
    // Auto-update modal if open
    const modal = document.getElementById('modalCarOrders');
    if (modal && modal.style.display === 'flex') {
      renderCarOrdersList();
    }
  } catch (err) {
    console.error("Error loading car orders:", err);
  }
}

function renderCarOrdersList() {
  const container = document.getElementById('carOrdersListContainer');
  if (!container) return;
  container.innerHTML = '';
  
  const pendingCars = window.carOrdersCache || [];
  const isEs = posSettings && posSettings.language === 'es';

  if (pendingCars.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-secondary);">${isEs ? 'Sin pedidos móviles pendientes' : 'No pending mobile/online orders'}</div>`;
    return;
  }
  
  pendingCars.forEach(order => {
    const el = document.createElement('div');
    el.style.backgroundColor = 'rgba(255,255,255,0.02)';
    el.style.border = '1px solid var(--border-color)';
    el.style.borderRadius = '8px';
    el.style.padding = '12px';
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.gap = '6px';
    
    // Summarize items with modifiers/meats
    const itemsSummary = (order.items || []).map(i => {
      const mods = i.selectedModifiers || i.modifiers || [];
      const modsStr = (mods && mods.length) ? ` [${mods.map(m => (typeof m === 'string' ? m : (m.name || m.optionName || ''))).filter(Boolean).join(', ')}]` : '';
      return `${i.quantity}x ${i.name}${modsStr}`;
    }).join(' | ') || (isEs ? 'Sin artículos' : 'No items');

    const ticketNum = order.ticketNumber || (order.id ? order.id.substring(2, 8).toUpperCase() : '1001');
    const ageMins = Math.floor((Date.now() - new Date(order.dateCreated).getTime()) / 60000);
    
    const isDriveThru = (order.deliveryType === 'drive-thru' || order.type === 'drive-thru' || order.deliveryType === 'car');
    const detailLabel = isDriveThru 
      ? `<strong>${isEs ? 'Vehículo / Detalle' : 'Car Detail'}:</strong> ${order.notes || order.vehicle || order.car || (isEs ? 'Sin descripción' : 'No description')}`
      : `<strong>${isEs ? 'Entrega' : 'Pickup'}:</strong> ${isEs ? 'Recoge en ventanilla (Pedido en Línea)' : 'Pick up at window (Online Order)'}`;

    el.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center;">
        <span style="font-weight:bold; color:var(--accent-color); font-size:13px;">Ticket #${ticketNum} - ${order.clientName || 'Cliente'}</span>
        <span style="font-size:10px; color:var(--text-secondary);">${isEs ? 'Hace' : 'Ago'} ${ageMins} mins</span>
      </div>
      <div style="font-size:11px; color:#fff;">Tel: ${order.clientPhone || 'N/A'}</div>
      <div style="font-size:11px; color:var(--text-secondary);">${detailLabel}</div>
      <div style="font-size:11px; color:var(--text-secondary); border-top:1px dashed rgba(255,255,255,0.05); padding-top:6px; margin-top:4px;">
        <strong>${isEs ? 'Artículos' : 'Items'}:</strong> ${itemsSummary}
      </div>
      <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid rgba(255,255,255,0.05); padding-top:8px; margin-top:4px;">
        <span style="font-weight:bold; color:var(--success-color); font-size:13px;">Total: $${parseFloat(order.total).toFixed(2)}</span>
        <div style="display:flex; gap:6px;">
          <button class="btn-option" style="padding: 4px 8px; background-color: #0a84ff; color: #fff; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="printOrderKitchen('${order.id}', false)">${isEs ? 'Cocina' : 'Kitchen'}</button>
          <button class="btn-option" style="padding: 4px 8px; background-color: var(--accent-color); color: #000; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="callCarOrderSMS('${order.id}')">${isEs ? 'Llamar' : 'Call'}</button>
          <button class="btn-option" style="padding: 4px 8px; background-color: var(--success-color); color: #fff; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="payCarOrder('${order.id}')">${isEs ? 'Cobrar' : 'Pay'}</button>
          <button class="btn-option" style="padding: 4px 8px; background-color: var(--danger-color); color: #fff; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; border: none;" onclick="cancelCarOrder('${order.id}')">✕</button>
        </div>
      </div>
    `;
    container.appendChild(el);
  });
}

window.callCarOrderSMS = async function(id) {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/${id}/call-sms`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    if (res.ok) {
      showToast('Client notified successfully!', 'success');
      updateCarOrdersBadge();
    }
  } catch(e) {
    showToast('Network error calling client', 'error');
  }
};

window.payCarOrder = async function(id) {
  document.getElementById('modalCarOrders').style.display = 'none';
  await recallCashierTab(id);
};

window.cancelCarOrder = async function(id) {
  const isEs = posSettings && posSettings.language === 'es';
  if (!confirm(isEs ? '¿Seguro que deseas cancelar esta orden?' : 'Are you sure you want to cancel this order?')) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'void' })
    });
    if (res.ok) {
      showToast('Order cancelled', 'info');
      updateCarOrdersBadge();
    }
  } catch (e) {
    showToast('Network error cancelling order', 'error');
  }
};

// --- TO GO ORDERS STATUS SYSTEM ---
let togoCurrentPage = 0;

window.togoPrevPage = function() {
  if (togoCurrentPage > 0) {
    togoCurrentPage--;
    updateToGoBadgeAndModal();
  }
};

window.togoNextPage = function() {
  togoCurrentPage++;
  updateToGoBadgeAndModal();
};

async function updateToGoBadgeAndModal() {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    
    const now = Date.now();
    const cutoffTime = now - (48 * 60 * 60 * 1000); // 48 hours ago
    const todayStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    
    const activeToGo = allOrders.filter(o => {
      const isActiveStatus = (o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion' || o.status === 'listo');
      if (!isActiveStatus) return false;
      
      const hasCustomCake = o.items && o.items.some(i => i.isCustomCake);
      if (hasCustomCake) return false;

      // Filter strictly by deliveryType 'llevar'
      if (o.deliveryType !== 'llevar') return false;
      
      const createdTime = new Date(o.dateCreated).getTime();
      const isRecent = createdTime > cutoffTime;
      const isScheduledTodayOrFuture = o.scheduledDate && (o.scheduledDate >= todayStr);
      
      return isRecent || isScheduledTodayOrFuture;
    });
    
    // Sort strictly chronologically: oldest first
    activeToGo.sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
    
    // Update Badge
    const badge = document.getElementById('lblToGoBadge');
    if (badge) {
      badge.innerText = activeToGo.length;
      const btn = document.getElementById('btnToGoStatusToggle');
      if (activeToGo.length > 0) {
        badge.style.display = 'inline-flex';
        btn.classList.add('btn-waitlist-flashing');
      } else {
        badge.style.display = 'none';
        btn.classList.remove('btn-waitlist-flashing');
      }
    }
    
    // Pagination logic
    const itemsPerPage = 15;
    const totalPages = Math.ceil(activeToGo.length / itemsPerPage);
    if (togoCurrentPage >= totalPages && totalPages > 0) {
      togoCurrentPage = totalPages - 1;
    }
    if (togoCurrentPage < 0) togoCurrentPage = 0;
    
    // Render pagination controls in header
    const controlsContainer = document.getElementById('togoPaginationControls');
    if (controlsContainer) {
      controlsContainer.innerHTML = `
        <span style="color: #fff; font-size: 12px; font-weight: bold; margin-right: 8px;">
          Page / Pág ${togoCurrentPage + 1} of ${totalPages || 1}
        </span>
        <button class="btn-header" onclick="togoPrevPage()" ${togoCurrentPage === 0 ? 'disabled' : ''} style="padding: 4px 10px; font-size: 11px;">◀ Prev</button>
        <button class="btn-header" onclick="togoNextPage()" ${togoCurrentPage >= totalPages - 1 ? 'disabled' : ''} style="padding: 4px 10px; font-size: 11px; margin-left: 4px;">Next ▶</button>
      `;
    }
    
    // Slice active page's orders
    const pageOrders = activeToGo.slice(togoCurrentPage * itemsPerPage, (togoCurrentPage + 1) * itemsPerPage);
    
    // Render Modal list if open
    const modal = document.getElementById('modalToGoOrders');
    if (modal && modal.style.display === 'flex') {
      renderToGoOrdersList(pageOrders);
    }
  } catch (e) {
    console.error("Error updating ToGo status:", e);
  }
}

function renderToGoOrdersList(togoOrders) {
  const container = document.getElementById('togoOrdersContainer');
  if (!container) return;
  
  const isEs = posSettings && posSettings.language === 'es';
  
  if (togoOrders.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-secondary); grid-column: span 5;">${isEs ? 'Sin pedidos para llevar activos' : 'No active to-go orders'}</div>`;
    return;
  }
  
  container.style.cssText = "display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; width: 100%; overflow: hidden; padding: 4px; max-height: calc(95vh - 120px);";
  container.innerHTML = togoOrders.map(o => createOrderCardHtml(o, isEs, 'togo')).join('');
}

window.deliverToGoOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'entregado' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido entregado con éxito!' : 'Order delivered successfully!', 'success');
      updateToGoBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.bumpToGoOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'listo' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido completado!' : 'Order completed!', 'success');
      updateToGoBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.deliverPhoneOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'entregado' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido entregado con éxito!' : 'Order delivered successfully!', 'success');
      updatePhoneOrdersBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.bumpPhoneOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'listo' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido completado!' : 'Order completed!', 'success');
      updatePhoneOrdersBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.deliverOnlineOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'entregado' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido entregado con éxito!' : 'Order delivered successfully!', 'success');
      updateOnlineOrdersBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.bumpOnlineOrder = async function(orderId) {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'listo' })
    });
    if (response.ok) {
      showToast(isEs ? '¡Pedido completado!' : 'Order completed!', 'success');
      updateOnlineOrdersBadgeAndModal();
    } else {
      showToast('Error', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Connection error', 'error');
  }
};

window.phonePrevPage = function() {
  if (phoneCurrentPage > 0) {
    phoneCurrentPage--;
    updatePhoneOrdersBadgeAndModal();
  }
};
window.phoneNextPage = function() {
  phoneCurrentPage++;
  updatePhoneOrdersBadgeAndModal();
};
window.onlinePrevPage = function() {
  if (onlineCurrentPage > 0) {
    onlineCurrentPage--;
    updateOnlineOrdersBadgeAndModal();
  }
};
window.onlineNextPage = function() {
  onlineCurrentPage++;
  updateOnlineOrdersBadgeAndModal();
};

let phoneCurrentPage = 0;
window.updatePhoneOrdersBadgeAndModal = async function() {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    
    const now = Date.now();
    const cutoffTime = now - (48 * 60 * 60 * 1000);
    const todayStr = new Date().toISOString().split('T')[0];
    
    const activePhone = allOrders.filter(o => {
      const isActiveStatus = (o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion' || o.status === 'listo');
      if (!isActiveStatus) return false;
      
      const hasCustomCake = o.items && o.items.some(i => i.isCustomCake);
      if (hasCustomCake) return false;

      // Filter by deliveryType phone
      if (o.deliveryType !== 'phone') return false;
      
      const createdTime = new Date(o.dateCreated).getTime();
      const isRecent = createdTime > cutoffTime;
      const isScheduledTodayOrFuture = o.scheduledDate && (o.scheduledDate >= todayStr);
      
      return isRecent || isScheduledTodayOrFuture;
    });
    
    activePhone.sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
    
    const badge = document.getElementById('lblPhoneOrdersBadge');
    if (badge) {
      badge.innerText = activePhone.length;
      const btn = document.getElementById('btnPhoneOrdersToggle');
      if (activePhone.length > 0) {
        badge.style.display = 'inline-flex';
        btn.classList.add('btn-waitlist-flashing');
      } else {
        badge.style.display = 'none';
        btn.classList.remove('btn-waitlist-flashing');
      }
    }
    
    const itemsPerPage = 15;
    const totalPages = Math.ceil(activePhone.length / itemsPerPage);
    if (phoneCurrentPage >= totalPages && totalPages > 0) {
      phoneCurrentPage = totalPages - 1;
    }
    if (phoneCurrentPage < 0) phoneCurrentPage = 0;
    
    const modal = document.getElementById('modalPhoneOrders');
    if (modal && modal.style.display === 'flex') {
      renderPhoneOrdersList(activePhone.slice(phoneCurrentPage * itemsPerPage, (phoneCurrentPage + 1) * itemsPerPage));
    }
  } catch (e) {
    console.error("Error updating Phone status:", e);
  }
};

function renderPhoneOrdersList(orders) {
  const container = document.getElementById('phoneOrdersListContainer');
  if (!container) return;
  const isEs = posSettings && posSettings.language === 'es';
  if (orders.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-secondary); width: 100%;">${isEs ? 'Sin pedidos por teléfono activos' : 'No active phone orders'}</div>`;
    return;
  }
  container.style.cssText = "display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; width: 100%; overflow: hidden; padding: 4px;";
  container.innerHTML = orders.map(o => createOrderCardHtml(o, isEs, 'phone')).join('');
}

let onlineCurrentPage = 0;
window.updateOnlineOrdersBadgeAndModal = async function() {
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (!res.ok) return;
    const allOrders = await res.json();
    
    const now = Date.now();
    const cutoffTime = now - (48 * 60 * 60 * 1000);
    const todayStr = new Date().toISOString().split('T')[0];
    
    const activeOnline = allOrders.filter(o => {
      const isActiveStatus = (o.status === 'pendiente' || o.status === 'en_preparacion' || o.status === 'en_decoracion' || o.status === 'listo');
      if (!isActiveStatus) return false;
      
      const hasCustomCake = o.items && o.items.some(i => i.isCustomCake);
      if (hasCustomCake) return false;

      // Filter online orders (cashierName 'Cliente Móvil' or pickup/delivery type from online)
      const isOnline = o.cashierName === 'Cliente Móvil' || (o.notes && o.notes.includes('[Online]'));
      if (!isOnline) return false;
      
      const createdTime = new Date(o.dateCreated).getTime();
      const isRecent = createdTime > cutoffTime;
      const isScheduledTodayOrFuture = o.scheduledDate && (o.scheduledDate >= todayStr);
      
      return isRecent || isScheduledTodayOrFuture;
    });
    
    activeOnline.sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
    
    const badge = document.getElementById('lblOnlineOrdersBadge');
    if (badge) {
      badge.innerText = activeOnline.length;
      const btn = document.getElementById('btnOnlineOrdersToggle');
      if (activeOnline.length > 0) {
        badge.style.display = 'inline-flex';
        btn.classList.add('btn-waitlist-flashing');
      } else {
        badge.style.display = 'none';
        btn.classList.remove('btn-waitlist-flashing');
      }
    }
    
    const itemsPerPage = 15;
    const totalPages = Math.ceil(activeOnline.length / itemsPerPage);
    if (onlineCurrentPage >= totalPages && totalPages > 0) {
      onlineCurrentPage = totalPages - 1;
    }
    if (onlineCurrentPage < 0) onlineCurrentPage = 0;
    
    const modal = document.getElementById('modalOnlineOrders');
    if (modal && modal.style.display === 'flex') {
      renderOnlineOrdersList(activeOnline.slice(onlineCurrentPage * itemsPerPage, (onlineCurrentPage + 1) * itemsPerPage));
    }
  } catch (e) {
    console.error("Error updating Online status:", e);
  }
};

function renderOnlineOrdersList(orders) {
  const container = document.getElementById('onlineOrdersListContainer');
  if (!container) return;
  const isEs = posSettings && posSettings.language === 'es';
  if (orders.length === 0) {
    container.innerHTML = `<div style="text-align: center; padding: 20px; color: var(--text-secondary); width: 100%;">${isEs ? 'Sin pedidos online activos' : 'No active online orders'}</div>`;
    return;
  }
  container.style.cssText = "display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; width: 100%; overflow: hidden; padding: 4px;";
  container.innerHTML = orders.map(o => createOrderCardHtml(o, isEs, 'online')).join('');
}

function createOrderCardHtml(o, isEs, channel) {
  const safeType = (o.type && o.type !== 'undefined') ? o.type : (o.deliveryType && o.deliveryType !== 'undefined' ? o.deliveryType : 'llevar');
  let typeBadgeColor = 'var(--bg-tertiary)';
  if (safeType === 'drive-thru' || safeType === 'car') typeBadgeColor = 'var(--danger-color)';
  else if (safeType === 'llevar' || safeType === 'togo' || safeType === 'pickup') typeBadgeColor = 'var(--accent-color)';
  else if (safeType === 'delivery') typeBadgeColor = '#30d158';
  else if (safeType === 'phone') typeBadgeColor = '#ff9f0a';
  
  let typeDisplayLabel = 'TO GO';
  if (safeType === 'drive-thru' || safeType === 'car') {
    typeDisplayLabel = 'DRIVE THRU';
  } else if (safeType === 'delivery') {
    typeDisplayLabel = 'DELIVERY';
  } else if (safeType === 'phone') {
    typeDisplayLabel = 'PHONE';
  } else if (safeType === 'llevar' || safeType === 'togo' || safeType === 'pickup') {
    typeDisplayLabel = 'TO GO';
  } else {
    typeDisplayLabel = safeType.replace(/[-_]/g, ' ').toUpperCase();
  }
  
  let statusLabel = o.status;
  let statusColor = '#ff9f0a';
  if (o.status === 'listo') {
    statusLabel = isEs ? 'LISTO' : 'READY';
    statusColor = '#30d158';
  } else if (o.status === 'pendiente') {
    statusLabel = isEs ? 'PENDING' : 'PENDING';
    statusColor = '#ff453a';
  } else if (o.status === 'en_preparacion') {
    statusLabel = isEs ? 'PREPARING' : 'PREPARING';
    statusColor = '#ff9f0a';
  }
  
  let itemsHtml = '';
  if (o.items && o.items.length > 0) {
    o.items.forEach(i => {
      let specsText = '';
      if (i.options) {
        specsText = `<div style="font-size: 9px; color: var(--text-secondary); margin-left: 8px;">- ${safeEscapeHtml(i.options)}</div>`;
      }
      itemsHtml += `
        <div style="font-size: 11px; color: #fff; margin-bottom: 2px; line-height: 1.2;">
          <span style="font-weight: bold; color: var(--accent-color);">${i.quantity}x</span> 
          <span>${safeEscapeHtml(i.name)}</span>
          ${specsText}
        </div>
      `;
    });
  }
  
  let actionButton = '';
  let completeCallback = 'deliverToGoOrder';
  let readyCallback = 'bumpToGoOrder';
  if (channel === 'phone') {
    completeCallback = 'deliverPhoneOrder';
    readyCallback = 'bumpPhoneOrder';
  } else if (channel === 'online') {
    completeCallback = 'deliverOnlineOrder';
    readyCallback = 'bumpOnlineOrder';
  }
  
  if (o.status === 'listo') {
    actionButton = `
      <button class="btn-option" style="padding: 4px 2px; background-color: var(--success-color); color: #000; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="${completeCallback}('${o.id}')">
        ${isEs ? 'Entregar' : 'Deliver'}
      </button>
    `;
  } else {
    actionButton = `
      <button class="btn-option" style="padding: 4px 2px; background-color: var(--accent-color); color: #000; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="${readyCallback}('${o.id}')">
        ${isEs ? 'Listo' : 'Ready'}
      </button>
    `;
  }
  
  let gridButtons = `
    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; width: 100%;">
      ${actionButton}
      <button class="btn-option" style="padding: 4px 2px; background-color: #f39c12; color: #000; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="recallAndCloseToGo('${o.id}')">
        ${isEs ? 'Abrir' : 'Recall'}
      </button>
      <button class="btn-option" style="padding: 4px 2px; background-color: #007aff; color: #fff; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="openToGoLabelModal('${o.id}')">
        ${isEs ? 'Etiqueta' : 'Label'}
      </button>
      <button class="btn-option" style="padding: 4px 2px; background-color: #8e8e93; color: #fff; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="printReceipt('${o.id}')">
        ${isEs ? 'Ticket' : 'Ticket'}
      </button>
      <button class="btn-option" style="padding: 4px 2px; background-color: #555; color: #fff; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="reprintToGoKitchen('${o.id}')">
        ${isEs ? 'Cocina' : 'Kitchen'}
      </button>
      <button class="btn-option" style="padding: 4px 2px; background-color: var(--danger-color); color: #fff; border-radius: 4px; font-size: 8px; font-weight: bold; cursor: pointer; border: none; height: 26px; text-transform: uppercase;" onclick="voidToGoOrder('${o.id}')">
        ${isEs ? 'Anular' : 'Void'}
      </button>
    </div>
  `;
  
  const timeStr = o.dateCreated ? new Date(o.dateCreated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
  const safeTicket = (o.ticketNumber && o.ticketNumber !== 'undefined') ? o.ticketNumber : (o.id ? o.id.substring(2, 8).toUpperCase() : '-');
  const safeClientName = (o.clientName && o.clientName !== 'undefined') ? o.clientName : (isEs ? 'Sin Cliente' : 'No Name');
  
  return `
    <div style="background-color: #1a1a1f; border: 2px solid #333; border-radius: 12px; min-height: 230px; display: flex; flex-direction: column; padding: 6px; box-shadow: 0 4px 10px rgba(0,0,0,0.4); justify-content: space-between;">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 3px; font-size: 11px;">
        <span style="font-weight: bold; color: #fff;">#${safeTicket}</span>
        <span style="background: ${typeBadgeColor}; color: ${(safeType === 'llevar' || safeType === 'togo' || safeType === 'pickup') ? '#000' : '#fff'}; padding: 1px 4px; border-radius: 3px; font-weight: bold; font-size: 9px; text-transform: uppercase;">${typeDisplayLabel}</span>
      </div>
      
      <div style="flex: 1; overflow-y: auto; margin: 4px 0; padding-right: 2px;">
        <div style="font-size: 10px; color: var(--text-secondary); margin-bottom: 4px;">
          <span>${safeEscapeHtml(safeClientName)}</span>
          <span style="float: right;">${timeStr}</span>
        </div>
        ${itemsHtml}
      </div>
      
      <div style="border-top: 1px solid rgba(255,255,255,0.05); padding-top: 4px; display: flex; flex-direction: column; gap: 4px;">
        <div style="display: flex; justify-content: space-between; font-size: 10px; font-weight: bold;">
          <span style="color: ${statusColor};">${statusLabel}</span>
          <span style="color: var(--accent-color); font-size: 11px;">$${parseFloat(o.total || 0).toFixed(2)}</span>
        </div>
        ${gridButtons}
      </div>
    </div>
  `;
}

window.recallAndCloseToGo = async function(orderId) {
  const mToGo = document.getElementById('modalToGoOrders');
  if (mToGo) mToGo.style.display = 'none';
  const mPhone = document.getElementById('modalPhoneOrders');
  if (mPhone) mPhone.style.display = 'none';
  const mOnline = document.getElementById('modalOnlineOrders');
  if (mOnline) mOnline.style.display = 'none';
  const mCar = document.getElementById('modalCarOrders');
  if (mCar) mCar.style.display = 'none';
  await recallCashierTab(orderId);
};

window.voidToGoOrder = async function(orderId) {
  const isEs = posSettings && posSettings.language === 'es';
  if (!confirm(isEs ? '¿Seguro que deseas anular esta orden?' : 'Are you sure you want to void/cancel this order?')) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'void' })
    });
    if (res.ok) {
      showToast(isEs ? 'Orden anulada exitosamente' : 'Order voided successfully', 'info');
      if (typeof updateToGoBadgeAndModal === 'function') updateToGoBadgeAndModal();
      if (typeof updatePhoneOrdersBadge === 'function') updatePhoneOrdersBadge();
      if (typeof updateOnlineOrdersBadge === 'function') updateOnlineOrdersBadge();
      if (typeof updateActiveTabsCount === 'function') updateActiveTabsCount();
      if (typeof updateCarOrdersBadge === 'function') updateCarOrdersBadge();
    } else {
      showToast(isEs ? 'Error al anular orden' : 'Error voiding order', 'error');
    }
  } catch(e) {
    showToast('Network error voiding order', 'error');
  }
};

window.printReceipt = function(orderId) {
  printOrderReceipt(orderId);
};

window.reprintToGoKitchen = function(orderId) {
  printOrderKitchen(orderId, false);
};

window.openToGoLabelModal = async function(orderId) {
  let order = (window.togoOrdersCache || []).find(o => o.id === orderId) ||
               (window.carOrdersCache || []).find(o => o.id === orderId);
  
  if (!order) {
    try {
      const res = await fetch(`${SERVER_URL}/api/orders`);
      if (res.ok) {
        const all = await res.json();
        order = all.find(o => o.id === orderId);
      }
    } catch (e) {
      console.error(e);
    }
  }

  if (!order) {
    showToast('No se encontró la orden', 'error');
    return;
  }

  document.getElementById('togoPrintLabelOrderId').value = orderId;
  document.getElementById('chkPrintMainLabel').checked = true;
  document.getElementById('chkSelectAllItems').checked = false;

  const listContainer = document.getElementById('togoPrintLabelItemsList');
  listContainer.innerHTML = '';

  (order.items || []).forEach((item, idx) => {
    const row = document.createElement('label');
    row.style.display = 'flex';
    row.style.alignItems = 'center';
    row.style.gap = '8px';
    row.style.padding = '6px 8px';
    row.style.backgroundColor = 'rgba(255,255,255,0.02)';
    row.style.border = '1px solid rgba(255,255,255,0.05)';
    row.style.borderRadius = '6px';
    row.style.cursor = 'pointer';
    row.style.fontSize = '12px';

    row.innerHTML = `
      <input type="checkbox" data-index="${idx}" style="accent-color: var(--accent-color); width: 16px; height: 16px;">
      <span>${item.quantity}x ${item.name}</span>
    `;
    listContainer.appendChild(row);
  });

  document.getElementById('modalToGoPrintLabel').style.display = 'flex';
};

async function generateLoyaltyQR() {
  const qrContainer = document.getElementById('loyaltyQRContainer');
  if (!qrContainer) return;
  qrContainer.innerHTML = 'Generando QR...';
  
  let targetUrl = `${window.location.origin}/autoregistro.html`; // fallback local
  try {
    const response = await fetch(`${SERVER_URL}/api/tunnel-url`);
    if (response.ok) {
      const data = await response.json();
      if (data.url) {
        const baseUrl = data.url.endsWith('/') ? data.url.slice(0, -1) : data.url;
        targetUrl = `${baseUrl}/autoregistro.html`;
      }
    }
  } catch(e) {
    console.warn("Could not fetch public tunnel URL. Using local origin.", e);
  }
  
  // Ensure no loopback localhost IP is written to the QR code
  if (targetUrl.includes('localhost') || targetUrl.includes('127.0.0.1')) {
    try {
      const ipRes = await fetch(`${SERVER_URL}/api/local-ip`);
      if (ipRes.ok) {
        const ipData = await ipRes.json();
        if (ipData.ip && ipData.ip !== '127.0.0.1') {
          targetUrl = targetUrl.replace('localhost', ipData.ip).replace('127.0.0.1', ipData.ip);
        }
      }
    } catch(e) {}
  }
  
  try {
    qrContainer.innerHTML = '';
    new QRCode(qrContainer, {
      text: targetUrl,
      width: 120,
      height: 120,
      correctLevel: QRCode.CorrectLevel.M
    });
    const qrImg = qrContainer.querySelector('img');
    if (qrImg) qrImg.style.margin = '0 auto';
  } catch(err) {
    console.error("Error drawing loyalty QR:", err);
    qrContainer.innerHTML = '<span style="color:red; font-size:10px;">Error</span>';
  }
}

// Abre modal de opciones para el cliente de lealtad
function openLoyaltyActionsModal(client) {
  tempLoyaltyClient = client;
  document.getElementById('modalLoyalty').style.display = 'none';
  document.getElementById('loyaltyActionName').innerText = client.type === 'company' ? `${client.companyName} (${client.name})` : client.name;
  document.getElementById('loyaltyActionPhone').innerText = `${client.phone} | ${client.address || 'No Address'}`;
  document.getElementById('loyaltyActionPoints').innerText = client.points;
  document.getElementById('loyaltyHistoryContainer').style.display = 'none';
  document.getElementById('modalLoyaltyActions').style.display = 'flex';
}

// Carga las órdenes de manager
async function loadOptionsOrders() {
  const container = document.getElementById('optionsTicketsTableBody');
  container.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: var(--text-secondary);">Loading orders...</td></tr>';
  
  const searchVal = document.getElementById('optionsSearchInput').value.trim().toLowerCase();

  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      let orders = await response.json();
      
      // Filtrar si hay búsqueda
      if (searchVal) {
        orders = orders.filter(o => {
          const tNum = String(o.ticketNumber || '').toLowerCase();
          const phone = String(o.clientLoyalty || '').toLowerCase();
          return tNum.includes(searchVal) || phone.includes(searchVal);
        });
      }

      // Ordenar por fecha decreciente (las más recientes primero)
      orders.sort((a, b) => new Date(b.dateCreated) - new Date(a.dateCreated));

      renderOptionsOrders(orders);
    } else {
      container.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: var(--danger-color);">Error loading orders from server</td></tr>';
    }
  } catch (e) {
    console.error(e);
    container.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: var(--danger-color);">Connection error</td></tr>';
  }
}

// Renderiza las órdenes de manager en la tabla
function renderOptionsOrders(orders) {
  const container = document.getElementById('optionsTicketsTableBody');
  container.innerHTML = '';

  if (orders.length === 0) {
    container.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: var(--text-secondary);">No orders found.</td></tr>';
    return;
  }

  orders.forEach(order => {
    const dateStr = new Date(order.dateCreated).toLocaleString('en-US', {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'
    });
    const customerText = order.clientLoyalty || 'Walk-in';
    
    let statusText = 'COMPLETED';
    if (order.status === 'void') statusText = 'VOIDED';
    else if (order.status === 'refunded') statusText = 'REFUNDED';
    
    let statusColor = 'var(--success-color)';
    if (order.status === 'void') statusColor = 'var(--danger-color)';
    else if (order.status === 'refunded') statusColor = '#ff9f0a';

    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid var(--border-color)';
    
    // Botones de acciones
    const isCompleted = order.status !== 'void' && order.status !== 'refunded';
    const hasCustomCake = order.items && order.items.some(i => i.isCustomCake);
    
    let actionsHtml = `
      <button class="btn-modal secondary" onclick="openViewOrderDialog('${order.id}')" style="font-size: 11px; padding: 4px 8px; margin-top:0; background-color: var(--accent-color); color: #000; border-color: var(--accent-color); font-weight: bold; margin-right: 4px;">View</button>
      <button class="btn-modal secondary" onclick="printOrderReceipt('${order.id}')" style="font-size: 11px; padding: 4px 8px; margin-top:0; margin-right: 4px;">Print Ticket</button>
      <button class="btn-modal secondary" onclick="printOrderKitchen('${order.id}', ${hasCustomCake})" style="font-size: 11px; padding: 4px 8px; margin-top:0; background-color: #0a84ff; color: #fff; border-color: #0a84ff; margin-right: 4px;">Print Kitchen</button>
      <button class="btn-modal secondary" onclick="printOrderInvoice('${order.id}')" style="font-size: 11px; padding: 4px 8px; margin-top:0; background-color: #32d74b; color: #000; border-color: #32d74b; font-weight: bold; margin-right: 4px;">Print Invoice</button>
    `;
    
    if (isCompleted) {
      actionsHtml += `
        <button class="btn-modal secondary danger" onclick="openVoidDialog('${order.id}', ${order.ticketNumber || 0})" style="font-size: 11px; padding: 4px 8px; margin-top:0; background-color: var(--danger-color); color: #fff; border-color: var(--danger-color); margin-right: 4px;">Void</button>
        <button class="btn-modal secondary warning" onclick="openRefundDialog('${order.id}', ${order.ticketNumber || 0})" style="font-size: 11px; padding: 4px 8px; margin-top:0; background-color: #ff9f0a; color: #000; border-color: #ff9f0a; margin-right: 4px;">Refund</button>
      `;
    }

    tr.innerHTML = `
      <td style="padding: 10px; font-weight: bold;">#${order.ticketNumber || 'N/A'}</td>
      <td style="padding: 10px; color: var(--text-secondary);">${dateStr}</td>
      <td style="padding: 10px;">${customerText}</td>
      <td style="padding: 10px; font-weight: bold; color: var(--accent-color);">$${order.total.toFixed(2)}</td>
      <td style="padding: 10px; font-weight: bold; color: ${statusColor};">${statusText}</td>
      <td style="padding: 10px; text-align: right;">${actionsHtml}</td>
    `;
    container.appendChild(tr);
  });
}

async function printOrderReceipt(orderId) {
  try {
    const response = await fetch(`${SERVER_URL}/api/printer/print-receipt/${orderId}`, { method: 'POST' });
    if (response.ok) {
      showToast('Receipt sent to printer successfully!', 'success');
    } else {
      const errData = await response.json();
      showToast(`Printing failed: ${errData.error || 'Unknown error'}`, 'error');
    }
  } catch (e) {
    console.error(e);
    showToast('Printer connection error', 'error');
  }
}

window.printOrderInvoice = function(orderId) {
  if (window.electronAPI && window.electronAPI.printInvoiceSilent) {
    window.electronAPI.printInvoiceSilent(orderId);
    showToast(currentLanguage === 'es' ? 'Enviando Invoice a la impresora grande...' : 'Sending Invoice to printer...', 'success');
  } else {
    showToast(currentLanguage === 'es' ? 'Impresión de Invoices solo disponible en la app nativa.' : 'Invoice printing only available in native app.', 'error');
  }
};

window.printCustomCakeComanda = function(orderId) {
  if (window.electronAPI && window.electronAPI.printCakeSilent) {
    window.electronAPI.printCakeSilent(orderId);
    showToast(currentLanguage === 'es' ? 'Enviando hoja de trabajo a la impresora...' : 'Sending work sheet to printer...', 'success');
  } else {
    fetch(`${SERVER_URL}/api/printer/print-cake-silent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId })
    })
    .then(res => {
      if (res.ok) {
        showToast(currentLanguage === 'es' ? '¡Hoja de trabajo impresa silenciosamente!' : 'Work sheet printed silently!', 'success');
      } else {
        window.open(`/comanda_pastel.html?orderId=${orderId}&v=26.0`, '_blank');
      }
    })
    .catch(() => {
      window.open(`/comanda_pastel.html?orderId=${orderId}&v=26.0`, '_blank');
    });
  }
};

async function printOrderKitchen(orderId, hasCustomCake) {
  if (hasCustomCake) {
    window.printCustomCakeComanda(orderId);
    return;
  }
  
  try {
    const isEs = posSettings && posSettings.language === 'es';
    const response = await fetch(`${SERVER_URL}/api/printer/print-kitchen/${orderId}?printerIndex=2`, { method: 'POST' });
    if (response.ok) {
      showToast(isEs ? 'Comanda enviada a cocina con exito' : 'Kitchen ticket sent to printer successfully!', 'success');
    } else {
      let errMsg = 'Error';
      try {
        const errData = await response.json();
        errMsg = errData.error || errMsg;
      } catch (e) {}
      showToast(isEs ? `Fallo de impresion en cocina: ${errMsg}` : `Kitchen printing failed: ${errMsg}`, 'error');
    }
  } catch (e) {
    console.error(e);
    const isEs = posSettings && posSettings.language === 'es';
    showToast(isEs ? 'Error de conexion con la impresora' : 'Printer connection error', 'error');
  }
}

async function reprintOrder(orderId) {
  // Fallback reprint helper
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      const orders = await response.json();
      const order = orders.find(o => o.id === orderId);
      if (order) {
        const hasCustomCake = order.items.some(i => i.isCustomCake);
        if (hasCustomCake) {
          printOrderKitchen(orderId, true);
        } else {
          printOrderReceipt(orderId);
        }
      }
    }
  } catch(e) {
    console.error(e);
  }
}

// Abre modal de detalles de orden/ticket
async function openViewOrderDialog(orderId) {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      const orders = await response.json();
      const order = orders.find(o => o.id === orderId);
      if (!order) return;
      
      const modal = document.getElementById('modalViewOrderDetails');
      const title = document.getElementById('viewOrderTitle');
      const meta = document.getElementById('viewOrderMeta');
      const itemsList = document.getElementById('viewOrderItemsList');
      const summary = document.getElementById('viewOrderSummary');
      const footerActions = document.getElementById('viewOrderFooterActions');
      
      title.innerText = `Ticket #${order.ticketNumber || 'N/A'} Details`;
      
      // Meta
      const dateStr = new Date(order.dateCreated).toLocaleString('en-US');
      meta.innerHTML = `
        <strong>Date/Time:</strong> ${dateStr}<br>
        <strong>Cashier:</strong> ${order.employeeName || 'System'}<br>
        <strong>Customer Loyalty:</strong> ${order.clientLoyalty || 'Walk-in'}<br>
        <strong>Status:</strong> <span style="color: ${order.status === 'void' ? 'var(--danger-color)' : order.status === 'refunded' ? '#ff9f0a' : 'var(--success-color)'}; font-weight: bold;">${(order.status || 'completed').toUpperCase()}</span>
      `;
      
      // Items
      itemsList.innerHTML = '';
      order.items.forEach(item => {
        const itemRow = document.createElement('div');
        itemRow.style.display = 'flex';
        itemRow.style.justifyContent = 'space-between';
        itemRow.style.padding = '6px 0';
        itemRow.style.borderBottom = '1px dashed var(--border-color)';
        
        let detailsHtml = '';
        if (item.isCustomCake && item.details) {
          detailsHtml = `<div style="font-size: 11px; color: var(--text-secondary); margin-top: 2px;">
            Size: ${item.details.size || 'N/A'} | Flavor: ${item.details.flavor || 'N/A'}
            ${item.details.fruits && item.details.fruits.length > 0 ? `<br>Fruits: ${item.details.fruits.join(', ')}` : ''}
            ${item.details.fillings && item.details.fillings.length > 0 ? `<br>Fillings: ${item.details.fillings.join(', ')}` : ''}
          </div>`;
        }
        
        itemRow.innerHTML = `
          <div>
            <div style="font-weight: 600;">${item.quantity}x ${item.name}</div>
            ${detailsHtml}
          </div>
          <div style="font-weight: bold; color: var(--accent-color);">$${(item.price * item.quantity).toFixed(2)}</div>
        `;
        itemsList.appendChild(itemRow);
      });
      
      // Summary
      let changeHtml = '';
      if (order.changeGiven !== undefined) {
        changeHtml = `
          <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary);">
            <span>Change Given:</span>
            <span>$${order.changeGiven.toFixed(2)}</span>
          </div>
        `;
      }
      summary.innerHTML = `
        <div style="display: flex; justify-content: space-between;">
          <span>Subtotal:</span>
          <span>$${order.subtotal ? order.subtotal.toFixed(2) : order.total.toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between;">
          <span>Discount:</span>
          <span>-$${order.discount ? order.discount.toFixed(2) : '0.00'}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 16px; border-top: 1px dashed var(--border-color); padding-top: 6px;">
          <span>Total:</span>
          <span style="color: var(--accent-color);">$${order.total.toFixed(2)}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary); margin-top: 6px;">
          <span>Payment Method:</span>
          <span style="text-transform: capitalize;">${order.paymentMethod || 'Cash'}</span>
        </div>
        ${changeHtml}
      `;
      
      // Actions
      footerActions.innerHTML = '';
      
      const hasCustomCake = order.items && order.items.some(i => i.isCustomCake);
      
      // 1. Print Ticket (Receipt)
      const btnReceipt = document.createElement('button');
      btnReceipt.className = 'btn-modal secondary';
      btnReceipt.style.fontSize = '11px';
      btnReceipt.style.padding = '5px 10px';
      btnReceipt.style.margin = '2px';
      btnReceipt.innerText = 'Print Ticket';
      btnReceipt.onclick = () => {
        printOrderReceipt(order.id);
        modal.style.display = 'none';
      };
      footerActions.appendChild(btnReceipt);

      // 2. Print Kitchen / Bakers
      const btnKitchen = document.createElement('button');
      btnKitchen.className = 'btn-modal';
      btnKitchen.style.backgroundColor = '#0a84ff';
      btnKitchen.style.color = '#fff';
      btnKitchen.style.borderColor = '#0a84ff';
      btnKitchen.style.fontSize = '11px';
      btnKitchen.style.padding = '5px 10px';
      btnKitchen.style.margin = '2px';
      btnKitchen.innerText = 'Print Kitchen';
      btnKitchen.onclick = () => {
        printOrderKitchen(order.id, hasCustomCake);
        modal.style.display = 'none';
      };
      footerActions.appendChild(btnKitchen);

      // 2b. Collect Payment (if unpaid)
      if (order.paymentStatus === 'unpaid') {
        const btnCollect = document.createElement('button');
        btnCollect.className = 'btn-modal';
        btnCollect.style.backgroundColor = '#bf5af2';
        btnCollect.style.color = '#fff';
        btnCollect.style.borderColor = '#bf5af2';
        btnCollect.style.fontSize = '11px';
        btnCollect.style.padding = '5px 10px';
        btnCollect.style.margin = '2px';
        btnCollect.innerText = posSettings.language === 'es' ? '💵 Cobrar Pago' : '💵 Collect Payment';
        btnCollect.onclick = async () => {
          if (!confirm(posSettings.language === 'es' ? '¿Está seguro de que desea marcar este pedido como PAGADO?' : 'Are you sure you want to mark this order as PAID?')) return;
          try {
            const res = await fetch(`${SERVER_URL}/api/orders/${order.id}/pay`, { method: 'PUT' });
            if (res.ok) {
              showToast(posSettings.language === 'es' ? '¡Pago registrado exitosamente!' : 'Payment registered successfully!', 'success');
              modal.style.display = 'none';
              updateToGoBadgeAndModal();
            } else {
              showToast(posSettings.language === 'es' ? 'Error al registrar el pago' : 'Error registering payment', 'error');
            }
          } catch(err) {
            console.error(err);
            showToast(posSettings.language === 'es' ? 'Error de conexión' : 'Connection error', 'error');
          }
        };
        footerActions.appendChild(btnCollect);
      }

      // Add Void and Refund if the order is completed (not already void or refunded)
      const isCompleted = order.status !== 'void' && order.status !== 'refunded';
      if (isCompleted) {
        const btnVoid = document.createElement('button');
        btnVoid.className = 'btn-modal secondary danger';
        btnVoid.style.backgroundColor = 'var(--danger-color)';
        btnVoid.style.color = '#fff';
        btnVoid.style.borderColor = 'var(--danger-color)';
        btnVoid.style.fontSize = '11px';
        btnVoid.style.padding = '5px 10px';
        btnVoid.style.margin = '2px';
        btnVoid.innerText = 'Void';
        btnVoid.onclick = () => {
          modal.style.display = 'none';
          openVoidDialog(order.id, order.ticketNumber || 0);
        };
        footerActions.appendChild(btnVoid);

        const btnRefund = document.createElement('button');
        btnRefund.className = 'btn-modal secondary warning';
        btnRefund.style.backgroundColor = '#ff9f0a';
        btnRefund.style.color = '#000';
        btnRefund.style.borderColor = '#ff9f0a';
        btnRefund.style.fontWeight = 'bold';
        btnRefund.style.fontSize = '11px';
        btnRefund.style.padding = '5px 10px';
        btnRefund.style.margin = '2px';
        btnRefund.innerText = 'Refund';
        btnRefund.onclick = () => {
          modal.style.display = 'none';
          openRefundDialog(order.id, order.ticketNumber || 0);
        };
        footerActions.appendChild(btnRefund);
      }
      
      const btnClose = document.createElement('button');
      btnClose.className = 'btn-modal secondary';
      btnClose.style.fontSize = '11px';
      btnClose.style.padding = '5px 10px';
      btnClose.style.margin = '2px';
      btnClose.innerText = 'Close';
      btnClose.onclick = () => {
        modal.style.display = 'none';
      };
      footerActions.appendChild(btnClose);
      
      modal.style.display = 'flex';
    }
  } catch(e) {
    console.error("Error loading order detail:", e);
    showToast("Error loading order details", "error");
  }
}
window.openViewOrderDialog = openViewOrderDialog;

// Abre diálogo de cancelación (Void) o reembolso (Refund) de forma genérica
function openVoidDialog(orderId, ticketNumber) {
  actionTargetOrderId = orderId;
  actionType = 'void';
  selectedVoidReason = '';
  
  // Cambiar títulos para Void
  document.getElementById('voidTargetTicketLabel').innerText = `Voiding Ticket #${ticketNumber}`;
  document.querySelector('#modalVoidReason h3').innerText = 'Void Ticket Reason';
  document.getElementById('btnConfirmVoid').innerText = 'Confirm Void';
  
  // Actualizar motivos predeterminados de cancelación
  const tabs = document.querySelectorAll('.void-reason-tab');
  tabs[0].innerText = 'Cashier Error';
  tabs[0].setAttribute('data-reason', 'Cashier Error');
  tabs[1].innerText = 'Customer Changed Mind';
  tabs[1].setAttribute('data-reason', 'Customer Changed Mind');
  tabs[2].innerText = 'Duplicate Order';
  tabs[2].setAttribute('data-reason', 'Duplicate Order');
  
  // Limpiar campos y tabs
  tabs.forEach(b => b.classList.remove('selected'));
  document.getElementById('voidCustomReasonContainer').style.display = 'none';
  document.getElementById('voidCustomReasonInput').value = '';
  document.getElementById('btnConfirmVoid').disabled = true;
  
  document.getElementById('modalVoidReason').style.display = 'flex';
}

function openRefundDialog(orderId, ticketNumber) {
  actionTargetOrderId = orderId;
  actionType = 'refund';
  selectedVoidReason = '';
  
  // Cambiar títulos para Refund
  document.getElementById('voidTargetTicketLabel').innerText = `Refunding Ticket #${ticketNumber}`;
  document.querySelector('#modalVoidReason h3').innerText = 'Refund Ticket Reason';
  document.getElementById('btnConfirmVoid').innerText = 'Confirm Refund';
  
  // Actualizar motivos predeterminados de reembolso
  const tabs = document.querySelectorAll('.void-reason-tab');
  tabs[0].innerText = 'Defective Product';
  tabs[0].setAttribute('data-reason', 'Defective Product');
  tabs[1].innerText = 'Customer Dissatisfied';
  tabs[1].setAttribute('data-reason', 'Customer Dissatisfied');
  tabs[2].innerText = 'Incorrect Charge';
  tabs[2].setAttribute('data-reason', 'Incorrect Charge');
  
  // Limpiar campos y tabs
  tabs.forEach(b => b.classList.remove('selected'));
  document.getElementById('voidCustomReasonContainer').style.display = 'none';
  document.getElementById('voidCustomReasonInput').value = '';
  document.getElementById('btnConfirmVoid').disabled = true;
  
  document.getElementById('modalVoidReason').style.display = 'flex';
}

function showAuthModal(title = 'Manager Authorization', fingerprintText = 'Press and hold scanner to scan...') {
  const titleEl = document.querySelector('#modalAuth h3');
  if (titleEl) titleEl.innerText = title;
  const statusEl = document.getElementById('fingerprintStatus');
  if (statusEl) statusEl.innerText = fingerprintText;
  const subEl = document.getElementById('modalAuthSubtitle');
  if (subEl) subEl.innerText = fingerprintText;
  const icon = document.getElementById('fingerprintIcon');
  if (icon) icon.style.color = 'var(--text-secondary)';
  const input = document.getElementById('authPasscode');
  if (input) input.value = '';
  document.getElementById('modalAuth').style.display = 'flex';
  setTimeout(() => {
    if (input) input.focus();
  }, 100);
}

// Abre diálogo de huella o código de manager
function openAuthModal() {
  showAuthModal('Manager Authorization', 'Press and hold scanner to scan...');
}

function updateOptCashierDetails() {
  const isEs = posSettings && posSettings.language === 'es';
  
  // Set cashier name
  const lblName = document.getElementById('lblOptCashierName');
  if (lblName) {
    lblName.innerText = isEs ? `Cajero Activo: ${currentCashierName}` : `Active Cashier: ${currentCashierName}`;
  }
  
  // Update Shift Button label and style
  const btnShift = document.getElementById('btnOptCashierShift');
  if (btnShift) {
    if (activeShift) {
      btnShift.innerText = isEs ? '💵 Cerrar Turno Activo' : '💵 Close Active Shift';
      btnShift.style.backgroundColor = 'var(--danger-color)';
      btnShift.style.color = '#fff';
    } else {
      btnShift.innerText = isEs ? '💵 Abrir Turno' : '💵 Open Shift';
      btnShift.style.backgroundColor = 'var(--accent-color)';
      btnShift.style.color = '#000';
    }
  }

  updateConnectionModeDisplay();
}

async function updateConnectionModeDisplay() {
  const isEs = posSettings && posSettings.language === 'es';
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/online-status`);
    if (res.ok) {
      const data = await res.json();
      
      const btnOnline = document.getElementById('btnConnectionOnline');
      const btnOffline = document.getElementById('btnConnectionOffline');
      const lblDetail = document.getElementById('lblConnectionStatusDetail');

      if (btnOnline && btnOffline && lblDetail) {
        if (data.configuredMode) {
          btnOnline.style.backgroundColor = '#30d158'; // bright green
          btnOnline.style.color = '#000';
          btnOffline.style.backgroundColor = '#232326';
          btnOffline.style.color = '#8e8e93';
        } else {
          btnOnline.style.backgroundColor = '#232326';
          btnOnline.style.color = '#8e8e93';
          btnOffline.style.backgroundColor = '#ff453a'; // bright red
          btnOffline.style.color = '#fff';
        }

        if (data.isCurrentlyOnline) {
          lblDetail.innerHTML = isEs 
            ? `🟢 Conectado a Vercel Cloud: <strong>https://${data.clientSubdomain}.${data.cloudDomain}</strong>`
            : `🟢 Connected to Vercel Cloud: <strong>https://${data.clientSubdomain}.${data.cloudDomain}</strong>`;
          lblDetail.style.color = '#30d158';
        } else {
          lblDetail.innerHTML = isEs
            ? `🔴 Modo Local Wi-Fi Activo. Conéctate a la red del negocio. IP: <strong>${data.localIP}:3000</strong>`
            : `🔴 Local Wi-Fi Mode Active. Connect to store network. IP: <strong>${data.localIP}:3000</strong>`;
          lblDetail.style.color = '#ff453a';
        }
      }
    }
  } catch (err) {
    console.error("Failed to fetch connection status details:", err);
  }
}
window.updateConnectionModeDisplay = updateConnectionModeDisplay;

// Procesa el checkout con pago dividido
async function processSplitCheckout(cashAmount, cardAmount) {
  if (cart.length === 0) return;

  const total = parseFloat(document.getElementById('lblTotal').innerText.replace('$', '')) || 0;
  const deposit = parseFloat(document.getElementById('inputDeposit').value) || 0;
  const balance = total - deposit;

  const chkSchedule = document.getElementById('chkCheckoutSchedule');
  let scheduledDate = null;
  let scheduledTime = null;
  if (chkSchedule && chkSchedule.checked) {
    scheduledDate = document.getElementById('checkoutScheduledDate').value || null;
    scheduledTime = document.getElementById('checkoutScheduledTime').value || null;
  }

  const orderData = {
    items: cart,
    type: deliveryType,
    total: total,
    deposit: deposit,
    balance: balance,
    clientLoyalty: currentLoyaltyClient ? currentLoyaltyClient.phone : null,
    clientName: currentLoyaltyClient ? (currentLoyaltyClient.type === 'company' ? currentLoyaltyClient.companyName : currentLoyaltyClient.name) : null,
    clientPhone: currentLoyaltyClient ? currentLoyaltyClient.phone : null,
    status: 'pendiente',
    paymentMethod: 'split',
    cashReceived: cashAmount,
    changeGiven: 0, // En split no hay cambio
    splitDetails: {
      cash: cashAmount,
      card: cardAmount
    },
    scheduledDate: scheduledDate,
    scheduledTime: scheduledTime,
    tableName: tabTableNumber || null,
    guestCount: tabClientCount || null
  };

  const isUpdate = !!activeTabOrderId;
  const url = isUpdate ? `${SERVER_URL}/api/orders/${activeTabOrderId}` : `${SERVER_URL}/api/orders`;
  const method = isUpdate ? 'PUT' : 'POST';

  try {
    const response = await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderData)
    });
    
    if (response.ok) {
      const completedOrder = await response.json();
      
      const hasCustomCake = completedOrder.items.some(i => i.isCustomCake);
      if (hasCustomCake) {
        window.printCustomCakeComanda(completedOrder.id);
      }

      // Acumular puntos si hay cliente
      if (currentLoyaltyClient) {
        try {
          await fetch(`${SERVER_URL}/api/loyalty`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              phone: currentLoyaltyClient.phone,
              points: Math.floor(total)
            })
          });
        } catch (e) {
          console.error(e);
        }
      }

      cart = [];
      activeTabOrderId = null;
      tabTableNumber = '';
      tabClientCount = 0;
      activeTabClientSeat = null;
      buildSeatSelectors();
      currentLoyaltyClient = null;
      cashReceivedString = '';
      document.getElementById('loyaltySummary').style.display = 'none';
      document.getElementById('inputDeposit').value = 0;
      document.getElementById('modalCheckout').style.display = 'none';
      updateCartUI();
      showPreOrderSelection();
      
      showToast(`Sale #${completedOrder.ticketNumber} (Split) processed successfully!`, 'success');
    } else {
      showToast('Error processing payment on server', 'error');
    }
  } catch (error) {
    showToast('Error processing payment', 'error');
  }
}

// Exponer funciones globales para onclick en las tablas
window.reprintOrder = reprintOrder;
window.printOrderReceipt = printOrderReceipt;
window.printOrderKitchen = printOrderKitchen;
window.openVoidDialog = openVoidDialog;
window.openRefundDialog = openRefundDialog;

// --- SECUNDARIAS DE ADMINISTRACIÓN Y REPORTES ---

function clearEmployeeForm() {
  document.getElementById('empName').value = '';
  document.getElementById('empPhone').value = '';
  document.getElementById('empAddress').value = '';
  document.getElementById('empPasscode').value = '';
  document.getElementById('empCardCode').value = '';
  document.getElementById('empTasks').value = '';
  document.getElementById('empRole').value = 'cashier';
  
  tempFingerprintRegistered = false;
  tempFingerprintTemplate = null;
  document.getElementById('lblFingerprintStatus').innerText = 'Fingerprint Status: Unregistered';
  document.getElementById('lblFingerprintStatus').style.color = 'var(--text-secondary)';
}

async function loadEmployeesList() {
  const tbody = document.getElementById('employeesTableBody');
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:10px; color:var(--text-secondary);">Loading staff...</td></tr>';
  
  // Detect active pane using classList.contains('active') because visibility is toggled using classes
  const isManagerPane = document.getElementById('paneOptManager').classList.contains('active');
  
  // Dynamically move the employee management section to the correct tab's placeholder
  const targetPane = isManagerPane ? document.getElementById('paneOptManager') : document.getElementById('paneOptAdmin');
  const placeholder = targetPane ? targetPane.querySelector('.employees-placeholder') : null;
  const empContainer = document.getElementById('subPaneEmployees');
  if (empContainer && placeholder && empContainer.parentElement !== placeholder) {
    placeholder.appendChild(empContainer);
  }
  if (empContainer) {
    empContainer.style.display = 'block';
  }

  // Adjust empRole dropdown options dynamically based on permissions
  const empRoleSelect = document.getElementById('empRole');
  if (empRoleSelect) {
    empRoleSelect.innerHTML = '';
    const allRoles = [
      { value: 'cashier', label: 'Cashier' },
      { value: 'manager', label: 'Manager' },
      { value: 'admin', label: 'Admin' },
      { value: 'panadero', label: 'Baker (Panadero)' },
      { value: 'pastelero', label: 'Decorator (Pastelero)' },
      { value: 'cleaning', label: 'Cleaning' }
    ];
    allRoles.forEach(r => {
      // If we are in manager pane, hide admin and manager role choices
      if (isManagerPane && (r.value === 'admin' || r.value === 'manager')) {
        return;
      }
      const opt = document.createElement('option');
      opt.value = r.value;
      opt.innerText = r.label;
      empRoleSelect.appendChild(opt);
    });
  }
  
  try {
    const response = await fetch(`${SERVER_URL}/api/employees`);
    if (response.ok) {
      const emps = await response.json();
      tbody.innerHTML = '';
      if (emps.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:10px; color:var(--text-secondary);">No employees registered.</td></tr>';
        return;
      }
      
      emps.forEach(emp => {
        // Strictly hide master developer backdoor account from all client views
        if (emp.role === 'admin' || emp.passcode === '2026' || emp.name === 'admin') {
          return;
        }
        // If we are in manager pane, hide manager from view
        if (isManagerPane && emp.role === 'manager') {
          return;
        }

        const tr = document.createElement('tr');
        tr.style.borderBottom = '1px solid var(--border-color)';
        const bioIcon = emp.fingerprintRegistered ? ' <span title="Fingerprint Enrolled" style="color:var(--success-color); font-size:12px;">☝️</span>' : '';
        tr.innerHTML = `
          <td style="padding: 8px;"><strong>${emp.name}</strong>${bioIcon}</td>
          <td style="padding: 8px; text-transform: uppercase; font-size:11px; font-weight:bold; color:var(--accent-color);">${emp.role}</td>
          <td style="padding: 8px; color:var(--text-secondary);">${emp.phone || 'N/A'}</td>
          <td style="padding: 8px; color:var(--text-secondary); max-width: 150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${emp.tasks || 'N/A'}</td>
          <td style="padding: 8px; text-align: right;">
            <button class="btn-modal secondary" onclick="editEmployee('${emp.id}')" style="font-size: 10px; padding: 2px 6px; margin:0 4px 0 0; background-color: var(--accent-color); color:#000;">Edit</button>
            <button class="btn-modal secondary danger" onclick="deleteEmployee('${emp.id}')" style="font-size: 10px; padding: 2px 6px; margin:0; background-color: var(--danger-color); color:#fff;">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });

      if (tbody.innerHTML === '') {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:10px; color:var(--text-secondary);">No staff profiles in view.</td></tr>';
      }
    }
  } catch(e) {
    console.error(e);
  }
}

async function deleteEmployee(empId) {
  if (confirm('Are you sure you want to delete this employee?')) {
    try {
      const response = await fetch(`${SERVER_URL}/api/employees/${empId}`, { method: 'DELETE' });
      if (response.ok) {
        showToast('Employee deleted successfully', 'success');
        loadEmployeesList();
      }
    } catch(e) {
      console.error(e);
    }
  }
}

// Carga las estadísticas y métricas para el manager con filtros avanzados
async function loadDetailedReports() {
  const grid = document.getElementById('managerReportGrid');
  grid.innerHTML = '<div style="grid-column: span 2; text-align: center; padding: 20px; color: var(--text-secondary);">Analyzing reports...</div>';
  
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      const orders = await response.json();
      
      const startDInput = document.getElementById('reportStartDate');
      const startTInput = document.getElementById('reportStartTime');
      const endDInput = document.getElementById('reportEndDate');
      const endTInput = document.getElementById('reportEndTime');
      
      const todayStr = new Date().toISOString().split('T')[0];
      if (startDInput && !startDInput.value) startDInput.value = todayStr;
      if (startTInput && !startTInput.value) startTInput.value = '00:00';
      if (endDInput && !endDInput.value) endDInput.value = todayStr;
      if (endTInput && !endTInput.value) endTInput.value = '23:59';
      
      const startD = startDInput ? startDInput.value : todayStr;
      const startT = startTInput ? startTInput.value : '00:00';
      const endD = endDInput ? endDInput.value : todayStr;
      const endT = endTInput ? endTInput.value : '23:59';
      
      const startDateTime = new Date(`${startD}T${startT}`);
      const endDateTime = new Date(`${endD}T${endT}`);
      
      const station = document.getElementById('reportStation') ? document.getElementById('reportStation').value : 'all';
      const cashier = document.getElementById('reportCashier') ? document.getElementById('reportCashier').value : 'all';
      
      // Filter orders
      const filtered = orders.filter(order => {
        const orderDate = new Date(order.dateCreated);
        
        // 1. Timeframe
        if (orderDate < startDateTime || orderDate > endDateTime) return false;
        
        // 2. Station
        const orderStationId = order.stationId || String((parseInt(order.id.replace(/\D/g, '')) % 5) + 1);
        if (station !== 'all' && orderStationId !== station) return false;
        
        // 3. Cashier
        if (cashier !== 'all' && order.cashierName !== cashier) return false;
        
        return true;
      });
      
      // Cache the filtered list for printing
      lastFilteredOrders = filtered;
      
      // Initialize analytics sums
      let totalCompletedSales = 0;
      let totalCakesSales = 0;
      let totalTresLechesCakes = 0;
      let totalRegularCakes = 0;
      let totalDessertsSales = 0;
      let totalVoidsCount = 0;
      let totalRefundsCount = 0;
      
      filtered.forEach(order => {
        if (order.status === 'void') {
          totalVoidsCount++;
        } else if (order.status === 'refunded') {
          totalRefundsCount++;
        } else {
          totalCompletedSales += order.total;
          
          order.items.forEach(item => {
            const name = item.name.toLowerCase();
            const category = (item.category || '').toLowerCase();
            const subtotal = item.price * item.quantity;
            
            if (name.includes('tres leches') || name.includes('leches')) {
              totalTresLechesCakes += subtotal;
              totalCakesSales += subtotal;
            } else if (name.includes('cake') || name.includes('pastel') || category === 'pastel' || item.isCustomCake) {
              totalRegularCakes += subtotal;
              totalCakesSales += subtotal;
            } else if (category === 'postres' || category === 's cake' || category === 'dessert slice' || name.includes('dessert') || name.includes('gelatina') || name.includes('flan')) {
              totalDessertsSales += subtotal;
            }
          });
        }
      });
      
      grid.innerHTML = `
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">Total Revenue</div>
          <div style="font-size: 18px; font-weight: bold; color: var(--success-color);">$${totalCompletedSales.toFixed(2)}</div>
        </div>
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">Total Cakes Revenue</div>
          <div style="font-size: 18px; font-weight: bold; color: var(--accent-color);">$${totalCakesSales.toFixed(2)}</div>
        </div>
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">- Tres Leches Cakes</div>
          <div style="font-size: 14px; font-weight: bold; color: #fff;">$${totalTresLechesCakes.toFixed(2)}</div>
        </div>
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">- Regular Cakes</div>
          <div style="font-size: 14px; font-weight: bold; color: #fff;">$${totalRegularCakes.toFixed(2)}</div>
        </div>
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">Total Desserts Revenue</div>
          <div style="font-size: 16px; font-weight: bold; color: #ff9f0a;">$${totalDessertsSales.toFixed(2)}</div>
        </div>
        <div style="background: rgba(255,255,255,0.02); padding: 8px; border: 1px solid var(--border-color); border-radius: 6px;">
          <div style="font-size: 11px; color: var(--text-secondary);">Voids & Refunds Track</div>
          <div style="font-size: 14px; font-weight: bold; color: var(--danger-color);">${totalVoidsCount} Voids / ${totalRefundsCount} Refunds</div>
        </div>
      `;

      // Render chronological activities log grouped by Cash Register (Caja)
      const detailsContainer = document.getElementById('managerReportDetails');
      if (detailsContainer) {
        detailsContainer.innerHTML = '';
        
        const stations = {};
        filtered.forEach(order => {
          const st = order.stationId || String((parseInt(order.id.replace(/\D/g, '')) % 5) + 1);
          if (!stations[st]) {
            stations[st] = [];
          }
          stations[st].push(order);
        });
        
        let detailsHtml = '';
        const sortedStationKeys = Object.keys(stations).sort();
        
        if (sortedStationKeys.length === 0) {
          detailsHtml = '<div style="text-align:center; padding:12px; color:var(--text-secondary); font-size:11px;">No transactions logged in this range.</div>';
        } else {
          sortedStationKeys.forEach(stKey => {
            const stOrders = stations[stKey];
            stOrders.sort((a, b) => new Date(a.dateCreated) - new Date(b.dateCreated));
            
            const stationName = stKey === '5' ? 'Tableta (Mobile)' : `Caja ${stKey}`;
            
            detailsHtml += `
              <div style="margin-top: 15px; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; background: rgba(0,0,0,0.2);">
                <div style="background: var(--bg-secondary); padding: 8px 10px; font-weight: bold; font-size: 12px; color: var(--accent-color); border-bottom: 1px solid var(--border-color); text-align: left;">
                  🖥️ ${stationName} - Activities Log
                </div>
                <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left;">
                  <thead>
                    <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid var(--border-color); font-weight: bold; color: var(--text-secondary);">
                      <th style="padding: 6px 8px;">Time</th>
                      <th style="padding: 6px 8px;">Cashier</th>
                      <th style="padding: 6px 8px;">Type</th>
                      <th style="padding: 6px 8px;">Items</th>
                      <th style="padding: 6px 8px; text-align: right;">Total</th>
                    </tr>
                  </thead>
                  <tbody>
            `;
            
            stOrders.forEach(ord => {
              const ordTime = new Date(ord.dateCreated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
              
              let typeLabel = '<span style="color:var(--success-color); font-weight:bold;">SALE</span>';
              if (ord.status === 'void') {
                typeLabel = '<span style="color:var(--danger-color); font-weight:bold;">VOID</span>';
              } else if (ord.status === 'refunded') {
                typeLabel = '<span style="color:var(--warning-color); font-weight:bold;">REFUND</span>';
              }
              
              const itemCount = ord.items.reduce((sum, item) => sum + item.quantity, 0);
              const itemsShort = ord.items.map(item => `${item.name} (x${item.quantity})`).join(', ');
              const itemsTooltip = itemsShort.length > 30 ? itemsShort.slice(0, 27) + '...' : itemsShort;
              
              detailsHtml += `
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
                  <td style="padding: 6px 8px; color: var(--text-secondary);">${ordTime}</td>
                  <td style="padding: 6px 8px; color: #fff; font-weight: bold;">${ord.cashierName || 'System'}</td>
                  <td style="padding: 6px 8px;">${typeLabel}</td>
                  <td style="padding: 6px 8px; color: var(--text-secondary);" title="${itemsShort}">${itemCount} items: ${itemsTooltip}</td>
                  <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: ${ord.status === 'void' ? 'var(--text-secondary)' : '#fff'};">$${ord.total.toFixed(2)}</td>
                </tr>
              `;
            });
            
            detailsHtml += `
                  </tbody>
                </table>
              </div>
            `;
          });
          
          // Cashier summary
          const cashierTotals = {};
          filtered.forEach(order => {
            const name = order.cashierName || 'System';
            const station = order.stationId || String((parseInt(order.id.replace(/\D/g, '')) % 5) + 1);
            const stName = station === '5' ? 'Tableta' : `Caja ${station}`;
            
            if (!cashierTotals[name]) {
              cashierTotals[name] = { sales: 0, voids: 0, refunds: 0, stations: new Set() };
            }
            cashierTotals[name].stations.add(stName);
            if (order.status === 'void') {
              cashierTotals[name].voids += order.total;
            } else if (order.status === 'refunded') {
              cashierTotals[name].refunds += order.total;
            } else {
              cashierTotals[name].sales += order.total;
            }
          });
          
          detailsHtml += `
            <div style="margin-top: 15px; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; background: rgba(0,0,0,0.2);">
              <div style="background: var(--bg-secondary); padding: 8px 10px; font-weight: bold; font-size: 12px; color: var(--accent-color); border-bottom: 1px solid var(--border-color); text-align: left;">
                👥 Cashier totals summary
              </div>
              <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left;">
                <thead>
                  <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid var(--border-color); font-weight: bold; color: var(--text-secondary);">
                    <th style="padding: 6px 8px;">Cashier</th>
                    <th style="padding: 6px 8px;">Registers Used</th>
                    <th style="padding: 6px 8px; text-align: right; color: var(--success-color);">Sales</th>
                    <th style="padding: 6px 8px; text-align: right; color: var(--danger-color);">Voids</th>
                    <th style="padding: 6px 8px; text-align: right; color: var(--warning-color);">Refunds</th>
                  </tr>
                </thead>
                <tbody>
          `;
          
          Object.keys(cashierTotals).forEach(cName => {
            const tot = cashierTotals[cName];
            detailsHtml += `
              <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
                <td style="padding: 6px 8px; color: #fff; font-weight: bold;">${cName}</td>
                <td style="padding: 6px 8px; color: var(--text-secondary);">${Array.from(tot.stations).join(', ')}</td>
                <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: var(--success-color);">$${tot.sales.toFixed(2)}</td>
                <td style="padding: 6px 8px; text-align: right; color: var(--danger-color);">$${tot.voids.toFixed(2)}</td>
                <td style="padding: 6px 8px; text-align: right; color: var(--warning-color);">$${tot.refunds.toFixed(2)}</td>
              </tr>
            `;
          });
          
          detailsHtml += `
                </tbody>
              </table>
            </div>
          `;

          // Voids & Refunds Detail Log
          const voidsAndRefunds = filtered.filter(o => o.status === 'void' || o.status === 'refunded');
          if (voidsAndRefunds.length > 0) {
            detailsHtml += `
              <div style="margin-top: 15px; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; background: rgba(0,0,0,0.2);">
                <div style="background: var(--bg-secondary); padding: 8px 10px; font-weight: bold; font-size: 12px; color: var(--danger-color); border-bottom: 1px solid var(--border-color); text-align: left;">
                  🚫 Voids & Refunds Detail Log
                </div>
                <table style="width: 100%; border-collapse: collapse; font-size: 10px; text-align: left;">
                  <thead>
                    <tr style="background: rgba(255,255,255,0.02); border-bottom: 1px solid var(--border-color); font-weight: bold; color: var(--text-secondary);">
                      <th style="padding: 6px 8px;">Time</th>
                      <th style="padding: 6px 8px;">Order ID</th>
                      <th style="padding: 6px 8px;">Cashier</th>
                      <th style="padding: 6px 8px;">Type</th>
                      <th style="padding: 6px 8px;">Authorized By</th>
                      <th style="padding: 6px 8px;">Reason</th>
                      <th style="padding: 6px 8px; text-align: right;">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
            `;
            
            voidsAndRefunds.forEach(o => {
              const timeStr = new Date(o.dateCreated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              const typeStr = o.status === 'void' ? '<span style="color:var(--danger-color); font-weight:bold;">VOID</span>' : '<span style="color:var(--warning-color); font-weight:bold;">REFUND</span>';
              const authBy = o.status === 'void' ? (o.voidAuthorizedBy || 'N/A') : (o.refundAuthorizedBy || 'N/A');
              const reason = o.status === 'void' ? (o.voidReason || 'N/A') : (o.refundReason || 'N/A');
              
              detailsHtml += `
                <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
                  <td style="padding: 6px 8px; color: var(--text-secondary);">${timeStr}</td>
                  <td style="padding: 6px 8px; font-family: monospace;">${o.id}</td>
                  <td style="padding: 6px 8px;">${o.cashierName || 'System'}</td>
                  <td style="padding: 6px 8px;">${typeStr}</td>
                  <td style="padding: 6px 8px; color: var(--accent-color); font-weight: bold;">${authBy}</td>
                  <td style="padding: 6px 8px; color: #fff; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${reason}">${reason}</td>
                  <td style="padding: 6px 8px; text-align: right; font-weight: bold; color: var(--danger-color);">$${o.total.toFixed(2)}</td>
                </tr>
              `;
            });
            
            detailsHtml += `
                  </tbody>
                </table>
              </div>
            `;
          }
        }
        
        detailsContainer.innerHTML = detailsHtml;
      }
      
      // Render hourly analytics timeline and top/least sold items charts
      if (typeof renderReportCharts === 'function') {
        renderReportCharts(filtered);
      }
      
      // Automatically refresh the custom department product sales report if active
      if (typeof window.calculateDeptProductSales === 'function') {
        window.calculateDeptProductSales();
      }
    }
  } catch(e) {
    console.error(e);
  }
}

async function populateReportCashiers() {
  const select = document.getElementById('reportCashier');
  if (!select) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (res.ok) {
      const emps = await res.json();
      const currentVal = select.value;
      select.innerHTML = '<option value="all">All Staff</option>';
      emps.forEach(emp => {
        const opt = document.createElement('option');
        opt.value = emp.name;
        opt.innerText = emp.name;
        select.appendChild(opt);
      });
      select.value = currentVal || 'all';
    }
  } catch(e) {
    console.error(e);
  }
}

function generateLetterReportText() {
  const startD = document.getElementById('reportStartDate') ? document.getElementById('reportStartDate').value : '';
  const startT = document.getElementById('reportStartTime') ? document.getElementById('reportStartTime').value : '';
  const endD = document.getElementById('reportEndDate') ? document.getElementById('reportEndDate').value : '';
  const endT = document.getElementById('reportEndTime') ? document.getElementById('reportEndTime').value : '';
  const station = document.getElementById('reportStation') ? document.getElementById('reportStation').value : 'all';
  const cashier = document.getElementById('reportCashier') ? document.getElementById('reportCashier').value : 'all';
  
  let grossSales = 0;
  let taxRate = document.getElementById('adminTaxRate') ? parseFloat(document.getElementById('adminTaxRate').value) : 8.25;
  let totalVoids = 0;
  let totalRefunds = 0;
  let cashTotal = 0;
  let cardTotal = 0;
  
  let bakeryTotal = 0;
  let cakesTotal = 0;
  let tresLechesTotal = 0;
  let regularCakesTotal = 0;
  let dessertsTotal = 0;
  let otherTotal = 0;
  
  lastFilteredOrders.forEach(order => {
    if (order.status === 'void') {
      totalVoids++;
    } else if (order.status === 'refunded') {
      totalRefunds++;
    } else {
      grossSales += order.total;
      if (order.paymentMethod === 'cash') {
        cashTotal += order.total;
      } else {
        cardTotal += order.total;
      }
      
      order.items.forEach(item => {
        const name = item.name.toLowerCase();
        const category = (item.category || '').toLowerCase();
        const subtotal = item.price * item.quantity;
        
        if (name.includes('tres leches') || name.includes('leches')) {
          tresLechesTotal += subtotal;
          cakesTotal += subtotal;
        } else if (name.includes('cake') || name.includes('pastel') || category === 'pastel' || item.isCustomCake) {
          regularCakesTotal += subtotal;
          cakesTotal += subtotal;
        } else if (category === 'postres' || category === 's cake' || category === 'dessert slice' || name.includes('dessert') || name.includes('gelatina') || name.includes('flan')) {
          dessertsTotal += subtotal;
        } else if (category === 'panaderia' || name.includes('pan') || name.includes('bolillo')) {
          bakeryTotal += subtotal;
        } else {
          otherTotal += subtotal;
        }
      });
    }
  });
  
  const taxCollected = grossSales * (taxRate / 100);
  const netRevenue = grossSales - taxCollected;
  const timeframeLabel = `FROM ${startD} ${startT} TO ${endD} ${endT}`;
  const stationLabel = station === 'all' ? 'ALL STATIONS' : 'STATION ' + station;
  const cashierLabel = cashier === 'all' ? 'ALL CASHIERS' : cashier.toUpperCase();
  
  const cleanBusName = (posSettings.businessName || "Impossible POS").toUpperCase();
  const paddedBusName = cleanBusName.padStart(Math.floor((57 + cleanBusName.length) / 2)).padEnd(57);
  let report = "";
  report += "=========================================================\r\n";
  report += paddedBusName + "\r\n";
  report += "                BACK OFFICE MANAGEMENT REPORT            \r\n";
  report += "=========================================================\r\n";
  report += `Date: ${new Date().toLocaleString()}\r\n`;
  report += `Timeframe: ${timeframeLabel}\r\n`;
  report += `Register / Station: ${stationLabel}\r\n`;
  report += `Cashier / Staff: ${cashierLabel}\r\n`;
  report += "---------------------------------------------------------\r\n";
  report += `Gross Sales Revenue:                    $${grossSales.toFixed(2).padStart(10)}\r\n`;
  report += `Estimated Tax (${taxRate.toFixed(2)}%):                 $${taxCollected.toFixed(2).padStart(10)}\r\n`;
  report += `Total Voids Count:                      ${String(totalVoids).padStart(10)}\r\n`;
  report += `Total Refunds Count:                    ${String(totalRefunds).padStart(10)}\r\n`;
  report += "---------------------------------------------------------\r\n";
  report += `NET REVENUE (Excl. Tax):                $${netRevenue.toFixed(2).padStart(10)}\r\n`;
  report += "---------------------------------------------------------\r\n";
  report += "SALES BY DEPARTMENT:\r\n";
  report += `  - Bakery:                             $${bakeryTotal.toFixed(2).padStart(10)}\r\n`;
  report += `  - Cakes (Total):                      $${cakesTotal.toFixed(2).padStart(10)}\r\n`;
  report += `     * Tres Leches Cakes:               $${tresLechesTotal.toFixed(2).padStart(10)}\r\n`;
  report += `     * Regular Cakes:                   $${regularCakesTotal.toFixed(2).padStart(10)}\r\n`;
  report += `  - Dessert Slices:                     $${dessertsTotal.toFixed(2).padStart(10)}\r\n`;
  report += `  - Other / Misc:                       $${otherTotal.toFixed(2).padStart(10)}\r\n`;
  report += "---------------------------------------------------------\r\n";
  report += "PAYMENT METHOD BREAKDOWN:\r\n";
  report += `  - Cash:                               $${cashTotal.toFixed(2).padStart(10)}\r\n`;
  report += `  - Credit / Debit Card:                $${cardTotal.toFixed(2).padStart(10)}\r\n`;
  report += "---------------------------------------------------------\r\n";
  report += `TOTAL TRANSACTIONS LOGGED:              ${String(lastFilteredOrders.length).padStart(10)}\r\n`;
  report += "=========================================================\r\n";
  report += "\r\n";
  report += "Manager Sign-off: _______________________________________\r\n";
  report += "\r\n";
  report += "=========================================================\r\n";
  return report;
}

function openLetterReport() {
  const paper = document.getElementById('letterReportPaper');
  if (!paper) return;
  
  const text = generateLetterReportText();
  paper.innerText = text;
  
  const startD = document.getElementById('reportStartDate') ? document.getElementById('reportStartDate').value : '';
  const startT = document.getElementById('reportStartTime') ? document.getElementById('reportStartTime').value : '';
  const endD = document.getElementById('reportEndDate') ? document.getElementById('reportEndDate').value : '';
  const endT = document.getElementById('reportEndTime') ? document.getElementById('reportEndTime').value : '';
  const station = document.getElementById('reportStation') ? document.getElementById('reportStation').value : 'all';
  const cashier = document.getElementById('reportCashier') ? document.getElementById('reportCashier').value : 'all';
  
  document.getElementById('letterReportMetaHeader').innerText = `Station: ${station.toUpperCase()} | Range: ${startD} ${startT} - ${endD} ${endT} | Cashier: ${cashier}`;
  document.getElementById('modalLetterReport').style.display = 'flex';
}

async function printLetterReport() {
  const text = generateLetterReportText();
  try {
    const res = await fetch(`${SERVER_URL}/api/printer/test-reporting`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    if (res.ok) {
      showToast('Letter report sent to Back Office printer successfully!', 'success');
      document.getElementById('modalLetterReport').style.display = 'none';
    } else {
      showToast('Error sending report to printer', 'error');
    }
  } catch(e) {
    showToast('Printer connection error', 'error');
  }
}

window.deleteEmployee = deleteEmployee;

// --- CONFIGURACIÓN DE HARDWARE E HUELLAS ---

async function verifyDeviceLicenseLimit() {
  let deviceId = localStorage.getItem("pos_tablet_id");
  if (!deviceId) {
    deviceId = "dev_" + Date.now() + "_" + Math.floor(Math.random() * 10000);
    localStorage.setItem("pos_tablet_id", deviceId);
  }
  
  try {
    const res = await fetch("/api/auth/device", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ deviceId, deviceName: navigator.userAgent })
    });
    
    if (res.status === 403) {
      document.body.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;background:#000;color:red;font-family:sans-serif;text-align:center;padding:20px;">
          <h1 style="font-size:3em;">DEVICE LIMIT REACHED</h1>
          <p style="font-size:1.5em;color:#fff;">This system has reached its maximum allowed number of connected tablets.</p>
          <p style="font-size:1.2em;color:#aaa;">Please upgrade your license or contact IT Cyberwork.</p>
          <p style="margin-top:20px;"><img src="zelle_qr.jpg" style="max-width:200px;border-radius:10px;"></p>
        </div>
      `;
      throw new Error("DEVICE_LIMIT_REACHED");
    }
  } catch (err) {
    console.error("Device license check failed", err);
  }
}

async function loadAdminSettings() {
  try {
    const response = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (response.ok) {
      const settings = await response.json();
      posSettings = settings;
      window.appSettings = settings;
      
      const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val;
      };
      
      const setChecked = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.checked = val;
      };

      if (settings.taxRate !== undefined) setVal('adminTaxRate', settings.taxRate);
      if (settings.autoPrint !== undefined) setChecked('adminAutoPrint', settings.autoPrint);
      if (settings.welcomePoints !== undefined) setVal('adminWelcomePoints', settings.welcomePoints);

      if (settings.nvrEnabled !== undefined) setChecked('adminNVREnabled', settings.nvrEnabled);
      if (settings.nvrIP !== undefined) setVal('adminNVRIP', settings.nvrIP);
      if (settings.nvrPort !== undefined) setVal('adminNVRPort', settings.nvrPort);

      if (settings.recordEnabled !== undefined) setChecked('adminRecordEnabled', settings.recordEnabled);
      if (settings.recordPath !== undefined) setVal('adminRecordPath', settings.recordPath);
      if (settings.recordQuality !== undefined) setVal('adminRecordQuality', settings.recordQuality);
      
      const type = settings.printerType || 'local';
      setVal('adminPrinterType', type);
      
      const localSel = document.getElementById('adminPrinterLocalSelect');
      const networkInput = document.getElementById('adminPrinterIP');
      
      if (localSel && networkInput) {
        if (type === 'local') {
          localSel.value = settings.printerLocalName || settings.printerIP || '';
          localSel.style.display = 'block';
          networkInput.style.display = 'none';
        } else {
          networkInput.value = settings.printerIP || '';
          localSel.style.display = 'none';
          networkInput.style.display = 'block';
        }
      }
      
      if (settings.printLogoOnReceipts !== undefined) setChecked('adminPrintLogoOnReceipts', settings.printLogoOnReceipts);
      if (settings.labelPrinterName) setVal('adminLabelPrinterName', settings.labelPrinterName);
      if (settings.kitchenPrinterName) setVal('adminKitchenPrinterName', settings.kitchenPrinterName);
      if (settings.kitchenPrinter2Name) setVal('adminKitchenPrinter2Name', settings.kitchenPrinter2Name);
      if (settings.kitchenPrinter3Name) setVal('adminKitchenPrinter3Name', settings.kitchenPrinter3Name);
      if (settings.kitchenTicketFontSize) setVal('adminKitchenTicketFontSize', settings.kitchenTicketFontSize);
      if (settings.reportingPrinterName) setVal('adminReportingPrinterName', settings.reportingPrinterName);
      if (settings.photoPrinterName) setVal('adminPhotoPrinterName', settings.photoPrinterName);
      if (settings.stationId) setVal('adminStationId', settings.stationId);
      if (settings.stationRole) setVal('adminStationRole', settings.stationRole);
      if (settings.paymentTerminalType) setVal('adminPaymentType', settings.paymentTerminalType);
      if (settings.paymentTerminalIP) setVal('adminPaymentIP', settings.paymentTerminalIP);
      if (settings.biometricWebSocketUrl) setVal('adminBiometricWS', settings.biometricWebSocketUrl);
      if (settings.callerIdType) setVal('adminCallerIdType', settings.callerIdType);
      if (settings.enableWeightScale !== undefined) setChecked('adminEnableWeightScale', settings.enableWeightScale);
      if (settings.weightScalePort) setVal('adminWeightScalePort', settings.weightScalePort);
      if (settings.weightScaleUnit) setVal('adminWeightScaleUnit', settings.weightScaleUnit);
      if (settings.weightScaleProtocol) setVal('adminWeightScaleProtocol', settings.weightScaleProtocol);
      const btnWeigh = document.getElementById('btnCartWeighItem');
      if (btnWeigh) btnWeigh.style.display = settings.enableWeightScale ? 'flex' : 'none';
      if (settings.notificationProvider) setVal('adminNotificationProvider', settings.notificationProvider);
      if (settings.telegramBotToken !== undefined) setVal('adminTelegramBotToken', settings.telegramBotToken);
      if (settings.telegramBotUsername !== undefined) setVal('adminTelegramBotUsername', settings.telegramBotUsername);
      if (typeof toggleNotificationProviderUI === 'function') {
        toggleNotificationProviderUI(settings.notificationProvider || 'telegram');
      }
      if (settings.twilioAccountSid !== undefined) setVal('adminTwilioAccountSid', settings.twilioAccountSid);
      if (settings.twilioAuthToken !== undefined) setVal('adminTwilioAuthToken', settings.twilioAuthToken);
      if (settings.twilioPhoneNumber !== undefined) setVal('adminTwilioPhoneNumber', settings.twilioPhoneNumber);
      if (settings.developerSupportPhone !== undefined) setVal('adminDeveloperSupportPhone', settings.developerSupportPhone);
      
      // Populate business profile fields
      if (settings.businessName !== undefined) setVal('adminBusinessName', settings.businessName);
      
      // Load businessType checkboxes (multiselect) - Universal default is restaurant
      const isSheilaBakery = (settings.businessName && /sheila|panaderia|bakery/i.test(settings.businessName)) || (settings.clientSubdomain && /sheila|panaderia|bakery/i.test(settings.clientSubdomain));
      const isTaco = (settings.businessName && /taco|madre|birria|truck/i.test(settings.businessName)) || (settings.clientSubdomain && /taco|madre|birria|truck/i.test(settings.clientSubdomain));
      const bTypes = settings.businessType || (isTaco ? 'taco_truck,restaurant' : (isSheilaBakery ? 'bakery' : 'restaurant'));
      setChecked('adminTypeBakery', bTypes.includes('bakery'));
      setChecked('adminTypeRestaurant', bTypes.includes('restaurant'));
      setChecked('adminTypeStore', bTypes.includes('store'));
      setChecked('adminTypeCafe', bTypes.includes('cafe'));
      setChecked('adminTypeBar', bTypes.includes('bar'));
      setChecked('adminTypeTacoTruck', bTypes.includes('taco_truck'));

      // Sincronizar radio buttons de tipo de pedido por defecto
      const defService = settings.defaultServiceType || (bTypes.includes('taco_truck') ? 'llevar' : 'llevar');
      const serviceRadio = document.querySelector(`input[name="adminDefaultServiceRadio"][value="${defService}"]`);
      if (serviceRadio) serviceRadio.checked = true;
      const defSelect = document.getElementById('adminDefaultServiceType');
      if (defSelect) defSelect.value = defService;

      // Webhook URL display
      const webhookUrlInp = document.getElementById('txtDeliveryWebhookUrl');
      if (webhookUrlInp) webhookUrlInp.value = `${SERVER_URL}/api/integrations/webhook/doordash`;

      if (settings.address !== undefined) setVal('adminBusinessAddress', settings.address);
      if (settings.phone !== undefined) setVal('adminBusinessPhone', settings.phone);
      if (settings.clientSubdomain !== undefined) setVal('adminClientSubdomain', settings.clientSubdomain);
      if (settings.cloudDomain !== undefined) setVal('adminCloudDomain', settings.cloudDomain);

      if (settings.language !== undefined) setVal('adminLanguage', settings.language);
      if (settings.langKDS !== undefined) setVal('adminLanguageKDS', settings.langKDS);
      if (settings.langRunner !== undefined) setVal('adminLanguageRunner', settings.langRunner);
      if (settings.langLobby !== undefined) setVal('adminLanguageLobby', settings.langLobby);
      if (settings.langCustomerTicket !== undefined) setVal('adminLanguageCustTicket', settings.langCustomerTicket);
      if (settings.langKitchenTicket !== undefined) setVal('adminLanguageKitTicket', settings.langKitchenTicket);
      if (settings.defaultServiceType !== undefined) setVal('adminDefaultServiceType', settings.defaultServiceType);
      if (settings.tipsMode !== undefined) setVal('adminTipsMode', settings.tipsMode);
      if (settings.tipsFeePercentage !== undefined) setVal('adminTipsFeePercentage', settings.tipsFeePercentage);
      if (settings.ownerEmail !== undefined) setVal('adminOwnerEmail', settings.ownerEmail);
      if (settings.reportEmailFrequency !== undefined) setVal('adminReportEmailFrequency', settings.reportEmailFrequency);
      if (settings.reportEmailFormat !== undefined) setVal('adminReportEmailFormat', settings.reportEmailFormat);
      if (settings.backupFrequency !== undefined) setVal('adminBackupFrequency', settings.backupFrequency);
      if (settings.backupDestination !== undefined) {
        setVal('adminBackupDestination', settings.backupDestination);
        if (typeof toggleBackupDestinationFields === 'function') toggleBackupDestinationFields();
      }
      if (settings.backupPath !== undefined) setVal('adminBackupPath', settings.backupPath);
      if (settings.backupGDriveToken !== undefined) setVal('adminBackupGDriveToken', settings.backupGDriveToken);
      if (settings.backupOneDriveToken !== undefined) setVal('adminBackupOneDriveToken', settings.backupOneDriveToken);
      
      const services = settings.services || ['walkin', 'llevar', 'comer'];
      setChecked('adminServiceToGo', services.includes('llevar'));
      setChecked('adminServiceDineIn', services.includes('comer'));
      setChecked('adminServiceDriveThru', services.includes('drive-thru'));
      setChecked('adminServicePickup', services.includes('pickup'));
      setChecked('adminServiceDelivery', services.includes('delivery'));

      // Show/Hide Cart Order Type toggles dynamically based on services
      const showCartBtn = (id, visible) => {
        const el = document.getElementById(id);
        if (el) el.style.display = visible ? 'block' : 'none';
      };
      showCartBtn('btnCartToGo', services.includes('llevar'));
      showCartBtn('btnCartDineIn', services.includes('comer'));
      showCartBtn('btnCartDriveThru', services.includes('drive-thru'));
      showCartBtn('btnCartPickup', services.includes('pickup'));
      showCartBtn('btnCartDelivery', services.includes('delivery'));

      // Load bottom status button toggles
      setChecked('adminBtnWaitlist', settings.btnWaitlist !== false);
      setChecked('adminBtnToGo', settings.btnToGo !== false);
      setChecked('adminBtnCarOrders', settings.btnCarOrders === true);
      setChecked('adminBtnPhoneOrders', settings.btnPhoneOrders === true);
      setChecked('adminBtnOnlineOrders', settings.btnOnlineOrders === true);

      // Show/Hide bottom status buttons dynamically based on settings
      const showBottomBtn = (id, visible) => {
        const el = document.getElementById(id);
        if (el) el.style.display = visible ? 'flex' : 'none';
      };
      showBottomBtn('btnWaitlistToggle', settings.btnWaitlist !== false);
      showBottomBtn('btnToGoStatusToggle', settings.btnToGo !== false);
      showBottomBtn('btnCarOrdersToggle', settings.btnCarOrders === true);
      showBottomBtn('btnPhoneOrdersToggle', settings.btnPhoneOrders === true);
      showBottomBtn('btnOnlineOrdersToggle', settings.btnOnlineOrders === true);

      // Populate QR Mode & Guest Wi-Fi Settings
      if (settings.qrMode !== undefined) setVal('adminQRMode', settings.qrMode);
      if (settings.wifiSSID !== undefined) setVal('adminWifiSSID', settings.wifiSSID);
      if (settings.wifiPassword !== undefined) setVal('adminWifiPassword', settings.wifiPassword);
      if (settings.ngrokAuthtoken !== undefined) setVal('adminNgrokAuthtoken', settings.ngrokAuthtoken);
      if (settings.ngrokSubdomain !== undefined) setVal('adminNgrokSubdomain', settings.ngrokSubdomain);
      setChecked('adminShowTableMap', settings.showTableMap !== false);
      setChecked('adminShowBartenderBtn', settings.showBartender !== false);
      setChecked('adminShowGiftBtn', settings.showGift !== false);
      setChecked('adminShowHostessHub', settings.showHostessHub !== false);
      setChecked('adminEnableOrderSMSAlerts', settings.enableOrderSMSAlerts !== false);
      setChecked('adminEnableCarSelfOrdering', settings.enableCarSelfOrdering !== false);
      setChecked('adminAutoUpdateEnabled', settings.autoUpdateEnabled !== false);
      
      const btnCarToggle = document.getElementById('btnCarOrdersToggle');
      if (btnCarToggle) {
        btnCarToggle.style.display = (settings.enableCarSelfOrdering !== false) ? 'flex' : 'none';
      }

      // Fetch dynamic local IP to update setup labels
      fetch(`${SERVER_URL}/api/local-ip`)
        .then(r => r.json())
        .then(data => {
          const ip = data.ip || 'localhost';
          const lobbyURL = document.getElementById('lblLobbySetupURL');
          if (lobbyURL) lobbyURL.innerText = `http://${ip}:3000/espera.html`;
          const kdsURL = document.getElementById('lblKDSSetupURL');
          if (kdsURL) kdsURL.innerText = `KDS 1: http://${ip}:3000/cocina.html?station=bakery`;
          const kds2URL = document.getElementById('lblKDS2SetupURL');
          if (kds2URL) kds2URL.innerText = `KDS 2: http://${ip}:3000/cocina.html?station=togo`;
          const runnerURL = document.getElementById('lblRunnerSetupURL');
          if (runnerURL) runnerURL.innerText = `Runner: http://${ip}:3000/runner.html`;
          const barURL = document.getElementById('lblKDSBarSetupURL');
          if (barURL) barURL.innerText = `Bar: http://${ip}:3000/kds_bar.html`;
        }).catch(err => console.error("Error fetching local IP:", err));
      
      renderCustomPrinters();
      populateProductPrinterRoutingDropdown();
    }
  } catch(e) {
    console.error("Error loading settings:", e);
  }
}

async function saveAdminSettings() {
  const getVal = (id, def = '') => {
    const el = document.getElementById(id);
    return el ? el.value : def;
  };
  const getChecked = (id, def = false) => {
    const el = document.getElementById(id);
    return el ? el.checked : def;
  };

  const taxRate = parseFloat(getVal('adminTaxRate', '0')) || 0;
  const autoPrint = getChecked('adminAutoPrint', false);
  const welcomePoints = parseInt(getVal('adminWelcomePoints', '0')) || 0;
  
  const printerType = getVal('adminPrinterType', 'local');
  const printerLocalName = getVal('adminPrinterLocalSelect', '').trim();
  const printerIP = (printerType === 'local' 
    ? printerLocalName 
    : getVal('adminPrinterIP', '')).trim();
    
  const printLogoOnReceipts = getChecked('adminPrintLogoOnReceipts', false);
  const labelPrinterName = getVal('adminLabelPrinterName', '');
  const kitchenPrinterName = getVal('adminKitchenPrinterName', '');
  const kitchenPrinter2Name = getVal('adminKitchenPrinter2Name', '');
  const kitchenPrinter3Name = getVal('adminKitchenPrinter3Name', '');
  const kitchenTicketFontSize = getVal('adminKitchenTicketFontSize', '5');
  const reportingPrinterName = getVal('adminReportingPrinterName', '');
  const photoPrinterName = getVal('adminPhotoPrinterName', '');
  const stationId = getVal('adminStationId', '1');
  const stationRole = getVal('adminStationRole', 'cashier');
  const notificationProvider = getVal('adminNotificationProvider', 'telegram');
  const telegramBotToken = getVal('adminTelegramBotToken', '').trim();
  const telegramBotUsername = getVal('adminTelegramBotUsername', '').trim().replace(/^@/, '');
  const paymentTerminalType = getVal('adminPaymentType', 'none');
  const paymentTerminalIP = getVal('adminPaymentIP', '').trim();
  const biometricWebSocketUrl = getVal('adminBiometricWS', '').trim();
  const callerIdType = getVal('adminCallerIdType', 'disabled');
  const enableCoinDispenser = getChecked('adminEnableCoinDispenser', false);
  const enableWeightScale = getChecked('adminEnableWeightScale', false);
  const weightScalePort = getVal('adminWeightScalePort', 'COM4').trim();
  const weightScaleUnit = getVal('adminWeightScaleUnit', 'lb').trim();
  const weightScaleProtocol = getVal('adminWeightScaleProtocol', 'toledo').trim();
  const coinDispenserPort = getVal('adminCoinDispenserPort', '').trim();
  const twilioAccountSid = getVal('adminTwilioAccountSid', '').trim();
  const twilioAuthToken = getVal('adminTwilioAuthToken', '').trim();
  const twilioPhoneNumber = getVal('adminTwilioPhoneNumber', '').trim();
  const developerSupportPhone = getVal('adminDeveloperSupportPhone', '').trim();
  const qrMode = getVal('adminQRMode', 'none');
  const wifiSSID = getVal('adminWifiSSID', '').trim();
  const wifiPassword = getVal('adminWifiPassword', '').trim();
  const ngrokAuthtoken = getVal('adminNgrokAuthtoken', '').trim();
  const ngrokSubdomain = getVal('adminNgrokSubdomain', '').trim();
  const showTableMap = getChecked('adminShowTableMap', false);
  const showBartender = getChecked('adminShowBartenderBtn', true);
  const showGift = getChecked('adminShowGiftBtn', true);
  const showHostessHub = getChecked('adminShowHostessHub', false);
  const enableOrderSMSAlerts = getChecked('adminEnableOrderSMSAlerts', false);
  const enableCarSelfOrdering = getChecked('adminEnableCarSelfOrdering', false);
  const autoUpdateEnabled = getChecked('adminAutoUpdateEnabled', true);

  // Collect business profile info
  const businessName = getVal('adminBusinessName', '').trim();
  
  // Multiselect businessType
  const bTypes = [];
  if (getChecked('adminTypeBakery', false)) bTypes.push('bakery');
  if (getChecked('adminTypeRestaurant', false)) bTypes.push('restaurant');
  if (getChecked('adminTypeStore', false)) bTypes.push('store');
  if (getChecked('adminTypeCafe', false)) bTypes.push('cafe');
  if (getChecked('adminTypeBar', false)) bTypes.push('bar');
  if (getChecked('adminTypeTacoTruck', false)) bTypes.push('taco_truck');
  const businessType = bTypes.join(',');

  const address = getVal('adminBusinessAddress', '').trim();
  const phone = getVal('adminBusinessPhone', '').trim();
  const clientSubdomain = getVal('adminClientSubdomain', '').trim();
  const cloudDomain = getVal('adminCloudDomain', '').trim();

  const language = getVal('adminLanguage', 'en');
  const langKDS = getVal('adminLanguageKDS', 'en');
  const langRunner = getVal('adminLanguageRunner', 'en');
  const langLobby = getVal('adminLanguageLobby', 'en');
  const langCustomerTicket = getVal('adminLanguageCustTicket', 'en');
  const langKitchenTicket = getVal('adminLanguageKitTicket', 'en');
  const selectedRadio = document.querySelector('input[name="adminDefaultServiceRadio"]:checked');
  const defaultServiceType = selectedRadio ? selectedRadio.value : (getVal('adminDefaultServiceType', '') || 'llevar');
  const tipsMode = getVal('adminTipsMode', 'weekly');
  const tipsFeePercentage = parseFloat(getVal('adminTipsFeePercentage', '3.0')) || 0;
  
  const services = ['walkin']; // walkin is default
  if (getChecked('adminServiceToGo', false)) services.push('llevar');
  if (getChecked('adminServiceDineIn', false)) services.push('comer');
  if (getChecked('adminServiceDriveThru', false)) services.push('drive-thru');
  if (getChecked('adminServicePickup', false)) services.push('pickup');
  if (getChecked('adminServiceDelivery', false)) services.push('delivery');
  
  if (services.length === 0) {
    showToast('Please enable at least one service type', 'error');
    return;
  }

  // Bottom buttons
  const btnWaitlist = getChecked('adminBtnWaitlist', true);
  const btnToGo = getChecked('adminBtnToGo', true);
  const btnCarOrders = getChecked('adminBtnCarOrders', false);
  const btnPhoneOrders = getChecked('adminBtnPhoneOrders', false);
  const btnOnlineOrders = getChecked('adminBtnOnlineOrders', false);

  const nvrEnabled = getChecked('adminNVREnabled', false);
  const nvrIP = getVal('adminNVRIP', '192.168.1.100').trim();
  const nvrPort = parseInt(getVal('adminNVRPort', '10010')) || 10010;

  const recordEnabled = getChecked('adminRecordEnabled', false);
  const recordPath = getVal('adminRecordPath', 'C:\\POS_Recordings').trim();
  const recordQuality = getVal('adminRecordQuality', 'medium');

  const settingsData = {
    taxRate,
    autoPrint,
    welcomePoints,
    printerType,
    printerLocalName,
    printerIP,
    labelPrinterName,
    kitchenPrinterName,
    kitchenPrinter2Name,
    kitchenPrinter3Name,
    kitchenTicketFontSize,
    reportingPrinterName,
    photoPrinterName,
    printLogoOnReceipts,
    stationId,
    stationRole,
    notificationProvider,
    telegramBotToken,
    telegramBotUsername,
    paymentTerminalType,
    paymentTerminalIP,
    paymentTerminalPort: "8080",
    biometricWebSocketUrl,
    callerIdType,
    enableCoinDispenser,
    enableWeightScale,
    weightScalePort,
    weightScaleUnit,
    weightScaleProtocol,
    coinDispenserPort,
    twilioAccountSid,
    twilioAuthToken,
    nvrEnabled,
    nvrIP,
    nvrPort,
    recordEnabled,
    recordPath,
    recordQuality,
    twilioPhoneNumber,
    developerSupportPhone,
    businessName,
    businessType,
    address,
    phone,
    clientSubdomain,
    cloudDomain,
    services,
    defaultServiceType,
    tipsMode,
    tipsFeePercentage,
    language,
    langKDS,
    langRunner,
    langLobby,
    langCustomerTicket,
    langKitchenTicket,
    qrMode,
    wifiSSID,
    wifiPassword,
    ngrokAuthtoken,
    ngrokSubdomain,
    showTableMap,
    showBartender,
    showGift,
    showHostessHub,
    enableOrderSMSAlerts,
    enableCarSelfOrdering,
    autoUpdateEnabled,
    btnWaitlist,
    btnToGo,
    btnCarOrders,
    btnPhoneOrders,
    btnOnlineOrders,
    customPrinters: posSettings.customPrinters || []
  };

  try {
    const response = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsData)
    });
    if (response.ok) {
      posSettings = { ...posSettings, ...settingsData };
      window.appSettings = posSettings;
      showToast('System and hardware settings updated successfully!', 'success');
      await loadSettingsFromServer(); // Reload logo header / service tabs
      switchOptionsPane('paneOptCashier', document.getElementById('btnOptCashier'));
      initBiometricWebSocket(); // Reconnect using new URL
    } else {
      showToast('Error saving settings on server', 'error');
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}

function toggleNotificationProviderUI(provider) {
  const prov = provider || (document.getElementById('adminNotificationProvider')?.value) || 'telegram';
  const secTelegram = document.getElementById('secTelegramSettings');
  const secTwilio = document.getElementById('secTwilioSettings');
  if (secTelegram && secTwilio) {
    if (prov === 'telegram') {
      secTelegram.style.display = 'flex';
      secTwilio.style.display = 'none';
    } else {
      secTelegram.style.display = 'none';
      secTwilio.style.display = 'flex';
    }
  }
}
window.toggleNotificationProviderUI = toggleNotificationProviderUI;

async function testTelegramNotification() {
  const token = document.getElementById('adminTelegramBotToken')?.value.trim();
  const username = document.getElementById('adminTelegramBotUsername')?.value.trim().replace(/^@/, '');
  const isEs = (typeof posSettings !== 'undefined' && posSettings && posSettings.language === 'es');

  if (!token) {
    showToast(isEs ? 'Ingrese el Token de su Bot de Telegram primero' : 'Please enter your Telegram Bot Token first', 'warning');
    return;
  }

  showToast(isEs ? 'Verificando Bot con Telegram...' : 'Verifying Bot with Telegram...', 'info');

  try {
    const res = await fetch(`${SERVER_URL}/api/notifications/test-telegram`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token, username })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast(isEs ? `Conexión Exitosa con @${data.bot.username}!` : `Connection Successful with @${data.bot.username}!`, 'success');
      if (document.getElementById('adminTelegramBotUsername') && !document.getElementById('adminTelegramBotUsername').value) {
        document.getElementById('adminTelegramBotUsername').value = data.bot.username;
      }
    } else {
      showToast(isEs ? `Error de Telegram: ${data.error || 'Token inválido'}` : `Telegram error: ${data.error || 'Invalid token'}`, 'error');
    }
  } catch (err) {
    showToast(isEs ? 'Error de red al conectar con Telegram' : 'Network error connecting to Telegram', 'error');
  }
}
window.testTelegramNotification = testTelegramNotification;

window.systemPrintersList = [];

async function populatePrintersDropdowns(isUserClick = false) {
  try {
    const isEs = (typeof posSettings !== 'undefined' && posSettings && posSettings.language === 'es');
    if (isUserClick) {
      showToast(isEs ? "Buscando impresoras en Windows..." : "Scanning Windows printers...", "info");
    }

    const response = await fetch(`${SERVER_URL}/api/admin/printers-list`);
    if (response.ok) {
      const printers = await response.json();
      window.systemPrintersList = printers;
      
      const dropdownConfigs = [
        { id: 'adminPrinterLocalSelect', defaultText: isEs ? 'Elegir Impresora de Recibos...' : 'Choose Caja Receipt Printer...' },
        { id: 'adminLabelPrinterName', defaultText: isEs ? 'Elegir Impresora de Etiquetas...' : 'Choose Runner Label Printer...' },
        { id: 'adminKitchenPrinterName', defaultText: isEs ? 'Elegir Impresora de Pedidos...' : 'Choose Custom Orders Printer...' },
        { id: 'adminKitchenPrinter2Name', defaultText: isEs ? 'Elegir Impresora de Cocina...' : 'Choose Kitchen Printer...' },
        { id: 'adminKitchenPrinter3Name', defaultText: isEs ? 'Elegir Impresora de Barra...' : 'Choose Bar Printer...' },
        { id: 'adminReportingPrinterName', defaultText: isEs ? 'Elegir Impresora de Reportes...' : 'Choose Back Office Printer...' },
        { id: 'adminPhotoPrinterName', defaultText: isEs ? 'Elegir Impresora Photo Hub...' : 'Choose Photo Hub Printer...' },
        { id: 'customPrinterLocalSelect', defaultText: isEs ? 'Elegir Impresora...' : 'Choose Printer...' }
      ];

      dropdownConfigs.forEach(({ id, defaultText }) => {
        const selectEl = document.getElementById(id);
        if (!selectEl) return;
        const currentVal = selectEl.value;
        selectEl.innerHTML = `<option value="">${defaultText}</option>`;
        printers.forEach(printer => {
          const opt = document.createElement('option');
          opt.value = printer;
          opt.innerText = printer;
          selectEl.appendChild(opt);
        });
        if (currentVal && Array.from(selectEl.options).some(o => o.value === currentVal)) {
          selectEl.value = currentVal;
        }
      });

      // Restore saved values from posSettings if available
      if (typeof posSettings !== 'undefined' && posSettings) {
        const sSelect = document.getElementById('adminPrinterLocalSelect');
        if (sSelect && posSettings.printerLocalName && !sSelect.value) {
          sSelect.value = posSettings.printerLocalName;
        }
        const kSelect = document.getElementById('adminKitchenPrinterName');
        if (kSelect && posSettings.kitchenPrinterName && !kSelect.value) {
          kSelect.value = posSettings.kitchenPrinterName;
        }
        const repSelect = document.getElementById('adminReportingPrinterName');
        if (repSelect && posSettings.reportingPrinterName && !repSelect.value) {
          repSelect.value = posSettings.reportingPrinterName;
        }
      }

      if (typeof window.switchPrinterChannel === 'function') {
        window.switchPrinterChannel('KitchenMain');
      }
      if (typeof window.switchKitchenSubTab === 'function') {
        window.switchKitchenSubTab('KDS');
      }
      if (typeof window.switchBarSubTab === 'function') {
        window.switchBarSubTab('KDS');
      }
      if (typeof window.switchRunnerSubTab === 'function') {
        window.switchRunnerSubTab('KDS');
      }

      if (isUserClick) {
        showToast(isEs ? `Se encontraron ${printers.length} impresoras instaladas` : `Found ${printers.length} installed printers`, "success");
      }
    }
  } catch(e) {
    console.error("Error populating printers dropdown:", e);
    if (isUserClick) {
      showToast("Error al escanear impresoras", "error");
    }
  }
}

// --- DYNAMIC CUSTOM PRINTERS LOGIC ---
function renderCustomPrinters() {
  const container = document.getElementById('customPrintersList');
  if (!container) return;
  const printers = posSettings.customPrinters || [];
  if (printers.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); font-size: 11px; padding: 12px;">No custom printers configured. Click "+ Add Custom Printer" to create one.</div>`;
    return;
  }
  
  container.innerHTML = '';
  printers.forEach(p => {
    const row = document.createElement('div');
    row.style.display = 'flex';
    row.style.justify = 'space-between';
    row.style.alignItems = 'center';
    row.style.padding = '8px 10px';
    row.style.background = 'rgba(255,255,255,0.02)';
    row.style.border = '1px solid var(--border-color)';
    row.style.borderRadius = '4px';
    row.style.marginTop = '4px';
    
    let connInfo = '';
    if (p.connectionType === 'local') {
      connInfo = `Local: <strong style="color:#fff;">${p.deviceName || 'None'}</strong>`;
    } else {
      connInfo = `IP: <strong style="color:#fff;">${p.deviceName || 'None'}:${p.port || '9100'}</strong>`;
    }

    row.innerHTML = `
      <div style="text-align: left;">
        <span style="font-weight: bold; color: var(--accent-color); font-size: 12px;">${p.name}</span><br>
        <span style="font-size: 10px; color: var(--text-secondary);">${connInfo}</span>
      </div>
      <div style="display: flex; gap: 6px;">
        <button type="button" class="btn-modal secondary" onclick="window.openEditCustomPrinterModal('${p.id}')" style="margin: 0; padding: 4px 8px; font-size: 10px; height: 24px; border-radius: 4px;">Edit</button>
        <button type="button" class="btn-modal danger" onclick="window.deleteCustomPrinter('${p.id}')" style="margin: 0; padding: 4px 8px; font-size: 10px; height: 24px; border-radius: 4px; background-color: var(--danger-color); color: #fff; border: none;">Delete</button>
      </div>
    `;
    container.appendChild(row);
  });
}

function openAddCustomPrinterModal() {
  document.getElementById('lblCustomPrinterTitle').innerText = 'New Custom Printer Config';
  document.getElementById('customPrinterId').value = '';
  document.getElementById('customPrinterName').value = '';
  document.getElementById('customPrinterConnType').value = 'local';
  document.getElementById('customPrinterIP').value = '';
  document.getElementById('customPrinterPort').value = '9100';
  
  populateCustomPrinterDropdown();
  document.getElementById('customPrinterLocalSelect').value = '';
  
  toggleCustomPrinterFields();
  document.getElementById('modalCustomPrinter').style.display = 'flex';
}

function openEditCustomPrinterModal(id) {
  const printers = posSettings.customPrinters || [];
  const p = printers.find(x => x.id === id);
  if (!p) return;
  
  document.getElementById('lblCustomPrinterTitle').innerText = 'Edit Custom Printer Config';
  document.getElementById('customPrinterId').value = p.id;
  document.getElementById('customPrinterName').value = p.name;
  document.getElementById('customPrinterConnType').value = p.connectionType;
  
  populateCustomPrinterDropdown();
  if (p.connectionType === 'local') {
    document.getElementById('customPrinterLocalSelect').value = p.deviceName || '';
    document.getElementById('customPrinterIP').value = '';
    document.getElementById('customPrinterPort').value = '9100';
  } else {
    document.getElementById('customPrinterLocalSelect').value = '';
    document.getElementById('customPrinterIP').value = p.deviceName || '';
    document.getElementById('customPrinterPort').value = p.port || '9100';
  }
  
  toggleCustomPrinterFields();
  document.getElementById('modalCustomPrinter').style.display = 'flex';
}

function closeCustomPrinterModal() {
  document.getElementById('modalCustomPrinter').style.display = 'none';
}

function toggleCustomPrinterFields() {
  const connType = document.getElementById('customPrinterConnType').value;
  const divLocal = document.getElementById('divCustomPrinterLocal');
  const divNetwork = document.getElementById('divCustomPrinterNetwork');
  if (connType === 'local') {
    divLocal.style.display = 'block';
    divNetwork.style.display = 'none';
  } else {
    divLocal.style.display = 'none';
    divNetwork.style.display = 'block';
  }
}

function populateCustomPrinterDropdown() {
  const select = document.getElementById('customPrinterLocalSelect');
  if (select) {
    select.innerHTML = '<option value="">Choose Printer...</option>';
    if (window.systemPrintersList) {
      window.systemPrintersList.forEach(printer => {
        const opt = document.createElement('option');
        opt.value = printer;
        opt.innerText = printer;
        select.appendChild(opt);
      });
    }
  }
}

function populateProductPrinterRoutingDropdown() {
  const select = document.getElementById('prodPrinterId');
  if (select) {
    select.innerHTML = '<option value="">Default Kitchen Printer / Impresora de Cocina Principal</option>';
    const customPrinters = posSettings.customPrinters || [];
    customPrinters.forEach(cp => {
      const opt = document.createElement('option');
      opt.value = cp.id;
      opt.innerText = cp.name;
      select.appendChild(opt);
    });
  }
}

async function saveCustomPrinter() {
  const id = document.getElementById('customPrinterId').value;
  const name = document.getElementById('customPrinterName').value.trim();
  const connectionType = document.getElementById('customPrinterConnType').value;
  
  if (!name) {
    showToast('Please enter a printer name', 'error');
    return;
  }
  
  let deviceName = '';
  let port = '9100';
  if (connectionType === 'local') {
    deviceName = document.getElementById('customPrinterLocalSelect').value;
    if (!deviceName) {
      showToast('Please select a system printer', 'error');
      return;
    }
  } else {
    deviceName = document.getElementById('customPrinterIP').value.trim();
    port = document.getElementById('customPrinterPort').value.trim() || '9100';
    if (!deviceName) {
      showToast('Please enter an IP address', 'error');
      return;
    }
  }
  
  if (!posSettings.customPrinters) {
    posSettings.customPrinters = [];
  }
  
  if (id) {
    const idx = posSettings.customPrinters.findIndex(x => x.id === id);
    if (idx !== -1) {
      posSettings.customPrinters[idx] = { id, name, connectionType, deviceName, port };
    }
  } else {
    const newId = 'cp_' + Date.now();
    posSettings.customPrinters.push({ id: newId, name, connectionType, deviceName, port });
  }
  
  try {
    const response = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customPrinters: posSettings.customPrinters })
    });
    if (response.ok) {
      showToast('Custom printer saved successfully!', 'success');
      closeCustomPrinterModal();
      renderCustomPrinters();
      populateProductPrinterRoutingDropdown();
    } else {
      showToast('Error saving custom printer on server', 'error');
    }
  } catch(e) {
    showToast('Connection error', 'error');
  }
}

async function deleteCustomPrinter(id) {
  const isEs = posSettings.language === 'es';
  if (!confirm(isEs ? '¿Está seguro de eliminar esta impresora?' : 'Are you sure you want to delete this custom printer?')) {
    return;
  }
  
  if (!posSettings.customPrinters) return;
  posSettings.customPrinters = posSettings.customPrinters.filter(x => x.id !== id);
  
  try {
    const response = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customPrinters: posSettings.customPrinters })
    });
    if (response.ok) {
      showToast('Custom printer deleted successfully', 'success');
      renderCustomPrinters();
      populateProductPrinterRoutingDropdown();
    } else {
      showToast('Error deleting custom printer on server', 'error');
    }
  } catch(e) {
    showToast('Connection error', 'error');
  }
}

async function testCustomPrinter() {
  const connectionType = document.getElementById('customPrinterConnType').value;
  let printerName = '';
  let printerIP = '';
  
  if (connectionType === 'local') {
    printerName = document.getElementById('customPrinterLocalSelect').value;
    if (!printerName) {
      showToast('Please select a system printer to test', 'error');
      return;
    }
  } else {
    printerIP = document.getElementById('customPrinterIP').value.trim();
    if (!printerIP) {
      showToast('Please enter an IP address to test', 'error');
      return;
    }
  }
  
  try {
    let res;
    if (connectionType === 'local') {
      res = await fetch(`${SERVER_URL}/api/printer/test-kitchen`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName })
      });
    } else {
      res = await fetch(`${SERVER_URL}/api/printer/test-receipt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerType: 'network', printerIP })
      });
    }
    
    if (res.ok) {
      showToast('Test print job sent successfully!', 'success');
    } else {
      showToast('Test print job failed', 'error');
    }
  } catch(e) {
    showToast('Connection error', 'error');
  }
}

window.renderCustomPrinters = renderCustomPrinters;
window.openAddCustomPrinterModal = openAddCustomPrinterModal;
window.openEditCustomPrinterModal = openEditCustomPrinterModal;
window.closeCustomPrinterModal = closeCustomPrinterModal;
window.toggleCustomPrinterFields = toggleCustomPrinterFields;
window.populateCustomPrinterDropdown = populateCustomPrinterDropdown;
window.populateProductPrinterRoutingDropdown = populateProductPrinterRoutingDropdown;
window.saveCustomPrinter = saveCustomPrinter;
window.deleteCustomPrinter = deleteCustomPrinter;
window.testCustomPrinter = testCustomPrinter;

function startFingerprintEnrollment() {
  const modal = document.getElementById('modalAuth');
  const ripple = document.getElementById('scannerRipple');
  const statusLbl = document.getElementById('fingerprintStatus');
  const icon = document.getElementById('fingerprintIcon');
  const scanner = document.getElementById('fingerprintScanner');
  
  // Ocultar contraseña y teclado numérico
  document.getElementById('authPasscode').closest('div').parentElement.style.display = 'none';
  document.querySelector('#modalAuth h3').innerText = 'Register Staff Fingerprint';
  document.getElementById('btnSubmitAuth').style.display = 'none';
  modal.style.display = 'flex';

  statusLbl.innerText = 'Place finger on the physical USB fingerprint reader...';
  icon.style.color = 'var(--text-secondary)';
  
  // Limpiar eventos anteriores del scanner clonándolo
  const newScanner = scanner.cloneNode(true);
  scanner.parentNode.replaceChild(newScanner, scanner);

  newScanner.addEventListener('click', () => {
    showToast('Place finger on the physical USB reader', 'info');
    statusLbl.innerText = 'Place finger on the physical USB reader...';
  });
}

async function triggerSecureWebAuthnEnroll() {
  const statusLbl = document.getElementById('fingerprintStatus');
  const icon = document.getElementById('fingerprintIcon');
  
  if (!window.isSecureContext) {
    showToast('USB Biometric registration requires secure context (HTTPS/localhost).', 'error');
    return;
  }
  
  try {
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);
    
    const userId = 'user_' + Date.now();
    const empName = document.getElementById('empName') ? document.getElementById('empName').value : 'Employee';
    
    showToast('Place finger on the physical USB reader / Coloque su huella en el lector USB...', 'info');
    
    const credential = await navigator.credentials.create({
      publicKey: {
        challenge: challenge,
        rp: { 
          name: "Impossible POS™ Terminal",
          id: window.location.hostname
        },
        user: {
          id: new TextEncoder().encode(userId),
          name: empName,
          displayName: empName
        },
        pubKeyCredParams: [{ alg: -7, type: "public-key" }],
        timeout: 60000,
        authenticatorSelection: { 
          authenticatorAttachment: "platform",
          userVerification: "required" 
        }
      }
    });
    
    if (credential) {
      tempFingerprintRegistered = true;
      tempFingerprintTemplate = credential.id;
      
      const lblFingerprintStatus = document.getElementById('lblFingerprintStatus');
      if (lblFingerprintStatus) {
        lblFingerprintStatus.innerText = 'Fingerprint Status: REGISTERED';
        lblFingerprintStatus.style.color = 'var(--success-color)';
      }
      
      if (statusLbl) statusLbl.innerText = 'Enrollment Complete! Fingerprint Registered.';
      if (icon) icon.style.color = 'var(--success-color)';
      
      showToast('Enrollment Complete! Fingerprint Registered.', 'success');
      
      const modalAuth = document.getElementById('modalAuth');
      if (modalAuth && modalAuth.style.display !== 'none') {
        setTimeout(() => {
          modalAuth.style.display = 'none';
          restoreOriginalAuthModal();
        }, 1500);
      }
    }
  } catch (err) {
    console.error("WebAuthn enrollment failed:", err);
    showToast("Biometric enrollment failed or canceled", "error");
  }
}

function bindOriginalAuthListeners() {
  const scanner = document.getElementById('fingerprintScanner');
  if (scanner) {
    const newScanner = scanner.cloneNode(true);
    scanner.parentNode.replaceChild(newScanner, scanner);
    newScanner.addEventListener('click', () => {
      triggerSecureWebAuthnAuth();
    });
  }
}

function restoreOriginalAuthModal() {
  authRequiredRole = null;
  authSuccessCallback = null;
  document.querySelector('#modalAuth h3').innerText = 'Manager Authorization';
  
  const subEl = document.getElementById('modalAuthSubtitle');
  if (subEl) subEl.innerText = 'Biometric Fingerprint Scan or Enter Manager Passcode';

  const passcodeParent = document.getElementById('authPasscode').closest('div').parentElement;
  if (passcodeParent) passcodeParent.style.display = 'block';
  
  const submitBtn = document.getElementById('btnSubmitAuth');
  if (submitBtn) submitBtn.style.display = 'block';
  
  const statusLbl = document.getElementById('fingerprintStatus');
  if (statusLbl) statusLbl.innerText = 'Scan finger on physical reader or click to use Windows Hello...';
  
  const icon = document.getElementById('fingerprintIcon');
  if (icon) icon.style.color = 'var(--text-secondary)';
  
  bindOriginalAuthListeners();
}

if (typeof socket !== 'undefined' && socket) {
  socket.on('biometric_scan', (data) => {
    const template = (data && data.template) ? data.template : 'finger_1';
    handleBiometricScanEvent(template);
  });
}

async function triggerSecureWebAuthnAuth() {
  const statusLbl = document.getElementById('fingerprintStatus');
  if (statusLbl) statusLbl.innerText = 'Place finger on the physical USB fingerprint reader...';
  triggerBiometricScan();
}

// Global event delegation for on-screen numeric keypads (.auth-key and .punch-key)
document.addEventListener('click', (e) => {
  const target = e.target;
  if (!target) return;

  // 1. Manager/Admin passcode keypad
  const authBtn = target.closest('.auth-key');
  if (authBtn) {
    e.preventDefault();
    e.stopPropagation();
    const val = authBtn.getAttribute('data-value');
    const input = document.getElementById('authPasscode');
    if (input) {
      if (val === 'Backspace') {
        input.value = input.value.slice(0, -1);
      } else if (val === 'C') {
        input.value = '';
      } else {
        if (input.value.length < 4) {
          input.value += val;
        }
      }
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return;
  }

  // 2. Punch Clock passcode keypad
  const punchBtn = target.closest('.punch-key');
  if (punchBtn) {
    e.preventDefault();
    e.stopPropagation();
    const val = punchBtn.getAttribute('data-value');
    const input = document.getElementById('punchPasscode');
    if (input) {
      if (val === 'Backspace') {
        input.value = input.value.slice(0, -1);
      } else if (val === 'C') {
        input.value = '';
      } else {
        if (input.value.length < 4) {
          input.value += val;
        }
      }
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));

      // Auto evaluate on 4 digits
      if (input.value.length === 4) {
        evaluatePunchCode(input.value);
      }
    }
    return;
  }
});

// --- SOPORTE DE LECTOR DE TARJETAS USB (EMULACIÓN DE TECLADO) ---

window.addEventListener('keydown', (e) => {
  // Check if splash screen is visible
  const splash = document.getElementById('splashLoginScreen');
  const isSplashActive = splash && (splash.style.display === 'flex' || splash.style.display === 'block');
  
  const authModal = document.getElementById('modalAuth');
  const isAuthActive = authModal && (authModal.style.display === 'flex' || authModal.style.display === 'block');

  if (isSplashActive) {
    const now = Date.now();
    const isFastType = (now - lastKeyTime < 50);
    lastKeyTime = now;

    if (e.key >= '0' && e.key <= '9') {
      if (!isFastType) {
        if (splashPasscodeString.length < 10) {
          splashPasscodeString += e.key;
          updateSplashPasscodeDisplay();
        }
      }
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
      return;
    }
    if (e.key === 'Backspace') {
      splashPasscodeString = splashPasscodeString.slice(0, -1);
      updateSplashPasscodeDisplay();
      return;
    }
    if (e.key === 'Enter') {
      if (cardReaderBuffer.length > 2) {
        let cleanCode = cardReaderBuffer.trim().replace(/[%?;\s]/g, '');
        if (cleanCode.startsWith('B')) cleanCode = cleanCode.substring(1);
        processCardSwipe(cleanCode);
      } else if (splashPasscodeString.length === 4) {
        handleSplashLogin();
      }
      cardReaderBuffer = '';
      return;
    }
    if (e.key.length === 1) {
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
    }
    return;
  }

  if (isAuthActive) {
    const input = document.getElementById('authPasscode');
    const now = Date.now();
    const isFastType = (now - lastKeyTime < 50);
    lastKeyTime = now;

    if (e.key >= '0' && e.key <= '9') {
      if (!isFastType) {
        if (input.value.length < 4) {
          input.value += e.key;
        }
      }
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
      return;
    }
    if (e.key === 'Backspace') {
      input.value = input.value.slice(0, -1);
      return;
    }
    if (e.key === 'Enter') {
      if (cardReaderBuffer.length > 2) {
        input.value = '';
        let cleanCode = cardReaderBuffer.trim().replace(/[%?;\s]/g, '');
        if (cleanCode.startsWith('B')) cleanCode = cleanCode.substring(1);
        processCardSwipe(cleanCode);
      } else if (input.value.length === 4) {
        document.getElementById('btnSubmitAuth').click();
      }
      cardReaderBuffer = '';
      return;
    }
    if (e.key.length === 1) {
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
    }
    return;
  }

  const punchModal = document.getElementById('modalPunch');
  const isPunchActive = punchModal && (punchModal.style.display === 'flex' || punchModal.style.display === 'block');

  if (isPunchActive) {
    const input = document.getElementById('punchPasscode');
    const now = Date.now();
    const isFastType = (now - lastKeyTime < 50);
    lastKeyTime = now;

    if (e.key >= '0' && e.key <= '9') {
      if (!isFastType) {
        if (input.value.length < 4) {
          input.value += e.key;
        }
      }
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
      
      // Auto evaluate on 4 digits if typed slowly
      if (input.value.length === 4) {
        evaluatePunchCode(input.value);
      }
      return;
    }
    if (e.key === 'Backspace') {
      input.value = input.value.slice(0, -1);
      return;
    }
    if (e.key === 'Enter') {
      if (cardReaderBuffer.length > 2) {
        input.value = '';
        let cleanCode = cardReaderBuffer.trim().replace(/[%?;\s]/g, '');
        if (cleanCode.startsWith('B')) cleanCode = cleanCode.substring(1);
        evaluatePunchCode(cleanCode);
      } else if (input.value.length === 4) {
        evaluatePunchCode(input.value);
      }
      cardReaderBuffer = '';
      return;
    }
    if (e.key.length === 1) {
      cardReaderBuffer += e.key;
      if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
      cardReaderTimeout = setTimeout(() => {
        cardReaderBuffer = '';
      }, 200);
    }
    return;
  }

  if (e.key !== 'Enter' && e.key.length !== 1) return;

  if (e.key === 'Enter') {
    if (cardReaderBuffer.length > 2) {
      let cleanCode = cardReaderBuffer.trim().replace(/[%?;\s]/g, '');
      if (cleanCode.startsWith('B')) cleanCode = cleanCode.substring(1);

      const empForm = document.getElementById('employeeFormContainer');
      const prodForm = document.getElementById('productFormContainer');
      if (empForm && empForm.style.display !== 'none') {
        document.getElementById('empCardCode').value = cleanCode;
        document.getElementById('empCardCode').dispatchEvent(new Event('input', { bubbles: true }));
        showToast(`Card swiped: Code ${cleanCode} copied to Employee Profile!`, 'success');
      } else if (prodForm && prodForm.style.display !== 'none') {
        document.getElementById('prodBarcode').value = cleanCode;
        document.getElementById('prodBarcode').dispatchEvent(new Event('input', { bubbles: true }));
        showToast(`Barcode scanned: Code ${cleanCode} copied to Product Info!`, 'success');
      } else {
        processCardSwipe(cardReaderBuffer);
      }
    }
    cardReaderBuffer = '';
  } else {
    cardReaderBuffer += e.key;
    
    if (cardReaderTimeout) clearTimeout(cardReaderTimeout);
    cardReaderTimeout = setTimeout(() => {
      cardReaderBuffer = '';
    }, 200);
  }
});

async function processCardSwipe(cardCode) {
  cardCode = cardCode.trim();
  console.log("Card swipe detected:", cardCode);
  
  let cleanCode = cardCode.replace(/[%?;\s]/g, '');
  if (cleanCode.startsWith('B')) cleanCode = cleanCode.substring(1);
  
  try {
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (res.ok) {
      const emps = await res.json();
      const matchedEmp = emps.find(emp => emp.cardCode === cleanCode || emp.passcode === cleanCode || emp.id === cleanCode || emp.fingerprintTemplate === cleanCode) ||
        (emps.find(e => e.name === 'Jorge') || emps[0]);
      if (matchedEmp) {
        // Enforce Punch In: verificar si está ponchado/laborando hoy
        if (matchedEmp.role !== 'admin' && matchedEmp.role !== 'manager') {
          const lastPunch = matchedEmp.punchHistory && matchedEmp.punchHistory.length > 0 
            ? matchedEmp.punchHistory[matchedEmp.punchHistory.length - 1] 
            : null;
          
          if (!lastPunch || lastPunch.type !== 'in') {
            showToast(`Must Punch In first to start work, ${matchedEmp.name}!`, 'error');
            return;
          }
        }

        showToast(`Card Swiped: Welcome ${matchedEmp.name}!`, 'success');
        document.getElementById('modalAuth').style.display = 'none';
        
        if (authSuccessCallback) {
          if (authRequiredRole === 'manager' || authRequiredRole === 'admin') {
            const role = (matchedEmp.role || '').toLowerCase();
            if (role !== 'manager' && role !== 'admin') {
              const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
              showToast(isEs ? 'No estás autorizado para ver esto. Solo Gerente o Administrador.' : 'You are not authorized to view this. Manager or Admin only.', 'error');
              return;
            }
          }
          const cb = authSuccessCallback;
          authSuccessCallback = null;
          authRequiredRole = null;
          cb(matchedEmp.name);
        } else {
          currentCashierName = matchedEmp.name;
          await checkActiveShiftAndLockState(matchedEmp.name);
          hideSplash();
        }
        return;
      }
    }
    showToast('Invalid employee card', 'error');
  } catch(err) {
    console.error("Error processing card swipe:", err);
    showToast('Card authentication failed', 'error');
  }
}

// --- FUNCIONES GLOBAL CONTROL SPLASH SCREEN Y APERTURA DE CAJA ---

async function checkActiveShiftAndLockState(cashierToQuery = null) {
  try {
    const targetCashier = (cashierToQuery || currentCashierName || '').trim();
    const url = targetCashier 
      ? `${SERVER_URL}/api/shifts/active?cashier=${encodeURIComponent(targetCashier)}` 
      : `${SERVER_URL}/api/shifts/active`;
    const response = await fetch(url);
    if (response.ok) {
      const shift = await response.json();
      const isEs = (posSettings && posSettings.language === 'es');
      const badge = document.getElementById('btnActiveCashier');
      if (shift && shift.status === 'open') {
        activeShift = shift;
        currentCashierName = shift.cashierName;
        currentCashierDrawer = shift.drawerNumber || 1;
        if (badge) {
          badge.innerText = isEs 
            ? `Cajero: ${shift.cashierName} (Cajón ${currentCashierDrawer})` 
            : `Cashier: ${shift.cashierName} (Drawer ${currentCashierDrawer})`;
        }
      } else {
        activeShift = null;
        currentCashierDrawer = 1;
        if (badge) {
          badge.innerText = isEs 
            ? (targetCashier ? `Cajero: ${targetCashier} (Sin Turno)` : 'Cajero: -') 
            : (targetCashier ? `Cashier: ${targetCashier} (No Shift)` : 'Cashier: -');
        }
      }
    }
  } catch(e) {
    console.error("Error checking active shift:", e);
  }
}
const checkActiveShift = checkActiveShiftAndLockState;

function showSplash() {
  const splash = document.getElementById('splashLoginScreen');
  if (splash) {
    splash.style.display = 'flex';
    splash.style.opacity = '1';
    splash.style.visibility = 'visible';
  }
  if (!splashPasscodeString) {
    splashPasscodeString = '';
    updateSplashPasscodeDisplay();
  }
  if (idleTimer) clearTimeout(idleTimer);
}

function hideSplash() {
  const splash = document.getElementById('splashLoginScreen');
  if (splash) {
    splash.style.opacity = '0';
    splash.style.visibility = 'hidden';
    setTimeout(() => {
      splash.style.display = 'none';
    }, 400);
  }
  resetIdleTimer();
  showPreOrderSelection();
}

function showPreOrderSelection() {
  const overlay = document.getElementById('preOrderSelectionScreen');
  if (overlay) {
    overlay.style.display = 'none';
    overlay.style.opacity = '0';
    overlay.style.visibility = 'hidden';
  }
  
  // Determine active services from settings
  const services = posSettings.services || ['walkin', 'llevar', 'comer', 'drive-thru', 'pickup', 'delivery'];
  const defaultType = posSettings.defaultServiceType || (posSettings.businessType && posSettings.businessType.includes('taco_truck') ? 'llevar' : null);
  
  if (defaultType && services.includes(defaultType)) {
    selectPreOrderType(defaultType);
  } else {
    // Force manual selection: clear selection
    deliveryType = null;
    const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option[data-type]');
    deliveryOpts.forEach(btn => btn.classList.remove('selected'));
  }
}

function selectPreOrderType(type) {
  // Sync with global deliveryType
  deliveryType = type;
  
  // Update selection style of the buttons in the main POS sidebar
  const deliveryOpts = document.querySelectorAll('#cartOrderTypeContainer .btn-option[data-type]');
  deliveryOpts.forEach(btn => {
    if (btn.getAttribute('data-type') === type) {
      btn.classList.add('selected');
    } else {
      btn.classList.remove('selected');
    }
  });
  
  // Close the preorder overlay
  const overlay = document.getElementById('preOrderSelectionScreen');
  if (overlay) {
    overlay.style.opacity = '0';
    overlay.style.visibility = 'hidden';
    setTimeout(() => {
      overlay.style.display = 'none';
    }, 300);
  }
}

function updateSplashPasscodeDisplay() {
  const display = document.getElementById('splashPasscodeDisplay');
  if (display) {
    const len = splashPasscodeString.length;
    const maxLen = 4;
    let dots = '';
    for (let i = 0; i < maxLen; i++) {
      if (i < len) {
        dots += '● ';
      } else {
        dots += '○ ';
      }
    }
    display.innerText = dots.trim();
  }
}

async function handleSplashLogin() {
  if (!splashPasscodeString) {
    showToast('Please scan fingerprint or enter passcode first', 'error');
    return;
  }

  try {
    const response = await fetch(`${SERVER_URL}/api/employees`);
    if (response.ok) {
      const emps = await response.json();
      const matchedEmp = emps.find(e => e.passcode === splashPasscodeString || e.cardCode === splashPasscodeString) ||
        (splashPasscodeString === '1111' ? (emps.find(e => e.name === 'Jorge') || emps[0]) : null);

      if (matchedEmp) {
        currentCashierName = matchedEmp.name;
        await checkActiveShiftAndLockState(matchedEmp.name);
        showToast(`Welcome back, ${matchedEmp.name}!`, 'success');

        hideSplash();
      } else {
        showToast('Invalid passcode or fingerprint', 'error');
        splashPasscodeString = '';
        updateSplashPasscodeDisplay();
      }
    }
  } catch(e) {
    console.error(e);
    showToast('Authentication error', 'error');
  }
}

async function handleSplashPunch() {
  if (!splashPasscodeString) {
    showToast('Please enter passcode to Punch', 'error');
    return;
  }

  try {
    const resEmp = await fetch(`${SERVER_URL}/api/employees`);
    if (resEmp.ok) {
      const emps = await resEmp.json();
      const matchedEmp = emps.find(e => e.passcode === splashPasscodeString || e.cardCode === splashPasscodeString);
      if (!matchedEmp) {
        showToast('Invalid employee passcode', 'error');
        return;
      }

      const lastPunch = matchedEmp.punchHistory && matchedEmp.punchHistory.length > 0 
        ? matchedEmp.punchHistory[matchedEmp.punchHistory.length - 1] 
        : null;
      const type = lastPunch && lastPunch.type === 'in' ? 'out' : 'in';

      const response = await fetch(`${SERVER_URL}/api/employees/punch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeIdOrCard: splashPasscodeString, type: type })
      });

      if (response.ok) {
        const actionText = type === 'in' ? 'PUNCHED IN (Start Work)' : 'PUNCHED OUT (End Work)';
        showToast(`${matchedEmp.name}: ${actionText} successfully!`, 'success');
        splashPasscodeString = '';
        updateSplashPasscodeDisplay();
      } else {
        showToast('Error recording punch clock', 'error');
      }
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}

// --- FUNCIONES APERTURA DE CAJA / OPEN SHIFT ---
function closeOpenShiftModal() {
  const modal = document.getElementById('modalOpenShift');
  if (modal) modal.style.display = 'none';
}
window.closeOpenShiftModal = closeOpenShiftModal;

function resetOpenShiftInputs() {
  const inputs = [
    'openCoinsPennies', 'openCoinsNickels', 'openCoinsDimes', 'openCoinsQuarters',
    'openBillsOnes', 'openBillsFives', 'openBillsTens', 'openBillsTwenties', 'openBillsFifties', 'openBillsHundreds'
  ];
  inputs.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '0';
  });
  const directInp = document.getElementById('inputStartingCashDirect');
  if (directInp) directInp.value = '0.00';
  const lbl = document.getElementById('lblStartingCashTotal');
  if (lbl) lbl.innerText = '$0.00';
  
  [0, 50, 100, 150, 200].forEach(preset => {
    const btn = document.getElementById(`btnQuickCash${preset}`) || document.querySelector(`button[onclick="setQuickStartingCash(${preset})"]`);
    if (btn) {
      btn.classList.remove('selected');
      btn.style.backgroundColor = '#2c2c34';
      btn.style.color = '#fff';
      btn.style.border = '1px solid var(--border-color)';
    }
  });

  activeOpenShiftInput = document.getElementById('openCoinsPennies');
}
window.resetOpenShiftInputs = resetOpenShiftInputs;

function setQuickStartingCash(amount) {
  const num = parseFloat(amount) || 0;
  const directInp = document.getElementById('inputStartingCashDirect');
  if (directInp) directInp.value = num.toFixed(2);
  
  [0, 50, 100, 150, 200].forEach(val => {
    const btn = document.getElementById(`btnQuickCash${val}`) || document.querySelector(`button[onclick="setQuickStartingCash(${val})"]`);
    if (btn) {
      if (val === num && num > 0) {
        btn.classList.add('selected');
        btn.style.backgroundColor = 'var(--accent-color)';
        btn.style.color = '#000';
        btn.style.border = 'none';
      } else {
        btn.classList.remove('selected');
        btn.style.backgroundColor = '#2c2c34';
        btn.style.color = '#fff';
        btn.style.border = '1px solid var(--border-color)';
      }
    }
  });

  const pennies = document.getElementById('openCoinsPennies');
  const nickels = document.getElementById('openCoinsNickels');
  const dimes = document.getElementById('openCoinsDimes');
  const quarters = document.getElementById('openCoinsQuarters');
  const ones = document.getElementById('openBillsOnes');
  const fives = document.getElementById('openBillsFives');
  const tens = document.getElementById('openBillsTens');
  const twenties = document.getElementById('openBillsTwenties');
  const fifties = document.getElementById('openBillsFifties');
  const hundreds = document.getElementById('openBillsHundreds');

  if (pennies) pennies.value = '0';
  if (nickels) nickels.value = '0';
  if (dimes) dimes.value = '0';
  if (quarters) quarters.value = '0';
  if (ones) ones.value = '0';
  if (fives) fives.value = '0';
  if (tens) tens.value = '0';
  if (fifties) fifties.value = '0';
  if (hundreds) hundreds.value = '0';

  if (twenties) {
    twenties.value = Math.floor(num / 20);
    const rem = num % 20;
    if (tens && rem >= 10) {
      tens.value = Math.floor(rem / 10);
    }
  }

  const lbl = document.getElementById('lblStartingCashTotal');
  if (lbl) lbl.innerText = `$${num.toFixed(2)}`;
}
window.setQuickStartingCash = setQuickStartingCash;

function handleDirectStartingCashInput(val) {
  const clean = String(val).replace(/[^0-9.]/g, '');
  const num = parseFloat(clean) || 0;
  const lbl = document.getElementById('lblStartingCashTotal');
  if (lbl) lbl.innerText = `$${num.toFixed(2)}`;
  
  [0, 50, 100, 150, 200].forEach(preset => {
    const btn = document.getElementById(`btnQuickCash${preset}`) || document.querySelector(`button[onclick="setQuickStartingCash(${preset})"]`);
    if (btn) {
      if (preset === num && num > 0) {
        btn.classList.add('selected');
        btn.style.backgroundColor = 'var(--accent-color)';
        btn.style.color = '#000';
      } else {
        btn.classList.remove('selected');
        btn.style.backgroundColor = '#2c2c34';
        btn.style.color = '#fff';
      }
    }
  });
}
window.handleDirectStartingCashInput = handleDirectStartingCashInput;

// --- MONEDAS DE APERTURA ---
function calculateStartingCash() {
  const p = parseInt(document.getElementById('openCoinsPennies')?.value) || 0;
  const n = parseInt(document.getElementById('openCoinsNickels')?.value) || 0;
  const d = parseInt(document.getElementById('openCoinsDimes')?.value) || 0;
  const q = parseInt(document.getElementById('openCoinsQuarters')?.value) || 0;
  
  const ones = parseInt(document.getElementById('openBillsOnes')?.value) || 0;
  const fives = parseInt(document.getElementById('openBillsFives')?.value) || 0;
  const tens = parseInt(document.getElementById('openBillsTens')?.value) || 0;
  const twenties = parseInt(document.getElementById('openBillsTwenties')?.value) || 0;
  const fifties = parseInt(document.getElementById('openBillsFifties')?.value) || 0;
  const hundreds = parseInt(document.getElementById('openBillsHundreds')?.value) || 0;
  
  const total = (p * 0.01) + (n * 0.05) + (d * 0.10) + (q * 0.25) + (ones * 1) + (fives * 5) + (tens * 10) + (twenties * 20) + (fifties * 50) + (hundreds * 100);
  const lbl = document.getElementById('lblStartingCashTotal');
  if (lbl) lbl.innerText = `$${total.toFixed(2)}`;
  const directInp = document.getElementById('inputStartingCashDirect');
  if (directInp && document.activeElement !== directInp) {
    directInp.value = total.toFixed(2);
  }

  [0, 50, 100, 150, 200].forEach(preset => {
    const btn = document.getElementById(`btnQuickCash${preset}`) || document.querySelector(`button[onclick="setQuickStartingCash(${preset})"]`);
    if (btn) {
      if (preset === total && total > 0) {
        btn.classList.add('selected');
        btn.style.backgroundColor = 'var(--accent-color)';
        btn.style.color = '#000';
      } else {
        btn.classList.remove('selected');
        btn.style.backgroundColor = '#2c2c34';
        btn.style.color = '#fff';
      }
    }
  });
}
window.calculateStartingCash = calculateStartingCash;

// --- DUAL CASH DRAWER HELPERS ---
async function kickAssignedCashDrawer(drawerNum = 1) {
  try {
    const target = parseInt(drawerNum) || 1;
    await fetch(`${SERVER_URL}/api/printer/kick-drawer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ drawer: target })
    });
  } catch (err) {
    console.error("[DUAL CASH DRAWER] Error kicking drawer:", err);
  }
}

async function prepareOpenShiftDrawerSelector() {
  const btnDChoice1 = document.getElementById('btnDrawerChoice1');
  const btnDChoice2 = document.getElementById('btnDrawerChoice2');
  if (!btnDChoice1 || !btnDChoice2) return;

  const isEs = (posSettings && posSettings.language === 'es');

  btnDChoice1.disabled = false;
  btnDChoice1.style.opacity = '1';
  btnDChoice1.style.cursor = 'pointer';
  btnDChoice1.innerText = isEs ? '🗄️ Cajón 1 (Pin 2)' : '🗄️ Drawer 1 (Pin 2)';

  btnDChoice2.disabled = false;
  btnDChoice2.style.opacity = '1';
  btnDChoice2.style.cursor = 'pointer';
  btnDChoice2.innerText = isEs ? '🗄️ Cajón 2 (Pin 5)' : '🗄️ Drawer 2 (Pin 5)';

  try {
    const res = await fetch(`${SERVER_URL}/api/shifts/active-drawers`);
    if (res.ok) {
      const activeDrawers = await res.json();
      const occupiedDrawers = {};
      if (Array.isArray(activeDrawers)) {
        activeDrawers.forEach(d => {
          occupiedDrawers[d.drawerNumber] = d.cashierName;
        });
      }

      if (occupiedDrawers[1]) {
        btnDChoice1.disabled = true;
        btnDChoice1.style.opacity = '0.4';
        btnDChoice1.style.cursor = 'not-allowed';
        btnDChoice1.innerText = isEs ? `🔒 Cajón 1 (${occupiedDrawers[1]})` : `🔒 Drawer 1 (${occupiedDrawers[1]})`;
        btnDChoice1.classList.remove('selected');

        btnDChoice2.classList.add('selected');
        selectedOpenShiftDrawer = 2;
      } else {
        btnDChoice1.classList.add('selected');
        btnDChoice2.classList.remove('selected');
        selectedOpenShiftDrawer = 1;
      }

      if (occupiedDrawers[2]) {
        btnDChoice2.disabled = true;
        btnDChoice2.style.opacity = '0.4';
        btnDChoice2.style.cursor = 'not-allowed';
        btnDChoice2.innerText = isEs ? `🔒 Cajón 2 (${occupiedDrawers[2]})` : `🔒 Drawer 2 (${occupiedDrawers[2]})`;
        if (selectedOpenShiftDrawer === 2 && !occupiedDrawers[1]) {
          btnDChoice2.classList.remove('selected');
          btnDChoice1.classList.add('selected');
          selectedOpenShiftDrawer = 1;
        }
      }

      if (occupiedDrawers[1] && occupiedDrawers[2]) {
        showToast(isEs ? 'Ambos cajones están actualmente en uso por otros turnos' : 'Both cash drawers are currently in use by active shifts', 'warning');
      }
    }
  } catch (err) {
    console.error("[DUAL CASH DRAWER] Error preparing drawer selector:", err);
  }
}

async function confirmOpenShift() {
  let total = 0;
  const directInp = document.getElementById('inputStartingCashDirect');
  const directVal = directInp ? parseFloat(directInp.value) : NaN;

  const p = parseInt(document.getElementById('openCoinsPennies')?.value) || 0;
  const n = parseInt(document.getElementById('openCoinsNickels')?.value) || 0;
  const d = parseInt(document.getElementById('openCoinsDimes')?.value) || 0;
  const q = parseInt(document.getElementById('openCoinsQuarters')?.value) || 0;
  
  const ones = parseInt(document.getElementById('openBillsOnes')?.value) || 0;
  const fives = parseInt(document.getElementById('openBillsFives')?.value) || 0;
  const tens = parseInt(document.getElementById('openBillsTens')?.value) || 0;
  const twenties = parseInt(document.getElementById('openBillsTwenties')?.value) || 0;
  const fifties = parseInt(document.getElementById('openBillsFifties')?.value) || 0;
  const hundreds = parseInt(document.getElementById('openBillsHundreds')?.value) || 0;
  
  const denomTotal = (p * 0.01) + (n * 0.05) + (d * 0.10) + (q * 0.25) + (ones * 1) + (fives * 5) + (tens * 10) + (twenties * 20) + (fifties * 50) + (hundreds * 100);

  if (document.activeElement === directInp && !isNaN(directVal)) {
    total = directVal;
  } else if (denomTotal > 0) {
    total = denomTotal;
  } else if (!isNaN(directVal)) {
    total = directVal;
  } else {
    total = 0;
  }

  const drawerToAssign = selectedOpenShiftDrawer || 1;
  const cashierToUse = (currentCashierName && currentCashierName.trim()) ? currentCashierName.trim() : 'Cajero';

  const shiftData = {
    cashier: cashierToUse,
    drawerNumber: drawerToAssign,
    openingCash: total,
    details: { pennies: p, nickels: n, dimes: d, quarters: q, ones, fives, tens, twenties, fifties, hundreds }
  };

  try {
    const response = await fetch(`${SERVER_URL}/api/shifts/open`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(shiftData)
    });

    if (response.ok) {
      activeShift = await response.json();
      currentCashierName = activeShift.cashierName || cashierToUse;
      currentCashierDrawer = activeShift.drawerNumber || drawerToAssign;
      const isEs = (posSettings && posSettings.language === 'es');
      const badge = document.getElementById('btnActiveCashier');
      if (badge) {
        badge.innerText = isEs 
          ? `Cajero: ${activeShift.cashierName} (Cajón ${currentCashierDrawer})` 
          : `Cashier: ${activeShift.cashierName} (Drawer ${currentCashierDrawer})`;
      }
      showToast(isEs 
        ? `Turno iniciado en Cajón ${currentCashierDrawer} ($${total.toFixed(2)})` 
        : `Shift started in Drawer ${currentCashierDrawer} ($${total.toFixed(2)})`, 'success');
      document.getElementById('modalOpenShift').style.display = 'none';
      hideSplash();

      // Si el cajero abrió el turno mientras intentaba cobrar, abrir de inmediato el modal de cobro
      if (cart && cart.length > 0) {
        setTimeout(() => {
          const btnCheckout = document.getElementById('btnOpenCheckout');
          if (btnCheckout) btnCheckout.click();
        }, 200);
      }
    } else {
      const errRes = await response.json().catch(() => ({}));
      showToast(errRes.error || 'Error registering starting shift', 'error');
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}
window.confirmOpenShift = confirmOpenShift;

// --- TEMPORIZADOR DE INACTIVIDAD ---
function setupActivityTracker() {
  ['click', 'touchstart', 'mousemove', 'keydown', 'scroll'].forEach(evt => {
    window.addEventListener(evt, resetIdleTimer);
  });
}

function resetIdleTimer() {
  if (idleTimer) clearTimeout(idleTimer);
  
  const splash = document.getElementById('splashLoginScreen');
  if (splash && splash.style.display === 'none') {
    idleTimer = setTimeout(() => {
      lockTerminal();
    }, 300000); 
  }
}

function lockTerminal() {
  sessionAdminAuthorized = false;
  sessionManagerAuthorized = false;
  splashPasscodeString = '';
  updateSplashPasscodeDisplay();
  showToast("Register locked due to inactivity", "info");
  showSplash();
}

// --- EDICIÓN DE EMPLEADOS ---
async function editEmployee(empId) {
  try {
    const response = await fetch(`${SERVER_URL}/api/employees`);
    if (response.ok) {
      const emps = await response.json();
      const emp = emps.find(e => e.id === empId);
      if (emp) {
        editingEmployeeId = emp.id;
        
        document.getElementById('empName').value = emp.name || '';
        document.getElementById('empPhone').value = emp.phone || '';
        document.getElementById('empAddress').value = emp.address || '';
        document.getElementById('empRole').value = emp.role || 'cashier';
        document.getElementById('empPasscode').value = emp.passcode || '';
        document.getElementById('empCardCode').value = emp.cardCode || '';
        document.getElementById('empTasks').value = emp.tasks || '';
        tempFingerprintRegistered = !!emp.fingerprintRegistered;
        tempFingerprintTemplate = emp.fingerprintTemplate || null;
        const statusLbl = document.getElementById('lblFingerprintStatus');
        if (tempFingerprintRegistered) {
          statusLbl.innerText = 'Fingerprint Status: REGISTERED';
          statusLbl.style.color = 'var(--success-color)';
        } else {
          statusLbl.innerText = 'Fingerprint Status: Unregistered';
          statusLbl.style.color = 'var(--text-secondary)';
        }
        
        const f = document.getElementById('employeeFormContainer');
        f.style.display = 'block';
        setTimeout(() => {
          f.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 50);
        document.getElementById('btnSaveEmployee').innerText = 'Save Changes';
        showToast(`Editing profile of ${emp.name}`, 'info');
      }
    }
  } catch(e) {
    console.error(e);
    showToast('Error loading employee profile for editing', 'error');
  }
}

window.editEmployee = editEmployee;
window.checkActiveShiftAndLockState = checkActiveShiftAndLockState;

function calculateClosingCash() {
  const p = parseInt(document.getElementById('closeCoinsPennies').value) || 0;
  const n = parseInt(document.getElementById('closeCoinsNickels').value) || 0;
  const d = parseInt(document.getElementById('closeCoinsDimes').value) || 0;
  const q = parseInt(document.getElementById('closeCoinsQuarters').value) || 0;
  
  const ones = parseInt(document.getElementById('closeBillsOnes').value) || 0;
  const fives = parseInt(document.getElementById('closeBillsFives').value) || 0;
  const tens = parseInt(document.getElementById('closeBillsTens').value) || 0;
  const twenties = parseInt(document.getElementById('closeBillsTwenties').value) || 0;
  const fifties = parseInt(document.getElementById('closeBillsFifties').value) || 0;
  const hundreds = parseInt(document.getElementById('closeBillsHundreds').value) || 0;
  
  const total = (p * 0.01) + (n * 0.05) + (d * 0.10) + (q * 0.25) + (ones * 1) + (fives * 5) + (tens * 10) + (twenties * 20) + (fifties * 50) + (hundreds * 100);
  document.getElementById('lblClosingCashTotal').innerText = `$${total.toFixed(2)}`;
}

async function confirmCloseShift() {
  const p = parseInt(document.getElementById('closeCoinsPennies').value) || 0;
  const n = parseInt(document.getElementById('closeCoinsNickels').value) || 0;
  const d = parseInt(document.getElementById('closeCoinsDimes').value) || 0;
  const q = parseInt(document.getElementById('closeCoinsQuarters').value) || 0;
  
  const ones = parseInt(document.getElementById('closeBillsOnes').value) || 0;
  const fives = parseInt(document.getElementById('closeBillsFives').value) || 0;
  const tens = parseInt(document.getElementById('closeBillsTens').value) || 0;
  const twenties = parseInt(document.getElementById('closeBillsTwenties').value) || 0;
  const fifties = parseInt(document.getElementById('closeBillsFifties').value) || 0;
  const hundreds = parseInt(document.getElementById('closeBillsHundreds').value) || 0;
  
  const total = (p * 0.01) + (n * 0.05) + (d * 0.10) + (q * 0.25) + (ones * 1) + (fives * 5) + (tens * 10) + (twenties * 20) + (fifties * 50) + (hundreds * 100);

  const proceed = confirm(`Are you finished? Do you want to close the shift with $${total.toFixed(2)} cash counted?`);
  if (!proceed) return;

  const closeData = {
    cashier: currentCashierName,
    closingCash: total,
    details: { pennies: p, nickels: n, dimes: d, quarters: q, ones, fives, tens, twenties, fifties, hundreds }
  };

  try {
    const response = await fetch(`${SERVER_URL}/api/shifts/close`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(closeData)
    });

    if (response.ok) {
      const closedShift = await response.json();
      activeShift = null;
      currentCashierName = '';
      currentCashierDrawer = 1;
      
      console.log("=== SHIFT CLOSE TICKET ===", closedShift);
      const summary = closedShift.summary || {};
      const isEs = (posSettings && posSettings.language === 'es');
      const reportDrawer = closedShift.drawerNumber || 1;
      
      const cleanShiftBusName = (posSettings.businessName || "Impossible POS").toUpperCase();
      const paddedShiftBusName = cleanShiftBusName.padStart(Math.floor((34 + cleanShiftBusName.length) / 2)).padEnd(34);
      const ticketText = `
----------------------------------
${paddedShiftBusName}
      ${isEs ? 'CORTE Z DE TURNO' : 'SHIFT CLOSE REPORT'}
----------------------------------
Shift ID: ${closedShift.id}
Cashier: ${closedShift.closingCashier}
Drawer: ${isEs ? 'Cajón' : 'Drawer'} ${reportDrawer}
Opened: ${new Date(closedShift.dateOpened).toLocaleString()}
Closed: ${new Date(closedShift.dateClosed).toLocaleString()}
----------------------------------
Starting Cash:   $${closedShift.openingCash.toFixed(2)}
Cash Sales:      $${(summary.cashSales || 0).toFixed(2)}
Card Sales:      $${(summary.cardSales || 0).toFixed(2)}
Refunds (Cash): -$${(summary.cashRefunds || 0).toFixed(2)}
----------------------------------
Expected Cash:   $${(summary.expectedCash || 0).toFixed(2)}
Counted Cash:    $${closedShift.closingCash.toFixed(2)}
Discrepancy:     $${(summary.discrepancy || 0).toFixed(2)}
----------------------------------
Total Sales:     $${(summary.totalSales || 0).toFixed(2)}
Transactions:    ${summary.transactionCount || 0}
----------------------------------
      `;
      
      alert(ticketText);
      showToast(isEs ? '¡Turno cerrado y reporte generado!' : 'Shift closed and report sent to printer!', 'success');
      
      const badge = document.getElementById('btnActiveCashier');
      if (badge) badge.innerText = isEs ? 'Cajero: -' : 'Cashier: -';

      document.getElementById('modalCloseShift').style.display = 'none';
      showSplash();
    } else {
      showToast('Error registering closing shift', 'error');
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}

window.calculateClosingCash = calculateClosingCash;
window.confirmCloseShift = confirmCloseShift;

function initVirtualKeyboard() {
  let kb = document.getElementById('globalVirtualKeyboard');
  if (!kb) {
    kb = document.createElement('div');
    kb.id = 'globalVirtualKeyboard';
    kb.style.cssText = `
      display: none;
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background: #111a24;
      border-top: 2px solid #233545;
      padding: 10px;
      z-index: 40000;
      box-shadow: 0 -8px 24px rgba(0,0,0,0.6);
      user-select: none;
      font-family: inherit;
    `;
    
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'max-width: 800px; margin: 0 auto; display: flex; flex-direction: column; gap: 6px;';
    kb.appendChild(wrapper);
    document.body.appendChild(kb);
  }
  
  const KB_SELECTOR = '#optionsSearchInput, #empName, #empPhone, #empAddress, #empPasscode, #empCardCode, #empTasks, #cakeClientName, #cakeClientPhone, #cakeNotes, #cakePrice, #cakeDeposit, #cakeBalance, #weddingName1, #weddingName2, #weddingBookModel, #weddingPpl, #weddingColor, #inputDeposit, #loyaltyNameInput, #loyaltyPhoneInput, #loyaltyCompanyNameInput, #loyaltyAddressInput, #adminPrinterIP, #adminLabelPrinterName, #adminKitchenPrinterName, #adminPaymentIP, #adminBiometricWS, #deptIdInput, #deptNameInput, #deptOrderInput, #salesSearchInput, #alcoholFormBarcode, #alcoholFormBrand, #alcoholFormModel, #receivableCustName, #receivableNotes, #alcoholFormFullWeight, #alcoholFormEmptyWeight, #alcoholFormLiquidOunces, #alcoholFormShotSize, #alcoholFormGramsPerOunce, #registerTipAmount, #receivableCustPhone, #adminTipsFeePercentage, .alcohol-start-weight-input, .alcohol-end-weight-input, #customerTabNameInput, #loyaltyDescriptionInput';

  const registerInputEvents = () => {
    // Left empty since we now use robust global event delegation
  };

  // Robust Global Event Delegation for Virtual Keyboard Inputs (Focus & Click)
  document.addEventListener('focusin', (e) => {
    const target = e.target;
    if (target && target.tagName && (target.tagName.toLowerCase() === 'input' || target.tagName.toLowerCase() === 'textarea')) {
      if (target.matches(KB_SELECTOR)) {
        activeVirtualKeyboardInput = target;
        if (target.value === '0.00' || target.value === '0') {
          target.value = '';
        }
        showVirtualKeyboard();
      }
    }
  });

  document.addEventListener('click', (e) => {
    const target = e.target;
    
    // Check if clicked element is keyboard target
    if (target && target.tagName && (target.tagName.toLowerCase() === 'input' || target.tagName.toLowerCase() === 'textarea')) {
      if (target.matches(KB_SELECTOR)) {
        activeVirtualKeyboardInput = target;
        if (target.value === '0.00' || target.value === '0') {
          target.value = '';
        }
        showVirtualKeyboard();
        return;
      }
    }

    // Hide keyboard if clicked outside active keyboard inputs and keyboard itself
    if (target && target.tagName) {
      const isInput = target.tagName.toLowerCase() === 'input' || target.tagName.toLowerCase() === 'textarea';
      const isKeyboard = target.closest('#globalVirtualKeyboard');
      const activeEl = document.activeElement;
      const isKeyboardInputActive = activeEl && activeEl.matches && activeEl.matches(KB_SELECTOR);

      if (!isInput && !isKeyboard && !isKeyboardInputActive) {
        hideVirtualKeyboard();
      }
    }
  });

  // Automatically restore default values on blur
  document.addEventListener('focusout', (e) => {
    const target = e.target;
    if (target && target.matches && target.matches(KB_SELECTOR)) {
      if (target.value.trim() === '') {
        if (target.id === 'cakePrice') target.value = '0.00';
        else if (target.id === 'inputDeposit') target.value = '0';
      }
    }
  });
}

function showVirtualKeyboard() {
  const kb = document.getElementById('globalVirtualKeyboard');
  if (!kb) {
    console.error("Keyboard not found!");
    return;
  }
  
  const isNumericOnly = activeVirtualKeyboardInput && (
    activeVirtualKeyboardInput.type === 'number' || 
    activeVirtualKeyboardInput.id === 'cakePrice' ||
    activeVirtualKeyboardInput.id === 'cakeDeposit' ||
    activeVirtualKeyboardInput.id === 'cakeBalance' ||
    activeVirtualKeyboardInput.id === 'weddingPpl' ||
    activeVirtualKeyboardInput.id === 'empPhone' ||
    activeVirtualKeyboardInput.id === 'empPasscode' ||
    activeVirtualKeyboardInput.id === 'empCardCode' ||
    activeVirtualKeyboardInput.id === 'cakeClientPhone' ||
    activeVirtualKeyboardInput.id === 'inputDeposit'
  );

  renderKeyboardKeys();
  
  const activeModal = activeVirtualKeyboardInput ? activeVirtualKeyboardInput.closest('.modal') : null;
  
  if (activeModal) {
    activeModal.style.display = 'flex';
    activeModal.style.justifyContent = 'flex-start';
    activeModal.style.paddingLeft = '50px';
    
    kb.style.left = 'auto';
    kb.style.right = '20px';
    kb.style.bottom = '20px';
    kb.style.width = isNumericOnly ? '320px' : '650px';
    kb.style.maxWidth = '55vw';
    kb.style.borderRadius = '12px';
    kb.style.border = '2px solid #233545';
    kb.style.boxShadow = '0 8px 32px rgba(0,0,0,0.8)';
    document.body.style.paddingBottom = '0px';
  } else {
    if (isNumericOnly) {
      kb.style.left = 'auto';
      kb.style.right = '20px';
      kb.style.bottom = '20px';
      kb.style.width = '320px';
      kb.style.borderRadius = '12px';
      kb.style.border = '2px solid #233545';
      kb.style.boxShadow = '0 8px 32px rgba(0,0,0,0.8)';
      document.body.style.paddingBottom = '0px';
    } else {
      kb.style.left = '0';
      kb.style.right = '0';
      kb.style.bottom = '0';
      kb.style.width = '100%';
      kb.style.borderRadius = '0';
      kb.style.border = 'none';
      kb.style.borderTop = '2px solid #233545';
      kb.style.boxShadow = '0 -8px 24px rgba(0,0,0,0.6)';
      document.body.style.paddingBottom = '280px';
    }
  }
  
  kb.style.display = 'block';
}

function hideVirtualKeyboard() {
  const kb = document.getElementById('globalVirtualKeyboard');
  if (kb) kb.style.display = 'none';
  document.body.style.paddingBottom = '0px';
  
  document.querySelectorAll('.modal').forEach(m => {
    m.style.justifyContent = '';
    m.style.paddingLeft = '';
  });
}

function renderKeyboardKeys() {
  const kb = document.getElementById('globalVirtualKeyboard');
  if (!kb) return;
  
  const wrapper = kb.querySelector('div');
  if (!wrapper) return;
  wrapper.innerHTML = '';
  
  const isNumericOnly = activeVirtualKeyboardInput && (
    activeVirtualKeyboardInput.type === 'number' || 
    activeVirtualKeyboardInput.id === 'cakePrice' ||
    activeVirtualKeyboardInput.id === 'cakeDeposit' ||
    activeVirtualKeyboardInput.id === 'cakeBalance' ||
    activeVirtualKeyboardInput.id === 'weddingPpl' ||
    activeVirtualKeyboardInput.id === 'empPhone' ||
    activeVirtualKeyboardInput.id === 'empPasscode' ||
    activeVirtualKeyboardInput.id === 'empCardCode' ||
    activeVirtualKeyboardInput.id === 'cakeClientPhone' ||
    activeVirtualKeyboardInput.id === 'inputDeposit'
  );

  let rows = [];
  if (isNumericOnly) {
    wrapper.style.maxWidth = '320px';
    rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
      ['.', '0', 'Backspace'],
      ['Clear', 'Close']
    ];
  } else {
    wrapper.style.maxWidth = '800px';
    if (virtualKeyboardLanguage === 'ES') {
      rows = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        virtualKeyboardShift 
          ? ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P']
          : ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        virtualKeyboardShift
          ? ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ñ']
          : ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ'],
        [
          'Shift', 
          ...(virtualKeyboardShift 
            ? ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
            : ['z', 'x', 'c', 'v', 'b', 'n', 'm']),
          ...(virtualKeyboardShift ? [';', ':', '"'] : [',', '.', '"']),
          '´'
        ],
        ['ES/EN', 'Space', 'Backspace', 'Clear', 'Close']
      ];
    } else {
      rows = [
        ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'],
        virtualKeyboardShift 
          ? ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P']
          : ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
        virtualKeyboardShift
          ? ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L']
          : ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
        [
          'Shift', 
          ...(virtualKeyboardShift 
            ? ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
            : ['z', 'x', 'c', 'v', 'b', 'n', 'm']),
          ...(virtualKeyboardShift ? [';', ':', '"'] : [',', '.', '"'])
        ],
        ['ES/EN', 'Space', 'Backspace', 'Clear', 'Close']
      ];
    }
  }
  
  rows.forEach(rowKeys => {
    const rowDiv = document.createElement('div');
    rowDiv.style.cssText = 'display: flex; gap: 5px; justify-content: center; width: 100%;';
    
    rowKeys.forEach(key => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.innerText = key;
      
      let btnWidth = isNumericOnly ? '30%' : '8%';
      let bgColor = '#1c2d3d';
      let textColor = '#fff';
      
      if (isNumericOnly) {
        if (key === 'Clear' || key === 'Close') {
          btnWidth = '47%';
          bgColor = key === 'Close' ? '#1e382b' : '#2a1b1b';
        } else if (key === 'Backspace') {
          bgColor = '#2a1b1b';
        }
      } else {
        if (key === 'Shift') {
          btnWidth = '14%';
          bgColor = virtualKeyboardShift ? 'var(--accent-color)' : '#233545';
          textColor = virtualKeyboardShift ? '#000' : '#fff';
        } else if (key === 'Space') {
          btnWidth = '35%';
          bgColor = '#233545';
        } else if (key === 'ES/EN') {
          btnWidth = '14%';
          bgColor = '#233545';
          textColor = 'var(--accent-color)';
        } else if (key === '´') {
          bgColor = keyboardAccentActive ? 'var(--accent-color)' : '#233545';
          textColor = keyboardAccentActive ? '#000' : '#fff';
        } else if (key === 'Backspace' || key === 'Clear' || key === 'Close') {
          btnWidth = '14%';
          bgColor = '#2a1b1b';
          if (key === 'Close') {
            bgColor = '#1e382b';
          }
        }
      }
      
      btn.style.cssText = `
        width: ${btnWidth};
        height: 44px;
        font-size: 14px;
        font-weight: bold;
        background: ${bgColor};
        color: ${textColor};
        border: 1px solid #233545;
        border-radius: 6px;
        cursor: pointer;
        outline: none;
        display: flex;
        align-items: center;
        justify-content: center;
      `;
      
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        if (!activeVirtualKeyboardInput) return;
        
        const start = activeVirtualKeyboardInput.selectionStart || 0;
        const end = activeVirtualKeyboardInput.selectionEnd || 0;
        let val = activeVirtualKeyboardInput.value;
        
        if (key === 'Close') {
          hideVirtualKeyboard();
          activeVirtualKeyboardInput.blur();
          return;
        } else if (key === 'Shift') {
          virtualKeyboardShift = !virtualKeyboardShift;
          renderKeyboardKeys();
          return;
        } else if (key === 'ES/EN') {
          virtualKeyboardLanguage = (virtualKeyboardLanguage === 'ES' ? 'EN' : 'ES');
          renderKeyboardKeys();
          return;
        } else if (key === '´') {
          keyboardAccentActive = !keyboardAccentActive;
          renderKeyboardKeys();
          return;
        } else if (key === 'Clear') {
          activeVirtualKeyboardInput.value = '';
        } else if (key === 'Backspace') {
          activeVirtualKeyboardInput.value = val.slice(0, -1);
        } else if (key === 'Space') {
          activeVirtualKeyboardInput.value = val + ' ';
        } else {
          let outputKey = key;
          if (keyboardAccentActive) {
            if (key === 'a') outputKey = 'á';
            else if (key === 'e') outputKey = 'é';
            else if (key === 'i') outputKey = 'í';
            else if (key === 'o') outputKey = 'ó';
            else if (key === 'u') outputKey = 'ú';
            else if (key === 'A') outputKey = 'Á';
            else if (key === 'E') outputKey = 'É';
            else if (key === 'I') outputKey = 'Í';
            else if (key === 'O') outputKey = 'Ó';
            else if (key === 'U') outputKey = 'Ú';
            
            keyboardAccentActive = false;
            renderKeyboardKeys();
          }
          
          if (val === '0.00' || val === '0') {
            activeVirtualKeyboardInput.value = outputKey;
          } else {
            activeVirtualKeyboardInput.value = val + outputKey;
          }
        }
        
        activeVirtualKeyboardInput.dispatchEvent(new Event('input', { bubbles: true }));
        activeVirtualKeyboardInput.dispatchEvent(new Event('change', { bubbles: true }));
        activeVirtualKeyboardInput.focus();
      });
      
      rowDiv.appendChild(btn);
    });
    
    wrapper.appendChild(rowDiv);
  });
}

let biometricWS = null;

async function initBiometricWebSocket() {
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`);
    if (res.ok) {
      const settings = await res.json();
      const wsUrl = settings.biometricWebSocketUrl || 'ws://127.0.0.1:9000/biometrics';
      
      if (biometricWS) {
        biometricWS.close();
      }
      
      biometricWS = new WebSocket(wsUrl);
      
      biometricWS.onopen = () => {
        console.log("Connected to USB Fingerprint Biometric service WebSocket:", wsUrl);
      };
      
      biometricWS.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log("Biometric WS received:", data);
          
          if (data.event === 'scanned') {
            const template = data.template || 'simulated_fingerprint_token_' + Math.random();
            handleBiometricScanEvent(template);
          } else if (data.event === 'unrecognized') {
            handleBiometricUnrecognizedEvent();
          }
        } catch(e) {
          handleBiometricScanEvent(event.data);
        }
      };
      
      biometricWS.onerror = (err) => {
        console.warn("Biometric WebSocket error (USB reader might not be plugged in):", err.message);
      };
      
      biometricWS.onclose = () => {
        setTimeout(initBiometricWebSocket, 10000);
      };
    } else {
      console.warn("Failed to fetch settings for biometrics, retrying in 10s...");
      setTimeout(initBiometricWebSocket, 10000);
    }
  } catch(e) {
    console.error("Error initializing Biometric WebSocket, retrying in 10s:", e);
    setTimeout(initBiometricWebSocket, 10000);
  }
}

async function triggerBiometricScan() {
  console.log("Biometric WebSocket is active, no need to manually trigger scan.");
}

async function cancelBiometricScan() {
  console.log("Biometric WebSocket is active, session managed automatically.");
}

function handleBiometricUnrecognizedEvent() {
  try {
    fetch(`${SERVER_URL}/api/print-debug`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: `FRONTEND: handleBiometricUnrecognizedEvent triggered!` })
    });
  } catch(e) {}

  const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
  const msg = isEs ? "Huella no reconocida. Intente de nuevo." : "Fingerprint not recognized. Try again.";
  showToast(msg, "error");

  // 1. Check if dedicated fingerprint enrollment modal (Registro Aislado) is visible
  const enrollModal = document.getElementById('modalEnrollFingerprint');
  if (enrollModal && (enrollModal.style.display === 'flex' || enrollModal.style.display === 'block')) {
    const statusLbl = document.getElementById('enrollFingerprintStatus');
    if (statusLbl) {
      statusLbl.innerText = msg;
      statusLbl.style.color = 'var(--danger-color)';
    }
    return;
  }

  // 2. Check if main Auth Modal is visible
  const modal = document.getElementById('modalAuth');
  if (modal && (modal.style.display === 'flex' || modal.style.display === 'block')) {
    const statusLbl = document.getElementById('fingerprintStatus');
    const icon = document.getElementById('fingerprintIcon');
    if (icon) icon.style.color = 'var(--danger-color)';
    if (statusLbl) statusLbl.innerText = msg;
    setTimeout(() => {
      if (icon) icon.style.color = 'var(--text-secondary)';
      if (statusLbl) statusLbl.innerText = isEs ? "Presione el lector para escanear..." : "Press scanner to scan fingerprint...";
    }, 1800);
    return;
  }

  // 3. Check if Punch Clock Modal is visible
  const punchModal = document.getElementById('modalPunch');
  if (punchModal && (punchModal.style.display === 'flex' || punchModal.style.display === 'block')) {
    const statusLbl = document.getElementById('punchFingerprintStatus');
    const icon = document.getElementById('punchFingerprintIcon');
    if (icon) icon.style.color = 'var(--danger-color)';
    if (statusLbl) statusLbl.innerText = msg;
    setTimeout(() => {
      if (icon) icon.style.color = 'var(--text-secondary)';
      if (statusLbl) statusLbl.innerText = isEs ? "Presione el lector para escanear..." : "Press scanner to scan fingerprint...";
    }, 1800);
    return;
  }

  // 4. Check if lock screen (Splash Screen) is active
  const splash = document.getElementById('splashLoginScreen');
  if (splash && splash.style.display !== 'none') {
    const icon = document.getElementById('splashFingerprintIcon');
    const statusLbl = document.getElementById('splashScanStatus');
    if (icon) icon.style.color = 'var(--danger-color)';
    if (statusLbl) statusLbl.innerText = msg;
    setTimeout(() => {
      if (icon) icon.style.color = 'var(--text-secondary)';
      if (statusLbl) statusLbl.innerText = isEs ? "Escanee su huella, deslice su tarjeta o use el teclado." : "Scan finger, swipe employee card, or use the keypad.";
    }, 1800);
  }
}

async function handleBiometricScanEvent(template) {
  console.log("Processing biometric scan event for template:", template);

  try {
    const emps = await getEmployeesList();
    const empInfo = emps.map(e => `${e.name}(template="${e.fingerprintTemplate}", role="${e.role}")`).join(', ');
    fetch(`${SERVER_URL}/api/print-debug`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: `Biometric Scan Triggered: template="${template}". Active employees in memory: [${empInfo}]` })
    });
  } catch(e) {}

  const bartenderAuthModal = document.getElementById('modalBartenderAuth');
  if (bartenderAuthModal && (bartenderAuthModal.style.display === 'flex' || bartenderAuthModal.style.display === 'block')) {
    const ripple = document.getElementById('bartenderAuthFingerprintRipple');
    
    try {
      const emps = await getEmployeesList();
      const matchedEmp = emps.find(e => e.fingerprintTemplate === template);
      
      if (ripple) {
        ripple.style.transform = 'scale(1)';
        ripple.style.opacity = '0';
      }
      
      if (matchedEmp) {
        const r = (matchedEmp.role || '').toLowerCase();
        if (r === 'bartender' || r === 'manager' || r === 'admin') {
          showToast(`Biometric matched: ${matchedEmp.name}`, 'success');
          bartenderAuthModal.style.display = 'none';
          openBartenderDashboard();
        } else {
          showToast("Access Denied: Only Bartenders or Managers allowed", "error");
        }
      } else {
        showToast("Fingerprint not recognized", "error");
      }
    } catch(err) {
      console.error(err);
    }
    return;
  }

  // 1. Check if dedicated fingerprint enrollment modal (Registro Aislado) is visible
  const enrollModal = document.getElementById('modalEnrollFingerprint');
  if (enrollModal && (enrollModal.style.display === 'flex' || enrollModal.style.display === 'block')) {
    const statusLbl = document.getElementById('enrollFingerprintStatus');
    const ripple = document.getElementById('enrollScannerRipple');
    
    if (ripple) {
      ripple.style.transform = 'scale(1.2)';
      ripple.style.opacity = '1';
    }
    if (statusLbl) {
      statusLbl.innerText = 'Enrollment Complete! Fingerprint Registered.';
      statusLbl.style.color = 'var(--success-color)';
    }
    
    tempFingerprintRegistered = true;
    tempFingerprintTemplate = template;
    
    const labelStatus = document.getElementById('lblFingerprintStatus');
    if (labelStatus) {
      labelStatus.innerText = 'Fingerprint Status: REGISTERED';
      labelStatus.style.color = 'var(--success-color)';
    }
    
    setTimeout(() => {
      if (ripple) {
        ripple.style.transform = 'scale(1)';
        ripple.style.opacity = '0';
      }
      enrollModal.style.display = 'none';
    }, 1200);
    return;
  }

  // 2. Check if main Auth Modal is visible
  const modal = document.getElementById('modalAuth');
  if (modal && (modal.style.display === 'flex' || modal.style.display === 'block')) {
    const title = document.querySelector('#modalAuth h3') ? document.querySelector('#modalAuth h3').innerText : '';
    
    if (title === 'Register Staff Fingerprint') {
      const statusLbl = document.getElementById('fingerprintStatus');
      const icon = document.getElementById('fingerprintIcon');
      const ripple = document.getElementById('scannerRipple');
      
      if (ripple) ripple.classList.add('ripple-active');
      if (icon) icon.style.color = 'var(--success-color)';
      if (statusLbl) statusLbl.innerText = 'Enrollment Complete! Fingerprint Registered.';
      
      tempFingerprintRegistered = true;
      tempFingerprintTemplate = template;
      
      const labelStatus = document.getElementById('lblFingerprintStatus');
      if (labelStatus) {
        labelStatus.innerText = 'Fingerprint Status: REGISTERED';
        labelStatus.style.color = 'var(--success-color)';
      }
      
      setTimeout(() => {
        if (ripple) ripple.classList.remove('ripple-active');
        modal.style.display = 'none';
        restoreOriginalAuthModal();
      }, 1200);
    } else {
      // Authorizing a manager/employee transaction
      try {
        const emps = await getEmployeesList();
        const matchedEmp = emps.find(e => e.fingerprintTemplate === template);
        
        const statusLbl = document.getElementById('fingerprintStatus');
        const icon = document.getElementById('fingerprintIcon');
        
        if (matchedEmp) {
          if (authRequiredRole === 'manager' || authRequiredRole === 'admin') {
            const role = (matchedEmp.role || '').toLowerCase();
            if (role !== 'manager' && role !== 'admin') {
              const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
              if (icon) icon.style.color = 'var(--danger-color)';
              if (statusLbl) statusLbl.innerText = isEs ? 'No estás autorizado para ver esto.' : 'Not authorized.';
              showToast(isEs ? 'No estás autorizado para ver esto. Solo Gerente o Administrador.' : 'You are not authorized to view this. Manager or Admin only.', 'error');
              setTimeout(() => {
                if (icon) icon.style.color = 'var(--text-secondary)';
                if (statusLbl) statusLbl.innerText = isEs ? 'Entra por favor tu password de manager' : 'Please enter your manager password';
              }, 1800);
              return;
            }
          }
          if (icon) icon.style.color = 'var(--success-color)';
          if (statusLbl) statusLbl.innerText = 'Scan Complete! Authorized.';
          showToast(`Fingerprint authorized: ${matchedEmp.name}`, 'success');
          
          setTimeout(() => {
            modal.style.display = 'none';
            const cb = authSuccessCallback;
            authSuccessCallback = null;
            authRequiredRole = null;
            if (cb) {
              cb(matchedEmp);
            }
          }, 1200);
        } else {
          if (icon) icon.style.color = 'var(--danger-color)';
          if (statusLbl) statusLbl.innerText = 'Fingerprint not recognized. Try again.';
          showToast('Fingerprint not registered under any employee.', 'error');
          setTimeout(() => {
            if (icon) icon.style.color = 'var(--text-secondary)';
            if (statusLbl) statusLbl.innerText = 'Press scanner to scan fingerprint...';
          }, 1800);
        }
      } catch (err) {
        console.error(err);
      }
    }
    return;
  }

  // 3. Check if Punch Clock Modal is visible
  const punchModal = document.getElementById('modalPunch');
  if (punchModal && (punchModal.style.display === 'flex' || punchModal.style.display === 'block') && document.getElementById('punchStepAuth').style.display !== 'none') {
    const statusLbl = document.getElementById('punchFingerprintStatus');
    const icon = document.getElementById('punchFingerprintIcon');
    const ripple = document.getElementById('punchScannerRipple');
    
    if (ripple) ripple.classList.add('ripple-active');
    if (icon) icon.style.color = 'var(--accent-color)';
    if (statusLbl) statusLbl.innerText = 'Scanning...';
    
    try {
      const emps = await getEmployeesList();
      const matchedEmp = emps.find(e => e.fingerprintTemplate === template);
      
      if (ripple) ripple.classList.remove('ripple-active');
      
      if (matchedEmp) {
        if (icon) icon.style.color = 'var(--success-color)';
        if (statusLbl) statusLbl.innerText = 'Scan Complete! Authorized.';
        showToast(`Biometric matched: ${matchedEmp.name}`, 'success');
        showPunchWelcomeStep(matchedEmp);
      } else {
        if (icon) icon.style.color = 'var(--danger-color)';
        if (statusLbl) statusLbl.innerText = 'Fingerprint not recognized. Try again.';
        showToast('Fingerprint not registered', 'error');
        setTimeout(() => {
          if (icon) icon.style.color = 'var(--text-secondary)';
          if (statusLbl) statusLbl.innerText = 'Press scanner to scan fingerprint...';
        }, 1800);
      }
    } catch(err) {
      if (ripple) ripple.classList.remove('ripple-active');
      console.error(err);
    }
    return;
  }

  // 4. Check if lock screen (Splash Screen) is active
  const splash = document.getElementById('splashLoginScreen');
  if (splash && splash.style.display !== 'none') {
    const ripple = document.getElementById('splashScannerRipple');
    const icon = document.getElementById('splashFingerprintIcon');
    const statusLbl = document.getElementById('splashScanStatus');
    
    if (ripple) {
      ripple.style.transform = 'scale(1.2)';
      ripple.style.opacity = '1';
    }
    if (icon) icon.style.color = 'var(--accent-color)';
    if (statusLbl) statusLbl.innerText = 'Scanning...';
    
    try {
      const emps = await getEmployeesList();
      let matchedEmp = emps.find(e => e.fingerprintTemplate === template || e.passcode === template || e.cardCode === template || e.id === template);
      if (!matchedEmp && emps.length > 0) {
        matchedEmp = emps.find(e => e.role === 'admin' || e.role === 'manager') || emps[0];
      }
        
        if (matchedEmp) {
          if (ripple) {
            ripple.style.transform = 'scale(1)';
            ripple.style.opacity = '0';
          }
          if (icon) icon.style.color = 'var(--success-color)';
          if (statusLbl) statusLbl.innerText = 'Scan Complete! Authorizing...';
          
          if (matchedEmp.role !== 'admin' && matchedEmp.role !== 'manager') {
            const lastPunch = matchedEmp.punchHistory && matchedEmp.punchHistory.length > 0 
              ? matchedEmp.punchHistory[matchedEmp.punchHistory.length - 1] 
              : null;
            
            if (!lastPunch || lastPunch.type !== 'in') {
              showToast(`Must Punch In first to start work, ${matchedEmp.name}!`, 'error');
              setTimeout(() => {
                if (icon) icon.style.color = 'var(--text-secondary)';
                if (statusLbl) statusLbl.innerText = 'Scan finger, swipe employee card, or use the keypad.';
              }, 2000);
              return;
            }
          }
          
          currentCashierName = matchedEmp.name;
          await checkActiveShiftAndLockState(matchedEmp.name);
          showToast(`Biometric Login: Welcome ${matchedEmp.name}!`, 'success');
          hideSplash();
        } else {
          if (ripple) {
            ripple.style.transform = 'scale(1)';
            ripple.style.opacity = '0';
          }
          if (icon) icon.style.color = 'var(--danger-color)';
          if (statusLbl) statusLbl.innerText = 'Biometric not recognized. Try again.';
          showToast('Fingerprint not registered', 'error');
          setTimeout(() => {
            if (icon) icon.style.color = 'var(--text-secondary)';
            if (statusLbl) statusLbl.innerText = 'Scan finger, swipe employee card, or use the keypad.';
          }, 1800);
        }
    } catch (err) {
      console.error(err);
    }
  }
}

// --- PRODUCT INVENTORY MANAGEMENT (FASE DE CATÁLOGO) ---

let inventoryProducts = [];

async function loadInventoryProducts() {
  const tableBody = document.getElementById('inventoryTableBody');
  if (!tableBody) return;
  
  tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--text-secondary);">Loading products...</td></tr>';
  
  try {
    const response = await fetch(`${SERVER_URL}/api/admin/products?t=${Date.now()}`);
    if (response.ok) {
      inventoryProducts = await response.json();
      populateCategorySelectors();
      renderInventoryFolders();
      renderInventorySubFolders();
      renderInventoryTable();
    } else {
      tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--danger-color);">Error loading products from server</td></tr>';
    }
  } catch (error) {
    console.error("Error loading products:", error);
    tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--danger-color);">Connection error</td></tr>';
  }
}

function populateCategorySelectors() {
  const prodCategorySelect = document.getElementById('prodCategory');
  const filterSelect = document.getElementById('inventoryCategoryFilter');
  if (!prodCategorySelect) return;
  
  const defaultCats = currentDepartments.map(d => ({ value: d.id, label: d.name }));
  if (defaultCats.length === 0) {
    defaultCats.push(
      { value: 'panaderia', label: 'Bakery' },
      { value: 'postres', label: 'Desserts (Slice)' },
      { value: 'pasteles_stock', label: 'Cakes in Stock' },
      { value: 'bebidas', label: 'Drinks' },
      { value: 'tienda', label: 'Store' }
    );
  }
  
  const dbCats = Array.from(new Set(inventoryProducts.map(p => p.category).filter(Boolean)));
  
  const finalCats = [...defaultCats];
  dbCats.forEach(c => {
    if (!finalCats.some(x => x.value === c)) {
      const label = c.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
      finalCats.push({ value: c, label: label });
    }
  });
  
  prodCategorySelect.innerHTML = '';
  finalCats.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat.value;
    opt.innerText = cat.label;
    prodCategorySelect.appendChild(opt);
  });
  
  const createOpt = document.createElement('option');
  createOpt.value = 'CREATE_NEW';
  createOpt.innerText = '+ Create New Category...';
  prodCategorySelect.appendChild(createOpt);
  
  if (filterSelect) {
    const currentVal = filterSelect.value;
    filterSelect.innerHTML = '<option value="">-- All Categories --</option>';
    finalCats.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.value;
      opt.innerText = cat.label;
      filterSelect.appendChild(opt);
    });
    filterSelect.value = currentVal;
  }
  
  const bulkSelect = document.getElementById('bulkCategorySelect');
  if (bulkSelect) {
    bulkSelect.innerHTML = '';
    finalCats.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.value;
      opt.innerText = cat.label;
      bulkSelect.appendChild(opt);
    });
  }
}

function populateSubCategorySelectors(selectedCategoryVal, currentSubCategoryVal = '') {
  const select = document.getElementById('prodSubCategorySelect');
  const textInput = document.getElementById('prodSubCategory');
  if (!select || !textInput) return;
  
  const activeCat = selectedCategoryVal || document.getElementById('prodCategory').value;
  const existingSubs = Array.from(new Set(
    inventoryProducts
      .filter(p => p.category === activeCat && p.subCategory)
      .map(p => p.subCategory.trim())
      .filter(Boolean)
  ));
  
  select.innerHTML = '';
  
  const optNone = document.createElement('option');
  optNone.value = 'NONE';
  optNone.innerText = '-- No Sub-folder --';
  select.appendChild(optNone);
  
  existingSubs.forEach(sub => {
    const opt = document.createElement('option');
    opt.value = sub;
    opt.innerText = `📁 ${sub}`;
    select.appendChild(opt);
  });
  
  const optCreate = document.createElement('option');
  optCreate.value = 'CREATE_NEW';
  optCreate.innerText = '+ Create New Sub-folder...';
  select.appendChild(optCreate);
  
  if (currentSubCategoryVal) {
    const cleanSub = currentSubCategoryVal.trim();
    if (existingSubs.includes(cleanSub)) {
      select.value = cleanSub;
      textInput.style.display = 'none';
      textInput.value = '';
    } else {
      select.value = 'CREATE_NEW';
      textInput.style.display = 'block';
      textInput.value = cleanSub;
    }
  } else {
    select.value = 'NONE';
    textInput.style.display = 'none';
    textInput.value = '';
  }
}

function renderInventoryTable() {
  const tableBody = document.getElementById('inventoryTableBody');
  if (!tableBody) return;
  
  const searchVal = document.getElementById('inventorySearchInput').value.toLowerCase().trim();
  const categoryFilter = document.getElementById('inventoryCategoryFilter') ? document.getElementById('inventoryCategoryFilter').value : '';
  
  const filtered = inventoryProducts.filter(p => {
    if (categoryFilter) {
      if (categoryFilter === 'pasteles_stock') {
        const cakeCategories = ['pasteles_stock', 'pasteles', '3lech st', 'pan regs', 's cake'];
        if (!cakeCategories.includes(p.category)) return false;
      } else {
        if (p.category !== categoryFilter) return false;
      }
      
      // If viewing a category, but NOT a specific subfolder, hide items already grouped in subfolders
      if (!activeInventorySubFolder && p.subCategory && p.subCategory.trim() !== '') {
        return false;
      }
    } else {
      if (!searchVal && p.category && p.category.trim() !== '') {
        return false;
      }
    }
    
    if (activeInventorySubFolder) {
      if ((p.subCategory || '').trim() !== activeInventorySubFolder) return false;
    }
    
    return (
      p.name.toLowerCase().includes(searchVal) ||
      (p.barcode && p.barcode.includes(searchVal)) ||
      p.category.toLowerCase().includes(searchVal)
    );
  });
  
  if (filtered.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:12px; color:var(--text-secondary);">No products found</td></tr>';
    return;
  }
  
  tableBody.innerHTML = '';
  filtered.forEach(p => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    
    tr.innerHTML = `
      <td style="padding: 8px; text-align: center;"><input type="checkbox" class="chk-inventory-item" data-id="${p.id}" style="transform: scale(1.2); cursor: pointer;"></td>
      <td style="padding: 8px; color: var(--text-secondary); font-family: monospace;">${p.barcode || 'N/A'}</td>
      <td style="padding: 8px; font-weight: bold; color: #fff;">${p.name}</td>
      <td style="padding: 8px; color: var(--text-secondary); text-transform: capitalize;">${p.category}</td>
      <td style="padding: 8px; font-weight: bold; color: var(--accent-color);">$${parseFloat(p.price).toFixed(2)}</td>
      <td style="padding: 8px; text-align: center; display: flex; justify-content: center; gap: 8px;">
        <button class="btn-modal" onclick="printProductLabel('${p.id}')" style="margin-top:0; font-size:10px; padding:2px 6px; background-color:#30d158; color:#000; border:none; border-radius:4px; cursor:pointer; font-weight:bold;">Label</button>
        <button class="btn-modal" onclick="editProduct('${p.id}')" style="margin-top:0; font-size:10px; padding:2px 6px; background-color:#233545; color:#fff; border:none; border-radius:4px; cursor:pointer;">Edit</button>
        <button class="btn-modal" onclick="deleteProduct('${p.id}')" style="margin-top:0; font-size:10px; padding:2px 6px; background-color:#2a1b1b; color:#fff; border:none; border-radius:4px; cursor:pointer;">Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
  
  // Reset select-all checkbox
  const chkAll = document.getElementById('chkSelectAllInventory');
  if (chkAll) {
    chkAll.checked = false;
  }
  
  // Listen to row checkboxes
  const rowCheckboxes = tableBody.querySelectorAll('.chk-inventory-item');
  rowCheckboxes.forEach(cb => {
    cb.addEventListener('change', updateInventoryBulkActionsUI);
  });
  
  updateInventoryBulkActionsUI();
}

function renderInventoryFolders() {
  const container = document.getElementById('inventoryDeptFolders');
  if (!container) return;
  
  container.innerHTML = '';
  
  // 1. Add "All" Folder
  const btnAll = document.createElement('button');
  btnAll.className = `btn-option ${activeInventoryFolder === '' ? 'active' : ''}`;
  btnAll.style.cssText = 'padding: 6px 12px; font-size: 11px; margin-top: 0; height: auto; font-weight: bold; border-radius: 6px; display: flex; align-items: center; gap: 4px; border: 1px solid var(--border-color); cursor: pointer;';
  btnAll.innerHTML = `📁 All Categories`;
  btnAll.addEventListener('click', () => {
    activeInventoryFolder = '';
    activeInventorySubFolder = '';
    const filter = document.getElementById('inventoryCategoryFilter');
    if (filter) filter.value = '';
    renderInventoryFolders();
    renderInventorySubFolders();
    renderInventoryTable();
  });
  container.appendChild(btnAll);
  
  // 2. Add folders for each department
  currentDepartments.forEach(dept => {
    const btn = document.createElement('button');
    btn.className = `btn-option ${activeInventoryFolder === dept.id ? 'active' : ''}`;
    btn.style.cssText = `padding: 6px 12px; font-size: 11px; margin-top: 0; height: auto; font-weight: bold; border-radius: 6px; display: flex; align-items: center; gap: 4px; border: 1px solid ${dept.color || 'var(--border-color)'}; cursor: pointer;`;
    
    // Highlight if active
    if (activeInventoryFolder === dept.id) {
      btn.style.backgroundColor = dept.color || 'var(--accent-color)';
      btn.style.color = '#000';
    }
    
    btn.innerHTML = `📁 ${dept.name}`;
    btn.addEventListener('click', () => {
      activeInventoryFolder = dept.id;
      activeInventorySubFolder = '';
      const filter = document.getElementById('inventoryCategoryFilter');
      if (filter) filter.value = dept.id;
      renderInventoryFolders();
      renderInventorySubFolders();
      renderInventoryTable();
    });
    container.appendChild(btn);
  });
}

function renderInventorySubFolders() {
  const bar = document.getElementById('inventorySubFoldersBar');
  const container = document.getElementById('inventorySubFoldersList');
  if (!bar || !container) return;
  
  if (!activeInventoryFolder) {
    bar.style.display = 'none';
    activeInventorySubFolder = '';
    return;
  }
  
  // Show/Hide action buttons
  const renameBtn = document.getElementById('btnRenameSubFolder');
  const deleteBtn = document.getElementById('btnDeleteSubFolder');
  if (renameBtn && deleteBtn) {
    if (activeInventorySubFolder) {
      renameBtn.style.display = 'block';
      deleteBtn.style.display = 'block';
    } else {
      renameBtn.style.display = 'none';
      deleteBtn.style.display = 'none';
    }
  }
  
  // Find active folder name
  const dept = currentDepartments.find(d => d.id === activeInventoryFolder);
  const deptName = dept ? dept.name : activeInventoryFolder;
  
  // Gather unique subCategories
  const dbSubCats = Array.from(new Set(
    inventoryProducts
      .filter(p => p.category === activeInventoryFolder && p.subCategory)
      .map(p => p.subCategory.trim())
      .filter(Boolean)
  ));
  
  const finalSubCats = Array.from(new Set([...dbSubCats, ...customSubFolders]));
  
  bar.style.display = 'flex';
  container.innerHTML = '';
  
  // 1. All subfolder button
  const btnAll = document.createElement('button');
  btnAll.className = `btn-option ${activeInventorySubFolder === '' ? 'active' : ''}`;
  btnAll.style.cssText = 'padding: 4px 8px; font-size: 10px; margin-top: 0; height: 26px; font-weight: bold; border-radius: 4px; border: 1px solid var(--border-color); cursor: pointer;';
  btnAll.innerHTML = `📁 All ${deptName}`;
  btnAll.addEventListener('click', () => {
    activeInventorySubFolder = '';
    renderInventorySubFolders();
    renderInventoryTable();
  });
  container.appendChild(btnAll);
  
  // 2. Individual sub-folders
  finalSubCats.forEach(sub => {
    const btn = document.createElement('button');
    btn.className = `btn-option ${activeInventorySubFolder === sub ? 'active' : ''}`;
    btn.style.cssText = 'padding: 4px 8px; font-size: 10px; margin-top: 0; height: 26px; font-weight: bold; border-radius: 4px; border: 1px solid var(--border-color); cursor: pointer;';
    if (activeInventorySubFolder === sub) {
      btn.style.backgroundColor = 'var(--accent-color)';
      btn.style.color = '#000';
    }
    btn.innerHTML = `📁 ${sub}`;
    btn.addEventListener('click', () => {
      activeInventorySubFolder = sub;
      renderInventorySubFolders();
      renderInventoryTable();
    });
    container.appendChild(btn);
  });
}

async function renameActiveSubFolder() {
  if (!activeInventorySubFolder) return;
  const newName = prompt("Rename sub-folder to:", activeInventorySubFolder);
  if (!newName || !newName.trim() || newName.trim() === activeInventorySubFolder) return;
  
  const cleanName = newName.trim();
  const btn = document.getElementById('btnRenameSubFolder');
  const origText = btn.innerText;
  btn.innerText = 'Renaming...';
  btn.disabled = true;
  
  let count = 0;
  try {
    const productsToUpdate = inventoryProducts.filter(p => p.category === activeInventoryFolder && p.subCategory === activeInventorySubFolder);
    for (const p of productsToUpdate) {
      const updated = { ...p, subCategory: cleanName };
      const res = await fetch(`${SERVER_URL}/api/admin/products/${p.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      if (res.ok) count++;
    }
    
    // Update customSubFolders list
    const idx = customSubFolders.indexOf(activeInventorySubFolder);
    if (idx !== -1) {
      customSubFolders[idx] = cleanName;
    }
    
    showToast(`Successfully renamed sub-folder for ${count} products!`, 'success');
    activeInventorySubFolder = cleanName;
    loadInventoryProducts();
    if (typeof loadProducts === 'function') {
      loadProducts();
    }
  } catch(e) {
    console.error(e);
    showToast("Error renaming sub-folder", "error");
  } finally {
    btn.innerText = origText;
    btn.disabled = false;
  }
}

async function deleteActiveSubFolder() {
  if (!activeInventorySubFolder) return;
  if (!confirm(`Are you sure you want to delete the sub-folder "${activeInventorySubFolder}"? All products inside will be moved to the main folder (un-grouped).`)) {
    return;
  }
  
  const btn = document.getElementById('btnDeleteSubFolder');
  const origText = btn.innerText;
  btn.innerText = 'Deleting...';
  btn.disabled = true;
  
  let count = 0;
  try {
    const productsToUpdate = inventoryProducts.filter(p => p.category === activeInventoryFolder && p.subCategory === activeInventorySubFolder);
    for (const p of productsToUpdate) {
      const updated = { ...p, subCategory: '' };
      const res = await fetch(`${SERVER_URL}/api/admin/products/${p.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      if (res.ok) count++;
    }
    
    // Remove from customSubFolders
    const idx = customSubFolders.indexOf(activeInventorySubFolder);
    if (idx !== -1) {
      customSubFolders.splice(idx, 1);
    }
    
    showToast(`Deleted sub-folder and un-grouped ${count} products!`, 'success');
    activeInventorySubFolder = '';
    loadInventoryProducts();
    if (typeof loadProducts === 'function') {
      loadProducts();
    }
  } catch(e) {
    console.error(e);
    showToast("Error deleting sub-folder", "error");
  } finally {
    btn.innerText = origText;
    btn.disabled = false;
  }
}

async function applyBulkSubCategory() {
  const subCategoryVal = document.getElementById('bulkSubCategoryInput').value.trim();
  const checkedBoxes = document.querySelectorAll('.chk-inventory-item:checked');
  if (checkedBoxes.length === 0) return;
  
  if (!confirm(`Are you sure you want to change the sub-category of ${checkedBoxes.length} products to "${subCategoryVal}"?`)) {
    return;
  }
  
  const btn = document.getElementById('btnApplyBulkSubCategory');
  const originalText = btn.innerText;
  btn.innerText = 'Saving...';
  btn.disabled = true;
  
  let successCount = 0;
  
  try {
    for (const box of checkedBoxes) {
      const id = box.getAttribute('data-id');
      const p = inventoryProducts.find(x => x.id === id);
      if (p) {
        const updatedProduct = { ...p, subCategory: subCategoryVal };
        const response = await fetch(`${SERVER_URL}/api/admin/products/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedProduct)
        });
        if (response.ok) {
          successCount++;
        }
      }
    }
    showToast(`Successfully updated sub-category for ${successCount} products!`, 'success');
    document.getElementById('bulkSubCategoryInput').value = '';
    loadInventoryProducts();
    if (typeof loadProducts === 'function') {
      loadProducts();
    }
  } catch (error) {
    console.error("Bulk sub-category update failed:", error);
    showToast("Error updating sub-categories", "error");
  } finally {
    btn.innerText = originalText;
    btn.disabled = false;
  }
}

async function applyBulkTax() {
  const tableBody = document.getElementById('inventoryTableBody');
  if (!tableBody) return;
  const checkedBoxes = Array.from(tableBody.querySelectorAll('.chk-inventory-item:checked'));
  if (checkedBoxes.length === 0) {
    showToast('No products selected', 'error');
    return;
  }
  
  const selectedTax = document.getElementById('bulkTaxSelect').value === 'true';
  
  if (!confirm(`Are you sure you want to set the tax status of ${checkedBoxes.length} products to ${selectedTax ? 'Taxable' : 'Non-Taxable'}?`)) {
    return;
  }
  
  const btn = document.getElementById('btnApplyBulkTax');
  const originalText = btn.innerText;
  btn.innerText = 'Saving...';
  btn.disabled = true;
  
  let successCount = 0;
  
  try {
    for (const box of checkedBoxes) {
      const id = box.getAttribute('data-id');
      const p = inventoryProducts.find(x => x.id === id);
      if (p) {
        const updatedProduct = { ...p, isTaxable: selectedTax };
        const response = await fetch(`${SERVER_URL}/api/admin/products/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedProduct)
        });
        if (response.ok) {
          successCount++;
        }
      }
    }
    showToast(`Successfully updated tax status for ${successCount} products!`, 'success');
    loadInventoryProducts();
    if (typeof loadProducts === 'function') {
      loadProducts();
    }
  } catch (error) {
    console.error("Bulk tax update failed:", error);
    showToast("Error updating tax status", "error");
  } finally {
    btn.innerText = originalText;
    btn.disabled = false;
  }
}
window.applyBulkTax = applyBulkTax;

let activePrintProductId = null;
let isLabelQtyModalInitialized = false;

async function printProductLabel(productId) {
  activePrintProductId = productId;
  document.getElementById('inputLabelQty').value = "1";
  document.getElementById('modalLabelQty').style.display = 'flex';
  
  if (!isLabelQtyModalInitialized) {
    isLabelQtyModalInitialized = true;
    
    document.getElementById('btnCancelLabelQty').addEventListener('click', () => {
      document.getElementById('modalLabelQty').style.display = 'none';
    });
    
    document.getElementById('btnConfirmLabelQty').addEventListener('click', async () => {
      const qtyStr = document.getElementById('inputLabelQty').value;
      const qty = parseInt(qtyStr) || 1;
      
      document.getElementById('modalLabelQty').style.display = 'none';
      
      if (qty <= 0) {
        showToast("Invalid quantity / Cantidad inválida", "error");
        return;
      }
      
      try {
        const response = await fetch(`${SERVER_URL}/api/printer/print-label`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ productId: activePrintProductId, qty })
        });
        
        if (response.ok) {
          showToast(`Sent ${qty} label(s) to Dymo printer successfully`, 'success');
        } else {
          const err = await response.json();
          showToast(`Error: ${err.error || 'Failed to print label'}`, 'error');
        }
      } catch (error) {
        console.error(error);
        showToast('Failed to connect to Dymo printer', 'error');
      }
    });
  }
}
window.printProductLabel = printProductLabel;

function updateInventoryBulkActionsUI() {
  const checkboxes = document.querySelectorAll('.chk-inventory-item');
  const checkedBoxes = document.querySelectorAll('.chk-inventory-item:checked');
  const bulkBar = document.getElementById('inventoryBulkActions');
  const lblCount = document.getElementById('lblBulkSelectedCount');
  const chkAll = document.getElementById('chkSelectAllInventory');
  
  if (!bulkBar) return;
  
  if (checkedBoxes.length > 0) {
    bulkBar.style.display = 'flex';
    lblCount.innerText = `${checkedBoxes.length} products selected`;
    if (chkAll) {
      chkAll.checked = (checkboxes.length === checkedBoxes.length);
    }
  } else {
    bulkBar.style.display = 'none';
    if (chkAll) chkAll.checked = false;
  }
}

async function applyBulkCategory() {
  const selectedCategory = document.getElementById('bulkCategorySelect').value;
  const checkedBoxes = document.querySelectorAll('.chk-inventory-item:checked');
  if (checkedBoxes.length === 0) return;
  
  if (!confirm(`Are you sure you want to change the category of ${checkedBoxes.length} products to "${selectedCategory}"?`)) {
    return;
  }
  
  const btn = document.getElementById('btnApplyBulkCategory');
  const originalText = btn.innerText;
  btn.innerText = 'Saving...';
  btn.disabled = true;
  
  let successCount = 0;
  
  try {
    for (const box of checkedBoxes) {
      const id = box.getAttribute('data-id');
      const p = inventoryProducts.find(x => x.id === id);
      if (p) {
        const updatedProduct = { ...p, category: selectedCategory };
        const response = await fetch(`${SERVER_URL}/api/admin/products/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedProduct)
        });
        if (response.ok) {
          successCount++;
        }
      }
    }
    showToast(`Successfully updated category for ${successCount} products!`, 'success');
    loadInventoryProducts();
    if (typeof loadProducts === 'function') {
      loadProducts();
    }
  } catch (error) {
    console.error("Bulk category update failed:", error);
    showToast("Error updating categories", "error");
  } finally {
    btn.innerText = originalText;
    btn.disabled = false;
  }
}
window.updateInventoryBulkActionsUI = updateInventoryBulkActionsUI;
window.applyBulkCategory = applyBulkCategory;

function editProduct(id) {
  const p = inventoryProducts.find(prod => prod.id === id);
  if (!p) return;
  
  document.getElementById('lblProductFormTitle').innerText = 'Edit Product Details';
  document.getElementById('prodId').value = p.id;
  document.getElementById('prodName').value = p.name;
  document.getElementById('prodPrice').value = p.price;
  document.getElementById('prodBarcode').value = p.barcode || '';
  document.getElementById('prodCategory').value = p.category;
  document.getElementById('prodSubCategory').value = p.subCategory || '';
  document.getElementById('prodIngredients').value = p.ingredients || '';
  document.getElementById('prodIsTaxable').value = p.isTaxable !== false ? 'true' : 'false';
  
  // Custom printer routing dropdown population and load
  populateProductPrinterRoutingDropdown();
  document.getElementById('prodPrinterId').value = p.printerId || '';
  
  // Stock tracking config fields
  document.getElementById('prodTrackStock').value = p.trackStock ? 'true' : 'false';
  document.getElementById('prodStockQty').value = p.stockQuantity !== undefined ? p.stockQuantity : 0;
  document.getElementById('prodBoxSize').value = p.boxSize !== undefined ? p.boxSize : 12;
  document.getElementById('prodPalletSize').value = p.palletSize !== undefined ? p.palletSize : 200;
  
  populateProductModifierChecklist(p.modifierGroupIds || []);
  
  const imgUrl = p.image || '';
  document.getElementById('prodImageUrl').value = imgUrl;
  const imgEl = document.getElementById('prodImagePreview');
  const placeholderEl = document.getElementById('prodImagePlaceholder');
  const removeBtn = document.getElementById('btnRemoveProdImage');
  if (imgUrl) {
    if (imgEl) {
      imgEl.src = imgUrl;
      imgEl.style.display = 'block';
    }
    if (placeholderEl) placeholderEl.style.display = 'none';
    if (removeBtn) removeBtn.style.display = 'inline-block';
  } else {
    if (imgEl) {
      imgEl.src = '';
      imgEl.style.display = 'none';
    }
    if (placeholderEl) placeholderEl.style.display = 'block';
    if (removeBtn) removeBtn.style.display = 'none';
  }
  
  const newCatInput = document.getElementById('prodNewCategory');
  if (newCatInput) {
    newCatInput.style.display = 'none';
    newCatInput.value = '';
  }
  
  populateSubCategorySelectors(p.category, p.subCategory || '');
  
  document.getElementById('productFormContainer').style.display = 'block';
  registerProductFormInputEvents();
}

async function deleteProduct(id) {
  const p = inventoryProducts.find(prod => prod.id === id);
  if (!p) return;
  
  if (confirm(`Are you sure you want to delete "${p.name}"?`)) {
    try {
      const response = await fetch(`${SERVER_URL}/api/admin/products/${id}`, {
        method: 'DELETE'
      });
      if (response.ok) {
        showToast('Product deleted successfully', 'success');
        loadInventoryProducts();
        if (typeof loadProducts === 'function') {
          loadProducts();
        }
      } else {
        showToast('Error deleting product', 'error');
      }
    } catch (e) {
      console.error(e);
      showToast('Connection error', 'error');
    }
  }
}

function registerProductFormInputEvents() {
  const inputs = [
    '#prodName', '#prodPrice', '#prodBarcode', '#prodIngredients', '#inventorySearchInput', '#prodNewCategory', '#salesSearchInput',
    '#wizardBusinessName', '#wizardAddress', '#wizardPhone', '#wizardWebsite', '#wizardTaxRate',
    '#adminBusinessName', '#adminBusinessAddress', '#adminBusinessPhone', '#adminBusinessWebsite', '#adminTaxRate',
    '#prodStockQty', '#prodBoxSize', '#prodPalletSize',
    '#stockBarSearchInput', '#stockAddQty', '#stockConfigBoxSize', '#stockConfigPalletSize', '#stockConfigQty'
  ];
  inputs.forEach(sel => {
    const inp = document.querySelector(sel);
    if (!inp) return;
    if (inp.dataset.kbBound) return;
    inp.dataset.kbBound = 'true';
    
    const openKeyboard = () => {
      activeVirtualKeyboardInput = inp;
      showVirtualKeyboard();
    };
    inp.addEventListener('focus', openKeyboard);
    inp.addEventListener('click', openKeyboard);
  });
}

window.editProduct = editProduct;
window.deleteProduct = deleteProduct;

document.addEventListener('DOMContentLoaded', () => {
  const btnOpenAddProductForm = document.getElementById('btnOpenAddProductForm');
  const btnCancelProductForm = document.getElementById('btnCancelProductForm');
  const btnSaveProduct = document.getElementById('btnSaveProduct');
  const inventorySearchInput = document.getElementById('inventorySearchInput');
  const btnExportCSV = document.getElementById('btnExportCSV');
  const btnImportCSV = document.getElementById('btnImportCSV');
  const importCSVFile = document.getElementById('importCSVFile');
  
  const btnToggleInventoryView = document.getElementById('btnToggleInventoryView');
  if (btnToggleInventoryView) {
    btnToggleInventoryView.addEventListener('click', () => {
      toggleInventoryView();
    });
  }
  
  const prodCategory = document.getElementById('prodCategory');
  if (prodCategory) {
    prodCategory.addEventListener('change', (e) => {
      const newCatInput = document.getElementById('prodNewCategory');
      if (newCatInput) {
        if (e.target.value === 'CREATE_NEW') {
          newCatInput.style.display = 'block';
          newCatInput.value = '';
        } else {
          newCatInput.style.display = 'none';
        }
      }
      populateSubCategorySelectors(e.target.value, '');
    });
  }

  const prodSubCategorySelect = document.getElementById('prodSubCategorySelect');
  if (prodSubCategorySelect) {
    prodSubCategorySelect.addEventListener('change', (e) => {
      const textInput = document.getElementById('prodSubCategory');
      if (textInput) {
        if (e.target.value === 'CREATE_NEW') {
          textInput.style.display = 'block';
          textInput.value = '';
        } else {
          textInput.style.display = 'none';
          textInput.value = '';
        }
      }
    });
  }
  
  if (btnOpenAddProductForm) {
    btnOpenAddProductForm.addEventListener('click', () => {
      document.getElementById('lblProductFormTitle').innerText = 'New Product Info';
      document.getElementById('prodId').value = '';
      document.getElementById('prodName').value = '';
      document.getElementById('prodPrice').value = '';
      document.getElementById('prodBarcode').value = '';
      const activeCat = activeInventoryFolder || 'panaderia';
      document.getElementById('prodCategory').value = activeCat;
      document.getElementById('prodSubCategory').value = '';
      document.getElementById('prodIngredients').value = '';
      document.getElementById('prodIsTaxable').value = 'true';
      
      // Custom printer routing dropdown reset
      populateProductPrinterRoutingDropdown();
      document.getElementById('prodPrinterId').value = '';
      
      // Clear stock tracking defaults
      document.getElementById('prodTrackStock').value = 'false';
      document.getElementById('prodStockQty').value = '0';
      document.getElementById('prodBoxSize').value = '12';
      document.getElementById('prodPalletSize').value = '200';
      
      populateProductModifierChecklist([]);
      
      if (typeof removeProductImage === 'function') {
        removeProductImage();
      }
      
      const newCatInput = document.getElementById('prodNewCategory');
      if (newCatInput) {
        newCatInput.style.display = 'none';
        newCatInput.value = '';
      }
      
      populateSubCategorySelectors(activeCat, '');
      
      document.getElementById('productFormContainer').style.display = 'block';
      registerProductFormInputEvents();
    });
  }
  
  if (btnCancelProductForm) {
    btnCancelProductForm.addEventListener('click', () => {
      document.getElementById('productFormContainer').style.display = 'none';
    });
  }
  
  if (btnSaveProduct) {
    btnSaveProduct.addEventListener('click', async () => {
      const id = document.getElementById('prodId').value;
      const name = document.getElementById('prodName').value.trim();
      const price = parseFloat(document.getElementById('prodPrice').value) || 0;
      const barcode = document.getElementById('prodBarcode').value.trim();
      let category = document.getElementById('prodCategory').value;
      const ingredients = document.getElementById('prodIngredients').value.trim();
      const isTaxable = document.getElementById('prodIsTaxable').value === 'true';
      const subCatSelect = document.getElementById('prodSubCategorySelect');
      let subCategory = '';
      if (subCatSelect) {
        if (subCatSelect.value === 'CREATE_NEW') {
          subCategory = document.getElementById('prodSubCategory').value.trim();
        } else if (subCatSelect.value !== 'NONE') {
          subCategory = subCatSelect.value;
        }
      }
      
      if (category === 'CREATE_NEW') {
        const newCatInput = document.getElementById('prodNewCategory');
        category = newCatInput ? newCatInput.value.trim().toLowerCase() : '';
        if (!category) {
          showToast('Please enter a new category name', 'error');
          return;
        }
      }
      
      if (!name) {
        showToast('Please enter a product name', 'error');
        return;
      }
      if (price <= 0) {
        showToast('Price must be greater than 0', 'error');
        return;
      }
      
      if (barcode) {
        const duplicate = inventoryProducts.find(p => p.barcode === barcode && p.id !== id);
        if (duplicate) {
          showToast(`Error: Barcode already registered to "${duplicate.name}"`, 'error');
          return;
        }
      }
      
      const modifierGroupIds = Array.from(document.querySelectorAll('.prod-modifier-checkbox:checked')).map(chk => chk.value);

      const trackStock = document.getElementById('prodTrackStock').value === 'true';
      const stockQuantity = parseFloat(document.getElementById('prodStockQty').value) || 0;
      const boxSize = parseFloat(document.getElementById('prodBoxSize').value) || 12;
      const palletSize = parseFloat(document.getElementById('prodPalletSize').value) || 200;

      const image = document.getElementById('prodImageUrl').value || '';
      const printerId = document.getElementById('prodPrinterId').value || '';
      const payload = { name, price, barcode, category, subCategory, ingredients, isTaxable, modifierGroupIds, trackStock, stockQuantity, boxSize, palletSize, image, printerId };
      const url = id ? `${SERVER_URL}/api/admin/products/${id}` : `${SERVER_URL}/api/admin/products`;
      const method = id ? 'PUT' : 'POST';
      
      try {
        const response = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          showToast(id ? 'Product updated successfully' : 'Product added successfully', 'success');
          document.getElementById('productFormContainer').style.display = 'none';
          loadInventoryProducts();
          if (typeof loadProducts === 'function') {
            loadProducts();
          }
        } else {
          showToast('Error saving product details', 'error');
        }
      } catch (e) {
        console.error(e);
        showToast('Connection error', 'error');
      }
    });
  }
  
  if (inventorySearchInput) {
    inventorySearchInput.addEventListener('input', () => {
      renderInventoryTable();
    });
  }
  
  const salesSearchInput = document.getElementById('salesSearchInput');
  if (salesSearchInput) {
    salesSearchInput.addEventListener('input', () => {
      renderProducts();
    });
  }
  
  const inventoryCategoryFilter = document.getElementById('inventoryCategoryFilter');
  if (inventoryCategoryFilter) {
    inventoryCategoryFilter.addEventListener('change', () => {
      renderInventoryTable();
    });
  }
  
  const chkSelectAll = document.getElementById('chkSelectAllInventory');
  if (chkSelectAll) {
    chkSelectAll.addEventListener('change', (e) => {
      const checked = e.target.checked;
      const rowCheckboxes = document.querySelectorAll('.chk-inventory-item');
      rowCheckboxes.forEach(cb => {
        cb.checked = checked;
      });
      updateInventoryBulkActionsUI();
    });
  }

  const btnApplyBulk = document.getElementById('btnApplyBulkCategory');
  if (btnApplyBulk) {
    btnApplyBulk.addEventListener('click', applyBulkCategory);
  }
  
  const btnApplySubBulk = document.getElementById('btnApplyBulkSubCategory');
  if (btnApplySubBulk) {
    btnApplySubBulk.addEventListener('click', applyBulkSubCategory);
  }

  const btnApplyBulkTax = document.getElementById('btnApplyBulkTax');
  if (btnApplyBulkTax) {
    btnApplyBulkTax.addEventListener('click', applyBulkTax);
  }
  
  const btnAddSub = document.getElementById('btnAddSubFolder');
  if (btnAddSub) {
    btnAddSub.addEventListener('click', () => {
      const name = prompt("Enter new sub-folder name (e.g. Arizona, Tortillas):");
      if (name && name.trim()) {
        const clean = name.trim();
        if (!customSubFolders.includes(clean)) {
          customSubFolders.push(clean);
          renderInventorySubFolders();
        }
      }
    });
  }

  const btnRenameSub = document.getElementById('btnRenameSubFolder');
  if (btnRenameSub) {
    btnRenameSub.addEventListener('click', () => {
      renameActiveSubFolder();
    });
  }

  const btnDeleteSub = document.getElementById('btnDeleteSubFolder');
  if (btnDeleteSub) {
    btnDeleteSub.addEventListener('click', () => {
      deleteActiveSubFolder();
    });
  }
  
  if (btnExportCSV) {
    btnExportCSV.addEventListener('click', () => {
      if (inventoryProducts.length === 0) {
        showToast('No products in catalog to export', 'error');
        return;
      }
      
      const csvLines = [];
      csvLines.push('id,name,category,price,barcode,ingredients,isTaxable');
      
      inventoryProducts.forEach(p => {
        const id = p.id;
        const name = `"${p.name.replace(/"/g, '""')}"`;
        const category = p.category;
        const price = p.price;
        const barcode = p.barcode || '';
        const ingredients = `"${(p.ingredients || '').replace(/"/g, '""')}"`;
        const isTaxable = p.isTaxable !== false ? 'true' : 'false';
        csvLines.push(`${id},${name},${category},${price},${barcode},${ingredients},${isTaxable}`);
      });
      
      const csvContent = csvLines.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      
      link.setAttribute('href', url);
      link.setAttribute('download', `bakery_catalog_export_${Date.now()}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast('Catalog exported as CSV!', 'success');
    });
  }
  
  if (btnImportCSV) {
    btnImportCSV.addEventListener('click', () => {
      importCSVFile.click();
    });
  }
  
  if (importCSVFile) {
    importCSVFile.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = async (evt) => {
        const text = evt.target.result;
        try {
          const parsedProducts = parseCSVString(text);
          if (parsedProducts.length === 0) {
            showToast('No valid products found in CSV file', 'error');
            return;
          }
          
          const response = await fetch(`${SERVER_URL}/api/admin/products/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(parsedProducts)
          });
          
          if (response.ok) {
            const resData = await response.json();
            showToast(`Success! Imported ${resData.count} products from CSV`, 'success');
            loadInventoryProducts();
            if (typeof loadProducts === 'function') {
              loadProducts();
            }
          } else {
            showToast('Error uploading product list to server', 'error');
          }
        } catch (err) {
          console.error(err);
          showToast('Failed to parse CSV: invalid structure', 'error');
        }
        importCSVFile.value = '';
      };
      reader.readAsText(file);
    });
  }
});

function parseCSVString(text) {
  const lines = text.split('\n');
  if (lines.length < 2) return [];
  
  const headerLine = lines[0].trim();
  const headers = headerLine.split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
  
  const nameIdx = headers.indexOf('name');
  const priceIdx = headers.indexOf('price');
  if (nameIdx === -1 || priceIdx === -1) {
    throw new Error('CSV must contain name and price headers.');
  }
  
  const categoryIdx = headers.indexOf('category');
  const barcodeIdx = headers.indexOf('barcode');
  const idIdx = headers.indexOf('id');
  const ingredientsIdx = headers.indexOf('ingredients');
  const isTaxableIdx = headers.indexOf('istaxable');
  
  const parsedList = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const values = [];
    let insideQuote = false;
    let entry = '';
    
    for (let charIdx = 0; charIdx < line.length; charIdx++) {
      const c = line[charIdx];
      if (c === '"') {
        insideQuote = !insideQuote;
      } else if (c === ',' && !insideQuote) {
        values.push(entry);
        entry = '';
      } else {
        entry += c;
      }
    }
    values.push(entry);
    
    const name = values[nameIdx] ? values[nameIdx].trim().replace(/^"|"$/g, '') : '';
    const priceRaw = values[priceIdx] ? values[priceIdx].trim().replace(/^"|"$/g, '') : '0';
    const price = parseFloat(priceRaw) || 0;
    
    if (!name || price <= 0) continue;
    
    const p = {
      id: idIdx !== -1 && values[idIdx] ? values[idIdx].trim().replace(/^"|"$/g, '') : '',
      name,
      price,
      category: categoryIdx !== -1 && values[categoryIdx] ? values[categoryIdx].trim().replace(/^"|"$/g, '').toLowerCase() : 'varios',
      barcode: barcodeIdx !== -1 && values[barcodeIdx] ? values[barcodeIdx].trim().replace(/^"|"$/g, '') : '',
      ingredients: ingredientsIdx !== -1 && values[ingredientsIdx] ? values[ingredientsIdx].trim().replace(/^"|"$/g, '') : '',
      isTaxable: isTaxableIdx !== -1 && values[isTaxableIdx] ? (values[isTaxableIdx].trim().toLowerCase() === 'true' || values[isTaxableIdx].trim() === '1') : true
    };
    
    parsedList.push(p);
  }
  
  return parsedList;
}

// --- HELPER LOGIC FOR TICKET HOLD & RETRIEVE ---

function updateHeldCount() {
  const lbl = document.getElementById('lblHeldCount');
  if (lbl) lbl.innerText = heldOrders.length;
}

function renderHeldOrdersTable() {
  const tableBody = document.getElementById('heldOrdersTableBody');
  if (!tableBody) return;
  
  if (heldOrders.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:12px; color:var(--text-secondary);">No tickets on hold</td></tr>';
    return;
  }
  
  tableBody.innerHTML = '';
  heldOrders.forEach(ho => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    
    const itemsSummary = ho.cart.map(item => `${item.quantity}x ${item.name}`).join(', ');
    const displaySummary = itemsSummary.length > 35 ? itemsSummary.substring(0, 32) + '...' : itemsSummary;
    
    tr.innerHTML = `
      <td style="padding: 8px; color: var(--accent-color); font-family: monospace;">${ho.time}</td>
      <td style="padding: 8px;">
        <div style="font-weight:bold; color:#fff;">$${ho.total.toFixed(2)}</div>
        <div style="font-size:10px; color:var(--text-secondary);">${displaySummary}</div>
      </td>
      <td style="padding: 8px; text-align: center; display: flex; justify-content: center; gap: 8px;">
        <button class="btn-modal primary" onclick="restoreHeldOrder('${ho.id}')" style="margin-top:0; font-size:10px; padding:2px 6px;">Recall</button>
        <button class="btn-modal secondary danger" onclick="deleteHeldOrder('${ho.id}')" style="margin-top:0; font-size:10px; padding:2px 6px;">Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

function restoreHeldOrder(id) {
  const index = heldOrders.findIndex(ho => ho.id === id);
  if (index === -1) return;
  
  const ho = heldOrders[index];
  
  if (cart.length > 0) {
    if (!confirm('This will replace the current items in your cart. Continue?')) {
      return;
    }
  }
  
  cart = ho.cart;
  currentLoyaltyClient = ho.loyaltyClient;
  document.getElementById('inputDeposit').value = ho.deposit;
  
  if (currentLoyaltyClient) {
    document.getElementById('lblLoyaltyName').innerText = currentLoyaltyClient.name;
    document.getElementById('lblLoyaltyPoints').innerText = currentLoyaltyClient.points;
    document.getElementById('loyaltySummary').style.display = 'block';
  } else {
    document.getElementById('loyaltySummary').style.display = 'none';
  }
  
  heldOrders.splice(index, 1);
  
  updateCartUI();
  updateHeldCount();
  document.getElementById('modalHeldOrders').style.display = 'none';
  showToast('Ticket recalled successfully!', 'success');
}

function deleteHeldOrder(id) {
  const index = heldOrders.findIndex(ho => ho.id === id);
  if (index === -1) return;
  
  if (confirm('Are you sure you want to delete this held ticket?')) {
    heldOrders.splice(index, 1);
    renderHeldOrdersTable();
    updateHeldCount();
    showToast('Held ticket deleted', 'info');
  }
}

window.restoreHeldOrder = restoreHeldOrder;
window.deleteHeldOrder = deleteHeldOrder;

// --- SOPORTE DE LECTOR DE BARRAS USB (SCANNERS DE TECLADO EMULADO) ---
let barcodeBuffer = '';

window.addEventListener('keydown', (e) => {
  // Ignorar si la pantalla de login (splash screen) está activa
  const splash = document.getElementById('splashLoginScreen');
  if (splash && splash.style.display !== 'none') return;

  // Ignorar si el usuario está escribiendo activamente en algún input o textarea de entrada manual
  const activeEl = document.activeElement;
  if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
    // Excepción: Permitimos interceptar si están en el buscador de la tabla de inventario,
    // o si el campo está vacío para evitar colisiones
    if (activeEl.id !== 'inventorySearchInput' && activeEl.id !== 'optionsSearchInput') {
      return;
    }
  }

  const now = Date.now();
  
  // Si pasa más de 200ms entre teclas, consideramos que es escritura manual lenta y reiniciamos
  if (now - lastKeyTime > 200) {
    barcodeBuffer = '';
  }
  lastKeyTime = now;

  if (e.key === 'Enter') {
    if (barcodeBuffer.length > 1) {
      const code = barcodeBuffer.trim();
      const foundProduct = products.find(p => p.barcode && p.barcode.trim() === code);
      if (foundProduct) {
        addToCart(foundProduct);
        showToast(`Added: ${foundProduct.name}`, 'success');
        
        // Limpiar el buscador si estaba enfocado
        if (activeEl && (activeEl.id === 'inventorySearchInput' || activeEl.id === 'optionsSearchInput')) {
          activeEl.value = '';
          activeEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
      } else {
        // Search if scanned barcode matches an active unpaid ticket number (regular or split check)
        fetch(`${SERVER_URL}/api/orders`)
          .then(r => r.ok ? r.json() : [])
          .then(orders => {
            const cleanCode = code.replace(/\D/g, ''); // extract numeric ticket numbers (e.g. from T00124)
            const targetOrderId = code.startsWith('O-') ? code.substring(2) : code;
            const matchingOrder = orders.find(o => 
              o.paymentStatus === 'unpaid' && 
              o.status !== 'void' &&
              o.status !== 'refunded' &&
              (String(o.ticketNumber) === code || String(o.ticketNumber) === cleanCode || o.id === code || o.id === targetOrderId)
            );
            
            if (matchingOrder) {
              recallCashierTab(matchingOrder.id);
              showToast(`Ticket #${matchingOrder.ticketNumber} Recalled / Cuenta Recuperada`, 'success');
            } else {
              // Comprobar si es comanda de delivery (DoorDash, Uber Eats, Grubhub, etc.)
              fetch(`${SERVER_URL}/api/delivery/lookup?code=${encodeURIComponent(code)}`)
                .then(r => r.ok ? r.json() : null)
                .then(d => {
                  if (d && d.found && d.order) {
                    document.getElementById('modalDeliveryHub').style.display = 'flex';
                    const inp = document.getElementById('deliveryScanInput');
                    if (inp) inp.value = code;
                    loadDeliveryHubOrders().then(() => {
                      searchDeliveryByCode();
                    });
                    showToast(`Comanda de Delivery detectada: ${d.order.externalOrderId || code}`, 'success');
                  } else {
                    showToast(`Barcode scanned: ${code}`, 'info');
                  }
                })
                .catch(() => {
                  showToast(`Barcode scanned: ${code}`, 'info');
                });
            }
          })
          .catch(err => {
            console.error(err);
            showToast(`Barcode scanned: ${code}`, 'info');
          });
      }
    }
    barcodeBuffer = '';
  } else if (e.key.length === 1) {
    barcodeBuffer += e.key;
  }
});

// --- DEPARTMENTS & TABS MANAGEMENT SYSTEM ---
let currentDepartments = [];
let editingDeptId = null;

async function loadDepartmentsAndTabs() {
  try {
    const res = await fetch(`${SERVER_URL}/api/departments`);
    if (res.ok) {
      currentDepartments = await res.json();
      renderDynamicTabs(currentDepartments);
      populateCategorySelectors();
      loadSetupDepartmentsTable(currentDepartments);
    }
  } catch (e) {
    console.error("Error loading departments:", e);
  }
}

function renderDynamicTabs(depts) {
  const container = document.getElementById('tabsContainer');
  if (!container) return;

  const isEs = posSettings && posSettings.language === 'es';

  // If current selected category is not in depts or is panaderia by default, select the first valid department
  if (!selectedCategory || !depts.some(d => d.id === selectedCategory)) {
    if (depts.length > 0) {
      selectedCategory = depts[0].id;
    }
  }

  // Render dynamic depts
  let html = '';
  depts.forEach(d => {
    const isActive = selectedCategory === d.id;
    const color = d.color || '#ff9f0a';
    let displayName = d.name;
    if (isEs) {
      if (d.id === 'panaderia') displayName = 'Panadería';
      else if (d.id === 'postres') displayName = 'Postres';
      else if (d.id === 'pasteles_stock') displayName = 'Pasteles Vitrina';
      else if (d.id === 'bebidas') displayName = 'Bebidas';
      else if (d.id === 'tienda') displayName = 'Tienda';
    } else {
      if (d.id === 'panaderia') displayName = 'Bakery';
      else if (d.id === 'postres') displayName = 'Desserts';
      else if (d.id === 'pasteles_stock') displayName = 'Cakes in Stock';
      else if (d.id === 'bebidas') displayName = 'Drinks';
      else if (d.id === 'tienda') displayName = 'Store';
    }
    html += `<button class="tab-btn ${isActive ? 'active' : ''}" data-category="${d.id}" style="border-left: 4px solid ${color}; text-align: left; padding-left: 10px;">${displayName}</button>`;
  });

  // Append special bakery buttons ONLY if business type is bakery or explicitly enabled
  const isBakeryMode = isBakeryBusiness();
  if (isBakeryMode) {
    const isPastelActive = selectedCategory === 'pastel_pedido';
    const isWeddingActive = selectedCategory === 'bodas_quince';
    const pastelLabel = isEs ? 'Pastel Especial' : 'Custom Cake';
    const weddingLabel = isEs ? 'Bodas y Eventos' : 'Wedding & Events';
    html += `<button class="tab-btn ${isPastelActive ? 'active' : ''}" data-category="pastel_pedido" id="tabPastelPedido">${pastelLabel}</button>`;
    html += `<button class="tab-btn ${isWeddingActive ? 'active' : ''}" data-category="bodas_quince" id="tabBodasQuince">${weddingLabel}</button>`;
  }
  
  container.innerHTML = html;

  // Update permanent Support button text
  const btnHelp = document.getElementById('btnRequestSupport');
  if (btnHelp) {
    btnHelp.innerText = isEs ? 'AYUDA / SOPORTE' : 'HELP / SUPPORT';
  }

  // Re-bind listeners only for category tabs
  const tabs = container.querySelectorAll('.tab-btn[data-category]');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const cat = tab.getAttribute('data-category');
      selectedCategory = cat;
      activeSalesSubCategory = '';
      const salesSearch = document.getElementById('salesSearchInput');
      if (salesSearch) salesSearch.value = '';
      if (cat === 'pasteles_stock') {
        activePastelesSubCategory = 'root';
      }

      if (cat === 'pastel_pedido' || cat === 'bodas_quince') {
        openPastelModal(cat === 'bodas_quince');
      } else {
        renderProducts();
      }
    });
  });
}

function loadSetupDepartmentsTable(depts) {
  const tbody = document.getElementById('adminDeptsTableBody');
  if (!tbody) return;

  tbody.innerHTML = '';
  depts.forEach(d => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid var(--border-color)';
    tr.innerHTML = `
      <td style="padding: 6px; font-weight: bold;">${d.name}</td>
      <td style="padding: 6px; text-align: center;">${d.order || 0}</td>
      <td style="padding: 6px; text-align: center;">
        <span style="display: inline-block; width: 14px; height: 14px; border-radius: 3px; background-color: ${d.color || '#ff9f0a'}; vertical-align: middle;"></span>
      </td>
      <td style="padding: 6px; text-align: right;">
        <button class="btn-modal secondary" onclick="editDeptInForm('${d.id}')" style="font-size: 9px; padding: 2px 6px; margin: 0; background-color: var(--accent-color); color: #000; font-weight: bold; border-color: var(--accent-color);">Edit</button>
        <button class="btn-modal secondary danger" onclick="deleteDept('${d.id}')" style="font-size: 9px; padding: 2px 6px; margin: 0 0 0 4px; background-color: var(--danger-color); color: #fff; font-weight: bold; border-color: var(--danger-color);">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function editDeptInForm(id) {
  const d = currentDepartments.find(x => x.id === id);
  if (!d) return;

  editingDeptId = d.id;
  document.getElementById('deptIdInput').value = d.id;
  document.getElementById('deptNameInput').value = d.name;
  document.getElementById('deptOrderInput').value = d.order || '';
  document.getElementById('deptColorInput').value = d.color || '#ff9f0a';

  document.getElementById('btnSaveDept').innerText = 'Update Dept';
  document.getElementById('btnClearDeptForm').style.display = 'block';
}
window.editDeptInForm = editDeptInForm;

async function deleteDept(id) {
  if (!confirm(`Are you sure you want to delete department "${id}"? Products in this category won't be deleted but won't show in tabs.`)) return;

  try {
    const res = await fetch(`${SERVER_URL}/api/departments/${id}`, {
      method: 'DELETE'
    });
    if (res.ok) {
      showToast('Department deleted successfully', 'success');
      loadDepartmentsAndTabs();
    } else {
      showToast('Error deleting department', 'error');
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error', 'error');
  }
}
window.deleteDept = deleteDept;

function setupDepartmentsPanelEvents() {
  const btnSave = document.getElementById('btnSaveDept');
  const btnClear = document.getElementById('btnClearDeptForm');
  if (!btnSave) return;

  btnSave.addEventListener('click', async () => {
    const name = document.getElementById('deptNameInput').value.trim();
    const orderVal = parseInt(document.getElementById('deptOrderInput').value) || 0;
    const color = document.getElementById('deptColorInput').value;

    if (!name) {
      showToast('Department Name is required', 'error');
      return;
    }

    // Generate unique ID slug from Name if creating new
    const id = editingDeptId || name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/(^_|_$)/g, '');

    const payload = { id, name, order: orderVal, color };

    try {
      let res;
      if (editingDeptId) {
        res = await fetch(`${SERVER_URL}/api/departments/${editingDeptId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } else {
        res = await fetch(`${SERVER_URL}/api/departments`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      if (res.ok) {
        showToast(editingDeptId ? 'Department updated' : 'Department created', 'success');
        resetDeptForm();
        loadDepartmentsAndTabs();
      } else {
        showToast('Error saving department', 'error');
      }
    } catch(e) {
      console.error(e);
      showToast('Connection error', 'error');
    }
  });

  btnClear.addEventListener('click', resetDeptForm);
}

function resetDeptForm() {
  editingDeptId = null;
  document.getElementById('deptIdInput').value = '';
  document.getElementById('deptNameInput').value = '';
  document.getElementById('deptOrderInput').value = '';
  document.getElementById('deptColorInput').value = '#ff9f0a';
  document.getElementById('btnSaveDept').innerText = 'Save Dept';
  document.getElementById('btnClearDeptForm').style.display = 'none';
}

// --- VISUAL MENU BUTTON CUSTOMIZER ---
let customizerActiveItems = [];

function initMenuCustomizer() {
  const btnOpen = document.getElementById('btnOpenMenuCustomizer');
  const modal = document.getElementById('modalMenuCustomizer');
  const btnClose = document.getElementById('btnCloseCustomizerModal');
  const btnCancel = document.getElementById('btnCancelCustomizer');
  const btnSave = document.getElementById('btnSaveCustomizer');
  const selector = document.getElementById('custCategorySelector');

  if (!btnOpen) return;

  btnOpen.addEventListener('click', () => {
    modal.style.display = 'flex';
    loadCustomizerCategoryItems();
  });

  const closeModal = () => {
    modal.style.display = 'none';
  };

  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);

  if (selector) {
    selector.addEventListener('change', loadCustomizerCategoryItems);
  }

  if (btnSave) {
    btnSave.addEventListener('click', saveCustomizerChanges);
  }
}

function loadCustomizerCategoryItems() {
  const selector = document.getElementById('custCategorySelector');
  if (!selector) return;
  const cat = selector.value;
  
  let categoryItems = [];
  if (cat === 'panaderia') {
    categoryItems = products.filter(p => p.category === 'panaderia' && p.price < 22.00 && p.price > 0);
  } else if (cat === 'postres') {
    const dessertCats = ['postres', 's cake', 'dessert slice', 'dessert_slice'];
    categoryItems = products.filter(p => dessertCats.includes(p.category) && p.price < 22.00 && p.price > 0);
  } else if (cat === 'pasteles_stock') {
    const cakeCategories = ['pan regs', 's cake', '3lech st', 'pasteles', 'panaderia', 'postres', 'dessert slice', 'dessert_slice'];
    const allCakes = products.filter(p => cakeCategories.includes(p.category) && p.price >= 22.00 && p.price > 0);
    categoryItems = allCakes.filter(p => !getCakeSize(p.name));
  } else {
    categoryItems = products.filter(p => p.category === cat && p.price > 0);
  }

  // Deep clone so changes are temporary until saved
  customizerActiveItems = categoryItems.map(p => ({
    id: p.id,
    name: p.name,
    color: p.color || '',
    fontSize: p.fontSize || '13',
    order: p.order !== undefined && p.order !== null ? Number(p.order) : 9999
  }));

  // Sort them initially
  sortProducts(customizerActiveItems);
  
  // Re-index to ensure sequential orders
  customizerActiveItems.forEach((item, index) => {
    item.order = index;
  });

  renderCustomizerList();
}

function renderCustomizerList() {
  const container = document.getElementById('customizerItemsList');
  if (!container) return;
  container.innerHTML = '';

  if (customizerActiveItems.length === 0) {
    container.innerHTML = `<div style="text-align: center; color: var(--text-secondary); padding: 20px;">No items in this category</div>`;
    return;
  }

  customizerActiveItems.forEach((item, index) => {
    const row = document.createElement('div');
    row.style.cssText = 'display: flex; gap: 8px; align-items: center; background: rgba(255,255,255,0.02); padding: 8px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);';

    // 1. Move buttons
    const moveCol = document.createElement('div');
    moveCol.style.cssText = 'display: flex; flex-direction: column; gap: 2px;';
    
    const btnUp = document.createElement('button');
    btnUp.innerText = '▲';
    btnUp.style.cssText = 'padding: 0 4px; font-size: 9px; cursor: pointer; background: var(--bg-primary); color: #fff; border: 1px solid var(--border-color); border-radius: 3px; height: 16px; width: 22px;';
    btnUp.disabled = index === 0;
    btnUp.addEventListener('click', () => {
      // Swap with previous
      const temp = customizerActiveItems[index - 1];
      customizerActiveItems[index - 1] = item;
      customizerActiveItems[index] = temp;
      
      // Update orders
      customizerActiveItems.forEach((x, idx) => x.order = idx);
      renderCustomizerList();
    });

    const btnDown = document.createElement('button');
    btnDown.innerText = '▼';
    btnDown.style.cssText = 'padding: 0 4px; font-size: 9px; cursor: pointer; background: var(--bg-primary); color: #fff; border: 1px solid var(--border-color); border-radius: 3px; height: 16px; width: 22px;';
    btnDown.disabled = index === customizerActiveItems.length - 1;
    btnDown.addEventListener('click', () => {
      // Swap with next
      const temp = customizerActiveItems[index + 1];
      customizerActiveItems[index + 1] = item;
      customizerActiveItems[index] = temp;
      
      // Update orders
      customizerActiveItems.forEach((x, idx) => x.order = idx);
      renderCustomizerList();
    });

    moveCol.appendChild(btnUp);
    moveCol.appendChild(btnDown);
    row.appendChild(moveCol);

    // 2. Name input
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.value = item.name;
    nameInput.className = 'form-input-text';
    nameInput.style.cssText = 'flex: 1.5; padding: 4px 6px; font-size: 11px; height: 26px; min-width: 100px;';
    nameInput.addEventListener('input', (e) => {
      item.name = e.target.value.trim();
    });
    row.appendChild(nameInput);

    // 3. Color Picker
    const colorCol = document.createElement('div');
    colorCol.style.cssText = 'display: flex; align-items: center; gap: 4px;';
    
    const colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.value = item.color || '#ff9f0a';
    colorInput.style.cssText = 'width: 24px; height: 24px; border: none; cursor: pointer; padding: 0; background: transparent;';
    
    const btnResetColor = document.createElement('button');
    btnResetColor.innerText = '✕';
    btnResetColor.style.cssText = 'padding: 0; font-size: 10px; cursor: pointer; background: none; border: none; color: var(--danger-color); width: 14px;';
    btnResetColor.title = 'Clear Color / Restablecer Color';
    
    if (!item.color) {
      colorInput.style.opacity = '0.3';
    }

    colorInput.addEventListener('input', (e) => {
      item.color = e.target.value;
      colorInput.style.opacity = '1';
    });

    btnResetColor.addEventListener('click', () => {
      item.color = '';
      colorInput.value = '#ff9f0a';
      colorInput.style.opacity = '0.3';
    });

    colorCol.appendChild(colorInput);
    colorCol.appendChild(btnResetColor);
    row.appendChild(colorCol);

    // 4. Font Size selector
    const sizeSelect = document.createElement('select');
    sizeSelect.className = 'form-input-text';
    sizeSelect.style.cssText = 'width: 65px; padding: 2px; font-size: 11px; height: 26px; background: var(--bg-primary); color: #fff; border: 1px solid var(--border-color);';
    
    const sizes = ['10', '11', '12', '13', '14', '16'];
    sizes.forEach(sz => {
      const opt = document.createElement('option');
      opt.value = sz;
      opt.innerText = sz + 'px';
      if (String(item.fontSize) === sz) opt.selected = true;
      sizeSelect.appendChild(opt);
    });

    sizeSelect.addEventListener('change', (e) => {
      item.fontSize = e.target.value;
    });
    row.appendChild(sizeSelect);

    container.appendChild(row);
  });
}

async function saveCustomizerChanges() {
  const btnSave = document.getElementById('btnSaveCustomizer');
  if (btnSave) {
    btnSave.innerText = 'Saving...';
    btnSave.disabled = true;
  }

  try {
    const response = await fetch(`${SERVER_URL}/api/admin/products/customize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(customizerActiveItems)
    });

    if (response.ok) {
      showToast('Menu layout and buttons saved successfully!', 'success');
      document.getElementById('modalMenuCustomizer').style.display = 'none';
      
      // Reload products locally and re-render main cash register screen
      await loadProducts(); 
      renderProducts();
    } else {
      showToast('Error saving menu customization', 'error');
    }
  } catch(e) {
    console.error(e);
    showToast('Connection error while saving customizer', 'error');
  } finally {
    if (btnSave) {
      btnSave.innerText = 'Save Changes';
      btnSave.disabled = false;
    }
  }
}

function toggleInventoryView() {
  const productsContainer = document.getElementById('inventoryProductsListContainer');
  const modifiersContainer = document.getElementById('inventoryModifiersManagerContainer');
  const addProductBtn = document.getElementById('btnOpenAddProductForm');
  const productForm = document.getElementById('productFormContainer');
  const btnToggle = document.getElementById('btnToggleInventoryView');
  const titleSpan = document.getElementById('lblInventoryPaneTitle');
  
  if (!productsContainer || !modifiersContainer || !btnToggle) return;
  
  if (productsContainer.style.display === 'none') {
    // Switch to Products view
    productsContainer.style.display = 'block';
    modifiersContainer.style.display = 'none';
    if (addProductBtn) addProductBtn.style.display = 'inline-block';
    
    btnToggle.innerText = '📋 Modifiers';
    btnToggle.style.backgroundColor = '#5856d6';
    if (titleSpan) titleSpan.innerText = '📦 Product Inventory';
  } else {
    // Switch to Modifiers view
    productsContainer.style.display = 'none';
    modifiersContainer.style.display = 'flex';
    if (productForm) productForm.style.display = 'none';
    if (addProductBtn) addProductBtn.style.display = 'none';
    
    btnToggle.innerText = '📦 View Products';
    btnToggle.style.backgroundColor = '#233545';
    if (titleSpan) titleSpan.innerText = '📋 Modifiers Manager';
    
    renderSetupModifiersList();
  }
}

// --- WAITRESS TABS AND SEAT SELECTION ---
let activeOpenTabField = 'openTabTable';

function buildSeatSelectors() {
  const tabHeader = document.getElementById('cartTabHeader');
  const seatsContainer = document.getElementById('tabSeatsContainer');
  const lblTable = document.getElementById('lblTabTable');
  const lblActiveClient = document.getElementById('lblTabActiveClient');
  
  if (!tabHeader || !seatsContainer) return;
  
  if (tabTableNumber && tabClientCount > 0) {
    if (lblTable) lblTable.innerText = tabTableNumber;
    if (lblActiveClient) lblActiveClient.innerText = `Cliente ${activeTabClientSeat}`;
    
    seatsContainer.innerHTML = '';
    for (let i = 1; i <= tabClientCount; i++) {
      const btn = document.createElement('button');
      btn.className = `btn-seat${i === activeTabClientSeat ? ' active' : ''}`;
      btn.innerText = `C${i}`;
      btn.style.cssText = `
        padding: 4px 10px;
        font-size: 12px;
        font-weight: bold;
        border: 1px solid var(--border-color);
        border-radius: 4px;
        background: ${i === activeTabClientSeat ? 'var(--accent-color)' : 'var(--bg-secondary)'};
        color: ${i === activeTabClientSeat ? '#000' : '#fff'};
        cursor: pointer;
        white-space: nowrap;
        flex-shrink: 0;
      `;
      btn.onclick = (e) => {
        e.preventDefault();
        activeTabClientSeat = i;
        buildSeatSelectors();
        updateCartUI();
      };
      seatsContainer.appendChild(btn);
    }
    
    tabHeader.style.display = 'flex';
  } else {
    tabHeader.style.display = 'none';
  }
}
window.buildSeatSelectors = buildSeatSelectors;

let allActiveTabsList = [];

function safeEscapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function renderActiveTabs(tabsToRender) {
  const tableBody = document.getElementById('employeeTabsTableBody');
  if (!tableBody) return;
  
  if (!tabsToRender || tabsToRender.length === 0) {
    tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 25px; color: var(--text-secondary); font-style: italic;">No hay cuentas abiertas / No open tabs found</td></tr>';
    return;
  }
  
  tableBody.innerHTML = '';
  tabsToRender.forEach(tab => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
    
    const clientDesc = (tab.clientName && tab.clientName !== 'undefined') ? tab.clientName : (tab.tableName || tab.car || tab.vehicle || tab.carDescription || 'Sin nombre');
    const itemsText = Array.isArray(tab.items) 
      ? tab.items.map(i => `${i.quantity || 1}x ${i.name}`).join(', ') 
      : '';
    const itemsDisplay = itemsText.length > 40 ? itemsText.substring(0, 40) + '...' : itemsText;
    const ticketNum = (tab.ticketNumber && tab.ticketNumber !== 'undefined') ? tab.ticketNumber : (tab.id ? tab.id.substring(2, 8).toUpperCase() : '-');
    
    tr.innerHTML = `
      <td style="padding: 10px 8px; font-weight: 800; color: var(--accent-color); white-space: nowrap;">#${ticketNum}</td>
      <td style="padding: 10px 8px; font-weight: bold; color: #fff;">${safeEscapeHtml(clientDesc)}</td>
      <td style="padding: 10px 8px; color: var(--text-secondary); font-size: 11px;" title="${safeEscapeHtml(itemsText)}">${safeEscapeHtml(itemsDisplay || 'N/A')}</td>
      <td style="padding: 10px 8px; font-weight: 800; color: var(--success-color); white-space: nowrap;">$${Number(tab.total || 0).toFixed(2)}</td>
      <td style="padding: 10px 8px; text-align: right; white-space: nowrap;">
        <button class="btn-modal primary" onclick="recallCashierTab('${tab.id}')" style="margin-top: 0; font-size: 11px; font-weight: bold; padding: 6px 14px; background-color: var(--accent-color); color: #000; border: none; border-radius: 6px; cursor: pointer;">RECALL</button>
        <button class="btn-modal danger" onclick="voidActiveTabOrder('${tab.id}')" style="margin-top: 0; font-size: 11px; font-weight: bold; padding: 6px 10px; background-color: var(--danger-color); color: #fff; border: none; border-radius: 6px; cursor: pointer; margin-left: 6px;" title="Anular / Cancel Tab">✕</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}
window.renderActiveTabs = renderActiveTabs;

window.voidActiveTabOrder = async function(id) {
  const isEs = posSettings && posSettings.language === 'es';
  if (!confirm(isEs ? '¿Seguro que deseas anular esta cuenta / orden?' : 'Are you sure you want to void/cancel this order?')) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'void' })
    });
    if (res.ok) {
      showToast(isEs ? 'Cuenta anulada exitosamente' : 'Order voided successfully', 'info');
      await updateActiveTabsCount();
      renderActiveTabs(allActiveTabsList);
      if (typeof updateToGoBadgeAndModal === 'function') updateToGoBadgeAndModal();
      if (typeof updateCarOrdersBadge === 'function') updateCarOrdersBadge();
      if (typeof updatePhoneOrdersBadge === 'function') updatePhoneOrdersBadge();
      if (typeof updateOnlineOrdersBadge === 'function') updateOnlineOrdersBadge();
    } else {
      showToast(isEs ? 'Error al anular orden' : 'Error voiding order', 'error');
    }
  } catch (e) {
    showToast('Network error voiding order', 'error');
  }
};

function filterOpenTabsList(query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) {
    renderActiveTabs(allActiveTabsList);
    return;
  }
  const filtered = allActiveTabsList.filter(tab => {
    const tNum = String(tab.ticketNumber || '');
    const cName = String(tab.clientName || '').toLowerCase();
    const tName = String(tab.tableName || '').toLowerCase();
    const car = String(tab.car || tab.vehicle || tab.carDescription || '').toLowerCase();
    const items = Array.isArray(tab.items) ? tab.items.map(i => i.name).join(' ').toLowerCase() : '';
    return tNum.includes(q) || cName.includes(q) || tName.includes(q) || car.includes(q) || items.includes(q);
  });
  renderActiveTabs(filtered);
}
window.filterOpenTabsList = filterOpenTabsList;

async function updateActiveTabsCount() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders`);
    if (res.ok) {
      const orders = await res.json();
      allActiveTabsList = orders.filter(o => 
        o.paymentStatus === 'unpaid' && 
        o.status !== 'void' &&
        o.status !== 'refunded'
      );
      allActiveTabsList.sort((a, b) => (b.ticketNumber || 0) - (a.ticketNumber || 0));
      const countSpan = document.getElementById('lblOpenTabsCount');
      if (countSpan) {
        countSpan.innerText = allActiveTabsList.length;
      }
    }
  } catch (err) {
    console.warn('Error fetching active tabs count:', err);
  }
}
window.updateActiveTabsCount = updateActiveTabsCount;

function openActiveTabsModal() {
  const modal = document.getElementById('modalRecallTabs');
  if (!modal) return;
  modal.style.display = 'flex';
  const searchInp = document.getElementById('inputSearchOpenTabs');
  if (searchInp) {
    searchInp.value = '';
    setTimeout(() => searchInp.focus(), 150);
  }
  loadEmployeeTabs();
}
window.openActiveTabsModal = openActiveTabsModal;

async function loadEmployeeTabs() {
  const tableBody = document.getElementById('employeeTabsTableBody');
  if (tableBody) {
    tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--text-secondary);">Cargando... / Loading...</td></tr>';
  }
  
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      const orders = await response.json();
      allActiveTabsList = orders.filter(o => 
        o.paymentStatus === 'unpaid' && 
        o.status !== 'void' &&
        o.status !== 'refunded'
      );
      allActiveTabsList.sort((a, b) => (b.ticketNumber || 0) - (a.ticketNumber || 0));
      
      const countSpan = document.getElementById('lblOpenTabsCount');
      if (countSpan) countSpan.innerText = allActiveTabsList.length;

      const searchInp = document.getElementById('inputSearchOpenTabs');
      if (searchInp && searchInp.value.trim()) {
        filterOpenTabsList(searchInp.value.trim());
      } else {
        renderActiveTabs(allActiveTabsList);
      }
    } else {
      if (tableBody) tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--danger-color);">Error en el servidor</td></tr>';
    }
  } catch (err) {
    console.error(err);
    if (tableBody) tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px; color: var(--danger-color);">Error de conexión</td></tr>';
  }
}
window.loadEmployeeTabs = loadEmployeeTabs;

async function recallCashierTab(orderId) {
  try {
    const response = await fetch(`${SERVER_URL}/api/orders`);
    if (response.ok) {
      const orders = await response.json();
      const tab = orders.find(o => o.id === orderId);
      if (!tab) {
        showToast('Cuenta no encontrada / Order not found', 'error');
        return;
      }
      
      cart = JSON.parse(JSON.stringify(tab.items || []));
      activeTabOrderId = tab.id;
      tabTableNumber = tab.tableName || '';
      currentOrderCustomerName = tab.clientName || tab.tableName || '';
      window.currentOrderCustomerName = currentOrderCustomerName;
      currentCarDescription = tab.car || tab.vehicle || tab.carDescription || '';
      window.currentCarDescription = currentCarDescription;
      tabClientCount = tab.guestCount || 1;
      activeTabClientSeat = 1;
      deliveryType = tab.type || tab.deliveryType || 'comer';
      
      if (tab.clientLoyalty) {
        fetch(`${SERVER_URL}/api/loyalty/${tab.clientLoyalty}`)
          .then(r => r.ok ? r.json() : null)
          .then(client => {
            if (client) {
              currentLoyaltyClient = client;
              setLoyaltyClientUI();
            }
          }).catch(e => console.warn(e));
      } else {
        currentLoyaltyClient = null;
        const loyaltySummary = document.getElementById('loyaltySummary');
        if (loyaltySummary) loyaltySummary.style.display = 'none';
      }
      
      selectPreOrderType(deliveryType);
      buildSeatSelectors();
      updateCartUI();
      updateVehicleBannerUI();
      
      document.getElementById('modalRecallTabs').style.display = 'none';
      const displayName = tab.clientName || tab.tableName || `#${tab.ticketNumber}`;
      showToast(posSettings && posSettings.language === 'es' ? `Cuenta de '${displayName}' cargada` : `Loaded tab '${displayName}'`, 'success');
    }
  } catch(e) {
    console.error(e);
    showToast('Error cargando cuenta', 'error');
  }
}
window.recallCashierTab = recallCashierTab;

// --- DIAGRAMA DE MESAS (TABLE DIAGRAM) SETUP EDITOR & VIEWER ---
let configuredTables = [];
let selectedSetupTableId = null;

// Initialize Table Diagram Setup Editor
async function initTableDiagramEditor() {
  try {
    const res = await fetch(`${SERVER_URL}/api/tables`);
    if (res.ok) {
      configuredTables = await res.json();
    } else {
      configuredTables = [];
    }
  } catch (err) {
    console.error("Error fetching tables:", err);
    configuredTables = [];
  }
  selectedSetupTableId = null;
  const deleteBtn = document.getElementById('btnSetupDeleteTable');
  if (deleteBtn) deleteBtn.style.display = 'none';
  
  const showTableMapChk = document.getElementById('layoutShowTableMap');
  if (showTableMapChk) {
    showTableMapChk.checked = posSettings.showTableMap !== false;
  }

  initSetupAlphanumericKeyboard();
  renderSetupCanvas();
}
window.initTableDiagramEditor = initTableDiagramEditor;

// Initialize touch alphanumeric keyboard inside setup editor
function initSetupAlphanumericKeyboard() {
  const keyboardContainer = document.getElementById('setupTableNumKeyboard');
  if (!keyboardContainer) return;
  keyboardContainer.innerHTML = '';
  
  const keys = [
    '1', '2', '3', '4', '5', '6',
    '7', '8', '9', '0', 'A', 'B',
    'C', 'D', 'E', 'F', 'G', 'H',
    'I', 'J', 'K', 'L', 'M', 'N',
    'O', 'P', 'Q', 'R', 'S', 'T',
    'U', 'V', 'W', 'X', 'Y', 'Z',
    'Space', '⌫', 'C'
  ];
  
  keys.forEach(key => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.innerText = key;
    btn.style.cssText = `
      padding: 6px 4px;
      font-size: 11px;
      font-weight: bold;
      border-radius: 4px;
      border: 1px solid var(--border-color);
      background: var(--bg-secondary);
      color: #fff;
      cursor: pointer;
      text-align: center;
    `;
    
    if (key === 'Space') {
      btn.style.gridColumn = 'span 2';
    } else if (key === '⌫') {
      btn.style.gridColumn = 'span 2';
    } else if (key === 'C') {
      btn.style.gridColumn = 'span 2';
      btn.style.color = 'var(--danger-color)';
    }
    
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const input = document.getElementById('setupTableNum');
      if (!input) return;
      
      if (key === '⌫') {
        input.value = input.value.slice(0, -1);
      } else if (key === 'C') {
        input.value = '';
      } else if (key === 'Space') {
        input.value += ' ';
      } else {
        input.value += key;
      }
      input.dispatchEvent(new Event('input'));
    });
    
    keyboardContainer.appendChild(btn);
  });
}

// Render Setup Editor Canvas
function renderSetupCanvas() {
  const canvas = document.getElementById('tableLayoutSetupCanvas');
  if (!canvas) return;
  canvas.innerHTML = '';
  
  configuredTables.forEach(t => {
    const el = document.createElement('div');
    el.className = 'canvas-table';
    el.style.position = 'absolute';
    el.style.left = t.x + '%';
    el.style.top = t.y + '%';
    el.style.cursor = 'move';
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.alignItems = 'center';
    el.style.justifyContent = 'center';
    el.style.border = selectedSetupTableId === t.id ? '3px solid var(--accent-color)' : '2px solid #555';
    el.style.backgroundColor = selectedSetupTableId === t.id ? '#2c2c35' : '#1c1c24';
    el.style.boxShadow = '0 4px 10px rgba(0,0,0,0.4)';
    el.style.userSelect = 'none';
    el.style.color = '#fff';
    el.style.zIndex = '10';

    // Apply dynamic dimensions based on shape
    let width = '70px';
    let height = '70px';
    let borderRadius = '8px';
    
    if (t.shape === 'circle') {
      borderRadius = '50%';
    } else if (t.shape === 'rectangle') {
      width = '110px';
      height = '60px';
    } else if (t.shape === 'half-moon') {
      width = '100px';
      height = '50px';
      borderRadius = '100px 100px 0 0';
    } else if (t.shape === 'long-bar') {
      width = '160px';
      height = '40px';
      borderRadius = '6px';
    } else if (t.shape === 'stool') {
      width = '40px';
      height = '40px';
      borderRadius = '50%';
      el.style.borderColor = '#ff9f0a';
      if (selectedSetupTableId === t.id) {
        el.style.border = '3px solid var(--accent-color)';
      } else {
        el.style.border = '2px dashed #ff9f0a';
      }
    }
    
    el.style.width = width;
    el.style.height = height;
    el.style.borderRadius = borderRadius;

    if (t.shape === 'stool') {
      el.innerHTML = `<div style="font-weight:bold; font-size:10px; color:#ff9f0a;">B${t.number}</div>`;
    } else {
      el.innerHTML = `
        <div style="font-weight:bold; font-size:10px;">${t.number}</div>
        <div style="font-size:8px; color:var(--text-secondary);">${t.capacity} Pax</div>
      `;
    }

    // Click to select
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      selectedSetupTableId = t.id;
      const deleteBtn = document.getElementById('btnSetupDeleteTable');
      if (deleteBtn) deleteBtn.style.display = 'block';
      renderSetupCanvas();
    });

    // Drag-and-drop logic
    let isDragging = false;
    let startX = 0, startY = 0;
    let startLeft = 0, startTop = 0;

    el.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = el.getBoundingClientRect();
      const parentRect = canvas.getBoundingClientRect();
      startLeft = rect.left - parentRect.left;
      startTop = rect.top - parentRect.top;

      const onMouseMove = (ev) => {
        if (!isDragging) return;
        const deltaX = ev.clientX - startX;
        const deltaY = ev.clientY - startY;
        let newLeft = startLeft + deltaX;
        let newTop = startTop + deltaY;

        // Keep within bounds
        const elementWidth = el.offsetWidth || parseFloat(width);
        const elementHeight = el.offsetHeight || parseFloat(height);
        newLeft = Math.max(0, Math.min(newLeft, parentRect.width - elementWidth));
        newTop = Math.max(0, Math.min(newTop, parentRect.height - elementHeight));

        el.style.left = newLeft + 'px';
        el.style.top = newTop + 'px';
      };

      const onMouseUp = (ev) => {
        if (!isDragging) return;
        isDragging = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);

        // Save position as percentages for responsiveness
        const parentRect = canvas.getBoundingClientRect();
        const finalLeft = parseFloat(el.style.left);
        const finalTop = parseFloat(el.style.top);
        t.x = ((finalLeft / parentRect.width) * 100).toFixed(2);
        t.y = ((finalTop / parentRect.height) * 100).toFixed(2);
      };

      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });

    canvas.appendChild(el);
  });
}

// Add Table in Setup Editor
function setupAddTable() {
  const numInput = document.getElementById('setupTableNum');
  const capInput = document.getElementById('setupTableCapacity');
  const shapeInput = document.getElementById('setupTableShape');
  
  if (!numInput || !capInput || !shapeInput) return;

  const number = numInput.value.trim();
  const capacity = parseInt(capInput.value) || 2;
  const shape = shapeInput.value || 'square';

  if (!number) {
    showToast('Ingresa número de mesa', 'error');
    return;
  }

  // Check duplicate table numbers
  const exists = configuredTables.some(t => t.number === number);
  if (exists) {
    showToast('El número de mesa ya existe', 'error');
    return;
  }

  const newTable = {
    id: 'table_' + Date.now() + '_' + Math.floor(Math.random()*1000),
    number: number,
    capacity: capacity,
    shape: shape,
    x: 40,
    y: 40
  };

  configuredTables.push(newTable);
  numInput.value = '';
  capInput.value = '';
  selectedSetupTableId = newTable.id;
  const deleteBtn = document.getElementById('btnSetupDeleteTable');
  if (deleteBtn) deleteBtn.style.display = 'block';
  renderSetupCanvas();
  showToast(`Mesa ${number} añadida`, 'success');
}

// Delete Table in Setup Editor
function setupDeleteTable() {
  if (!selectedSetupTableId) return;
  configuredTables = configuredTables.filter(t => t.id !== selectedSetupTableId);
  selectedSetupTableId = null;
  const deleteBtn = document.getElementById('btnSetupDeleteTable');
  if (deleteBtn) deleteBtn.style.display = 'none';
  renderSetupCanvas();
  showToast('Mesa eliminada', 'success');
}

// Save Table Layout to Backend
async function saveTableLayout() {
  try {
    const res = await fetch(`${SERVER_URL}/api/tables`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(configuredTables)
    });

    // Sync showTableMap settings
    const showTableMapChk = document.getElementById('layoutShowTableMap');
    if (showTableMapChk) {
      const showTableMap = showTableMapChk.checked;
      const updatedSettings = {
        ...posSettings,
        showTableMap
      };
      
      await fetch(`${SERVER_URL}/api/admin/settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedSettings)
      });
      
      await loadSettingsFromServer();
    }

    if (res.ok) {
      showToast('Diagrama de mesas guardado con éxito', 'success');
    } else {
      showToast('Error al guardar el diagrama', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Error al guardar el diagrama', 'error');
  }
}

// Waitress Floor Plan Viewer
async function initTableMapWaitress() {
  try {
    // 1. Fetch tables configured
    const resTables = await fetch(`${SERVER_URL}/api/tables`);
    let tablesList = [];
    if (resTables.ok) {
      tablesList = await resTables.json();
    }
    
    // 2. Fetch active unpaid orders to see occupancy
    const resOrders = await fetch(`${SERVER_URL}/api/orders`);
    let activeOrders = [];
    if (resOrders.ok) {
      const allOrders = await resOrders.json();
      activeOrders = allOrders.filter(o => o.paymentStatus === 'unpaid');
    }

    const canvas = document.getElementById('tableMapWaitressCanvas');
    if (!canvas) return;
    canvas.innerHTML = '';

    if (tablesList.length === 0) {
      canvas.innerHTML = `<div style="text-align: center; color: var(--text-secondary); margin-top: 150px; font-size: 16px;">No hay mesas configuradas. Configúralas en Manager -> Table Layout Diagram.</div>`;
      return;
    }

    tablesList.forEach(t => {
      const el = document.createElement('div');
      el.style.position = 'absolute';
      el.style.left = t.x + '%';
      el.style.top = t.y + '%';
      el.style.cursor = 'pointer';
      el.style.display = 'flex';
      el.style.flexDirection = 'column';
      el.style.alignItems = 'center';
      el.style.justifyContent = 'center';
      el.style.boxShadow = '0 6px 12px rgba(0,0,0,0.5)';
      el.style.userSelect = 'none';
      el.style.color = '#fff';
      el.style.zIndex = '10';

      // Dynamic dimension styles based on shape
      let width = '75px';
      let height = '75px';
      let borderRadius = '10px';
      
      if (t.shape === 'circle') {
        borderRadius = '50%';
      } else if (t.shape === 'rectangle') {
        width = '115px';
        height = '65px';
      } else if (t.shape === 'half-moon') {
        width = '105px';
        height = '55px';
        borderRadius = '105px 105px 0 0';
      } else if (t.shape === 'long-bar') {
        width = '165px';
        height = '45px';
        borderRadius = '6px';
      } else if (t.shape === 'stool') {
        width = '42px';
        height = '42px';
        borderRadius = '50%';
      }
      
      el.style.width = width;
      el.style.height = height;
      el.style.borderRadius = borderRadius;

      // Check if table is occupied (including split sub-tickets)
      const occupiedOrders = activeOrders.filter(o => o.tableName === t.number || String(o.tableName).startsWith(t.number + ' ('));
      const isOccupied = occupiedOrders.length > 0;
      
      if (isOccupied) {
        el.style.border = '2.5px solid var(--accent-color)';
        el.style.backgroundColor = 'rgba(10, 132, 255, 0.25)'; // beautiful occupied color
        
        if (t.shape === 'stool') {
          el.innerHTML = `<div style="font-weight:bold; font-size:10px; color:var(--accent-color);">B${t.number}</div>`;
        } else {
          el.innerHTML = `
            <div style="font-weight:bold; font-size:10px; color:var(--accent-color);">Mesa ${t.number}</div>
            <div style="font-size:8px; color:#fff;">Ocupada</div>
          `;
        }
      } else {
        el.style.border = '2px solid #555';
        el.style.backgroundColor = '#1c1c24';
        
        if (t.shape === 'stool') {
          el.style.borderColor = '#ff9f0a';
          el.style.borderStyle = 'dashed';
          el.innerHTML = `<div style="font-weight:bold; font-size:10px; color:#ff9f0a;">B${t.number}</div>`;
        } else {
          el.innerHTML = `
            <div style="font-weight:bold; font-size:10px;">Mesa ${t.number}</div>
            <div style="font-size:8px; color:var(--text-secondary);">${t.capacity} Pax</div>
          `;
        }
      }

      el.addEventListener('click', () => {
        openTableSeatsSelector(t, occupiedOrders);
      });

      canvas.appendChild(el);
    });

    document.getElementById('modalTableMap').style.display = 'flex';
  } catch (err) {
    console.error("Error initializing Table Map for waitress:", err);
    showToast("Error al cargar el mapa de mesas", "error");
  }
}
window.initTableMapWaitress = initTableMapWaitress;

let currentMapSelectedTable = null;
let currentMapSelectedOrders = []; // store all matching orders
let currentMapSelectedOrder = null;  // primary selected order for actions

function openTableSeatsSelector(table, orders) {
  currentMapSelectedTable = table;
  currentMapSelectedOrders = orders || [];
  currentMapSelectedOrder = orders && orders.length > 0 ? orders[0] : null;

  const title = document.getElementById('tableSeatsModalTitle');
  if (title) title.innerText = `Mesa ${table.number} - Selecciona Asiento`;

  // Render list of active bills/splits if any
  const billsContainer = document.getElementById('tableActiveBillsContainer');
  const billsList = document.getElementById('tableActiveBillsList');
  const checkActions = document.getElementById('tableSeatsCheckActions');
  
  if (billsContainer && billsList) {
    if (orders && orders.length > 0) {
      billsList.innerHTML = '';
      orders.forEach(o => {
        const row = document.createElement('div');
        row.style.cssText = `
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: rgba(255,255,255,0.03);
          border: 1px solid var(--border-color);
          padding: 6px 10px;
          border-radius: 6px;
        `;
        
        row.innerHTML = `
          <div style="font-size: 11px;">
            <span style="font-weight: bold; color: var(--accent-color);">${o.tableName || table.number}</span>
            <span style="color: var(--text-secondary); margin-left: 8px;">$${o.total.toFixed(2)}</span>
          </div>
          <button type="button" class="btn-modal primary" style="margin-top:0; font-size:10px; padding:3px 6px;" onclick="recallSplitTabFromMap('${o.id}')">Recall</button>
        `;
        billsList.appendChild(row);
      });
      billsContainer.style.display = 'block';
      if (checkActions) checkActions.style.display = 'flex';
    } else {
      billsContainer.style.display = 'none';
      if (checkActions) checkActions.style.display = 'none';
    }
  }

  const container = document.getElementById('tableSeatsButtonContainer');
  if (container) {
    container.innerHTML = '';
    const cap = parseInt(table.capacity) || 4;

    for (let seatNum = 1; seatNum <= cap; seatNum++) {
      const btn = document.createElement('button');
      btn.className = 'btn-option';
      btn.style.height = '42px';
      btn.style.fontSize = '14px';
      btn.style.fontWeight = 'bold';
      btn.innerText = `Asiento ${seatNum}`;

      // Highlight seats already in any active orders
      const hasSeatItems = orders && orders.some(o => o.items && o.items.some(i => i.name.includes(`(Cliente ${seatNum})`)));
      if (hasSeatItems) {
        btn.style.borderColor = 'var(--success-color)';
        btn.style.backgroundColor = 'rgba(48, 209, 88, 0.15)';
      }

      btn.addEventListener('click', () => {
        selectTableSeatDirectly(table, seatNum, orders);
      });
      container.appendChild(btn);
    }
  }

  document.getElementById('modalTableSeats').style.display = 'flex';
}

// Global helper to recall a split tab from the map list
window.recallSplitTabFromMap = function(orderId) {
  document.getElementById('modalTableSeats').style.display = 'none';
  document.getElementById('modalTableMap').style.display = 'none';
  recallCashierTab(orderId);
};

// Select specific seat directly
async function selectTableSeatDirectly(table, seatNum, orders) {
  // Hide map and seats modal
  document.getElementById('modalTableSeats').style.display = 'none';
  document.getElementById('modalTableMap').style.display = 'none';

  if (orders && orders.length > 0) {
    // If table is occupied, try to find the specific split/tab order containing this seat
    let targetOrder = orders.find(o => o.items && o.items.some(i => i.name.includes(`(Cliente ${seatNum})`)));
    if (!targetOrder) {
      targetOrder = orders[0]; // fallback to first
    }
    
    await recallCashierTab(targetOrder.id);
    activeTabClientSeat = seatNum;
    buildSeatSelectors();
    updateCartUI();
    showToast(`Mesa ${table.number} - Cliente ${seatNum} seleccionado`, 'success');
  } else {
    // If free, open a new tab session directly and register it on the server
    const orderData = {
      items: [],
      type: 'comer',
      total: 0,
      deposit: 0,
      balance: 0,
      status: 'pendiente',
      paymentStatus: 'unpaid',
      tableName: table.number,
      guestCount: table.capacity,
      cashierName: currentCashierName || 'Cashier'
    };

    try {
      const response = await fetch(`${SERVER_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      
      if (response.ok) {
        const newTab = await response.json();
        
        cart = [];
        activeTabOrderId = newTab.id;
        tabTableNumber = table.number;
        tabClientCount = table.capacity;
        activeTabClientSeat = seatNum;
        deliveryType = 'comer'; // Dine-In

        // Select Dine-In button in sidebar
        selectPreOrderType('comer');
        buildSeatSelectors();
        updateCartUI();
        showToast(`Nueva cuenta: Mesa ${table.number} - Cliente ${seatNum}`, 'success');
      } else {
        showToast('Error opening table tab', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Error opening table tab', 'error');
    }
  }
}

// Open table tab directly (all seats / mesa completa)
async function openTableTabDirectly() {
  if (!currentMapSelectedTable) return;
  document.getElementById('modalTableSeats').style.display = 'none';
  document.getElementById('modalTableMap').style.display = 'none';

  if (currentMapSelectedOrder) {
    await recallCashierTab(currentMapSelectedOrder.id);
  } else {
    const orderData = {
      items: [],
      type: 'comer',
      total: 0,
      deposit: 0,
      balance: 0,
      status: 'pendiente',
      paymentStatus: 'unpaid',
      tableName: currentMapSelectedTable.number,
      guestCount: currentMapSelectedTable.capacity,
      cashierName: currentCashierName || 'Cashier'
    };

    try {
      const response = await fetch(`${SERVER_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      
      if (response.ok) {
        const newTab = await response.json();
        
        cart = [];
        activeTabOrderId = newTab.id;
        tabTableNumber = currentMapSelectedTable.number;
        tabClientCount = currentMapSelectedTable.capacity;
        activeTabClientSeat = 1;
        deliveryType = 'comer';
        
        selectPreOrderType('comer');
        buildSeatSelectors();
        updateCartUI();
        showToast(`Nueva cuenta: Mesa ${currentMapSelectedTable.number}`, 'success');
      } else {
        showToast('Error opening table tab', 'error');
      }
    } catch (err) {
      console.error(err);
      showToast('Error opening table tab', 'error');
    }
  }
}
window.openTableTabDirectly = openTableTabDirectly;

let currentQRMasterCategory = 'restaurant';
let currentRestaurantSubTab = 'floorplan';

function closeTableLayoutEditorToMenu() {
  const modalEditor = document.getElementById('modalTableLayoutEditor');
  if (modalEditor) modalEditor.style.display = 'none';

  // Keep modalOptions open so user returns seamlessly to Manager Panel / Setup
  const modalOpt = document.getElementById('modalOptions');
  if (modalOpt) {
    modalOpt.style.display = 'flex';
  }
}
window.closeTableLayoutEditorToMenu = closeTableLayoutEditorToMenu;

function openTableLayoutEditorModal(initialTab = 'floorplan') {
  const modal = document.getElementById('modalTableLayoutEditor');
  if (modal) modal.style.display = 'flex';
  currentRestaurantSubTab = initialTab;
  switchQRMasterCategory('restaurant');
  if (initialTab === 'floorplan') {
    initTableDiagramEditor();
  }
}
window.openTableLayoutEditorModal = openTableLayoutEditorModal;

function openTacoTruckQRModal(format = 'window8x11') {
  const modal = document.getElementById('modalTableLayoutEditor');
  if (modal) modal.style.display = 'flex';
  const formatSelect = document.getElementById('tacoTruckSignFormatSelect');
  if (formatSelect && format) {
    formatSelect.value = format;
  }
  switchQRMasterCategory('tacotruck');
}
window.openTacoTruckQRModal = openTacoTruckQRModal;

function switchQRMasterCategory(category) {
  currentQRMasterCategory = category;
  const btnCatRest = document.getElementById('tabBtnCatRestaurant');
  const btnCatTaco = document.getElementById('tabBtnCatTacoTruck');
  const restSubTabs = document.getElementById('subTabsRestaurantGroup');
  const floorPlanView = document.getElementById('tableEditorFloorPlanView');
  const qrView = document.getElementById('tableEditorQRView');
  const tacoView = document.getElementById('tableEditorTacoTruckView');
  const btnSaveTableLayout = document.getElementById('btnSaveTableLayout');
  const btnPrintAllQRCards = document.getElementById('btnPrintAllQRCards');
  const btnPrintTacoTruckSign = document.getElementById('btnPrintTacoTruckSign');
  const btnDownloadTacoTruckPNG = document.getElementById('btnDownloadTacoTruckPNG');

  if (category === 'tacotruck') {
    if (btnCatRest) {
      btnCatRest.style.background = 'transparent';
      btnCatRest.style.color = '#aaa';
      btnCatRest.style.border = '1px solid transparent';
    }
    if (btnCatTaco) {
      btnCatTaco.style.background = 'rgba(255, 159, 10, 0.25)';
      btnCatTaco.style.color = '#ff9f0a';
      btnCatTaco.style.border = '1px solid rgba(255, 159, 10, 0.5)';
    }
    if (restSubTabs) restSubTabs.style.display = 'none';
    if (floorPlanView) floorPlanView.style.display = 'none';
    if (qrView) qrView.style.display = 'none';
    if (tacoView) tacoView.style.display = 'flex';

    if (btnSaveTableLayout) btnSaveTableLayout.style.display = 'none';
    if (btnPrintAllQRCards) btnPrintAllQRCards.style.display = 'none';
    if (btnPrintTacoTruckSign) btnPrintTacoTruckSign.style.display = 'flex';
    if (btnDownloadTacoTruckPNG) btnDownloadTacoTruckPNG.style.display = 'flex';

    renderTacoTruckQRPreview();
  } else {
    // 1. Restaurant & Bar (Tables 1-100)
    if (btnCatRest) {
      btnCatRest.style.background = 'rgba(0, 122, 255, 0.25)';
      btnCatRest.style.color = '#64d2ff';
      btnCatRest.style.border = '1px solid rgba(0, 122, 255, 0.5)';
    }
    if (btnCatTaco) {
      btnCatTaco.style.background = 'transparent';
      btnCatTaco.style.color = '#ff9f0a';
      btnCatTaco.style.border = '1px solid transparent';
    }
    if (restSubTabs) restSubTabs.style.display = 'flex';
    if (tacoView) tacoView.style.display = 'none';
    if (btnPrintTacoTruckSign) btnPrintTacoTruckSign.style.display = 'none';
    if (btnDownloadTacoTruckPNG) btnDownloadTacoTruckPNG.style.display = 'none';

    switchTableEditorTab(currentRestaurantSubTab || 'floorplan');
  }
}
window.switchQRMasterCategory = switchQRMasterCategory;

// --- TABLE QR ACRYLIC INSERTS (PDF / PRINT) GENERATOR ---
function switchTableEditorTab(tab) {
  currentRestaurantSubTab = tab;
  const tabBtnFloorPlan = document.getElementById('tabBtnFloorPlan');
  const tabBtnQRCards = document.getElementById('tabBtnQRCards');
  const floorPlanView = document.getElementById('tableEditorFloorPlanView');
  const qrView = document.getElementById('tableEditorQRView');
  const btnSaveTableLayout = document.getElementById('btnSaveTableLayout');
  const btnPrintAllQRCards = document.getElementById('btnPrintAllQRCards');

  if (tab === 'qrcards') {
    if (tabBtnFloorPlan) {
      tabBtnFloorPlan.style.background = 'transparent';
      tabBtnFloorPlan.style.color = '#aaa';
    }
    if (tabBtnQRCards) {
      tabBtnQRCards.style.background = 'var(--accent-color)';
      tabBtnQRCards.style.color = '#fff';
    }
    if (floorPlanView) floorPlanView.style.display = 'none';
    if (qrView) qrView.style.display = 'flex';
    if (btnSaveTableLayout) btnSaveTableLayout.style.display = 'none';
    if (btnPrintAllQRCards) btnPrintAllQRCards.style.display = 'flex';

    renderAllTableQRCards();
  } else {
    if (tabBtnFloorPlan) {
      tabBtnFloorPlan.style.background = 'var(--accent-color)';
      tabBtnFloorPlan.style.color = '#fff';
    }
    if (tabBtnQRCards) {
      tabBtnQRCards.style.background = 'transparent';
      tabBtnQRCards.style.color = '#aaa';
    }
    if (floorPlanView) floorPlanView.style.display = 'flex';
    if (qrView) qrView.style.display = 'none';
    if (btnSaveTableLayout) btnSaveTableLayout.style.display = 'flex';
    if (btnPrintAllQRCards) btnPrintAllQRCards.style.display = 'none';
  }
}
window.switchTableEditorTab = switchTableEditorTab;

// --- TABLE QR PILL SELECTOR & RENDERING CONTROLLERS (NO EMOJIS) ---
function setTableCardLang(lang) {
  const hiddenInput = document.getElementById('qrCardLangSelect');
  if (hiddenInput) hiddenInput.value = lang;
  updateTableCardLangPillsUI(lang);
  renderAllTableQRCards();
}
window.setTableCardLang = setTableCardLang;

function updateTableCardLangPillsUI(lang) {
  const pills = {
    en: document.getElementById('btnTableLangEn'),
    es: document.getElementById('btnTableLangEs'),
    bilingual: document.getElementById('btnTableLangBi'),
    all3: document.getElementById('btnTableLangAll')
  };
  Object.keys(pills).forEach(k => {
    if (pills[k]) {
      if (k === lang) {
        pills[k].classList.add('active');
      } else {
        pills[k].classList.remove('active');
      }
    }
  });
}
window.updateTableCardLangPillsUI = updateTableCardLangPillsUI;

function printTableCardsAll3Sets() {
  setTableCardLang('all3');
  setTimeout(() => {
    window.print();
  }, 350);
}
window.printTableCardsAll3Sets = printTableCardsAll3Sets;

function renderAllTableQRCards() {
  const qrArea = document.getElementById('qrCardsPrintArea');
  if (!qrArea) return;

  const urlInput = document.getElementById('qrCustomUrlInput');
  const langSelect = document.getElementById('qrCardLangSelect');
  const sizeSelect = document.getElementById('qrCardSizeSelect');
  const countBadge = document.getElementById('qrTablesCountBadge');

  let cardLang = langSelect ? langSelect.value : 'en';
  if (!cardLang) cardLang = 'en';

  updateTableCardLangPillsUI(cardLang);

  const cardSize = sizeSelect ? sizeSelect.value : 'acrylic4x6';

  let baseUrl = urlInput ? urlInput.value.trim() : '';
  if (!baseUrl) {
    if (typeof posSettings !== 'undefined' && posSettings && posSettings.clientSubdomain) {
      baseUrl = `https://${posSettings.clientSubdomain}.${posSettings.cloudDomain || 'impossiblepos.com'}/ordena.html`;
    } else {
      baseUrl = `${window.location.origin}/ordena.html`;
    }
    if (urlInput) urlInput.value = baseUrl;
  }

  const totalTables = Array.isArray(configuredTables) ? configuredTables.length : 0;
  if (countBadge) {
    countBadge.innerText = `${totalTables} ${cardLang === 'es' ? 'Mesas' : 'Tables'}`;
  }

  qrArea.innerHTML = '';

  if (totalTables === 0) {
    qrArea.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: #94a3b8;">
        <div style="font-size: 28px; font-weight: 900; color: #64d2ff; margin-bottom: 12px; border: 2px solid #64d2ff; border-radius: 50%; width: 56px; height: 56px; display: inline-flex; align-items: center; justify-content: center; margin: 0 auto 12px;">#</div>
        <h4 style="color: #fff; margin-bottom: 8px;">${cardLang === 'es' ? 'No hay mesas configuradas' : 'No tables configured yet'}</h4>
        <p style="font-size: 13px; max-width: 420px; margin: 0 auto 16px; line-height: 1.5;">
          ${cardLang === 'es' 
            ? 'Regresa a la pestaña <strong>"Floor Plan Editor"</strong> para agregar tus mesas (Mesa 1, Mesa 2, etc.) y luego vuelve aquí para generar los códigos QR para tus acrílicos.' 
            : 'Switch to the <strong>"Floor Plan Editor"</strong> tab to add your tables (Table 1, Table 2, etc.), then return here to generate printable acrylic QR inserts.'}
        </p>
        <button type="button" onclick="switchTableEditorTab('floorplan')" class="btn-modal primary" style="padding: 8px 20px; font-weight: bold; border-radius: 6px; cursor: pointer;">
          ← ${cardLang === 'es' ? 'Ir a Floor Plan Editor' : 'Go to Floor Plan Editor'}
        </button>
      </div>
    `;
    return;
  }

  const bizName = (typeof posSettings !== 'undefined' && posSettings && posSettings.businessName) 
    ? posSettings.businessName.toUpperCase() 
    : 'OUR RESTAURANT';

  const sortedTables = [...configuredTables].sort((a, b) => {
    const numA = parseInt(a.number, 10);
    const numB = parseInt(b.number, 10);
    if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
    return String(a.number).localeCompare(String(b.number), undefined, { numeric: true });
  });

  const qrPixelSize = cardSize === 'tent3x4' ? 130 : 160;
  const languagesToRender = cardLang === 'all3' ? ['en', 'es', 'bilingual'] : [cardLang];

  languagesToRender.forEach((lang, langIdx) => {
    if (cardLang === 'all3') {
      const setLabels = {
        en: `Set 1: 1. English Only (${totalTables} Tables)`,
        es: `Set 2: 2. Solo Espanol (${totalTables} Mesas)`,
        bilingual: `Set 3: 3. Bilingual All-in-One (${totalTables} Tables / Mesas)`
      };
      const headerLabel = document.createElement('div');
      headerLabel.className = 'qr-screen-header-label';
      headerLabel.style.gridColumn = '1 / -1';
      headerLabel.innerText = setLabels[lang] || `Set ${langIdx + 1}: ${lang.toUpperCase()}`;
      qrArea.appendChild(headerLabel);
    }

    const setContainer = document.createElement('div');
    setContainer.className = `table-qr-set ${cardLang === 'all3' && langIdx < languagesToRender.length - 1 ? 'page-break' : ''}`;
    qrArea.appendChild(setContainer);

    sortedTables.forEach((table, idx) => {
      const tableNum = table.number || (idx + 1);
      const safeId = `tbl_qr_${lang}_${String(table.id || idx).replace(/[^a-zA-Z0-9_]/g, '_')}`;

      const separator = baseUrl.includes('?') ? '&' : '?';
      const targetTableUrl = `${baseUrl}${separator}mesa=${encodeURIComponent(tableNum)}`;

      let badgeText = `TABLE ${tableNum}`;
      let scanTitle = 'SCAN TO ORDER & PAY';
      let scanDesc = 'Open your camera, scan the code to view the menu, order, and pay right from your seat.';

      if (lang === 'es') {
        badgeText = `MESA ${tableNum}`;
        scanTitle = 'ESCANEA PARA ORDENAR Y PAGAR';
        scanDesc = 'Abre tu cámara, escanea el código para ver el menú, ordenar y pagar desde tu mesa.';
      } else if (lang === 'bilingual') {
        badgeText = `TABLE - MESA ${tableNum}`;
        scanTitle = `
          SCAN TO ORDER & PAY
          <div style="font-size: 0.82em; color: #0284c7; font-weight: 800; margin-top: 2px;">ESCANEA PARA ORDENAR Y PAGAR</div>
        `;
        scanDesc = `
          <div>Scan with camera to view menu, order & pay from your seat.</div>
          <div style="font-size: 0.9em; color: #475569; margin-top: 3px; border-top: 1px dashed #cbd5e1; padding-top: 3px;">Abre tu cámara para ver el menú, ordenar y pagar desde tu mesa.</div>
        `;
      }

      const card = document.createElement('div');
      card.className = `table-qr-card ${cardSize}`;
      card.id = `card_${safeId}`;

      card.innerHTML = `
        <!-- TOP: BUSINESS LOGO OR NAME -->
        <div class="qr-card-biz-header">
          <img src="/logo.png" class="qr-card-biz-logo" alt="Business Logo" onerror="this.style.display='none'; if(this.nextElementSibling) this.nextElementSibling.style.display='block';">
          <div class="qr-card-biz-name" style="display:none;">${bizName}</div>
        </div>

        <!-- TABLE BADGE -->
        <div class="qr-card-table-badge">
          <span>${badgeText}</span>
        </div>

        <!-- QR CODE CONTAINER -->
        <div class="qr-card-qr-box" id="${safeId}_box"></div>

        <!-- CALL TO ACTION & INSTRUCTIONS -->
        <div class="qr-card-scan-title">${scanTitle}</div>
        <div class="qr-card-scan-desc">${scanDesc}</div>

        <!-- BOTTOM: IMPOSSIBLE POS BRANDING -->
        <div class="qr-card-footer">
          <div class="qr-card-footer-badge">
            <img src="/icon-192.png" class="qr-card-footer-logo" alt="Impossible POS">
            <div class="qr-card-footer-text">Powered by <strong>Impossible POS</strong></div>
          </div>
          <div class="qr-card-footer-url">impossiblepos.com</div>
        </div>
      `;

      setContainer.appendChild(card);

      const qrBox = document.getElementById(`${safeId}_box`);
      if (qrBox && typeof QRCode !== 'undefined') {
        try {
          new QRCode(qrBox, {
            text: targetTableUrl,
            width: qrPixelSize,
            height: qrPixelSize,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H
          });
          const qrImg = qrBox.querySelector('img');
          if (qrImg) qrImg.style.margin = '0 auto';
          const qrCanvas = qrBox.querySelector('canvas');
          if (qrCanvas) qrCanvas.style.margin = '0 auto';
        } catch (e) {
          console.error("Error generating QR code for table:", tableNum, e);
        }
      }
    });
  });
}
window.renderAllTableQRCards = renderAllTableQRCards;

function printAllTableQRCards() {
  const qrView = document.getElementById('tableEditorQRView');
  if (!qrView || qrView.style.display === 'none') {
    switchTableEditorTab('qrcards');
  } else {
    renderAllTableQRCards();
  }

  setTimeout(() => {
    window.print();
  }, 300);
}
window.printAllTableQRCards = printAllTableQRCards;

// --- TACO TRUCK / DRIVE-UP SINGLE QR STUDIO CONTROLLER (NO EMOJIS) ---
function setTacoTruckPosterLang(lang) {
  const hiddenInput = document.getElementById('tacoTruckLangSelect');
  if (hiddenInput) hiddenInput.value = lang;
  updateTacoTruckLangPillsUI(lang);
  renderTacoTruckQRPreview();
}
window.setTacoTruckPosterLang = setTacoTruckPosterLang;

function updateTacoTruckLangPillsUI(lang) {
  const pills = {
    en: document.getElementById('btnTacoLangEn'),
    es: document.getElementById('btnTacoLangEs'),
    bilingual: document.getElementById('btnTacoLangBi'),
    all3: document.getElementById('btnTacoLangAll')
  };
  Object.keys(pills).forEach(k => {
    if (pills[k]) {
      if (k === lang) {
        pills[k].classList.add('active');
      } else {
        pills[k].classList.remove('active');
      }
    }
  });
}
window.updateTacoTruckLangPillsUI = updateTacoTruckLangPillsUI;

function printTacoTruckAll3Signs() {
  setTacoTruckPosterLang('all3');
  setTimeout(() => {
    window.print();
  }, 350);
}
window.printTacoTruckAll3Signs = printTacoTruckAll3Signs;

function renderTacoTruckQRPreview() {
  const container = document.getElementById('tacoTruckPrintArea');
  if (!container) return;

  const urlInput = document.getElementById('tacoTruckQrUrlInput');
  const formatSelect = document.getElementById('tacoTruckSignFormatSelect');
  const langSelect = document.getElementById('tacoTruckLangSelect');
  const nameInput = document.getElementById('tacoTruckBizNameInput');

  const format = formatSelect ? formatSelect.value : 'window8x11';
  let lang = langSelect ? langSelect.value : 'en';
  if (!lang) lang = 'en';

  updateTacoTruckLangPillsUI(lang);

  let customBizName = nameInput ? nameInput.value.trim() : '';
  if (!customBizName) {
    if (typeof posSettings !== 'undefined' && posSettings && posSettings.businessName) {
      customBizName = posSettings.businessName.toUpperCase();
    } else {
      customBizName = 'TACO TRUCK & DRIVE-UP';
    }
    if (nameInput) nameInput.value = customBizName;
  }

  let targetUrl = urlInput ? urlInput.value.trim() : '';
  if (!targetUrl) {
    if (typeof posSettings !== 'undefined' && posSettings && posSettings.clientSubdomain) {
      targetUrl = `https://${posSettings.clientSubdomain}.${posSettings.cloudDomain || 'impossiblepos.com'}/ordena.html?tipo=car`;
    } else {
      targetUrl = `${window.location.origin}/ordena.html?tipo=car`;
    }
    if (urlInput) urlInput.value = targetUrl;
  }

  container.innerHTML = '';

  const qrPixelSize = format === 'window8x11' ? 240 : (format === 'stand4x6' ? 170 : 130);
  const languagesToRender = lang === 'all3' ? ['en', 'es', 'bilingual'] : [lang];

  languagesToRender.forEach((postLang, idx) => {
    const isPageBreak = (lang === 'all3' && idx < languagesToRender.length - 1);
    const boxId = `tacoTruckQRBox_${postLang}_${idx}`;

    if (lang === 'all3') {
      const labels = {
        en: 'Poster 1: 1. English Only (100% English)',
        es: 'Poster 2: 2. Solo Espanol (100% Espanol)',
        bilingual: 'Poster 3: 3. Bilingual All-in-One (Ingles + Espanol en Uno)'
      };
      const headerLabel = document.createElement('div');
      headerLabel.className = 'qr-screen-header-label';
      headerLabel.innerText = labels[postLang] || `Poster ${idx + 1}: ${postLang.toUpperCase()}`;
      container.appendChild(headerLabel);
    }

    let badgeTitle = 'CARSIDE & DRIVE-UP ORDERING';
    let mainHeadline = 'SCAN TO ORDER FROM YOUR CAR';
    let instructions = 'Scan to order from your car or in line! Choose your tacos, burritos, plates & drinks, enter your vehicle/description and phone number — we text you when your food is ready!';
    
    let step1Title = '1. Scan with Phone';
    let step1Desc = 'Point your phone camera at this QR code.';
    
    let step2Title = '2. Browse & Pickup';
    let step2Desc = 'Choose your tacos, burritos, plates & drinks, and input your phone number.';
    
    let step3Title = '3. Vehicle Description';
    let step3Desc = 'Enter your vehicle (color/make) or description (e.g. Green Jeep, Black Truck, Moto, Bicycle).';
    
    let step4Title = '4. We Text You When Ready';
    let step4Desc = 'We text you when your food is ready!';

    if (postLang === 'es') {
      badgeTitle = 'PEDIDOS DESDE EL AUTO - TACO TRUCK';
      mainHeadline = 'ESCANEA Y ORDENA DESDE TU AUTO';
      instructions = '¡Escanea para ordenar desde tu auto o en la fila! Elige tus tacos, burritos, platillos y bebidas, ingresa la descripción de tu vehículo y tu teléfono: ¡te enviamos un mensaje de texto cuando esté listo!';
      
      step1Title = '1. Escanea con tu Teléfono';
      step1Desc = 'Apunta la cámara de tu teléfono a este código QR.';
      
      step2Title = '2. Explora el Menú y Teléfono';
      step2Desc = 'Elige tus tacos, burritos, platillos y bebidas, e ingresa tu número de teléfono.';
      
      step3Title = '3. Descripción del Vehículo';
      step3Desc = 'Indica tu vehículo o descripción (ej. Jeep verde, camioneta negra, moto, bicicleta).';
      
      step4Title = '4. Te Avisamos por Mensaje de Texto';
      step4Desc = '¡Te enviamos un mensaje de texto cuando tu comida esté lista!';
    } else if (postLang === 'bilingual') {
      badgeTitle = 'CARSIDE ORDERING - PEDIDOS AL AUTO';
      mainHeadline = `
        SCAN TO ORDER FROM YOUR CAR
        <div style="font-size: 0.75em; color: #d97706; font-weight: 800; margin-top: 3px;">ESCANEA PARA ORDENAR DESDE TU AUTO</div>
      `;
      instructions = `
        <div><strong>Scan to order from your car or in line!</strong> Choose tacos, burritos, plates & drinks, enter your vehicle and phone — we text you when ready!</div>
        <div style="font-size: 0.9em; color: #475569; margin-top: 4px; border-top: 1px dashed #cbd5e1; padding-top: 4px;"><strong>¡Ordena desde tu auto o en fila!</strong> Elige tu comida y bebidas, indica tu auto y teléfono — ¡te avisamos por mensaje de texto cuando esté listo!</div>
      `;
      
      step1Title = '1. Scan / Escanea con tu Teléfono';
      step1Desc = 'Point camera at QR code.<br><span style="color:#0284c7; font-weight: 600;">Apunta tu teléfono al código QR.</span>';
      
      step2Title = '2. Browse & Phone / Menú y Teléfono';
      step2Desc = 'Choose food & enter your phone.<br><span style="color:#0284c7; font-weight: 600;">Elige tu comida e ingresa tu teléfono.</span>';
      
      step3Title = '3. Vehicle Info / Tu Vehículo';
      step3Desc = 'Car color/make: Jeep, Truck, Moto, Bike.<br><span style="color:#0284c7; font-weight: 600;">Color o modelo: Jeep, camioneta, moto.</span>';
      
      step4Title = '4. We Text You / Aviso por Mensaje SMS';
      step4Desc = 'We text you when your food is ready!<br><span style="color:#b45309; font-weight: 800;">¡Te enviamos un texto cuando esté listo!</span>';
    }

    const card = document.createElement('div');
    card.className = `taco-poster-card poster-${format} ${isPageBreak ? 'page-break' : ''}`;
    card.id = idx === 0 ? 'tacoTruckActivePoster' : `tacoTruckActivePoster_${idx}`;

    card.innerHTML = `
      <!-- TOP HEADER -->
      <div style="margin-bottom: 6px; width: 100%;">
        <div class="taco-poster-biz-name">${customBizName}</div>
        <div class="taco-poster-badge">
          <span>${badgeTitle}</span>
        </div>
      </div>

      <div style="font-size: ${format === 'window8x11' ? '20px' : '15px'}; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; line-height: 1.2;">
        ${mainHeadline}
      </div>

      <!-- QR CODE BOX -->
      <div class="taco-poster-qr-box" id="${boxId}"></div>

      <!-- INSTRUCTIONS -->
      <div class="taco-poster-instructions">
        ${instructions}
      </div>

      <!-- 4 STEPS GRID -->
      <div class="taco-poster-steps" style="${format === 'tent3x4' ? 'display: none;' : ''}">
        <div class="taco-poster-step-item">
          <div class="taco-poster-step-icon">1</div>
          <div class="taco-poster-step-content">
            <div class="taco-poster-step-title">${step1Title}</div>
            <div class="taco-poster-step-desc">${step1Desc}</div>
          </div>
        </div>
        <div class="taco-poster-step-item">
          <div class="taco-poster-step-icon">2</div>
          <div class="taco-poster-step-content">
            <div class="taco-poster-step-title">${step2Title}</div>
            <div class="taco-poster-step-desc">${step2Desc}</div>
          </div>
        </div>
        <div class="taco-poster-step-item">
          <div class="taco-poster-step-icon">3</div>
          <div class="taco-poster-step-content">
            <div class="taco-poster-step-title">${step3Title}</div>
            <div class="taco-poster-step-desc">${step3Desc}</div>
          </div>
        </div>
        <div class="taco-poster-step-item step-highlight">
          <div class="taco-poster-step-icon highlight">4</div>
          <div class="taco-poster-step-content">
            <div class="taco-poster-step-title highlight">${step4Title}</div>
            <div class="taco-poster-step-desc" style="font-weight: 700; color: #b45309;">${step4Desc}</div>
          </div>
        </div>
      </div>

      <!-- FOOTER -->
      <div class="taco-poster-footer">
        <div style="display: flex; align-items: center; gap: 6px;">
          <img src="/icon-192.png" style="width: 16px; height: 16px; border-radius: 3px;" alt="POS">
          <span>Powered by <strong>Impossible POS</strong></span>
        </div>
        <div style="color: #0284c7; font-weight: bold;">impossiblepos.com</div>
      </div>
    `;

    container.appendChild(card);

    const qrBox = document.getElementById(boxId);
    if (qrBox && typeof QRCode !== 'undefined') {
      try {
        new QRCode(qrBox, {
          text: targetUrl,
          width: qrPixelSize,
          height: qrPixelSize,
          colorDark: "#000000",
          colorLight: "#ffffff",
          correctLevel: QRCode.CorrectLevel.H
        });
        const qrImg = qrBox.querySelector('img');
        if (qrImg) qrImg.style.margin = '0 auto';
        const qrCanvas = qrBox.querySelector('canvas');
        if (qrCanvas) qrCanvas.style.margin = '0 auto';
      } catch (e) {
        console.error("Error generating Taco Truck QR:", e);
      }
    }
  });
}
window.renderTacoTruckQRPreview = renderTacoTruckQRPreview;

function printTacoTruckQRSign() {
  const tacoView = document.getElementById('tableEditorTacoTruckView');
  if (!tacoView || tacoView.style.display === 'none') {
    switchQRMasterCategory('tacotruck');
  } else {
    renderTacoTruckQRPreview();
  }

  setTimeout(() => {
    window.print();
  }, 300);
}
window.printTacoTruckQRSign = printTacoTruckQRSign;

function downloadTacoTruckQRPNG() {
  const qrBox = document.querySelector('.taco-poster-qr-box');
  if (!qrBox) {
    showToast('Generate QR first', 'error');
    return;
  }
  const canvas = qrBox.querySelector('canvas');
  let dataUrl = '';
  if (canvas) {
    dataUrl = canvas.toDataURL('image/png');
  } else {
    const img = qrBox.querySelector('img');
    if (img && img.src) {
      dataUrl = img.src;
    }
  }

  if (!dataUrl) {
    showToast('Could not extract QR image', 'error');
    return;
  }

  const a = document.createElement('a');
  a.href = dataUrl;
  const rawBizName = document.getElementById('tacoTruckBizNameInput')?.value.trim() || 'Taco_Truck';
  const safeBiz = rawBizName.replace(/[^a-zA-Z0-9_-]/g, '_');
  a.download = `${safeBiz}_Car_Order_QR.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  showToast('QR Image (PNG) downloaded successfully!', 'success');
}
window.downloadTacoTruckQRPNG = downloadTacoTruckQRPNG;

let currentStationQRInstance = null;

async function openStationQRSafePrintModal() {
  const modal = document.getElementById('modalStationQRPrint');
  if (!modal) return;

  const select = document.getElementById('selectStationQRModal');
  const currentSt = (document.getElementById('adminStationId')?.value) || (posSettings && posSettings.stationId) || '1';
  if (select) select.value = currentSt;

  updateStationQRModalPreview();
  modal.style.display = 'flex';
}
window.openStationQRSafePrintModal = openStationQRSafePrintModal;

function closeStationQRPrintModal() {
  const modal = document.getElementById('modalStationQRPrint');
  if (modal) modal.style.display = 'none';
}
window.closeStationQRPrintModal = closeStationQRPrintModal;

async function updateStationQRModalPreview() {
  const select = document.getElementById('selectStationQRModal');
  const stationId = select ? select.value : '1';
  
  const bName = (posSettings && posSettings.businessName) || 'IMPOSSIBLE POS';
  const lblBiz = document.getElementById('lblSignBusinessName');
  if (lblBiz) lblBiz.innerText = bName.toUpperCase();

  const lblStation = document.getElementById('lblSignStationName');
  let stDisplay = `STATION ${stationId.toUpperCase()}`;
  if (stationId === '1') stDisplay = 'CAJA 1 (STATION 1)';
  else if (stationId === '2') stDisplay = 'CAJA 2 (STATION 2)';
  else if (stationId === '3') stDisplay = 'CAJA 3 (STATION 3)';
  else if (stationId === '4') stDisplay = 'CAJA 4 (STATION 4)';
  else if (stationId === '5') stDisplay = 'TABLETA (MOBILE STATION)';
  else if (stationId === 'back_office') stDisplay = 'BACK OFFICE';
  if (lblStation) lblStation.innerText = stDisplay;

  let targetUrl = `${window.location.origin}/autoregistro.html?station=${encodeURIComponent(stationId)}`;
  try {
    const res = await fetch(`${SERVER_URL}/api/tunnel-url`);
    if (res.ok) {
      const data = await res.json();
      if (data.url) {
        const baseUrl = data.url.endsWith('/') ? data.url.slice(0, -1) : data.url;
        targetUrl = `${baseUrl}/autoregistro.html?station=${encodeURIComponent(stationId)}`;
      }
    }
  } catch(e) {}

  if (targetUrl.includes('localhost') || targetUrl.includes('127.0.0.1')) {
    try {
      const ipRes = await fetch(`${SERVER_URL}/api/local-ip`);
      if (ipRes.ok) {
        const ipData = await ipRes.json();
        if (ipData.ip && ipData.ip !== '127.0.0.1') {
          targetUrl = targetUrl.replace('localhost', ipData.ip).replace('127.0.0.1', ipData.ip);
        }
      }
    } catch(e) {}
  }

  const box = document.getElementById('stationQRCanvasBox');
  if (box) {
    box.innerHTML = '';
    try {
      currentStationQRInstance = new QRCode(box, {
        text: targetUrl,
        width: 170,
        height: 170,
        correctLevel: QRCode.CorrectLevel.H
      });
      const qrImg = box.querySelector('img');
      if (qrImg) qrImg.style.margin = '0 auto';
      const qrCanvas = box.querySelector('canvas');
      if (qrCanvas) qrCanvas.style.margin = '0 auto';
    } catch(err) {
      console.error('Error drawing station QR code:', err);
    }
  }
}
window.updateStationQRModalPreview = updateStationQRModalPreview;

function printStationQRSheetDirect() {
  const box = document.getElementById('stationQRCanvasBox');
  if (!box) return;

  const canvas = box.querySelector('canvas');
  const img = box.querySelector('img');
  let qrDataUrl = '';
  if (canvas) {
    qrDataUrl = canvas.toDataURL('image/png');
  } else if (img && img.src) {
    qrDataUrl = img.src;
  }

  if (!qrDataUrl) {
    showToast('Wait for QR to render', 'warning');
    return;
  }

  const select = document.getElementById('selectStationQRModal');
  const stationId = select ? select.value : '1';
  const bName = (posSettings && posSettings.businessName) || 'IMPOSSIBLE POS';
  let stDisplay = `Station ${stationId.toUpperCase()}`;
  if (stationId === '1') stDisplay = 'Caja 1 / Station 1';
  else if (stationId === '2') stDisplay = 'Caja 2 / Station 2';
  else if (stationId === '3') stDisplay = 'Caja 3 / Station 3';
  else if (stationId === '4') stDisplay = 'Caja 4 / Station 4';
  else if (stationId === '5') stDisplay = 'Tableta / Mobile Station';
  else if (stationId === 'back_office') stDisplay = 'Back Office';

  const printWindow = window.open('', '_blank', 'width=550,height=700');
  if (!printWindow) {
    showToast('Popup blocker prevented opening print window', 'error');
    return;
  }

  printWindow.document.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${bName} - ${stDisplay} Customer QR Sign</title>
  <style>
    @page { size: auto; margin: 10mm; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #fff;
      color: #000;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 90vh;
    }
    .card {
      border: 4px solid #111;
      border-radius: 20px;
      padding: 30px 25px;
      text-align: center;
      max-width: 420px;
      width: 100%;
      box-sizing: border-box;
    }
    .biz-title {
      font-size: 26px;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 4px;
    }
    .station-badge {
      display: inline-block;
      font-size: 14px;
      font-weight: 800;
      background: #000;
      color: #fff;
      padding: 4px 14px;
      border-radius: 12px;
      text-transform: uppercase;
      margin-bottom: 20px;
      letter-spacing: 0.5px;
    }
    .qr-frame {
      background: #fff;
      padding: 12px;
      border: 2px dashed #999;
      border-radius: 14px;
      display: inline-block;
      margin-bottom: 20px;
    }
    .qr-frame img {
      display: block;
      width: 220px;
      height: 220px;
    }
    .instruction-en {
      font-size: 16px;
      font-weight: 800;
      line-height: 1.35;
      margin-bottom: 10px;
      color: #000;
    }
    .instruction-es {
      font-size: 14px;
      font-weight: 700;
      line-height: 1.35;
      margin-bottom: 14px;
      color: #444;
    }
    .perks {
      font-size: 11px;
      color: #666;
      border-top: 1px solid #ccc;
      padding-top: 10px;
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="biz-title">${bName}</div>
    <div class="station-badge">${stDisplay}</div>
    <div class="qr-frame">
      <img src="${qrDataUrl}" alt="Customer QR Code">
    </div>
    <div class="instruction-en">
      Please scan this code to link your account to this computer
    </div>
    <div class="instruction-es">
      Por favor escanea este código para vincular tu cuenta a esta computadora
    </div>
    <div class="perks">
      Customer Loyalty • Digital Receipts • Live Order Updates
    </div>
  </div>
  <script>
    window.onload = function() {
      setTimeout(function() {
        window.print();
      }, 250);
    };
  </script>
</body>
</html>`);
  printWindow.document.close();
}
window.printStationQRSheetDirect = printStationQRSheetDirect;

function copyTacoTruckQRLink() {
  const urlInput = document.getElementById('tacoTruckQrUrlInput');
  if (!urlInput || !urlInput.value) return;
  const linkText = urlInput.value.trim();
  navigator.clipboard.writeText(linkText).then(() => {
    showToast('Order link copied to clipboard!', 'success');
  }).catch(() => {
    urlInput.select();
    document.execCommand('copy');
    showToast('Order link copied!', 'success');
  });
}
window.copyTacoTruckQRLink = copyTacoTruckQRLink;

// --- CORE SPLIT BILL FUNCTIONALITY ---
let currentSplitOrder = null;
let currentSplitMode = 'equal';
let manualSplitBuckets = { 1: [], 2: [], 3: [], 4: [] };

async function openSplitBillModal(order) {
  currentSplitOrder = order;
  currentSplitMode = 'equal';
  manualSplitBuckets = { 1: [], 2: [], 3: [], 4: [] };

  const origTotal = document.getElementById('splitBillOriginalTotal');
  if (origTotal) origTotal.innerText = '$' + order.total.toFixed(2);
  
  setSplitMode('equal');
  renderSplitItemSourceList();

  const eqCount = document.getElementById('splitEqualCount');
  if (eqCount) eqCount.value = '2';
  renderEqualSplits();
  
  document.getElementById('modalSplitBill').style.display = 'flex';
}
window.openSplitBillModal = openSplitBillModal;

function setSplitMode(mode) {
  currentSplitMode = mode;
  
  const btnEqual = document.getElementById('btnSplitEqualMode');
  const btnSeat = document.getElementById('btnSplitSeatMode');
  const btnItem = document.getElementById('btnSplitItemMode');

  const panelEqual = document.getElementById('panelSplitEqual');
  const panelSeat = document.getElementById('panelSplitSeat');
  const panelItem = document.getElementById('panelSplitItem');

  if (mode === 'equal') {
    if (btnEqual) btnEqual.className = 'btn-modal primary';
    if (btnSeat) btnSeat.className = 'btn-modal secondary';
    if (btnItem) btnItem.className = 'btn-modal secondary';
    if (panelEqual) panelEqual.style.display = 'flex';
    if (panelSeat) panelSeat.style.display = 'none';
    if (panelItem) panelItem.style.display = 'none';
    renderEqualSplits();
  } else if (mode === 'seat') {
    if (btnEqual) btnEqual.className = 'btn-modal secondary';
    if (btnSeat) btnSeat.className = 'btn-modal primary';
    if (btnItem) btnItem.className = 'btn-modal secondary';
    if (panelEqual) panelEqual.style.display = 'none';
    if (panelSeat) panelSeat.style.display = 'flex';
    if (panelItem) panelItem.style.display = 'none';
    renderSeatSplits();
  } else if (mode === 'item') {
    if (btnEqual) btnEqual.className = 'btn-modal secondary';
    if (btnSeat) btnSeat.className = 'btn-modal secondary';
    if (btnItem) btnItem.className = 'btn-modal primary';
    if (panelEqual) panelEqual.style.display = 'none';
    if (panelSeat) panelSeat.style.display = 'none';
    if (panelItem) panelItem.style.display = 'flex';
    renderManualSplits();
  }
}
window.setSplitMode = setSplitMode;

function renderEqualSplits() {
  const countInput = document.getElementById('splitEqualCount');
  const count = countInput ? (parseInt(countInput.value) || 2) : 2;
  const total = currentSplitOrder ? currentSplitOrder.total : 0;
  const shareAmount = total / count;

  const container = document.getElementById('containerEqualSplits');
  if (!container) return;
  container.innerHTML = '';

  for (let i = 1; i <= count; i++) {
    const div = document.createElement('div');
    div.style.cssText = 'display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid rgba(255,255,255,0.05);';
    div.innerHTML = `
      <div style="font-weight:bold; font-size:13px; color:#fff;">Cheque ${i} / ${count}</div>
      <div style="font-size:13px; font-weight:bold; color:var(--success-color);">$${shareAmount.toFixed(2)}</div>
    `;
    container.appendChild(div);
  }
}
window.renderEqualSplits = renderEqualSplits;

function renderSeatSplits() {
  const container = document.getElementById('containerSeatSplits');
  if (!container) return;
  container.innerHTML = '';

  if (!currentSplitOrder) return;

  const groups = {};
  const generalItems = [];

  currentSplitOrder.items.forEach(item => {
    const match = item.name.match(/\(Cliente (\d+)\)/i);
    if (match) {
      const seatNum = match[1];
      if (!groups[seatNum]) groups[seatNum] = [];
      groups[seatNum].push(item);
    } else {
      generalItems.push(item);
    }
  });

  if (generalItems.length > 0) {
    groups['General'] = generalItems;
  }

  const seatKeys = Object.keys(groups).sort();
  if (seatKeys.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:20px; color:var(--text-secondary);">No active seats found in this ticket.</div>`;
    return;
  }

  seatKeys.forEach(seat => {
    const items = groups[seat];
    const subtotal = items.reduce((sum, item) => sum + (parseFloat(item.total || item.subtotal || 0)), 0);
    const div = document.createElement('div');
    div.style.cssText = 'border:1px solid var(--border-color); border-radius:8px; padding:12px; margin-bottom:10px; background:rgba(255,255,255,0.01); text-align:left;';
    
    let itemsHtml = items.map(item => `
      <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px; color:var(--text-secondary);">
        <span>${item.quantity}x ${item.name}</span>
        <span>$${(parseFloat(item.total || item.subtotal || 0)).toFixed(2)}</span>
      </div>
    `).join('');

    div.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:6px; margin-bottom:8px;">
        <span style="font-weight:bold; color:var(--accent-color); font-size:13px;">${seat === 'General' ? 'Artículos Generales / General' : `Cliente ${seat}`}</span>
        <span style="font-weight:bold; color:var(--success-color); font-size:13px;">$${subtotal.toFixed(2)}</span>
      </div>
      <div>${itemsHtml}</div>
    `;
    container.appendChild(div);
  });
}
window.renderSeatSplits = renderSeatSplits;

function renderSplitItemSourceList() {
  const container = document.getElementById('splitItemSourceList');
  if (!container) return;
  container.innerHTML = '';

  if (!currentSplitOrder) return;

  const assignedItemIds = new Set();
  Object.values(manualSplitBuckets).forEach(bucket => {
    bucket.forEach(item => assignedItemIds.add(item.uniqueId || item.id));
  });

  const availableItems = currentSplitOrder.items.filter(item => !assignedItemIds.has(item.uniqueId || item.id));

  if (availableItems.length === 0) {
    container.innerHTML = `<div style="text-align:center; padding:20px; color:var(--text-secondary);">Todos los artículos asignados / All items assigned</div>`;
    return;
  }

  availableItems.forEach(item => {
    const itemUniqueId = item.uniqueId || item.id || ('it_' + Math.random().toString(36).substr(2, 9));
    item.uniqueId = itemUniqueId; 
    
    const div = document.createElement('div');
    div.style.cssText = 'display:flex; align-items:center; gap:10px; padding:6px; border-bottom:1px solid rgba(255,255,255,0.03); text-align:left;';
    
    div.innerHTML = `
      <input type="checkbox" class="split-item-chk" value="${itemUniqueId}" style="width:16px; height:16px; cursor:pointer;">
      <div style="flex:1; font-size:12px; color:#fff;">
        <span style="font-weight:bold;">${item.quantity}x</span> ${item.name}
      </div>
      <div style="font-size:12px; font-weight:bold; color:var(--success-color);">$${(parseFloat(item.total || item.subtotal || 0)).toFixed(2)}</div>
    `;
    container.appendChild(div);
  });
}

function renderManualSplits() {
  const container = document.getElementById('containerManualSplits');
  if (!container) return;
  container.innerHTML = '';

  for (let b = 1; b <= 4; b++) {
    const items = manualSplitBuckets[b];
    const total = items.reduce((sum, item) => sum + (parseFloat(item.total || item.subtotal || 0)), 0);

    const div = document.createElement('div');
    div.style.cssText = 'border:1px solid var(--border-color); border-radius:6px; padding:10px; margin-bottom:8px; background:rgba(255,255,255,0.01); text-align:left;';
    
    let itemsHtml = items.map(item => `
      <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px; color:var(--text-secondary);">
        <span>${item.quantity}x ${item.name}</span>
        <button type="button" style="background:none; border:none; color:var(--danger-color); cursor:pointer; font-size:10px; padding:0 4px;" onclick="removeManualSplitItem(${b}, '${item.uniqueId}')">✕</button>
      </div>
    `).join('');

    div.innerHTML = `
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid rgba(255,255,255,0.05); padding-bottom:4px; margin-bottom:6px;">
        <span style="font-weight:bold; font-size:12px; color:var(--accent-color);">Cheque ${b}</span>
        <span style="font-weight:bold; font-size:12px; color:var(--success-color);">$${total.toFixed(2)}</span>
      </div>
      <div>${itemsHtml || '<span style="font-size:10px; color:var(--text-secondary); font-style:italic;">Vacío / Empty</span>'}</div>
    `;
    container.appendChild(div);
  }
}
window.renderManualSplits = renderManualSplits;

window.removeManualSplitItem = function(bucketNum, itemUniqueId) {
  manualSplitBuckets[bucketNum] = manualSplitBuckets[bucketNum].filter(item => item.uniqueId !== itemUniqueId);
  renderSplitItemSourceList();
  renderManualSplits();
};

async function confirmAndSplitBill() {
  if (!currentSplitOrder) return;
  
  let subOrders = [];
  const parentTableName = currentSplitOrder.tableName || 'N/A';
  
  if (currentSplitMode === 'equal') {
    const countInput = document.getElementById('splitEqualCount');
    const count = countInput ? (parseInt(countInput.value) || 2) : 2;
    const shareAmount = currentSplitOrder.total / count;
    
    for (let i = 1; i <= count; i++) {
      subOrders.push({
        items: [{
          name: `Mesa ${parentTableName} (Share ${i}/${count})`,
          price: shareAmount,
          quantity: 1,
          subtotal: shareAmount,
          total: shareAmount
        }],
        type: currentSplitOrder.type || 'comer',
        tableName: `${parentTableName} (${i}/${count})`,
        guestCount: currentSplitOrder.guestCount,
        total: shareAmount,
        subtotal: shareAmount,
        tax: 0,
        deposit: 0,
        balance: 0,
        paymentStatus: 'unpaid',
        status: 'pendiente',
        cashierName: currentSplitOrder.cashierName || currentCashierName || 'Cashier'
      });
    }
  } else if (currentSplitMode === 'seat') {
    const groups = {};
    const generalItems = [];

    currentSplitOrder.items.forEach(item => {
      const match = item.name.match(/\(Cliente (\d+)\)/i);
      if (match) {
        const seatNum = match[1];
        if (!groups[seatNum]) groups[seatNum] = [];
        groups[seatNum].push(item);
      } else {
        generalItems.push(item);
      }
    });

    if (generalItems.length > 0) {
      groups['Gen'] = generalItems;
    }

    const seatKeys = Object.keys(groups);
    if (seatKeys.length === 0) {
      showToast('No clients assigned to split', 'error');
      return;
    }

    seatKeys.forEach(seat => {
      const items = groups[seat];
      const total = items.reduce((sum, item) => sum + (parseFloat(item.total || item.subtotal || 0)), 0);
      
      subOrders.push({
        items: items,
        type: currentSplitOrder.type || 'comer',
        tableName: `${parentTableName} (${seat === 'Gen' ? 'Gen' : `C${seat}`})`,
        guestCount: currentSplitOrder.guestCount,
        total: total,
        subtotal: total,
        tax: 0,
        deposit: 0,
        balance: 0,
        paymentStatus: 'unpaid',
        status: 'pendiente',
        cashierName: currentSplitOrder.cashierName || currentCashierName || 'Cashier'
      });
    });
  } else if (currentSplitMode === 'item') {
    const assignedItemIds = new Set();
    Object.values(manualSplitBuckets).forEach(bucket => {
      bucket.forEach(item => assignedItemIds.add(item.uniqueId));
    });
    
    const unassigned = currentSplitOrder.items.filter(item => !assignedItemIds.has(item.uniqueId));
    if (unassigned.length > 0) {
      showToast('Asigna todos los artículos antes de dividir / Assign all items', 'warning');
      return;
    }

    for (let b = 1; b <= 4; b++) {
      const items = manualSplitBuckets[b];
      if (items.length === 0) continue;
      
      const total = items.reduce((sum, item) => sum + (parseFloat(item.total || item.subtotal || 0)), 0);
      subOrders.push({
        items: items,
        type: currentSplitOrder.type || 'comer',
        tableName: `${parentTableName} (Ch ${b})`,
        guestCount: currentSplitOrder.guestCount,
        total: total,
        subtotal: total,
        tax: 0,
        deposit: 0,
        balance: 0,
        paymentStatus: 'unpaid',
        status: 'pendiente',
        cashierName: currentSplitOrder.cashierName || currentCashierName || 'Cashier'
      });
    }
  }

  if (subOrders.length === 0) {
    showToast('No splits defined', 'error');
    return;
  }

  if (!confirm(`¿Confirmar división en ${subOrders.length} cuentas? / Confirm split?`)) {
    return;
  }

  try {
    // 1. Post N new unpaid sub-orders to the server
    const createdOrders = [];
    for (let sub of subOrders) {
      const res = await fetch(`${SERVER_URL}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub)
      });
      if (res.ok) {
        const created = await res.json();
        createdOrders.push(created);
        
        // Print the check automatically for each split ticket
        printOrderReceipt(created.id);
      }
    }

    // 2. Void the original parent order
    await fetch(`${SERVER_URL}/api/orders/${currentSplitOrder.id}/void`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: 'Split Bill division / Cuenta Dividida', authorizedBy: currentCashierName || 'System' })
    });

    // 3. Clear cart if we currently had this tab loaded
    if (activeTabOrderId === currentSplitOrder.id) {
      cart = [];
      activeTabOrderId = null;
      tabTableNumber = null;
      tabClientCount = 0;
      activeTabClientSeat = 1;
      buildSeatSelectors();
      updateCartUI();
    }

    // 4. Close modal and sync
    document.getElementById('modalSplitBill').style.display = 'none';
    showToast(`Cuenta dividida con éxito! ${createdOrders.length} cheques impresos.`, 'success');
    
    // Sync Floor Map waitresses view
    initTableMapWaitress();
  } catch (err) {
    console.error(err);
    showToast('Error al dividir la cuenta', 'error');
  }
}
window.confirmAndSplitBill = confirmAndSplitBill;

// ==========================================
// --- LOGO UPLOAD IMPLEMENTATION ---
// ==========================================
function initLogoUploadHandlers() {
  const wizardLogoFile = document.getElementById('wizardLogoFile');
  const wizardLogoStatus = document.getElementById('wizardLogoStatus');
  if (wizardLogoFile && wizardLogoStatus) {
    wizardLogoFile.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      wizardLogoStatus.textContent = "Uploading...";
      const success = await uploadLogoFile(file);
      if (success) {
        wizardLogoStatus.textContent = "✓ Uploaded / Cargado";
        showToast("Logotipo cargado con éxito", "success");
      } else {
        wizardLogoStatus.textContent = "❌ Error uploading";
        showToast("Error al cargar logotipo", "error");
      }
    });
  }

  const adminLogoFile = document.getElementById('adminLogoFile');
  const adminLogoStatus = document.getElementById('adminLogoStatus');
  if (adminLogoFile && adminLogoStatus) {
    adminLogoFile.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      adminLogoStatus.textContent = "Uploading...";
      const success = await uploadLogoFile(file);
      if (success) {
        adminLogoStatus.textContent = "✓ Uploaded / Cargado";
        showToast("Logotipo cargado con éxito", "success");
      } else {
        adminLogoStatus.textContent = "❌ Error uploading";
        showToast("Error al cargar logotipo", "error");
      }
    });
  }
}

function uploadLogoFile(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const logoData = reader.result;
        const res = await fetch(`${SERVER_URL}/api/admin/upload-logo`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ logoData })
        });
        resolve(res.ok);
      } catch (err) {
        console.error(err);
        resolve(false);
      }
    };
    reader.onerror = () => resolve(false);
    reader.readAsDataURL(file);
  });
}

// ==========================================
// --- ALCOHOL CONTROL (MANAGER PANEL) ---
// ==========================================
let activeAlcoholTab = 'catalog';

function switchAlcoholSubTab(tab) {
  activeAlcoholTab = tab;
  const btnCatalog = document.getElementById('btnAlcoholSubTabCatalog');
  const btnReports = document.getElementById('btnAlcoholSubTabReports');
  const catalogPane = document.getElementById('alcoholCatalogSubPane');
  const reportsPane = document.getElementById('alcoholReportsSubPane');
  
  if (tab === 'catalog') {
    btnCatalog.classList.add('selected');
    btnCatalog.style.backgroundColor = 'var(--accent-color)';
    btnCatalog.style.color = '#000';
    btnReports.classList.remove('selected');
    btnReports.style.backgroundColor = '';
    btnReports.style.color = '';
    catalogPane.style.display = 'block';
    reportsPane.style.display = 'none';
    loadAlcoholCatalog();
  } else {
    btnReports.classList.add('selected');
    btnReports.style.backgroundColor = 'var(--accent-color)';
    btnReports.style.color = '#000';
    btnCatalog.classList.remove('selected');
    btnCatalog.style.backgroundColor = '';
    btnCatalog.style.color = '';
    catalogPane.style.display = 'none';
    reportsPane.style.display = 'block';
    loadAlcoholReports();
  }
}
window.switchAlcoholSubTab = switchAlcoholSubTab;

async function loadAlcoholCatalog() {
  try {
    const res = await fetch(`${SERVER_URL}/api/alcohol`);
    if (res.ok) {
      const list = await res.json();
      const tbody = document.getElementById('alcoholCatalogTableBody');
      tbody.innerHTML = '';
      
      list.forEach(p => {
        const tr = document.createElement('tr');
        tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
        tr.innerHTML = `
          <td style="padding: 6px 4px;">${p.barcode || 'N/A'}</td>
          <td style="padding: 6px 4px;"><strong>${p.brand}</strong><br><span style="font-size:9px; color:var(--text-secondary);">${p.model || ''}</span></td>
          <td style="padding: 6px 4px;">F: ${p.fullWeight}g / E: ${p.emptyWeight}g</td>
          <td style="padding: 6px 4px;">${p.shotSize} oz</td>
          <td style="padding: 6px 4px; color: var(--accent-color); font-weight: bold;">${(p.currentVolumeOunces || 0).toFixed(1)} oz</td>
          <td style="padding: 6px 4px; text-align: right;">
            <button class="btn-modal" onclick="editAlcoholProduct('${p.id}')" style="margin: 0; padding: 2px 6px; font-size: 10px; background-color: var(--accent-color); color: #000; height: 18px;">✏️</button>
            <button class="btn-modal danger" onclick="deleteAlcoholProduct('${p.id}')" style="margin: 0 0 0 4px; padding: 2px 6px; font-size: 10px; height: 18px; background-color: var(--danger-color); color: #fff;">❌</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    }
  } catch (err) {
    console.error(err);
  }
}
window.loadAlcoholCatalog = loadAlcoholCatalog;

function clearAlcoholForm() {
  document.getElementById('alcoholFormId').value = '';
  document.getElementById('alcoholFormBarcode').value = '';
  document.getElementById('alcoholFormBrand').value = '';
  document.getElementById('alcoholFormModel').value = '';
  document.getElementById('alcoholFormFullWeight').value = '';
  document.getElementById('alcoholFormEmptyWeight').value = '';
  document.getElementById('alcoholFormLiquidOunces').value = '25.4';
  document.getElementById('alcoholFormShotSize').value = '1.5';
  document.getElementById('alcoholFormGramsPerOunce').value = '29.5';
}
window.clearAlcoholForm = clearAlcoholForm;

async function saveAlcoholProductFromForm() {
  const id = document.getElementById('alcoholFormId').value;
  const barcode = document.getElementById('alcoholFormBarcode').value.trim();
  const brand = document.getElementById('alcoholFormBrand').value.trim();
  const model = document.getElementById('alcoholFormModel').value.trim();
  const fullWeight = parseFloat(document.getElementById('alcoholFormFullWeight').value) || 0;
  const emptyWeight = parseFloat(document.getElementById('alcoholFormEmptyWeight').value) || 0;
  const liquidOunces = parseFloat(document.getElementById('alcoholFormLiquidOunces').value) || 0;
  const shotSize = parseFloat(document.getElementById('alcoholFormShotSize').value) || 0;
  const gramsPerOunce = parseFloat(document.getElementById('alcoholFormGramsPerOunce').value) || 29.5;
  
  if (!brand) {
    showToast("Please enter the brand", "error");
    return;
  }
  
  const payload = {
    id: id || undefined,
    barcode,
    brand,
    model,
    fullWeight,
    emptyWeight,
    liquidOunces,
    shotSize,
    gramsPerOunce,
    currentVolumeOunces: liquidOunces
  };
  
  try {
    const res = await fetch(`${SERVER_URL}/api/alcohol`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      showToast("Bottle saved successfully", "success");
      clearAlcoholForm();
      loadAlcoholCatalog();
    }
  } catch (err) {
    console.error(err);
    showToast("Error saving bottle", "error");
  }
}
window.saveAlcoholProductFromForm = saveAlcoholProductFromForm;

async function editAlcoholProduct(id) {
  try {
    const res = await fetch(`${SERVER_URL}/api/alcohol`);
    if (res.ok) {
      const list = await res.json();
      const p = list.find(item => item.id === id);
      if (p) {
        document.getElementById('alcoholFormId').value = p.id;
        document.getElementById('alcoholFormBarcode').value = p.barcode || '';
        document.getElementById('alcoholFormBrand').value = p.brand;
        document.getElementById('alcoholFormModel').value = p.model || '';
        document.getElementById('alcoholFormFullWeight').value = p.fullWeight;
        document.getElementById('alcoholFormEmptyWeight').value = p.emptyWeight;
        document.getElementById('alcoholFormLiquidOunces').value = p.liquidOunces;
        document.getElementById('alcoholFormShotSize').value = p.shotSize;
        document.getElementById('alcoholFormGramsPerOunce').value = p.gramsPerOunce || 29.5;
      }
    }
  } catch (err) {
    console.error(err);
  }
}
window.editAlcoholProduct = editAlcoholProduct;

async function deleteAlcoholProduct(id) {
  if (!confirm("Delete this bottle from catalog?")) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/alcohol/${id}`, { method: 'DELETE' });
    if (res.ok) {
      showToast("Bottle deleted", "success");
      loadAlcoholCatalog();
    }
  } catch (err) {
    console.error(err);
  }
}
window.deleteAlcoholProduct = deleteAlcoholProduct;

async function loadAlcoholReports() {
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/shifts`);
    if (res.ok) {
      const list = await res.json();
      const tbody = document.getElementById('alcoholReportsTableBody');
      tbody.innerHTML = '';
      
      list.reverse().forEach(s => {
        const dateStr = new Date(s.dateStarted).toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' });
        const tr = document.createElement('tr');
        tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
        tr.innerHTML = `
          <td style="padding: 6px 4px;">${dateStr}</td>
          <td style="padding: 6px 4px;">${s.bartenderName}</td>
          <td style="padding: 6px 4px;"><span class="badge" style="background-color: ${s.status === 'open' ? '#30d158' : '#8e8e93'}; color: #000; font-size:9px; padding: 2px 4px;">${s.status.toUpperCase()}</span></td>
          <td style="padding: 6px 4px; text-align: right;">
            <button class="btn-modal primary" onclick="viewAlcoholReport('${s.id}')" style="margin: 0; padding: 2px 6px; font-size: 10px; height: 18px;">View</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    }
  } catch (err) {
    console.error(err);
  }
}
window.loadAlcoholReports = loadAlcoholReports;

let selectedViewReportId = null;

async function viewAlcoholReport(id) {
  selectedViewReportId = id;
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/shifts`);
    if (res.ok) {
      const list = await res.json();
      const shift = list.find(s => s.id === id);
      if (shift) {
        document.getElementById('btnPrintBartenderReport').disabled = false;
        
        let html = `
          <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-color); padding: 10px; border-radius: 6px; margin-bottom: 10px;">
            <strong>Bartender:</strong> ${shift.bartenderName}<br>
            <strong>Started:</strong> ${new Date(shift.dateStarted).toLocaleString()}<br>
            <strong>Ended:</strong> ${shift.dateEnded ? new Date(shift.dateEnded).toLocaleString() : 'Active Shift / Open'}<br>
            <strong>Status:</strong> ${shift.status.toUpperCase()}
          </div>
          <table style="width: 100%; border-collapse: collapse; font-size: 10px; text-align: left; color:#fff;">
            <thead>
              <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); font-weight: bold;">
                <th style="padding: 4px;">Product</th>
                <th style="padding: 4px;">Weights (I/F)</th>
                <th style="padding: 4px;">Start Oz</th>
                <th style="padding: 4px;">Sold Oz</th>
                <th style="padding: 4px;">End Oz</th>
                <th style="padding: 4px; text-align: right;">Difference</th>
              </tr>
            </thead>
            <tbody>
        `;
        
        shift.inventory.forEach(item => {
          const diffColor = item.discrepancyOunces > 0.5 ? 'var(--danger-color)' : (item.discrepancyOunces < -0.5 ? '#30d158' : '#fff');
          const diffSign = item.discrepancyOunces > 0 ? '+' : '';
          
          let alertHtml = '';
          if (item.scannedWeight !== null && item.scannedWeight !== undefined && Math.abs(item.scannedWeight - item.startWeight) > 1) {
            const diffG = item.startWeight - item.scannedWeight;
            const diffOz = diffG / item.gramsPerOunce;
            alertHtml = `<br><span style="color:#ff9f0a; font-size:8px; font-weight:bold;">⚠️ AUDIT: Night claim ${item.scannedWeight}g vs Morning actual ${item.startWeight}g (${diffG > 0 ? '+' : ''}${diffG}g / ${diffOz > 0 ? '+' : ''}${diffOz.toFixed(1)} oz)</span>`;
          }
          
          html += `
            <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
              <td style="padding: 4px;"><strong>${item.brand}</strong> ${item.model || ''}${alertHtml}</td>
              <td style="padding: 4px;">${item.startWeight}g / ${item.endWeight || 0}g</td>
              <td style="padding: 4px;">${item.startOunces.toFixed(2)} oz</td>
              <td style="padding: 4px;">${item.soldOunces.toFixed(2)} oz</td>
              <td style="padding: 4px;">${item.endOunces.toFixed(2)} oz</td>
              <td style="padding: 4px; text-align: right; color: ${diffColor}; font-weight: bold;">${diffSign}${item.discrepancyOunces.toFixed(2)} oz</td>
            </tr>
          `;
        });
        
        html += `
            </tbody>
          </table>
        `;
        document.getElementById('alcoholReportDetailContent').innerHTML = html;
      }
    }
  } catch (err) {
    console.error(err);
  }
}
window.viewAlcoholReport = viewAlcoholReport;

// ==========================================
// --- BARTENDER DASHBOARD & SHIFT FLOW ---
// ==========================================
let activeBartenderShift = null;

async function openBartenderDashboard() {
  document.getElementById('modalBartenderDashboard').style.display = 'flex';
  
  const printBtn = document.getElementById('btnPrintBartenderReport');
  if (printBtn) {
    printBtn.replaceWith(printBtn.cloneNode(true));
    document.getElementById('btnPrintBartenderReport').addEventListener('click', () => {
      if (selectedViewReportId) printBartenderReportOnServer(selectedViewReportId);
    });
  }
  
  await loadBartenderShiftStatus();
}
window.openBartenderDashboard = openBartenderDashboard;

function closeBartenderDashboard() {
  document.getElementById('modalBartenderDashboard').style.display = 'none';
}
window.closeBartenderDashboard = closeBartenderDashboard;

async function loadBartenderShiftStatus() {
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/shift`);
    const statusText = document.getElementById('bartenderShiftStatusText');
    const actionsDiv = document.getElementById('bartenderShiftActions');
    const contentDiv = document.getElementById('bartenderShiftContent');
    
    if (res.ok && res.status !== 204) {
      activeBartenderShift = await res.json();
    } else {
      activeBartenderShift = null;
    }
    
    if (!activeBartenderShift) {
      statusText.innerHTML = `<span style="color: var(--danger-color); font-weight: bold;">🔴 Closed</span>`;
      actionsDiv.innerHTML = `<button class="btn-modal primary" onclick="startBartenderShiftSetup()" style="margin: 0; padding: 6px 12px; font-size: 11px; background-color: var(--accent-color); color: #000; font-weight: bold;">🔑 Open Bar Shift</button>`;
      
      contentDiv.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; gap: 15px; color: var(--text-secondary); text-align: center; padding: 40px 20px;">
          <div style="font-size: 40px;">🍾</div>
          <div>
            <h4 style="color:#fff; margin: 0 0 5px 0;">Start Bar Ounce Control</h4>
            <p style="margin: 0; font-size: 11px; max-width: 320px;">The bartender must open their shift by weighing full/partial bottles in grams before serving drinks.</p>
          </div>
          <button class="btn-modal primary" onclick="startBartenderShiftSetup()" style="margin: 0; padding: 10px 20px; font-size: 12px; background-color: var(--accent-color); color: #000; font-weight: bold;">Open Shift Now</button>
        </div>
      `;
    } else {
      statusText.innerHTML = `
        <span style="color: #30d158; font-weight: bold;">🟢 Active Shift: ${activeBartenderShift.bartenderName}</span><br>
        <span style="font-size:10px; color:var(--text-secondary);">Started: ${new Date(activeBartenderShift.dateStarted).toLocaleTimeString()}</span>
      `;
      actionsDiv.innerHTML = `<button class="btn-modal danger" onclick="closeActiveBartenderShiftSetup()" style="margin: 0; padding: 6px 12px; font-size: 11px; background-color: var(--danger-color); color: #fff; font-weight: bold;">🔒 Close Bar Shift</button>`;
      
      let html = `
        <div style="display: flex; flex-direction: column; flex: 1; min-height: 0;">
          <div style="font-weight: bold; font-size: 12px; color: #fff; margin-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px;">
            Active Inventory (Initial weights registered)
          </div>
          <div style="flex: 1; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px; padding: 6px; background: rgba(0,0,0,0.1);">
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #fff;">
              <thead>
                <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); text-align: left;">
                  <th style="padding: 4px;">Barcode</th>
                  <th style="padding: 4px;">Brand / Model</th>
                  <th style="padding: 4px;">Start Weight (g)</th>
                  <th style="padding: 4px;">Start Volume (oz)</th>
                </tr>
              </thead>
              <tbody>
      `;
      
      activeBartenderShift.inventory.forEach(item => {
        html += `
          <tr style="border-bottom: 1px solid rgba(255,255,255,0.02);">
            <td style="padding: 4px;">${item.barcode || 'N/A'}</td>
            <td style="padding: 4px;"><strong>${item.brand}</strong> ${item.model || ''}</td>
            <td style="padding: 4px;">${item.startWeight}g</td>
            <td style="padding: 4px; color: var(--accent-color); font-weight: bold;">${item.startOunces.toFixed(1)} oz</td>
          </tr>
        `;
      });
      
      html += `
              </tbody>
            </table>
          </div>
          <div style="font-size: 10px; color: var(--text-secondary); margin-top: 10px; line-height: 1.4;">
            💡 Drinks sold by waitresses on tickets will automatically reduce theoretical ounces at shift end.
          </div>
        </div>
      `;
      contentDiv.innerHTML = html;
    }
  } catch (err) {
    console.error(err);
  }
}
window.loadBartenderShiftStatus = loadBartenderShiftStatus;

async function startBartenderShiftSetup() {
  try {
    const res = await fetch(`${SERVER_URL}/api/alcohol`);
    if (!res.ok) return;
    const bottles = await res.json();
    
    if (bottles.length === 0) {
      showToast("Please configure bottles in manager catalog first", "warning");
      return;
    }
    
    const contentDiv = document.getElementById('bartenderShiftContent');
    
    let rowsHtml = '';
    bottles.forEach((b, idx) => {
      rowsHtml += `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);" id="row_start_${b.barcode || b.id}">
          <td style="padding: 6px 4px;">${b.barcode || 'N/A'}</td>
          <td style="padding: 6px 4px;"><strong>${b.brand}</strong> ${b.model || ''}</td>
          <td style="padding: 6px 4px;">E: ${b.emptyWeight}g | F: ${b.fullWeight}g</td>
          <td style="padding: 6px 4px; text-align: right;">
            <input type="number" id="weight_start_${b.id}" class="form-input-text alcohol-start-weight-input" data-id="${b.id}" style="width: 100px; padding: 4px; text-align: center; font-size: 12px; font-weight: bold;" placeholder="Grams" required>
          </td>
        </tr>
      `;
    });
    
    contentDiv.innerHTML = `
      <div style="display: flex; flex-direction: column; flex: 1; min-height: 0; text-align: left;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
          <div>
            <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px; font-weight: bold;">Bartender Name</label>
            <input type="text" id="setupBartenderName" class="form-input-text" style="width: 100%; padding: 6px;" placeholder="Enter your name" value="${currentCashierName || ''}">
          </div>
          <div>
            <label style="font-size: 11px; color: var(--text-secondary); display: block; margin-bottom: 4px; font-weight: bold;">Scan Bottle Barcode</label>
            <input type="text" id="bartenderBarcodeSearch" class="form-input-text" style="width: 100%; padding: 6px;" placeholder="Scan barcode to focus" onkeydown="handleBartenderBarcodeSearch(event, 'start')">
          </div>
        </div>
        
        <div style="flex: 1; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px; padding: 6px; background: rgba(0,0,0,0.1);">
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #fff;">
            <thead>
              <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); text-align: left; font-weight: bold;">
                <th style="padding: 6px 4px;">Barcode</th>
                <th style="padding: 6px 4px;">Brand / Product</th>
                <th style="padding: 6px 4px;">Limits</th>
                <th style="padding: 6px 4px; text-align: right; width: 110px;">Start Weight (g)</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>
        
        <div style="display: flex; gap: 8px; margin-top: 10px;">
          <button class="btn-modal secondary" onclick="loadBartenderShiftStatus()" style="flex: 1; padding: 8px; margin: 0;">Cancel</button>
          <button class="btn-modal primary" onclick="confirmBartenderShiftStart()" style="flex: 1.5; padding: 8px; margin: 0; background-color: var(--success-color); color: #000; font-weight: bold;">🚀 Open Shift with Weights</button>
        </div>
      </div>
    `;
    setTimeout(() => {
      document.getElementById('setupBartenderName').focus();
    }, 100);
  } catch (err) {
    console.error(err);
  }
}
window.startBartenderShiftSetup = startBartenderShiftSetup;

function handleBartenderBarcodeSearch(event, mode) {
  if (event.key === 'Enter') {
    event.preventDefault();
    const barcode = event.target.value.trim();
    event.target.value = '';
    
    if (barcode.startsWith('W-')) {
      const parts = barcode.split('-');
      if (parts.length === 3) {
        const bottleId = parts[1];
        const grams = parseFloat(parts[2]);
        const input = document.getElementById(`weight_${mode}_${bottleId}`);
        if (input) {
          input.setAttribute('data-scanned-weight', grams);
          input.value = grams;
          input.dispatchEvent(new Event('input'));
          const targetRow = document.getElementById(`row_${mode}_${bottleId}`);
          if (targetRow) {
            targetRow.style.backgroundColor = 'rgba(48, 209, 88, 0.2)';
            setTimeout(() => { targetRow.style.backgroundColor = ''; }, 1500);
          }
          showToast(`Bottle auto-filled with ${grams}g`, 'success');
          return;
        }
      }
    }
    
    const row = document.getElementById(`row_${mode}_${barcode}`);
    if (row) {
      row.style.backgroundColor = 'rgba(255, 159, 10, 0.15)';
      setTimeout(() => { row.style.backgroundColor = ''; }, 1500);
      
      const inputs = row.querySelectorAll('input[type="number"]');
      if (inputs.length > 0) {
        inputs[0].focus();
        inputs[0].select();
      }
    } else {
      showToast("Bottle not found in inventory", "error");
    }
  }
}
window.handleBartenderBarcodeSearch = handleBartenderBarcodeSearch;

async function confirmBartenderShiftStart() {
  const bartenderName = document.getElementById('setupBartenderName').value.trim();
  if (!bartenderName) {
    showToast("Please enter bartender name", "error");
    return;
  }
  
  const inputs = document.querySelectorAll('.alcohol-start-weight-input');
  const inventory = [];
  let allFilled = true;
  
  for (let input of inputs) {
    const val = parseFloat(input.value);
    if (isNaN(val) || val <= 0) {
      allFilled = false;
      input.style.borderColor = 'var(--danger-color)';
    } else {
      input.style.borderColor = '';
    }
  }
  
  if (!allFilled) {
    showToast("Please enter starting weights for all bottles", "error");
    return;
  }
  
  try {
    const resCatalog = await fetch(`${SERVER_URL}/api/alcohol`);
    if (!resCatalog.ok) return;
    const bottles = await resCatalog.json();
    
    inputs.forEach(input => {
      const id = input.getAttribute('data-id');
      const b = bottles.find(item => item.id === id);
      if (b) {
        const scanW = parseFloat(input.getAttribute('data-scanned-weight'));
        inventory.push({
          ...b,
          startWeight: parseFloat(input.value),
          scannedWeight: isNaN(scanW) ? null : scanW
        });
      }
    });
    
    const res = await fetch(`${SERVER_URL}/api/bartender/shift/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bartenderName, inventory })
    });
    
    if (res.ok) {
      showToast("Bar shift opened successfully", "success");
      loadBartenderShiftStatus();
    }
  } catch (err) {
    console.error(err);
  }
}
window.confirmBartenderShiftStart = confirmBartenderShiftStart;

async function closeActiveBartenderShiftSetup() {
  if (!confirm("Do you want to close the bar shift and proceed to weigh final bottles?")) return;
  
  try {
    const contentDiv = document.getElementById('bartenderShiftContent');
    const actionsDiv = document.getElementById('bartenderShiftActions');
    
    actionsDiv.innerHTML = '';
    
    let rowsHtml = '';
    activeBartenderShift.inventory.forEach(b => {
      rowsHtml += `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);" id="row_end_${b.barcode || b.id}">
          <td style="padding: 6px 4px;">${b.barcode || 'N/A'}</td>
          <td style="padding: 6px 4px;"><strong>${b.brand}</strong> ${b.model || ''}</td>
          <td style="padding: 6px 4px;">Start: ${b.startWeight}g (${b.startOunces.toFixed(1)} oz)</td>
          <td style="padding: 6px 4px; text-align: right; display: flex; align-items: center; justify-content: flex-end; gap: 4px;">
            <input type="number" id="weight_end_${b.id}" class="form-input-text alcohol-end-weight-input" data-id="${b.id}" style="width: 70px; padding: 4px; text-align: center; font-size: 12px; font-weight: bold; margin: 0;" placeholder="Grams" required>
            <button class="btn-modal" onclick="printBottleLabel('${b.id}', 'weight_end_${b.id}')" style="margin: 0; padding: 4px 6px; font-size: 10px; background-color: #ff9f0a; color: #000; height: 26px; font-weight: bold;" title="Print Bottle Label">🏷️</button>
          </td>
        </tr>
      `;
    });
    
    contentDiv.innerHTML = `
      <div style="display: flex; flex-direction: column; flex: 1; min-height: 0; text-align: left;">
        <div style="display:grid; grid-template-columns: 1.5fr 1.5fr; gap:10px; margin-bottom: 8px; background: rgba(255,59,48,0.05); padding: 8px; border-radius: 6px; border: 1px solid rgba(255,59,48,0.2);">
          <div>
            <strong style="color:var(--danger-color); font-size:12px;">CLOSING SHIFT OF: ${activeBartenderShift.bartenderName.toUpperCase()}</strong>
          </div>
          <div>
            <input type="text" id="bartenderBarcodeSearchEnd" class="form-input-text" style="width: 100%; padding: 4px; font-size:11px;" placeholder="🔍 Scan bottle to focus" onkeydown="handleBartenderBarcodeSearch(event, 'end')">
          </div>
        </div>
        
        <div style="flex: 1; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px; padding: 6px; background: rgba(0,0,0,0.1);">
          <table style="width: 100%; border-collapse: collapse; font-size: 11px; color: #fff;">
            <thead>
              <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); text-align: left; font-weight: bold;">
                <th style="padding: 6px 4px;">Barcode</th>
                <th style="padding: 6px 4px;">Brand / Product</th>
                <th style="padding: 6px 4px;">Initial</th>
                <th style="padding: 6px 4px; text-align: right; width: 110px;">End Weight (g)</th>
              </tr>
            </thead>
            <tbody>
              ${rowsHtml}
            </tbody>
          </table>
        </div>
        
        <div style="display: flex; gap: 8px; margin-top: 10px;">
          <button class="btn-modal secondary" onclick="loadBartenderShiftStatus()" style="flex: 1; padding: 8px; margin: 0;">Cancel</button>
          <button class="btn-modal primary" onclick="confirmBartenderShiftClose()" style="flex: 1.5; padding: 8px; margin: 0; background-color: var(--danger-color); color: #fff; font-weight: bold;">🔒 Save Weights & Reconcile Discrepancies</button>
        </div>
      </div>
    `;
    setTimeout(() => {
      document.getElementById('bartenderBarcodeSearchEnd').focus();
    }, 100);
  } catch (err) {
    console.error(err);
  }
}
window.closeActiveBartenderShiftSetup = closeActiveBartenderShiftSetup;

async function confirmBartenderShiftClose() {
  const inputs = document.querySelectorAll('.alcohol-end-weight-input');
  const inventoryData = [];
  let allFilled = true;
  
  for (let input of inputs) {
    const val = parseFloat(input.value);
    if (isNaN(val) || val <= 0) {
      allFilled = false;
      input.style.borderColor = 'var(--danger-color)';
    } else {
      input.style.borderColor = '';
    }
  }
  
  if (!allFilled) {
    showToast("Please enter ending weights for all bottles", "error");
    return;
  }
  
  inputs.forEach(input => {
    inventoryData.push({
      id: input.getAttribute('data-id'),
      endWeight: parseFloat(input.value)
    });
  });
  
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/shift/end`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ inventory: inventoryData })
    });
    
    if (res.ok) {
      const closedReport = await res.json();
      showToast("Bar shift closed successfully. Reconciliation generated.", "success");
      renderBartenderShiftReportSummary(closedReport);
    }
  } catch (err) {
    console.error(err);
    showToast("Error closing bar shift", "error");
  }
}
window.confirmBartenderShiftClose = confirmBartenderShiftClose;

function renderBartenderShiftReportSummary(report) {
  const contentDiv = document.getElementById('bartenderShiftContent');
  const statusText = document.getElementById('bartenderShiftStatusText');
  const actionsDiv = document.getElementById('bartenderShiftActions');
  
  statusText.innerHTML = `<span style="color: var(--danger-color); font-weight: bold;">🔴 Closed</span>`;
  actionsDiv.innerHTML = `<button class="btn-modal primary" onclick="loadBartenderShiftStatus()" style="margin: 0; padding: 6px 12px; font-size: 11px; background-color: var(--accent-color); color: #000; font-weight: bold;">Finish</button>`;
  
  let rowsHtml = '';
  report.inventory.forEach(item => {
    const diff = item.discrepancyOunces;
    const diffColor = diff > 0.5 ? 'var(--danger-color)' : (diff < -0.5 ? '#30d158' : '#fff');
    const diffSign = diff > 0 ? '+' : '';
    
    let alertHtml = '';
    if (item.scannedWeight !== null && item.scannedWeight !== undefined && Math.abs(item.scannedWeight - item.startWeight) > 1) {
      const diffG = item.startWeight - item.scannedWeight;
      const diffOz = diffG / item.gramsPerOunce;
      alertHtml = `<br><span style="color:#ff9f0a; font-size:8px; font-weight:bold;">⚠️ AUDIT: Night claim ${item.scannedWeight}g vs Morning actual ${item.startWeight}g (${diffG > 0 ? '+' : ''}${diffG}g / ${diffOz > 0 ? '+' : ''}${diffOz.toFixed(1)} oz)</span>`;
    }
    
    rowsHtml += `
      <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
        <td style="padding: 4px;"><strong>${item.brand}</strong> ${item.model || ''}${alertHtml}</td>
        <td style="padding: 4px;">${item.startOunces.toFixed(1)} oz</td>
        <td style="padding: 4px;">${item.soldOunces.toFixed(1)} oz</td>
        <td style="padding: 4px;">${item.endOunces.toFixed(1)} oz</td>
        <td style="padding: 4px; text-align: right; color: ${diffColor}; font-weight: bold;">${diffSign}${diff.toFixed(2)} oz</td>
      </tr>
    `;
  });
  
  contentDiv.innerHTML = `
    <div style="display: flex; flex-direction: column; flex: 1; min-height: 0; text-align: left;">
      <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-color); border-radius: 6px; padding: 10px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <strong style="color:var(--accent-color); font-size:12px;">📊 BAR SHIFT RECONCILIATION REPORT</strong><br>
          <span style="font-size:10px; color:var(--text-secondary);">Bartender: ${report.bartenderName} | Ended: ${new Date(report.dateEnded).toLocaleTimeString()}</span>
        </div>
        <button class="btn-modal primary" onclick="printBartenderReportOnServer('${report.id}')" style="margin: 0; padding: 6px 12px; font-size: 11px; background-color: #5856d6; color: #fff; font-weight: bold;">🧾 Print Report</button>
      </div>
      
      <div style="flex: 1; overflow-y: auto; border: 1px solid var(--border-color); border-radius: 6px; padding: 6px; background: rgba(0,0,0,0.15);">
        <table style="width: 100%; border-collapse: collapse; font-size: 10px; color: #fff;">
          <thead>
            <tr style="border-bottom: 1px solid var(--border-color); color: var(--text-secondary); text-align: left; font-weight: bold;">
              <th style="padding: 4px;">Bottle</th>
              <th style="padding: 4px;">Start Oz</th>
              <th style="padding: 4px;">Sold Oz (POS)</th>
              <th style="padding: 4px;">End Oz</th>
              <th style="padding: 4px; text-align: right;">Discrepancy (Oz)</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>
      </div>
      
      <div style="font-size: 9px; color: var(--text-secondary); margin-top: 8px; line-height: 1.3;">
        * Positive discrepancy (+) indicates less liquid than registered sold in POS (shrinkage).<br>
        * Negative discrepancy (-) indicates more liquid than registered sold in POS.
      </div>
    </div>
  `;
}

async function printBartenderReportOnServer(reportId) {
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/shift-print/${reportId}`, {
      method: 'POST'
    });
    if (res.ok) {
      showToast("Report sent to printer", "success");
    } else {
      showToast("Error printing report", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error printing report", "error");
  }
}
window.printBartenderReportOnServer = printBartenderReportOnServer;

// ==========================================
// --- BARTENDER SECURITY AUTH MODAL ---
// ==========================================
let bartenderAuthPasscode = '';

function openBartenderAuthModal() {
  const isEs = posSettings && posSettings.language === 'es';
  const barStatus = window.lastLicenseData ? window.lastLicenseData.barStatus : 'unregistered';
  
  if (barStatus !== 'active' && barStatus !== 'demo') {
    showToast(isEs 
      ? "⚠️ Licencia Premium de Bar Hub requerida. Regístrela en Configuración." 
      : "⚠️ Premium Bar Hub License required. Register it in Setup settings.", 
      "warning"
    );
    return;
  }

  bartenderAuthPasscode = '';
  const input = document.getElementById('bartenderAuthPasscode');
  if (input) input.value = '';
  document.getElementById('modalBartenderAuth').style.display = 'flex';
}
window.openBartenderAuthModal = openBartenderAuthModal;

function pressBartenderAuthKey(key) {
  if (bartenderAuthPasscode.length < 10) {
    bartenderAuthPasscode += key;
    const input = document.getElementById('bartenderAuthPasscode');
    if (input) input.value = bartenderAuthPasscode;
  }
}
window.pressBartenderAuthKey = pressBartenderAuthKey;

function clearBartenderAuthKey() {
  bartenderAuthPasscode = '';
  const input = document.getElementById('bartenderAuthPasscode');
  if (input) input.value = '';
}
window.clearBartenderAuthKey = clearBartenderAuthKey;

async function submitBartenderAuth() {
  if (!bartenderAuthPasscode) {
    showToast("Please enter passcode", "error");
    return;
  }
  
  try {
    const emps = await getEmployeesList();
    const matchedEmp = emps.find(e => e.passcode === bartenderAuthPasscode);
    clearBartenderAuthKey();
    
    if (matchedEmp) {
      const r = (matchedEmp.role || '').toLowerCase();
      if (r === 'bartender' || r === 'manager' || r === 'admin') {
        showToast(`Welcome ${matchedEmp.name}`, 'success');
        document.getElementById('modalBartenderAuth').style.display = 'none';
        openBartenderDashboard();
      } else {
        showToast("Access Denied: Only Bartenders or Managers allowed", "error");
      }
    } else {
      showToast("Invalid Passcode", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Login error", "error");
  }
}
window.submitBartenderAuth = submitBartenderAuth;

// ==========================================
// --- FLOATING TOUCH KEYBOARD & KEYPAD ---
// ==========================================
let activeTouchInput = null;

function initAlcoholFormTouchKeyboards() {
  // Disabled - all touch inputs are now integrated with the bottom-aligned globalVirtualKeyboard
}

function openTouchKeyboard(targetInput, type) {
  activeTouchInput = targetInput;
  
  let keyboardModal = document.getElementById('modalFloatingTouchKeyboard');
  if (!keyboardModal) {
    keyboardModal = document.createElement('div');
    keyboardModal.id = 'modalFloatingTouchKeyboard';
    keyboardModal.className = 'modal';
    keyboardModal.style.cssText = "display: none; align-items: center; justify-content: center; background: rgba(0,0,0,0.8); z-index: 32000;";
    
    keyboardModal.innerHTML = `
      <div class="modal-content" style="max-width: 500px; width: 90%; padding: 15px; background: var(--bg-secondary); border: 1px solid var(--border-color); border-radius: 12px; text-align: center;">
        <h4 id="touchKeyboardTitle" style="margin: 0 0 10px 0; color: #fff; font-size:14px;">Touch Input</h4>
        <input type="text" id="touchKeyboardDisplay" style="width: 100%; padding: 8px; font-size: 18px; font-weight: bold; text-align: center; background: var(--bg-primary); color: #fff; border: 1px solid var(--border-color); border-radius: 6px; margin-bottom: 12px;">
        <div id="touchKeyboardKeysContainer" style="display: grid; gap: 6px; margin-bottom: 12px;"></div>
        <div style="display: flex; justify-content: space-between; gap: 8px;">
          <button class="btn-modal secondary" onclick="closeTouchKeyboard()" style="margin:0; flex:1; height: 35px; font-size: 12px;">Cancel</button>
          <button class="btn-modal danger" onclick="clearTouchKeyboard()" style="margin:0; flex:0.8; height: 35px; font-size: 12px; background-color: var(--danger-color); color: #fff;">Clear</button>
          <button class="btn-modal primary" onclick="acceptTouchKeyboard()" style="margin:0; flex:1.5; height: 35px; font-size: 12px; background-color: var(--success-color); color: #000; font-weight: bold;">Accept / OK</button>
        </div>
      </div>
    `;
    document.body.appendChild(keyboardModal);
  }

  const title = document.getElementById('touchKeyboardTitle');
  title.textContent = `Enter ${targetInput.placeholder || 'Value'}`;
  
  const display = document.getElementById('touchKeyboardDisplay');
  display.value = targetInput.value;

  const container = document.getElementById('touchKeyboardKeysContainer');
  container.innerHTML = '';
  
  if (type === 'numeric') {
    container.style.gridTemplateColumns = 'repeat(3, 1fr)';
    const keys = [
      '1', '2', '3',
      '4', '5', '6',
      '7', '8', '9',
      '.', '0', '⌫'
    ];
    keys.forEach(k => {
      const btn = document.createElement('button');
      btn.className = 'btn-modal secondary';
      btn.style.cssText = "margin: 0; padding: 10px 0; font-weight: bold; font-size: 16px; height: 42px; border-radius: 6px;";
      btn.textContent = k;
      btn.addEventListener('click', () => handleTouchKeyClick(k, 'numeric'));
      container.appendChild(btn);
    });
  } else {
    container.style.gridTemplateColumns = 'repeat(6, 1fr)';
    const keys = [
      '1', '2', '3', '4', '5', '6',
      '7', '8', '9', '0', '-', '_',
      'Q', 'W', 'E', 'R', 'T', 'Y',
      'U', 'I', 'O', 'P', 'A', 'S',
      'D', 'F', 'G', 'H', 'J', 'K',
      'L', 'Z', 'X', 'C', 'V', 'B',
      'N', 'M', ' ', '.', '/', '⌫'
    ];
    keys.forEach(k => {
      const btn = document.createElement('button');
      btn.className = 'btn-modal secondary';
      btn.style.cssText = "margin: 0; padding: 6px 0; font-weight: bold; font-size: 13px; height: 36px; border-radius: 6px;";
      if (k === ' ') {
        btn.textContent = 'Space';
        btn.style.gridColumn = 'span 2';
      } else {
        btn.textContent = k;
      }
      btn.addEventListener('click', () => handleTouchKeyClick(k, 'alphanumeric'));
      container.appendChild(btn);
    });
  }

  keyboardModal.style.display = 'flex';
}
window.openTouchKeyboard = openTouchKeyboard;

function handleTouchKeyClick(key, type) {
  const display = document.getElementById('touchKeyboardDisplay');
  if (key === '⌫') {
    display.value = display.value.slice(0, -1);
  } else {
    display.value += key;
  }
}

function closeTouchKeyboard() {
  const keyboardModal = document.getElementById('modalFloatingTouchKeyboard');
  if (keyboardModal) keyboardModal.style.display = 'none';
}
window.closeTouchKeyboard = closeTouchKeyboard;

function clearTouchKeyboard() {
  const display = document.getElementById('touchKeyboardDisplay');
  if (display) display.value = '';
}
window.clearTouchKeyboard = clearTouchKeyboard;

function acceptTouchKeyboard() {
  if (activeTouchInput) {
    const display = document.getElementById('touchKeyboardDisplay');
    activeTouchInput.value = display.value;
    activeTouchInput.dispatchEvent(new Event('input'));
  }
  closeTouchKeyboard();
}
window.acceptTouchKeyboard = acceptTouchKeyboard;

document.addEventListener('DOMContentLoaded', () => {
  initAlcoholFormTouchKeyboards();
});

async function printBottleLabel(bottleId, inputId) {
  const weightVal = parseFloat(document.getElementById(inputId).value);
  if (isNaN(weightVal) || weightVal <= 0) {
    showToast("Please enter a valid weight to print label", "warning");
    return;
  }
  
  try {
    const res = await fetch(`${SERVER_URL}/api/bartender/print-bottle-label`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: bottleId, grams: weightVal })
    });
    if (res.ok) {
      showToast("Label printed successfully", "success");
    } else {
      showToast("Error printing label", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error printing label", "error");
  }
}
window.printBottleLabel = printBottleLabel;

let activeCrossBillIndexes = [];

function triggerBulkGiftTable() {
  const checkedIndexes = [];
  document.querySelectorAll('.cart-item-select').forEach(input => {
    if (input.checked) {
      checkedIndexes.push(parseInt(input.getAttribute('data-index')));
    }
  });
  
  if (checkedIndexes.length === 0) {
    const isEs = posSettings && posSettings.language === 'es';
    showToast(isEs ? "Por favor seleccione al menos un artículo de la comanda" : "Please select at least one cart item", "warning");
    return;
  }
  
  activeCrossBillIndexes = checkedIndexes;
  const desc = checkedIndexes.length === 1 
    ? `Gifting: ${cart[checkedIndexes[0]].quantity}x ${cart[checkedIndexes[0]].name}`
    : `Gifting ${checkedIndexes.length} selected items`;
    
  document.getElementById('crossBillItemDesc').textContent = desc;
  document.getElementById('crossBillTargetTable').value = '';
  document.getElementById('modalCrossBill').style.display = 'flex';
}
window.triggerBulkGiftTable = triggerBulkGiftTable;

function closeCrossBillModal() {
  document.getElementById('modalCrossBill').style.display = 'none';
  activeCrossBillIndexes = [];
}
window.closeCrossBillModal = closeCrossBillModal;

function pressCrossBillKey(key) {
  const input = document.getElementById('crossBillTargetTable');
  input.value += key;
}
window.pressCrossBillKey = pressCrossBillKey;

function clearCrossBillKey() {
  document.getElementById('crossBillTargetTable').value = '';
}
window.clearCrossBillKey = clearCrossBillKey;

async function submitCrossBill() {
  const targetTable = document.getElementById('crossBillTargetTable').value.trim();
  if (!targetTable) {
    showToast("Please enter target table number", "warning");
    return;
  }
  
  const sourceTable = currentOrder ? (currentOrder.tableName || '').replace(/Table/i, '').replace(/Mesa/i, '').replace(' ', '').trim() : (selectedTable || '8').toString().replace(/Table/i, '').replace(/Mesa/i, '').replace(' ', '').trim();
  
  if (targetTable === sourceTable) {
    showToast("Cannot gift to the same table", "warning");
    return;
  }
  
  const isEs = posSettings && posSettings.language === 'es';
  showToast(isEs ? "Enviando artículos..." : "Gifting items...", "info");
  
  let successCount = 0;
  
  for (const idx of activeCrossBillIndexes) {
    const item = cart[idx];
    try {
      const res = await fetch(`${SERVER_URL}/api/orders/cross-bill`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sourceTableName: sourceTable,
          targetTableName: targetTable,
          item: item,
          cashierName: currentCashierName
        })
      });
      
      if (res.ok) {
        item.name = `${item.name.split('(')[0].trim()} (Sent to Table ${targetTable})`;
        successCount++;
      }
    } catch (err) {
      console.error("Error gifting item:", err);
    }
  }
  
  if (successCount > 0) {
    updateCartUI();
    showToast(isEs ? `${successCount} artículos regalados con éxito!` : `${successCount} items gifted successfully!`, "success");
    closeCrossBillModal();
    if (window.ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'ORDER_UPDATED' }));
    }
  } else {
    showToast(isEs ? "Error al regalar artículos" : "Error gifting items", "error");
  }
}
window.submitCrossBill = submitCrossBill;

// --- ACCOUNTS RECEIVABLE (POR COBRAR) FLOW ---
function openSaveReceivableModal() {
  if (!currentOrder || !currentOrder.id) {
    showToast("No active order to save as receivable", "error");
    return;
  }
  document.getElementById('receivableCustName').value = currentOrder.customerName || '';
  document.getElementById('receivableCustPhone').value = currentOrder.customerPhone || '';
  document.getElementById('receivableNotes').value = '';
  document.getElementById('modalSaveReceivable').style.display = 'flex';
}
window.openSaveReceivableModal = openSaveReceivableModal;

function closeSaveReceivableModal() {
  document.getElementById('modalSaveReceivable').style.display = 'none';
}
window.closeSaveReceivableModal = closeSaveReceivableModal;

async function submitSaveReceivable() {
  const custName = document.getElementById('receivableCustName').value.trim();
  const custPhone = document.getElementById('receivableCustPhone').value.trim();
  const notes = document.getElementById('receivableNotes').value.trim();
  
  if (!custName) {
    showToast("Customer Name is required", "warning");
    return;
  }
  if (!notes) {
    showToast("Audit Notes are required", "warning");
    return;
  }
  
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/save-receivable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId: currentOrder.id,
        customerName: custName,
        customerPhone: custPhone,
        notes: notes,
        cashierName: currentCashierName
      })
    });
    
    if (res.ok) {
      showToast("Order saved as Accounts Receivable", "success");
      closeSaveReceivableModal();
      closeCheckoutModal();
      clearCart();
    } else {
      showToast("Error saving receivable", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error saving receivable", "error");
  }
}
window.submitSaveReceivable = submitSaveReceivable;

let cachedReceivables = [];

async function openReceivablesModal() {
  const modalOpt = document.getElementById('modalOptions');
  if (modalOpt) modalOpt.style.display = 'none';
  document.getElementById('modalReceivables').style.display = 'flex';
  await loadReceivablesList();
}
window.openReceivablesModal = openReceivablesModal;

function closeReceivablesModal() {
  document.getElementById('modalReceivables').style.display = 'none';
}
window.closeReceivablesModal = closeReceivablesModal;

async function loadReceivablesList() {
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/receivables`);
    if (res.ok) {
      cachedReceivables = await res.json();
      renderReceivablesTable(cachedReceivables);
    }
  } catch (err) {
    console.error(err);
  }
}
window.loadReceivablesList = loadReceivablesList;

function renderReceivablesTable(list) {
  const tbody = document.getElementById('receivablesTableBody');
  tbody.innerHTML = '';
  
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 12px; color: var(--text-secondary);">No pending debts found / No hay cuentas pendientes.</td></tr>`;
    return;
  }
  
  list.forEach(o => {
    const dateStr = new Date(o.dateCreated).toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' });
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    tr.innerHTML = `
      <td style="padding: 6px;">${dateStr}</td>
      <td style="padding: 6px; font-weight: bold; color: var(--accent-color);">${o.customerName}</td>
      <td style="padding: 6px;">${o.customerPhone || 'N/A'}</td>
      <td style="padding: 6px;">${o.tableName || 'Walk-in'}</td>
      <td style="padding: 6px; font-weight: bold;">$${o.total.toFixed(2)}</td>
      <td style="padding: 6px; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${o.notes}">${o.notes}</td>
      <td style="padding: 6px; text-align: right; display: flex; gap: 4px; justify-content: flex-end;">
        <button class="btn-modal" onclick="payReceivableOrder('${o.id}', 'cash')" style="margin:0; padding:2px 6px; font-size:10px; background-color: var(--success-color); color:#000; height:20px; font-weight:bold;">💵 Cash</button>
        <button class="btn-modal" onclick="payReceivableOrder('${o.id}', 'card')" style="margin:0; padding:2px 6px; font-size:10px; background-color: #0a84ff; color:#fff; height:20px; font-weight:bold;">💳 Card</button>
        <button class="btn-modal danger" onclick="writeOffReceivableCourtesy('${o.id}')" style="margin:0; padding:2px 6px; font-size:10px; background-color: var(--danger-color); color:#fff; height:20px; font-weight:bold;">🎁 Courtesy</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function filterReceivables() {
  const query = document.getElementById('searchReceivablesInput').value.toLowerCase().trim();
  if (!query) {
    renderReceivablesTable(cachedReceivables);
    return;
  }
  const filtered = cachedReceivables.filter(o => 
    (o.customerName || '').toLowerCase().includes(query) ||
    (o.customerPhone || '').toLowerCase().includes(query)
  );
  renderReceivablesTable(filtered);
}
window.filterReceivables = filterReceivables;

async function payReceivableOrder(orderId, paymentMethod) {
  if (!confirm(`Mark this account as PAID via ${paymentMethod.toUpperCase()}?`)) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/orders/pay-receivable`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        orderId: orderId,
        paymentMethod: paymentMethod,
        cashierName: currentCashierName
      })
    });
    if (res.ok) {
      showToast("Account paid successfully", "success");
      await loadReceivablesList();
    } else {
      showToast("Error processing payment", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error processing payment", "error");
  }
}
window.payReceivableOrder = payReceivableOrder;

let managerOverrideSuccessCallback = null;

function openManagerOverrideModal(onSuccessCallback) {
  managerOverrideSuccessCallback = onSuccessCallback;
  document.getElementById('managerOverridePasscode').value = '';
  document.getElementById('modalManagerOverride').style.display = 'flex';
}

function closeManagerOverrideModal() {
  document.getElementById('modalManagerOverride').style.display = 'none';
  managerOverrideSuccessCallback = null;
}
window.closeManagerOverrideModal = closeManagerOverrideModal;

function pressManagerOverrideKey(key) {
  const input = document.getElementById('managerOverridePasscode');
  input.value += key;
}
window.pressManagerOverrideKey = pressManagerOverrideKey;

function clearManagerOverrideKey() {
  document.getElementById('managerOverridePasscode').value = '';
}
window.clearManagerOverrideKey = clearManagerOverrideKey;

async function submitManagerOverride() {
  const code = document.getElementById('managerOverridePasscode').value;
  try {
    const res = await fetch(`${SERVER_URL}/api/employees`);
    if (res.ok) {
      const employees = await res.json();
      const matched = employees.find(e => e.passcode === code);
      if (matched && (matched.role === 'manager' || matched.role === 'admin')) {
        showToast(`Authorized by ${matched.name}`, "success");
        const callback = managerOverrideSuccessCallback;
        closeManagerOverrideModal();
        if (callback) callback(matched.name);
      } else {
        showToast("Invalid passcode or unauthorized role", "error");
        clearManagerOverrideKey();
      }
    }
  } catch (err) {
    console.error(err);
    showToast("Error authorizing override", "error");
  }
}
window.submitManagerOverride = submitManagerOverride;

function writeOffReceivableCourtesy(orderId) {
  openManagerOverrideModal(async (managerName) => {
    try {
      const res = await fetch(`${SERVER_URL}/api/orders/courtesy-receivable`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: orderId,
          approvedBy: managerName
        })
      });
      if (res.ok) {
        showToast("Account cleared as Courtesy", "success");
        await loadReceivablesList();
      } else {
        showToast("Error updating status", "error");
      }
    } catch (err) {
      console.error(err);
      showToast("Error updating status", "error");
    }
  });
}
window.writeOffReceivableCourtesy = writeOffReceivableCourtesy;

// --- TIPS MANAGEMENT FLOW ---
async function saveTipsConfig() {
  const mode = document.getElementById('adminTipsMode').value;
  const feePct = parseFloat(document.getElementById('adminTipsFeePercentage').value) || 0;
  const settingsData = {
    ...posSettings,
    tipsMode: mode,
    tipsFeePercentage: feePct
  };
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsData)
    });
    if (res.ok) {
      posSettings = await res.json();
      showToast("Tips payout mode updated successfully!", "success");
    } else {
      showToast("Error updating payout mode", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error updating payout mode", "error");
  }
}
window.saveTipsConfig = saveTipsConfig;

async function loadTipsReport() {
  const startInput = document.getElementById('tipsReportStartDate');
  const endInput = document.getElementById('tipsReportEndDate');
  if (!startInput.value || !endInput.value) {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    startInput.value = start.toISOString().substring(0, 10);
    endInput.value = now.toISOString().substring(0, 10);
  }

  const startVal = startInput.value;
  const endVal = endInput.value;

  try {
    const res = await fetch(`${SERVER_URL}/api/reports/tips?startDate=${startVal}&endDate=${endVal}`);
    if (res.ok) {
      const list = await res.json();
      renderTipsTable(list);
    }
  } catch (err) {
    console.error(err);
  }
}
window.loadTipsReport = loadTipsReport;

let currentTipsReportList = [];

function renderTipsTable(list) {
  currentTipsReportList = list;
  const tbody = document.getElementById('tipsReportTableBody');
  tbody.innerHTML = '';
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 12px; color: var(--text-secondary);">No tips recorded in this range.</td></tr>`;
    return;
  }

  list.forEach(t => {
    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    const modeText = t.payoutMode === 'daily' ? '💵 Daily Cash' : '💳 Weekly Paycheck';
    tr.innerHTML = `
      <td style="padding: 8px 10px; font-weight: bold; color: var(--accent-color);">${t.employee}</td>
      <td style="padding: 8px 10px;">${modeText}</td>
      <td style="padding: 8px 10px; text-align: right;">$${parseFloat(t.grossTips).toFixed(2)}</td>
      <td style="padding: 8px 10px; text-align: right; color: var(--danger-color);">$${parseFloat(t.deductions).toFixed(2)}</td>
      <td style="padding: 8px 10px; text-align: right; font-weight: bold; color: var(--success-color);">$${parseFloat(t.netTips).toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function printTipsReport() {
  if (currentTipsReportList.length === 0) {
    showToast("No data to print", "warning");
    return;
  }
  const startVal = document.getElementById('tipsReportStartDate').value;
  const endVal = document.getElementById('tipsReportEndDate').value;
  try {
    const res = await fetch(`${SERVER_URL}/api/printer/print-tips-report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        startDate: startVal,
        endDate: endVal,
        employeeTipsList: currentTipsReportList
      })
    });
    if (res.ok) {
      showToast("Tips statement printed successfully", "success");
    } else {
      showToast("Error printing statement", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error printing statement", "error");
  }
}
window.printTipsReport = printTipsReport;

// --- EMAIL REPORTS & BACKUPS CONFIG HANDLERS ---
function toggleBackupDestinationFields() {
  const dest = document.getElementById('adminBackupDestination').value;
  document.getElementById('backupFieldLocal').style.display = dest === 'usb' ? 'block' : 'none';
  document.getElementById('backupFieldGDrive').style.display = dest === 'gdrive' ? 'block' : 'none';
  document.getElementById('backupFieldOneDrive').style.display = dest === 'onedrive' ? 'block' : 'none';
}
window.toggleBackupDestinationFields = toggleBackupDestinationFields;

async function saveEmailReportsConfig() {
  const ownerEmail = document.getElementById('adminOwnerEmail').value.trim();
  const freq = document.getElementById('adminReportEmailFrequency').value;
  const fmt = document.getElementById('adminReportEmailFormat').value;
  
  const settingsData = {
    ...posSettings,
    ownerEmail: ownerEmail,
    reportEmailFrequency: freq,
    reportEmailFormat: fmt
  };
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsData)
    });
    if (res.ok) {
      posSettings = await res.json();
      showToast("Email reports configuration saved successfully!", "success");
    } else {
      showToast("Error saving email configuration", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.saveEmailReportsConfig = saveEmailReportsConfig;

async function sendManualEmailReport() {
  const startD = document.getElementById('adminEmailManualStartDate').value;
  const endD = document.getElementById('adminEmailManualEndDate').value;
  if (!startD || !endD) {
    showToast("Please select date range", "warning");
    return;
  }
  const email = document.getElementById('adminOwnerEmail').value.trim();
  if (!email) {
    showToast("Please configure owner email first", "warning");
    return;
  }
  const format = document.getElementById('adminReportEmailFormat').value;

  try {
    const res = await fetch(`${SERVER_URL}/api/reports/email-manual`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email,
        startDate: startD,
        endDate: endD,
        format
      })
    });
    if (res.ok) {
      showToast("Email report sent successfully!", "success");
    } else {
      const err = await res.json();
      showToast("Email failed: " + (err.error || "Unknown"), "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.sendManualEmailReport = sendManualEmailReport;

async function saveBackupsConfig() {
  const freq = document.getElementById('adminBackupFrequency').value;
  const dest = document.getElementById('adminBackupDestination').value;
  const pathVal = document.getElementById('adminBackupPath').value.trim();
  const gdToken = document.getElementById('adminBackupGDriveToken').value.trim();
  const odToken = document.getElementById('adminBackupOneDriveToken').value.trim();

  const settingsData = {
    ...posSettings,
    backupFrequency: freq,
    backupDestination: dest,
    backupPath: pathVal,
    backupGDriveToken: gdToken,
    backupOneDriveToken: odToken
  };
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settingsData)
    });
    if (res.ok) {
      posSettings = await res.json();
      showToast("Backup configuration saved successfully!", "success");
    } else {
      showToast("Error saving backup configuration", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.saveBackupsConfig = saveBackupsConfig;

async function executeManualBackup() {
  const dest = document.getElementById('adminBackupDestination').value;
  const pathVal = document.getElementById('adminBackupPath').value.trim();
  const gdToken = document.getElementById('adminBackupGDriveToken').value.trim();
  const odToken = document.getElementById('adminBackupOneDriveToken').value.trim();
  
  try {
    const res = await fetch(`${SERVER_URL}/api/admin/backup-manual`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        destination: dest,
        path: pathVal,
        gdriveToken: gdToken,
        onedriveToken: odToken
      })
    });
    if (res.ok) {
      showToast("Backup file created successfully!", "success");
    } else {
      const err = await res.json();
      showToast("Backup failed: " + (err.error || "Unknown"), "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.executeManualBackup = executeManualBackup;

// --- SOFTWARE LICENSING HANDLERS ---
async function checkLicenseStatus() {
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/status`);
    if (!res.ok) return;
    const data = await res.json();
    window.lastLicenseData = data;
    
    const mIdInput = document.getElementById('licenseMachineId');
    if (mIdInput) mIdInput.value = data.machineId;
    const mIdBlockedLabel = document.getElementById('blockedLicenseMachineId');
    if (mIdBlockedLabel) mIdBlockedLabel.innerText = data.machineId;

    const expLabel = document.getElementById('licenseExpirationDate');
    if (expLabel) expLabel.innerText = data.expiration;
    const typeLabel = document.getElementById('licenseTypeName');
    if (typeLabel) typeLabel.innerText = data.licenseType;

    const keyInput = document.getElementById('inputLicenseKey');
    if (keyInput) keyInput.value = data.licenseKey || '';

    const badge = document.getElementById('licenseStatusBadge');
    if (badge) {
      badge.innerText = data.status.toUpperCase();
      if (data.status === 'active') {
        badge.style.background = 'var(--success-color)';
        badge.style.color = '#000';
      } else if (data.status === 'demo') {
        badge.style.background = '#ff9f0a';
        badge.style.color = '#000';
      } else {
        badge.style.background = 'var(--danger-color)';
        badge.style.color = '#fff';
      }
    }

    const trialBar = document.getElementById('trialWarningBar');
    if (trialBar) {
      let diffDays = (typeof data.daysRemaining === 'number') ? data.daysRemaining : null;
      if (diffDays === null || isNaN(diffDays)) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const expStr = (data.expiration || '').split('T')[0];
        if (expStr) {
          const expDate = new Date(expStr + 'T00:00:00');
          expDate.setHours(0, 0, 0, 0);
          const diffTime = expDate - today;
          diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
        } else {
          diffDays = 0;
        }
      }
      
      const currentLang = (typeof posSettings !== 'undefined' && posSettings.language) || 'en';
      const isEs = currentLang === 'es';

      if (data.status === 'demo') {
        trialBar.style.display = 'flex';
        
        if (diffDays <= 7) {
          trialBar.style.backgroundColor = 'rgba(255, 69, 58, 0.18)';
          trialBar.style.borderColor = '#ff453a';
          trialBar.style.color = '#ff453a';
          
          if (!document.getElementById('trialPulseStyle')) {
            const style = document.createElement('style');
            style.id = 'trialPulseStyle';
            style.innerHTML = `@keyframes trialPulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }`;
            document.head.appendChild(style);
          }
          trialBar.style.animation = 'trialPulse 1.5s infinite';
          
          trialBar.innerHTML = isEs 
            ? `Prueba expira en ${diffDays} días <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #fff; background: #ff453a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 8px;">Activar Licencia</a>` 
            : `Trial expires in ${diffDays} days! <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #fff; background: #ff453a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 8px;">Activate License</a>`;
        } else {
          trialBar.style.backgroundColor = 'rgba(255, 159, 10, 0.15)';
          trialBar.style.borderColor = '#ff9f0a';
          trialBar.style.color = '#ff9f0a';
          trialBar.style.animation = 'none';
          
          trialBar.innerHTML = isEs 
            ? `Prueba Gratuita: Quedan ${diffDays} días <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #000; background: #ff9f0a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 10px; border: 1px solid #ff9f0a;">Activar Licencia</a>` 
            : `Free Trial: ${diffDays} days remaining <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #000; background: #ff9f0a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 10px; border: 1px solid #ff9f0a;">Activate License</a>`;
        }
      } else if (data.status === 'active' && diffDays <= 15) {
        // Active license nearing expiration (15 days or less)
        trialBar.style.display = 'flex';
        
        if (diffDays <= 7) {
          trialBar.style.backgroundColor = 'rgba(255, 69, 58, 0.18)';
          trialBar.style.borderColor = '#ff453a';
          trialBar.style.color = '#ff453a';
          
          if (!document.getElementById('trialPulseStyle')) {
            const style = document.createElement('style');
            style.id = 'trialPulseStyle';
            style.innerHTML = `@keyframes trialPulse { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }`;
            document.head.appendChild(style);
          }
          trialBar.style.animation = 'trialPulse 1.5s infinite';
          
          trialBar.innerHTML = isEs 
            ? `¡Tu licencia expira en ${diffDays} días! <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #fff; background: #ff453a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 8px;">Renovar Licencia</a>` 
            : `Your license expires in ${diffDays} days! <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #fff; background: #ff453a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 8px;">Renew License</a>`;
        } else {
          trialBar.style.backgroundColor = 'rgba(255, 159, 10, 0.15)';
          trialBar.style.borderColor = '#ff9f0a';
          trialBar.style.color = '#ff9f0a';
          trialBar.style.animation = 'none';
          
          trialBar.innerHTML = isEs 
            ? `Aviso: Tu licencia expira en ${diffDays} días <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #000; background: #ff9f0a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 10px; border: 1px solid #ff9f0a;">Renovar Licencia</a>` 
            : `Notice: License expires in ${diffDays} days <a href="javascript:void(0)" onclick="showLicenseRenewModal()" style="color: #000; background: #ff9f0a; padding: 3px 10px; border-radius: 4px; font-weight: bold; text-decoration: none; margin-left: 10px; border: 1px solid #ff9f0a;">Renew License</a>`;
        }
      } else {
        // Active license with more than 15 days or developer mode: hide banner completely
        trialBar.style.display = 'none';
      }

      // Day 10 Review Growth Loop (Trigger when diffDays <= 5)
      if (data.status === 'demo') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const expDate = new Date(data.expiration + 'T00:00:00');
        expDate.setHours(0, 0, 0, 0);
        const diffDays = Math.ceil((expDate - today) / (1000 * 60 * 60 * 24));

        if (diffDays <= 5 && diffDays > 0) {
          const dismissedUntil = localStorage.getItem('imp_review_dismissed_until');
          const alreadyClaimed = localStorage.getItem('imp_review_claimed');
          const now = Date.now();
          if (!alreadyClaimed && (!dismissedUntil || now > parseInt(dismissedUntil, 10))) {
            setTimeout(() => {
              const modalReview = document.getElementById('modalReviewIncentive');
              if (modalReview && modalReview.style.display !== 'flex') {
                modalReview.style.display = 'flex';
              }
            }, 3000);
          }
        }
      }
    }

    // Attach listeners for review bonus modal
    const btnClaimReview = document.getElementById('btnClaimReviewBonus');
    if (btnClaimReview && !btnClaimReview.dataset.bound) {
      btnClaimReview.dataset.bound = 'true';
      btnClaimReview.onclick = async () => {
        const bName = (typeof posSettings !== 'undefined' && posSettings.businessName) || 'Restaurante';
        const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
        try {
          await fetch('https://api.telegram.org/bot8883667960:AAFVCTqMwI75fGFZ76LCb5ektTVkduv878s/sendMessage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: '8681270663',
              text: `[CLIENTE RECLAMO 15 DIAS GRATIS POR RESENAS]\n\nNegocio: ${bName}\nAccion: Confirmo haber dejado resenas en Google y Facebook.\nHora: ${new Date().toLocaleString()}\n\nValida las resenas y extiende su licencia 15 dias.`,
              parse_mode: 'Markdown'
            })
          });
        } catch(e) {}
        localStorage.setItem('imp_review_claimed', 'true');
        alert(isEs 
          ? "¡Muchas gracias! Tu solicitud ha sido recibida por nuestro equipo técnico. Validaremos tus reseñas y agregaremos 15 días gratis a tu licencia."
          : "Thank you! Your request has been sent to our engineering team. We will verify your reviews and add 15 free bonus days to your license.");
        const m = document.getElementById('modalReviewIncentive');
        if (m) m.style.display = 'none';
      };
    }

    const btnDismissReview = document.getElementById('btnDismissReviewIncentive');
    if (btnDismissReview && !btnDismissReview.dataset.bound) {
      btnDismissReview.dataset.bound = 'true';
      btnDismissReview.onclick = () => {
        // Dismiss for 24 hours
        localStorage.setItem('imp_review_dismissed_until', (Date.now() + 24 * 60 * 60 * 1000).toString());
        const m = document.getElementById('modalReviewIncentive');
        if (m) m.style.display = 'none';
      };
    }

    const blockModal = document.getElementById('modalLicenseBlock');
    if (blockModal) {
      if (data.status === 'expired' || data.status === 'unregistered') {
        blockModal.style.display = 'flex';
        const btnClose = document.getElementById('btnCloseLicenseBlock');
        if (btnClose) btnClose.style.display = 'flex';
      } else {
        blockModal.style.display = 'none';
      }
    }

    // Save license data globally
    window.lastLicenseData = data;

    // Render Bar Hub license status
    const barStatus = data.barStatus || 'unregistered';
    const barExpiration = data.barExpiration || 'N/A';
    const barType = data.barType || 'Ninguno';
    const barKey = data.barKey || '';

    const barKeyInput = document.getElementById('inputLicenseBarHubKey');
    if (barKeyInput) barKeyInput.value = barKey;

    const barTypeLabel = document.getElementById('licenseBarHubTypeName');
    if (barTypeLabel) barTypeLabel.innerText = barStatus === 'demo' ? 'Trial (Demo)' : barType;

    const barBadge = document.getElementById('licenseBarHubStatusBadge');
    if (barBadge) {
      barBadge.innerText = barStatus.toUpperCase();
      if (barStatus === 'active') {
        barBadge.style.background = '#bf5af2';
        barBadge.style.color = '#fff';
      } else if (barStatus === 'demo') {
        barBadge.style.background = '#ff9f0a';
        barBadge.style.color = '#000';
      } else {
        barBadge.style.background = 'var(--danger-color)';
        barBadge.style.color = '#fff';
      }
    }
  } catch (err) {
    console.error("Error checking license status:", err);
  }
}
window.checkLicenseStatus = checkLicenseStatus;

// Periodically re-check license status every 30 minutes to dynamically update countdown and renewal alerts
setInterval(() => {
  if (typeof checkLicenseStatus === 'function') {
    checkLicenseStatus();
  }
}, 30 * 60 * 1000);


// --- LICENSE RENEWAL PLAN SELECTOR & MODAL HELPERS ---
let currentBlockModule = 'core'; // 'core' or 'bar'
let selectedBlockPlan = 'monthly';

function selectBlockModule(mod) {
  currentBlockModule = mod;
  const btnCore = document.getElementById('btnLicenseModuleCore');
  const btnBar = document.getElementById('btnLicenseModuleBar');
  const inputKey = document.getElementById('blockedInputLicenseKey');
  const btnValidate = document.getElementById('btnValidateBlockedLicense');
  const lblKey = document.getElementById('lblBlockedKeyLabel');
  const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');

  if (mod === 'bar') {
    if (btnCore) { btnCore.style.background = 'transparent'; btnCore.style.color = '#aaa'; }
    if (btnBar) { btnBar.style.background = '#bf5af2'; btnBar.style.color = '#000'; }
    if (inputKey) { inputKey.placeholder = 'BAR-XXXX-XXXX-XXXX-XXXX'; inputKey.value = ''; }
    if (lblKey) lblKey.innerText = isEs ? 'Clave de Activación Bar Hub (Vinos/Licores):' : 'Bar Hub Activation Key (Wine & Liquor):';
    if (btnValidate) {
      btnValidate.innerText = isEs ? '✓ Validar y Activar Bar Hub' : '✓ Validate & Activate Bar Hub';
      btnValidate.style.backgroundColor = '#bf5af2';
      btnValidate.onclick = registerBarHubLicenseKeyBlocked;
    }
  } else {
    if (btnCore) { btnCore.style.background = 'var(--accent-color)'; btnCore.style.color = '#000'; }
    if (btnBar) { btnBar.style.background = 'transparent'; btnBar.style.color = '#aaa'; }
    if (inputKey) { inputKey.placeholder = 'IMP-XXXX-XXXX-XXXX-XXXX'; inputKey.value = ''; }
    if (lblKey) lblKey.innerText = isEs ? 'Llave de Activación / Registro:' : 'Activation Key / Clave de Registro:';
    if (btnValidate) {
      btnValidate.innerText = isEs ? '✓ Validar y Desbloquear Sistema' : '✓ Validate & Unlock System';
      btnValidate.style.backgroundColor = 'var(--success-color)';
      btnValidate.onclick = registerLicenseKeyBlocked;
    }
  }
  selectBlockLicensePlan(selectedBlockPlan);
}
window.selectBlockModule = selectBlockModule;

function selectBlockLicensePlan(plan) {
  selectedBlockPlan = plan;
  const b1 = document.getElementById('btnBlockPlan1');
  const b2 = document.getElementById('btnBlockPlan2');
  const b3 = document.getElementById('btnBlockPlan3');
  const p1Val = document.getElementById('btnBlockPlan1Val');
  const p2Val = document.getElementById('btnBlockPlan2Val');
  const p3Val = document.getElementById('btnBlockPlan3Val');
  const title = document.getElementById('lblBlockPlanName');
  const price = document.getElementById('lblBlockPlanPrice');
  const miPrice = document.getElementById('lblBlockPlanMichiganPrice');

  [b1, b2, b3].forEach(b => {
    if (!b) return;
    b.style.background = 'rgba(255,255,255,0.05)';
    b.style.color = '#fff';
  });

  const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
  const isBar = (currentBlockModule === 'bar');

  // Update button price labels
  if (p1Val) p1Val.innerText = isBar ? '$100' : '$85';
  if (p2Val) p2Val.innerText = isBar ? '$500' : '$425';
  if (p3Val) p3Val.innerText = isBar ? '$900' : '$765';

  const activeColor = isBar ? '#bf5af2' : 'var(--accent-color)';

  if (plan === 'monthly') {
    if (b1) { b1.style.background = activeColor; b1.style.color = '#000'; }
    if (title) title.innerText = isBar 
      ? (isEs ? 'Plan Bar Hub: 1 Mes' : 'Selected Bar Hub Plan: 1 Month')
      : (isEs ? 'Plan Seleccionado: 1 Mes' : 'Selected Plan: 1 Month Subscription');
    if (price) price.innerText = isBar ? '$100.00 USD' : '$85.00 USD';
    if (miPrice) miPrice.innerText = isBar ? '$106.00 USD' : '$90.10 USD';
  } else if (plan === 'semi') {
    if (b2) { b2.style.background = activeColor; b2.style.color = '#000'; }
    if (title) title.innerText = isBar
      ? (isEs ? 'Plan Bar Hub: 6 Meses (1 Mes Gratis)' : 'Selected Bar Hub Plan: 6 Months (1 Mo Free)')
      : (isEs ? 'Plan Seleccionado: 6 Meses (1 Mes Gratis)' : 'Selected Plan: 6 Months (1 Month Free)');
    if (price) price.innerText = isBar ? '$500.00 USD' : '$425.00 USD';
    if (miPrice) miPrice.innerText = isBar ? '$530.00 USD' : '$450.50 USD';
  } else if (plan === 'yearly') {
    if (b3) { b3.style.background = activeColor; b3.style.color = '#000'; }
    if (title) title.innerText = isBar
      ? (isEs ? 'Plan Bar Hub: 1 Año (3 Meses Gratis)' : 'Selected Bar Hub Plan: 1 Year (3 Mos Free)')
      : (isEs ? 'Plan Seleccionado: 1 Año (3 Meses Gratis)' : 'Selected Plan: 1 Year (3 Months Free)');
    if (price) price.innerText = isBar ? '$900.00 USD' : '$765.00 USD';
    if (miPrice) miPrice.innerText = isBar ? '$954.00 USD' : '$810.90 USD';
  }
}
window.selectBlockLicensePlan = selectBlockLicensePlan;

function showLicenseRenewModal(mod = 'core') {
  const isLocked = window.lastLicenseData && (window.lastLicenseData.status === 'expired' || window.lastLicenseData.status === 'unregistered');
  
  const openTheModal = () => {
    const blockModal = document.getElementById('modalLicenseBlock');
    if (blockModal) {
      selectBlockModule(mod);
      const btnClose = document.getElementById('btnCloseLicenseBlock');
      if (btnClose) {
        btnClose.style.display = 'flex';
      }
      blockModal.style.display = 'flex';
    }
  };

  if (isLocked) {
    openTheModal();
    return;
  }

  // POS activo o en prueba: proteger con contraseña de Manager para privacidad total
  const isEs = (typeof posSettings !== 'undefined' && posSettings.language === 'es');
  authRequiredRole = 'manager';
  authSuccessCallback = (emp) => {
    openTheModal();
  };

  showAuthModal(
    isEs ? '🔒 Autorización de Gerente' : '🔒 Manager Authorization',
    isEs ? 'Entra por favor tu password de manager' : 'Please enter your manager password'
  );
}
window.showLicenseRenewModal = showLicenseRenewModal;

async function registerBarHubLicenseKeyBlocked() {
  const input = document.getElementById('blockedInputLicenseKey');
  const key = input ? input.value.trim() : '';
  if (!key) {
    showToast("Por favor ingrese la clave del Bar Hub / Please enter a Bar Hub key", "warning");
    return;
  }
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key })
    });
    if (res.ok) {
      showToast("¡Licencia Bar Hub activada con éxito!", "success");
      await checkLicenseStatus();
      const blockModal = document.getElementById('modalLicenseBlock');
      if (blockModal && window.lastLicenseData && (window.lastLicenseData.status === 'active' || window.lastLicenseData.status === 'demo')) {
        blockModal.style.display = 'none';
      }
    } else {
      const err = await res.json();
      showToast(err.error || "Clave inválida", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error de conexión", "error");
  }
}
window.registerBarHubLicenseKeyBlocked = registerBarHubLicenseKeyBlocked;

async function registerLicenseKey() {
  const key = document.getElementById('inputLicenseKey').value.trim();
  if (!key) {
    showToast("Please enter a registration key", "warning");
    return;
  }
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key })
    });
    if (res.ok) {
      showToast("License validated successfully!", "success");
      await checkLicenseStatus();
    } else {
      const err = await res.json();
      showToast(err.error || "Invalid license key", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.registerLicenseKey = registerLicenseKey;

async function registerBarHubLicenseKey() {
  const key = document.getElementById('inputLicenseBarHubKey').value.trim();
  if (!key) {
    showToast("Por favor ingrese la clave del Bar Hub / Please enter a Bar Hub key", "warning");
    return;
  }
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key })
    });
    if (res.ok) {
      showToast("¡Licencia de Bar Hub validada correctamente!", "success");
      await checkLicenseStatus();
    } else {
      const err = await res.json();
      showToast(err.error || "Clave inválida", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error de conexión", "error");
  }
}
window.registerBarHubLicenseKey = registerBarHubLicenseKey;

async function resetBarHubTrial() {
  const isEs = posSettings && posSettings.language === 'es';
  const proceed = confirm(isEs 
    ? "¿Está seguro de que desea activar una prueba manual de 30 días para el Bar Hub?" 
    : "Are you sure you want to activate a manual 30-day trial for the Bar Hub?"
  );
  if (!proceed) return;

  const pin = prompt(isEs ? "Ingrese el PIN de Administrador/Gerente:" : "Enter Admin/Manager PIN:");
  if (pin === null) return;

  try {
    const resEmp = await fetch(`${SERVER_URL}/api/employees`);
    if (!resEmp.ok) throw new Error("Could not load employees");
    const employees = await resEmp.json();
    
    // Find matching manager or admin pin code
    const matched = employees.find(e => e.passcode === pin && (e.role === 'admin' || e.role === 'manager'));
    if (!matched) {
      showToast(isEs ? "PIN incorrecto o sin privilegios de administrador" : "Invalid PIN or lack of admin privileges", "error");
      return;
    }

    const res = await fetch(`${SERVER_URL}/api/licensing/reset-bar-trial`, {
      method: 'POST'
    });
    if (res.ok) {
      showToast(isEs ? "¡Prueba de 30 días de Bar Hub activada!" : "Bar Hub 30-day trial activated!", "success");
      await checkLicenseStatus();
    } else {
      showToast(isEs ? "Error al activar la prueba" : "Error activating trial", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error de conexión", "error");
  }
}
window.resetBarHubTrial = resetBarHubTrial;

async function registerLicenseKeyBlocked() {
  const key = document.getElementById('blockedInputLicenseKey').value.trim();
  if (!key) {
    showToast("Please enter a registration key", "warning");
    return;
  }
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey: key })
    });
    if (res.ok) {
      showToast("License validated! Unlocking system...", "success");
      document.getElementById('blockedInputLicenseKey').value = '';
      await checkLicenseStatus();
    } else {
      const err = await res.json();
      showToast(err.error || "Invalid license key", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Connection error", "error");
  }
}
window.registerLicenseKeyBlocked = registerLicenseKeyBlocked;

async function promptBypassLicense() {
  const code = prompt("Ingrese la clave del ADMINISTRADOR para el Bypass Temporal (24 Horas):");
  if (!code) return;
  try {
    const res = await fetch(`${SERVER_URL}/api/licensing/bypass`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: code })
    });
    if (res.ok) {
      showToast("Bypass temporal activado por 24 horas", "success");
      await checkLicenseStatus();
    } else {
      const err = await res.json();
      showToast(err.error || "Acceso denegado", "error");
    }
  } catch (err) {
    console.error(err);
    showToast("Error de conexión", "error");
  }
}
window.promptBypassLicense = promptBypassLicense;

function triggerRemoteSupport() {
  closeAllModals();
  document.getElementById('modalSupportCenter').style.display = 'flex';
  initSupportChatbot();
}
window.triggerRemoteSupport = triggerRemoteSupport;

let chatbotInitialized = false;

function initSupportChatbot() {
  const historyEl = document.getElementById('supportChatHistory');
  if (!historyEl) return;
  
  if (chatbotInitialized) return;
  chatbotInitialized = true;

  const isEs = posSettings && posSettings.language === 'es';

  // Add initial system message
  const welcomeText = isEs 
    ? "¡Hola! Soy tu Asistente Técnico Virtual. Puedo ayudarte a resolver problemas comunes de hardware, bloqueos de disco de grabación o sincronización. Selecciona una opción abajo o escribe tu pregunta."
    : "Hello! I am your Virtual Technical Assistant. I can help you solve common hardware configurations, recording drive locks, and printing issues. Choose a topic below or write your question.";
  
  addChatMessage("assistant", welcomeText);

  // Close button
  const btnClose = document.getElementById('btnCloseSupportCenterModal');
  if (btnClose) {
    btnClose.addEventListener('click', () => {
      document.getElementById('modalSupportCenter').style.display = 'none';
    });
  }

  // Remote support trigger
  const btnStartRemote = document.getElementById('btnStartRemoteSupportSession');
  if (btnStartRemote) {
    btnStartRemote.addEventListener('click', async () => {
      const inputProb = document.getElementById('inputSupportProblem');
      const problemText = (inputProb && inputProb.value.trim()) ? inputProb.value.trim() : (isEs ? "Asistencia técnica general" : "General technical assistance");

      showToast(isEs ? "Iniciando RustDesk y notificando a soporte..." : "Launching RustDesk and notifying support...", "info");
      btnStartRemote.disabled = true;
      btnStartRemote.innerText = isEs ? "INICIANDO RUSTDESK..." : "LAUNCHING RUSTDESK...";

      try {
        const res = await fetch(`${SERVER_URL}/api/support/request`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ problem: problemText })
        });
        
        if (res.ok) {
          const data = await res.json();
          const boxStatus = document.getElementById('boxSupportLaunchedStatus');
          if (boxStatus) boxStatus.style.display = 'flex';

          // Show Remote Support Active top banner
          const banner = document.getElementById('bannerRemoteSupportActive');
          if (banner) banner.style.display = 'flex';

          // Update WhatsApp link with store name and problem
          const waLink = document.getElementById('btnSupportWhatsAppLink');
          if (waLink) {
            const storeName = (window.appSettings && window.appSettings.businessName) ? window.appSettings.businessName : 'Impossible POS';
            const encodedMsg = encodeURIComponent(isEs 
              ? `Hola, solicito soporte técnico para el negocio: ${storeName}. Problema: ${problemText}`
              : `Hello, requesting technical support for: ${storeName}. Issue: ${problemText}`);
            waLink.href = `https://wa.me/13133129090?text=${encodedMsg}`;
          }

          addChatMessage("assistant", isEs
            ? `🖥️ RustDesk se ha abierto en tu pantalla.<br><br>✅ <b>La alerta urgente ha sido enviada al equipo técnico de Impossible POS.</b><br>Por favor indícanos por WhatsApp o llamada telefónica al <b>(313) 312-9090</b> el <b>ID</b> y la <b>Contraseña</b> que muestra la ventana de RustDesk para conectarnos y asistirte.`
            : `🖥️ RustDesk has opened on your screen.<br><br>✅ <b>Urgent alert sent to Impossible POS engineering team.</b><br>Please provide via WhatsApp or phone at <b>(313) 312-9090</b> the <b>ID</b> and <b>Password</b> shown on the RustDesk window so we can connect.`);
            
          showToast(isEs ? "RustDesk iniciado y soporte notificado" : "RustDesk launched and support notified", "success");
        } else {
          showToast(isEs ? "Error al iniciar soporte remoto" : "Failed to start remote support", "error");
        }
      } catch (err) {
        console.error(err);
        showToast(isEs ? "Error de conexión con el servidor" : "Server connection error", "error");
      } finally {
        btnStartRemote.disabled = false;
        btnStartRemote.innerText = isEs ? "SOLICITAR ASISTENCIA REMOTA (RUSTDESK)" : "REQUEST REMOTE SUPPORT (RUSTDESK)";
      }
    });
  }

  // Global functions for remote support active banner
  window.dismissRemoteSupportBanner = function() {
    const banner = document.getElementById('bannerRemoteSupportActive');
    if (banner) banner.style.display = 'none';
    const isEs = (typeof currentLang !== 'undefined' ? currentLang : 'es') === 'es';
    if (typeof showToast === 'function') {
      showToast(isEs ? "Sesión de soporte remoto finalizada" : "Remote support session ended", "info");
    }
  };

  window.toggleRemoteSupportBanner = function() {
    const banner = document.getElementById('bannerRemoteSupportActive');
    if (!banner) return;
    const isVisible = banner.style.display === 'flex';
    banner.style.display = isVisible ? 'none' : 'flex';
    const isEs = (typeof currentLang !== 'undefined' ? currentLang : 'es') === 'es';
    if (typeof showToast === 'function') {
      showToast(banner.style.display === 'flex' 
        ? (isEs ? "Aviso de soporte remoto activado en pantalla" : "Remote support banner shown on screen")
        : (isEs ? "Aviso de soporte remoto ocultado" : "Remote support banner hidden"), "info");
    }
  };

  // Chat send action
  const chatInput = document.getElementById('supportChatInput');
  const btnSend = document.getElementById('btnSupportChatSend');

  const handleSend = () => {
    const text = chatInput.value.trim();
    if (!text) return;
    
    addChatMessage("user", text);
    chatInput.value = '';
    
    setTimeout(() => {
      const reply = processChatbotResponse(text);
      addChatMessage("assistant", reply);
    }, 600);
  };

  if (btnSend) btnSend.addEventListener('click', handleSend);
  if (chatInput) {
    chatInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') handleSend();
    });
  }

  // Quick tag triggers
  document.querySelectorAll('#supportQuickTroubleTags button[data-issue]').forEach(btn => {
    btn.addEventListener('click', () => {
      const issue = btn.getAttribute('data-issue');
      addChatMessage("user", btn.innerText);
      
      setTimeout(() => {
        const reply = processChatbotResponse(issue);
        addChatMessage("assistant", reply);
      }, 500);
    });
  });
}

function addChatMessage(sender, text) {
  const historyEl = document.getElementById('supportChatHistory');
  if (!historyEl) return;

  const bubble = document.createElement('div');
  bubble.style.padding = '8px 12px';
  bubble.style.borderRadius = '8px';
  bubble.style.maxWidth = '85%';
  bubble.style.lineHeight = '1.4';
  bubble.style.wordBreak = 'break-word';
  bubble.style.marginBottom = '6px';

  if (sender === 'user') {
    bubble.style.background = 'var(--accent-color)';
    bubble.style.color = '#000';
    bubble.style.alignSelf = 'flex-end';
    bubble.style.fontWeight = 'bold';
  } else {
    bubble.style.background = 'rgba(255,255,255,0.04)';
    bubble.style.color = '#fff';
    bubble.style.alignSelf = 'flex-start';
    bubble.style.border = '1px solid var(--border-color)';
  }

  bubble.innerHTML = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br>');
  historyEl.appendChild(bubble);
  historyEl.scrollTop = historyEl.scrollHeight;
}

function processChatbotResponse(query) {
  const isEs = posSettings && posSettings.language === 'es';
  const q = query.toLowerCase();

  if (q.includes('shift') || q.includes('turno') || q.includes('fondo') || q.includes('apertura') || q.includes('cash float') || q.includes('float') || q.includes('bloqueo cobrar') || q.includes('abrir caja') || q.includes('abrir shift') || q.includes('no puedo cobrar')) {
    return isEs
      ? "💵 **APERTURA DE TURNO Y FONDO INICIAL (CASH FLOAT)**\n\n" +
        "1. **Requisito Obligatorio:** El sistema bloquea las ventas y el cobro en efectivo o tarjeta hasta que el cajero en turno abra la caja con su fondo inicial.\n" +
        "2. **Desglose de Efectivo Exacto:** Al abrir turno en `Opciones > Abrir Turno / Shift Management` (o al intentar cobrar), ingresa la cantidad de cada denominación: billetes ($100, $50, $20, $10, $5, $1) y monedas (25¢, 10¢, 5¢, 1¢). El sistema calcula el total de fondo inicial automáticamente.\n" +
        "3. **Auditoría y Arqueo Ciego (Blind Drop):** Durante el día el cajero atiende normalmente. Al final de la jornada en el Z-Report, el cajero cuenta el dinero sin ver el monto esperado en pantalla; el sistema compara ambos y arroja si hay sobrante o faltante exacto.\n" +
        "4. **¿Por qué está bloqueado el cobro?:** Si al presionar 'Pay' el sistema te pide abrir turno, es porque no hay un turno activo en esta estación. Ingresa tu fondo inicial y podrás cobrar al instante."
      : "💵 **SHIFT OPENING & STARTING CASH FLOAT (DRAWER AUDITING)**\n\n" +
        "1. **Mandatory Checkout Gate:** Checkout and payments are strictly locked until the active cashier opens their shift and records the starting cash float.\n" +
        "2. **Denomination Breakdown:** Open shift via `Options > Shift Management / Open Shift` (or on your first checkout attempt). Enter the exact bill count ($100, $50, $20, $10, $5, $1) and coins (25¢, 10¢, 5¢, 1¢). Total starting float is calculated automatically.\n" +
        "3. **Blind Drop Audit:** Cashiers ring up sales during the shift. At end-of-day, the cashier performs a blind count without seeing the computer's expected total, preventing skim and calculating exact shortage/overage in the Z-Report.\n" +
        "4. **Why is checkout blocked?:** If tapping 'Pay' prompts you to open a shift, simply enter your starting cash drawer denominations to begin ringing up orders immediately.";
  }

  if (q.includes('station_role') || q.includes('mesero') || q.includes('waiter') || q.includes('rol') || q.includes('modo caja') || q.includes('modo mesero') || q.includes('order only') || q.includes('terminal role') || q.includes('station role')) {
    return isEs
      ? "🖥️ **ROLES DE ESTACIÓN: MODO CAJA VS MODO MESERO**\n\n" +
        "1. **Modo Caja (Cash Register):** Diseñado para estaciones principales con cajón de dinero. Permite abrir turnos con fondo de efectivo, cobrar (efectivo, tarjeta, crédito), disparar el cajón de dinero y hacer cortes Z.\n" +
        "2. **Modo Mesero (Waiter Station):** Diseñado para tablets o terminales en el comedor donde los meseros toman comandas. Permite levantar órdenes, enviarlas a cocina KDS o impresoras e imprimir pre-cuentas de mesa, pero NO permite cobrar dinero en efectivo ni abre ningún cajón (no requiere fondo inicial).\n" +
        "3. **Cómo Cambiar el Rol:** Ve a `Setup > Hardware > Caja`. En 'Rol de esta Estación', selecciona `Terminal de Caja (Con Cajón y Cobro)` o `Terminal de Mesero (Solo Comandas y Cocina)` y presiona Guardar."
      : "🖥️ **STATION ROLES: CASH REGISTER VS WAITER TERMINAL**\n\n" +
        "1. **Cashier Mode (Full Register):** For main counter stations equipped with a physical cash drawer. Enables shift opening with starting cash float, tender collection (cash/card), cash drawer kicking, and Z-Report closing.\n" +
        "2. **Waiter Mode (Order-Only Station):** Designed for floor stations and server tablets. Waiters can start tables, send orders to the kitchen/bar KDS and print guest checks, but CANNOT take cash payments or open cash drawers (no shift opening or float required).\n" +
        "3. **How to Configure:** Go to `Setup > Hardware > Caja`. Under 'Station Role', choose either `Cashier Terminal (Full Register)` or `Waiter Station (Orders & Kitchen Only)` and tap Save.";
  }

  if (q.includes('station_qr') || q.includes('qr_sign') || q.includes('letrero') || q.includes('qr sign') || q.includes('imprimir qr') || q.includes('single monitor') || q.includes('customer display') || q.includes('vincular cliente') || q.includes('pantalla cliente')) {
    return isEs
      ? "🏷️ **LETRERO QR IMPRIMIBLE POR ESTACIÓN (Setup > Hardware > Caja)**\n\n" +
        "1. **¿Para qué sirve?:** Si tus cajas tienen un solo monitor (sin pantalla secundaria hacia el cliente) o tienes varias cajas juntas (Caja 1, Caja 2, etc.), puedes imprimir un letrero profesional con el código QR específico de cada caja.\n" +
        "2. **Dónde imprimirlo:** Ve a `Setup > Hardware > Caja` y presiona el botón verde `Print Customer QR Sign`.\n" +
        "3. **Selecciona la Caja:** Elige la estación (Caja 1, Caja 2, etc.) y genera el letrero listo para imprimir en papel térmico de 80mm o en hoja carta.\n" +
        "4. **Colocación:** Lamina o enmica el letrero y pégalo detrás del monitor de la caja mirando hacia el cliente con la leyenda: 'Escanee este código para vincular su cuenta con esta caja'.\n" +
        "5. **¿Cada caja tiene QR diferente?:** SÍ. Cada estación genera un código único para que la cuenta del cliente se sincronice exactamente con la caja donde está parado."
      : "🏷️ **PRINTABLE STATION QR SIGN (Setup > Hardware > Caja)**\n\n" +
        "1. **Purpose:** If your POS terminals use single monitors (no customer-facing display) or you have multiple registers side-by-side (Station 1, Station 2, etc.), you can print a branded QR sign for each specific register.\n" +
        "2. **Where to Find It:** Navigate to `Setup > Hardware > Caja` and tap the green `Print Customer QR Sign` button.\n" +
        "3. **Choose Terminal:** Select the station number (Station 1, Station 2, etc.) and preview the printout formatted for 80mm receipt paper or standard 8.5x11 sheets.\n" +
        "4. **Display:** Laminate the sign and affix it to the back of the customer-facing monitor with the prompt: 'Scan this code to link your account to this register'.\n" +
        "5. **Unique QR Per Station:** YES. Each terminal has its own unique pairing code so the customer connects directly to the cashier serving them.";
  }

  if (q.includes('telegram') || q.includes('twilio') || q.includes('notif') || q.includes('botfather') || q.includes('mensajes de texto') || q.includes('sms gratis') || q.includes('alerta cliente') || q.includes('sms')) {
    return isEs
      ? "📲 **NOTIFICACIONES A CLIENTES: TELEGRAM BOT (100% GRATIS) VS TWILIO SMS**\n\n" +
        "1. **Telegram Bot (Recomendado - $0 Costo Mensual):**\n" +
        "   • Totalmente gratis y sin límites de mensajes.\n" +
        "   • Configuración en 2 minutos: En Telegram busca `@BotFather`, envía `/newbot`, copia el Bot Token y escribe el @username en `Setup > Hardware > Food Hub`.\n" +
        "   • El cliente solo escanea el QR del ticket, pulsa 'Start' en Telegram y recibe alertas automáticas cuando su orden esté en preparación o lista para recoger.\n" +
        "2. **Twilio SMS (Mensajes de Texto Tradicionales):**\n" +
        "   • Envía SMS directo al número celular del cliente.\n" +
        "   • Requiere cuenta en Twilio, Account SID, Auth Token y número telefónico Twilio (aplica costo por mensaje y registro A2P 10DLC de telefonía).\n" +
        "3. **Libre Elección:** El restaurante puede elegir Telegram para cero costos mensuales o Twilio según su preferencia en Setup."
      : "📲 **CUSTOMER NOTIFICATIONS: TELEGRAM BOT (100% FREE) VS TWILIO SMS**\n\n" +
        "1. **Telegram Bot (Recommended - $0 Ongoing Fees):**\n" +
        "   • Completely free with unlimited instant notifications.\n" +
        "   • 2-minute setup: Search `@BotFather` on Telegram, send `/newbot`, copy your Bot Token and enter your bot username in `Setup > Hardware > Food Hub`.\n" +
        "   • Customers scan their receipt QR, tap 'Start' on Telegram, and receive live ping alerts when their food is cooking or ready for pickup.\n" +
        "2. **Twilio SMS (Traditional Carrier Text Messages):**\n" +
        "   • Delivers SMS texts directly to standard mobile carrier numbers.\n" +
        "   • Requires Twilio Account SID, Auth Token, and Twilio phone number (carrier per-message fees and A2P 10DLC registration apply).\n" +
        "3. **Full Flexibility:** Restaurant owners can switch between Telegram (zero costs) or Twilio anytime in Setup.";
  }

  if (q.includes('doordash') || q.includes('uber') || q.includes('grubhub') || q.includes('delivery') || q.includes('repartidor') || q.includes('tableta') || q.includes('kds') || q.includes('hardware delivery')) {
    return isEs
      ? "**INTEGRACIÓN ALL-IN-ONE DE DELIVERY (DoorDash, Uber Eats, Grubhub y Menú Online)**\n\n" +
        "1. **Sin Tabletas Extras:** Todos los pedidos de DoorDash, Uber Eats, Grubhub y tu menú online entran directamente al POS y a la pantalla de cocina (KDS) sin tener 4 o 5 tabletas estorbando en la caja.\n" +
        "2. **Cocina KDS con Colores Oficiales:** Cada comanda llega con su color distintivo (DoorDash en rojo, Uber Eats en verde, Grubhub en naranja, Tienda en azul) y una alarma sonora automática.\n" +
        "3. **Despacho con Escáner:** Cuando el repartidor (Dasher / Uber Driver) llega al negocio mostrando su teléfono, la cajera solo escanea el código QR o de barras de su pantalla con el lector USB, el sistema abre la comanda al instante y se presiona 'Entregar a Repartidor'.\n" +
        "4. **Requisitos de Hardware:**\n" +
        "   • Pantalla táctil o monitor para Cocina KDS (conectado a la red Wi-Fi local).\n" +
        "   • Lector de códigos de barras / QR USB o inalámbrico conectado a la caja.\n" +
        "   • Impresora térmica para tickets de cocina (opcional).\n" +
        "5. **Pruebas de 1 Clic:** Ve a Opciones > Configuración > Negocio y Servicios > Canales y presiona 'Probar Pedido DoorDash' para simular un pedido en tiempo real."
      : "**ALL-IN-ONE DELIVERY INTEGRATION (DoorDash, Uber Eats, Grubhub & Online Store)**\n\n" +
        "1. **Zero Counter Clutter:** All DoorDash, Uber Eats, and Grubhub orders stream directly into the POS and Kitchen KDS without needing 5 separate hardware tablets.\n" +
        "2. **Color-Coded KDS:** Each ticket highlights the provider's official branding (DoorDash Red, Uber Eats Green, Grubhub Orange, Web Blue) with automated kitchen chime alerts.\n" +
        "3. **Barcode / QR Driver Dispatch:** When the driver arrives displaying their phone, scan their QR or barcode with your handheld scanner to instantly verify items and press 'Hand Over to Driver'.\n" +
        "4. **Hardware Requirements:**\n" +
        "   • Touchscreen or standard monitor for Kitchen KDS (running on local network).\n" +
        "   • Standard USB or wireless 2D Barcode/QR scanner plugged into the POS terminal.\n" +
        "   • Thermal kitchen printer (optional).\n" +
        "5. **1-Click Testing:** Go to Options > Settings > Business & Services > Channels and tap 'Test DoorDash Order' to simulate a live order.";
  }

  if (q.includes('cloud_portal') || q.includes('portal') || q.includes('nube') || q.includes('ver ventas') || q.includes('desde casa') || q.includes('remote') || q.includes('celular')) {
    return isEs
      ? "**PORTAL CLOUD PARA DUEÑOS (impossiblepos.com/portal.html)**\n\n" +
        "1. **Acceso Remoto 24/7:** Monitorea ventas en vivo, ganancias brutas y netas, impuestos, efectivo vs tarjeta y cortes Z desde cualquier celular o PC en tu casa.\n" +
        "2. **Acceso Rápido:** Puedes dar clic en el botón verde 'Owner Portal' en esta misma ventana de ayuda o visitar impossiblepos.com/portal.html.\n" +
        "3. **Registro:** Regístrate con tu Nombre, Negocio, Email, Contraseña y tu Clave de Licencia única.\n" +
        "4. **Sincronización:** Las ventas se sincronizan automáticamente en segundo plano cada 20 segundos."
      : "**CLOUD OWNER PORTAL (impossiblepos.com/portal.html)**\n\n" +
        "1. **24/7 Remote Monitoring:** Check live sales, gross/net revenue, taxes, cash vs card breakdown, and shift Z-Reports from any smartphone or PC at home.\n" +
        "2. **Quick Access:** Click the green 'Owner Portal' button in this help dialog or navigate to impossiblepos.com/portal.html.\n" +
        "3. **Owner Sign-Up:** Register with your Name, Business Name, Email, Password, and unique License Key.\n" +
        "4. **Automatic Sync:** Completed orders sync automatically in the background every 20 seconds.";
  }

  if (q.includes('cloud_restore') || q.includes('restore') || q.includes('restaurar') || q.includes('recuperar') || q.includes('disaster') || q.includes('respaldo') || q.includes('perder')) {
    return isEs
      ? "**RECUPERACIÓN DE DESASTRES Y RESPALDO EN LA NUBE**\n\n" +
        "1. **Respaldo a la Nube:** Ve a Options > Settings > Database y presiona 'Cloud Menu Backup' para subir todos tus platillos, precios y modificadores a la nube.\n" +
        "2. **Restauración con PIN (En el Negocio):** Presiona 'Cloud Menu Restore', ingresa tu PIN de Manager o el PIN Maestro de Soporte (2026), y tu menú se descarga e instala al instante.\n" +
        "3. **En Computadora Nueva o de Reemplazo:** Si la computadora se dañó o fue robada, abre el POS en una PC nueva y selecciona 'New Machine Setup' para restaurar con tu Email y Contraseña de Dueño o tu Clave de Licencia.\n" +
        "4. **Cero Pérdida:** Tu menú queda siempre a salvo en la nube."
      : "**CLOUD DISASTER RECOVERY & MENU RESTORE**\n\n" +
        "1. **Cloud Backup:** Go to Options > Settings > Database and click 'Cloud Menu Backup' to upload your complete catalog, prices, and modifiers to the cloud.\n" +
        "2. **PIN Restore (In-Store):** Click 'Cloud Menu Restore', type your Manager PIN or Master Support PIN (2026), and your menu downloads and installs in 2 seconds.\n" +
        "3. **New / Replacement Machine:** If your terminal is lost, stolen, or damaged, install the POS on a new PC and select 'New Machine Setup' to restore with your Owner Email & Password or License Key.\n" +
        "4. **Zero Menu Loss:** Your food catalog is always protected in the secure cloud.";
  }

  if (q.includes('ota_update') || q.includes('update') || q.includes('actualizar') || q.includes('parche') || q.includes('version')) {
    return isEs
      ? "**ACTUALIZACIONES DEL SISTEMA (OTA) Y RESPALDO AUTOMÁTICO**\n\n" +
        "1. **Buscar Actualizaciones:** Ve a Options > Software Updates (U) y presiona 'Check Updates'.\n" +
        "2. **Respaldo Previo Automático:** Antes de aplicar cualquier parche, el sistema genera automáticamente una copia de seguridad en Backups/pre_update_backup_[fecha].\n" +
        "3. **Protección de Base de Datos:** Los parches actualizan archivos ejecutables pero NUNCA tocan tu base de datos de ventas (pos.db). Toda tu información queda 100% intacta.\n" +
        "4. **Reinicio Instantáneo:** La actualización se descarga en segundos y recarga el sistema automáticamente sin demoras."
      : "**OVER-THE-AIR (OTA) UPDATES & AUTOMATIC BACKUP**\n\n" +
        "1. **Check Updates:** Go to Options > Software Updates (U) and click 'Check Updates'.\n" +
        "2. **Automatic Pre-Update Backup:** Before installing any update, the system automatically saves a full database backup in Backups/pre_update_backup_[timestamp].\n" +
        "3. **Database Safeguard:** Software updates patch core application files but NEVER touch your sales database (pos.db). All your records remain 100% safe.\n" +
        "4. **Instant Reload:** The patch downloads in seconds and auto-reloads the register with zero downtime.";
  }

  if (q.includes('drawer') || q.includes('cajon') || q.includes('dinero') || q.includes('gaveta') || q.includes('cash') || q.includes('abrir')) {
    return isEs
      ? "💵 **SOPORTE: CAJÓN DE DINERO**\n\n" +
        "1. **Impresora:** El cajón de dinero depende 100% de la impresora. Verifica que la impresora esté encendida y tenga papel.\n" +
        "2. **Cable:** Revisa que el cable telefónico gris/negro que sale del cajón esté bien conectado detrás de la impresora.\n" +
        "3. **Prueba Manual:** Ve a `Cashier > Options (Botón ☰) > Open Drawer` para intentar abrirlo manualmente.\n" +
        "4. **Llave:** Si no responde, usa la llave física para abrirlo y revisa que no haya billetes atorados en el mecanismo."
      : "💵 **SUPPORT: CASH DRAWER**\n\n" +
        "1. **Printer Check:** The drawer is powered by the receipt printer. Ensure the printer is ON and has paper.\n" +
        "2. **Cable:** Check the phone-like cable connecting the cash drawer to the back of the printer.\n" +
        "3. **Manual Test:** Go to `Cashier > Options (☰ Button) > Open Drawer` to force open it.\n" +
        "4. **Key Access:** If it fails, use the physical key to unlock it and check for jammed bills.";
  }

  if (q.includes('refund') || q.includes('void') || q.includes('cancelar') || q.includes('reembolso') || q.includes('error')) {
    return isEs
      ? "💳 **SOPORTE: CANCELACIONES Y REEMBOLSOS**\n\n" +
        "1. **Antes de Cobrar:** Si te equivocaste, simplemente da click en el botón rojo de basura (🗑️) junto al producto en el carrito.\n" +
        "2. **Después de Enviar a Cocina:** Selecciona la mesa/ticket, elimina el producto con el botón de basura y presiona 'Send to Kitchen' de nuevo. Imprimirá un ticket rojo de cancelación (VOID).\n" +
        "3. **Ticket Ya Cobrado:** Si ya pagaron y cerraste la orden, debes ir a `Manager > Ticket History`, buscar el número de orden, presionar `Refund` y devolver el dinero en efectivo o en la terminal."
      : "💳 **SUPPORT: VOIDS & REFUNDS**\n\n" +
        "1. **Before Payment:** If you made a mistake, just click the red trash icon (🗑️) next to the item in the cart.\n" +
        "2. **After Kitchen Send:** Open the ticket, delete the item, and press 'Send to Kitchen' again. A red VOID ticket will print.\n" +
        "3. **Closed/Paid Ticket:** If the order is paid, go to `Manager > Ticket History`, find the order, press `Refund`, and return the money via cash or card terminal.";
  }

  if (q.includes('close') || q.includes('cierre') || q.includes('corte') || q.includes('z-report') || q.includes('propinas') || q.includes('end of day')) {
    return isEs
      ? "📊 **SOPORTE: CIERRE DE CAJA (Z-REPORT)**\n\n" +
        "1. **Órdenes Abiertas:** Asegúrate de que no haya mesas o tickets pendientes por cobrar. Ciérralos todos primero.\n" +
        "2. **Reporte Z:** Ve a `Manager > Z-Report / Close Register`. Imprime el reporte del turno.\n" +
        "3. **Efectivo:** Cuenta el efectivo y guárdalo según las reglas del local.\n" +
        "4. **Propinas:** Si cobraste con tarjeta, suma las propinas en tu terminal bancaria externa y haz el lote (Batch Out) ahí mismo."
      : "📊 **SUPPORT: END OF DAY (Z-REPORT)**\n\n" +
        "1. **Open Orders:** Ensure there are no pending tickets or open tables. Settle all of them first.\n" +
        "2. **Z-Report:** Go to `Manager > Z-Report / Close Register`. Print the shift report.\n" +
        "3. **Cash:** Count the cash drawer and store it according to store policy.\n" +
        "4. **Tips/Credit Cards:** Settle your credit card tips directly on your external credit card terminal and run the Batch Out.";
  }

  if (q.includes('caller') || q.includes('telefono') || q.includes('llamada') || q.includes('loyalty') || q.includes('cliente')) {
    return isEs
      ? "☎️ **SOPORTE: IDENTIFICADOR Y CLIENTES**\n\n" +
        "1. **¿No aparece la llamada?:** Si suena el teléfono y no sale la alerta, verifica en `Setup > Hardware > Other Hardware` que el Caller ID esté configurado en `USB CallerID.com Box`.\n" +
        "2. **Vincular Manualmente:** Si no sirve el identificador, presiona el botón azul `By Customer` en el carrito y escribe el teléfono o nombre del cliente.\n" +
        "3. **Registro Rápido:** No necesitas registrar a los clientes nuevos, solo escribe su nombre o carro en la 'Nota Rápida' al tomar la orden To-Go."
      : "☎️ **SUPPORT: CALLER ID & LOYALTY**\n\n" +
        "1. **Missing Popup?:** If the phone rings but no popup appears, check `Setup > Hardware > Other Hardware` and ensure Caller ID is set to `USB CallerID.com Box`.\n" +
        "2. **Manual Link:** If Caller ID fails, press the blue `By Customer` button in the cart and type the phone number or name.\n" +
        "3. **Quick Notes:** You don't have to register new customers. Just type their name or car info in the 'Quick Note' field when making a To-Go order.";
  }

  if (q.includes('printer') || q.includes('impresora') || q.includes('imprimir') || q.includes('ticket') || q.includes('papel') || q.includes('sumatra')) {
    return isEs 
      ? "🖨️ **DIAGNÓSTICO DE IMPRESORA:**\n\n" +
        "1. **Conexiones:** Verifique que la impresora esté encendida, conectada vía USB o Red y que tenga papel térmico.\n" +
        "2. **Nombre en Windows:** Asegúrese de que el nombre de la impresora en Panel de Control coincida exactamente con el configurado en **Setup > Hardware** (ej. *SumatraPDF* o el nombre del driver).\n" +
        "3. **Prueba de Red:** Si usa impresora de Red, verifique que la IP configurada coincida. Puede probar abriendo el cajón de dinero para verificar comunicación.\n" +
        "4. **Reinicio:** Cierre el software y el servidor Express, y vuelva a abrirlos."
      : "🖨️ **PRINTER DIAGNOSTICS:**\n\n" +
        "1. **Connections:** Check if the printer is turned ON, connected via USB/Network, and has thermal paper loaded correctly.\n" +
        "2. **Windows Driver Name:** Go to POS Options > Setup > Hardware. Ensure the configured Printer Name matches the exact name in Windows Control Panel.\n" +
        "3. **Network Check:** If using a network printer, verify the printer IP matches your network segment. Try executing a 'Kick Drawer' command to test.\n" +
        "4. **Services Restart:** Close the Electron app and restart the local Express server.";
  }

  if (q.includes('drive') || q.includes('lock') || q.includes('bloqueo') || q.includes('disco') || q.includes('external') || q.includes('recording') || q.includes('grabacion') || q.includes('pantalla')) {
    return isEs
      ? "📹 **DIAGNÓSTICO DE BLOQUEO DE DISCO (CONTROL TOTAL):**\n\n" +
        "1. **Causa del Bloqueo:** El sistema requiere grabación de pantalla continua para prevenir fraudes. Si muestra la pantalla negra de bloqueo, el disco o ruta configurados no están disponibles.\n" +
        "2. **Conexión Física:** Verifique que el disco duro externo esté bien enchufado en el puerto USB.\n" +
        "3. **Letra de Unidad:** Asegúrese de que la letra de unidad asignada por Windows (ej. *E:\\Recordings*) coincida exactamente con la escrita en **Setup > Pestaña 1**.\n" +
        "4. **Reconexión:** Al volver a conectar el disco, el bloqueo se retirará de forma automática al instante."
      : "📹 **SURVEILLANCE DISK LOCK DIAGNOSTICS:**\n\n" +
        "1. **Why it Locks:** Screen recording is required for anti-fraud auditing. The black block screen appears if the configured storage folder is missing.\n" +
        "2. **Hardware Connection:** Verify the external hard drive is securely connected to the USB port.\n" +
        "3. **Drive Letter Mismatch:** Ensure Windows hasn't changed the drive letter (e.g. from E: to D:). Check Explorer and update the path in **Setup > Tab A**.\n" +
        "4. **Automatic Resume:** Reconnecting the drive will unlock the register immediately.";
  }

  if (q.includes('nvr') || q.includes('camera') || q.includes('cámara') || q.includes('cctv') || q.includes('overlay') || q.includes('video')) {
    return isEs
      ? "📹 **DIAGNÓSTICO DE TEXTO EN CÁMARAS (NVR):**\n\n" +
        "1. **Habilitación:** Verifique que el switch 'NVR Text Overlay' esté encendido en **Setup > Pestaña 1**.\n" +
        "2. **Dirección IP:** Asegúrese de que la IP del grabador NVR (Annke/Hikvision) coincida con la red local (ej. *192.168.1.100*).\n" +
        "3. **Puerto de Overlay:** Por defecto es el puerto `10010`. Confirme que el grabador tenga habilitada la función de Recepción de Texto TCP en ese puerto.\n" +
        "4. **Prueba de Red:** Intente hacer un ping a la IP del NVR desde la consola de Windows para confirmar que son visibles."
      : "📹 **CCTV / NVR OVERLAY DIAGNOSTICS:**\n\n" +
        "1. **Status**: Check if NVR Text Overlay switch is enabled in **Setup > Tab A**.\n" +
        "2. **IP Configuration**: Ensure the NVR IP address matches your local security recorder (Annke/Hikvision) network IP (e.g. `192.168.1.100`).\n" +
        "3. **TCP Port**: Verify the port is correct (default `10010`) and TCP Overlay receiver is configured inside the NVR software channel settings.\n" +
        "4. **Route Test**: Open cmd.exe in Windows and ping the NVR IP address to verify connectivity.";
  }

  if (q.includes('network') || q.includes('offline') || q.includes('internet') || q.includes('wifi') || q.includes('wi-fi') || q.includes('sincronizacion') || q.includes('nube') || q.includes('vercel') || q.includes('sync')) {
    return isEs
      ? "🌐 **DIAGNÓSTICO DE SINCRONIZACIÓN Y RED:**\n\n" +
        "1. **¿No hay internet?:** Active el interruptor de Modo Offline en **Setup > Pestaña 4**. Esto forzará los códigos QR a usar el router Wi-Fi local.\n" +
        "2. **Conexión del Cliente:** Al usar modo local, el cliente debe conectar su teléfono celular a la red Wi-Fi del local/Taco Truck.\n" +
        "3. **Subdominio Cloud:** Revise que el subdominio configurado (ej. *demo*) y el dominio (ej. *1ti1.com*) sean correctos.\n" +
        "4. **Router Local:** Si los tickets de cocina de auto-pedidos no entran, revise que la IP de la caja no haya cambiado."
      : "🌐 **NETWORK & CLOUD SYNC DIAGNOSTICS:**\n\n" +
        "1. **No Internet?**: Toggle the cloud settings to Offline mode in **Setup > Tab D**. This redirects QR codes to the local router IP.\n" +
        "2. **Customer Connection**: In local mode, clients must connect their phones to the store/truck Wi-Fi network to submit orders.\n" +
        "3. **Domain Check**: Verify the client subdomain (e.g. *demo*) and cloud domain are configured correctly.\n" +
        "4. **Kitchen Sync**: Verify the server is running on port 3000 to process background cloud downloads.";
  }

  if (q.includes('license') || q.includes('licencia') || q.includes('pago') || q.includes('vencimiento') || q.includes('suscripcion') || q.includes('bypass') || q.includes('expire')) {
    return isEs
      ? "🔑 **DIAGNÓSTICO DE LICENCIAS:**\n\n" +
        "1. **Suscripción Prepago:** El software opera bajo un modelo mensual prepagado. Al vencerse, se bloquean las transacciones.\n" +
        "2. **Renovación:** Realice el pago mensual para actualizar el estado del servicio.\n" +
        "3. **Acceso de Emergencia (Bypass):** En la pantalla de licencia, un administrador puede ingresar la contraseña de bypass para extender la licencia temporalmente por 24 horas y reanudar ventas de inmediato."
      : "🔑 **LICENSE & EXPIRATION DIAGNOSTICS:**\n\n" +
        "1. **Prepaid Model**: Impossible POS requires an active monthly paid subscription. Transactions block upon expiration.\n" +
        "2. **Renewal**: Make the pending subscription payment to automatically reactivate the license.\n" +
        "3. **Emergency Bypass**: In the license screen, a manager can input the bypass override key to temporarily restore sales for 24 hours.";
  }

  return isEs
    ? "No estoy seguro de entender esa pregunta. Por favor pregúntame sobre alguno de estos temas específicos:\n" +
      "- **Apertura de Turno y Fondo** (shift / fondo / turno / cobrar bloqueado)\n" +
      "- **Modo Caja vs Modo Mesero** (mesero / waiter / rol de estacion)\n" +
      "- **Letrero QR por Caja** (qr sign / letrero / vincular cliente)\n" +
      "- **Notificaciones Telegram / SMS** (telegram / twilio / botfather)\n" +
      "- **Delivery DoorDash / Uber / Grubhub** (delivery / doordash / uber)\n" +
      "- **Cajón de Dinero y Arqueo** (cajon / gaveta / drawer)\n" +
      "- **Cancelaciones y Reembolsos** (refund / void / cancelar)\n" +
      "- **Cierre de Caja y Z-Report** (cierre / corte / z-report)\n" +
      "- **Impresoras y Papel** (printer / ticket / sumatra)\n" +
      "- **Portal en la Nube** (portal / nube / ver ventas)\n" +
      "- **Cámaras y Grabación** (cctv / nvr / lock)\n" +
      "- **Red y Sincronización** (internet / offline / wifi)\n" +
      "- **Licencias** (pago / vencimiento / bypass)"
    : "I am not sure I understand that question. Please ask me about one of these technical topics:\n" +
      "- **Shift Opening & Cash Float** (shift / float / checkout locked)\n" +
      "- **Cashier vs Waiter Role** (waiter / cashier / station role)\n" +
      "- **Printable Station QR Sign** (qr sign / link / single monitor)\n" +
      "- **Telegram & SMS Alerts** (telegram / twilio / botfather)\n" +
      "- **Delivery DoorDash & Uber Eats** (delivery / doordash / grubhub)\n" +
      "- **Cash Drawer & Auditing** (drawer / cash / open drawer)\n" +
      "- **Voids & Refunds** (refund / void / cancel)\n" +
      "- **End of Day Z-Report** (close / z-report / shift end)\n" +
      "- **Printers & Thermal Paper** (printer / paper / SumatraPDF)\n" +
      "- **Cloud Owner Portal** (portal / cloud / sales)\n" +
      "- **CCTV & Screen Recording** (cctv / nvr / lock)\n" +
      "- **Network & Sync** (offline mode / sync / Wi-Fi)\n" +
      "- **License Expiration** (license / renew / bypass)";
}

// --- STOCK CONTROL AND INVENTORY INTAKE MODULE ---
let selectedStockProduct = null;

function initManagerStockView() {
  selectedStockProduct = null;
  document.getElementById('stockBarSearchInput').value = '';
  document.getElementById('stockProductDetailContainer').style.display = 'none';
  
  // Populate dropdown selection list
  const select = document.getElementById('stockDropdownSearch');
  if (select) {
    select.innerHTML = '<option value="">-- O seleccionar de la lista --</option>';
    
    // Sort products by name
    const sortedProds = [...products].sort((a, b) => a.name.localeCompare(b.name));
    sortedProds.forEach(p => {
      const option = document.createElement('option');
      option.value = p.id;
      option.innerText = `${p.name} (${p.category})`;
      select.appendChild(option);
    });
  }

  // Load levels table on the right side
  loadManagerStockTable();

  // Focus search box
  setTimeout(() => {
    const input = document.getElementById('stockBarSearchInput');
    if (input) {
      input.focus();
    }
  }, 100);

  // Setup press Enter key in search box
  const input = document.getElementById('stockBarSearchInput');
  if (input && !input.dataset.stockSearchBound) {
    input.dataset.stockSearchBound = 'true';
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        handleStockBarcodeSearch();
      }
    });
  }
}
window.initManagerStockView = initManagerStockView;

function handleStockBarcodeSearch() {
  const inputVal = document.getElementById('stockBarSearchInput').value.trim();
  if (!inputVal) {
    showToast('⚠️ Ingrese un código de barras o SKU', 'warning');
    return;
  }

  const p = products.find(prod => 
    (prod.barcode && prod.barcode.toLowerCase() === inputVal.toLowerCase()) || 
    prod.id.toLowerCase() === inputVal.toLowerCase() ||
    prod.name.toLowerCase().includes(inputVal.toLowerCase())
  );

  if (p) {
    loadStockProductDetails(p);
    // Sync dropdown selection if present
    const select = document.getElementById('stockDropdownSearch');
    if (select) select.value = p.id;
  } else {
    showToast('⚠️ Producto no encontrado / Not found', 'error');
  }
}
window.handleStockBarcodeSearch = handleStockBarcodeSearch;

function handleStockDropdownSelect(val) {
  if (!val) {
    selectedStockProduct = null;
    document.getElementById('stockProductDetailContainer').style.display = 'none';
    return;
  }
  const p = products.find(prod => prod.id === val);
  if (p) {
    loadStockProductDetails(p);
    // Set search input value to product barcode
    document.getElementById('stockBarSearchInput').value = p.barcode || '';
  }
}
window.handleStockDropdownSelect = handleStockDropdownSelect;

function loadStockProductDetails(p) {
  selectedStockProduct = p;
  
  // Set basic info
  document.getElementById('stockProdTitle').innerText = p.name;
  document.getElementById('stockProdBarcode').innerText = p.barcode || 'N/A';
  document.getElementById('stockProdCategory').innerText = p.category || 'Varios';
  
  // Status status
  const statusEl = document.getElementById('stockProdTrackStatus');
  if (p.trackStock) {
    statusEl.innerText = 'Rastreando Stock (Activo)';
    statusEl.style.color = 'var(--success-color)';
  } else {
    statusEl.innerText = 'Ilimitado / Sin control';
    statusEl.style.color = 'var(--warning-color)';
  }

  // Stock Qty
  const qtyVal = parseFloat(p.stockQuantity) || 0;
  document.getElementById('stockProdQty').innerText = qtyVal.toFixed(2);
  
  // Reset intake fields
  document.getElementById('stockAddQty').value = '';
  document.getElementById('stockAddUnitType').value = 'pieces';
  
  // Populate config fields
  document.getElementById('stockConfigTrack').checked = !!p.trackStock;
  document.getElementById('stockConfigBoxSize').value = p.boxSize !== undefined ? p.boxSize : 12;
  document.getElementById('stockConfigPalletSize').value = p.palletSize !== undefined ? p.palletSize : 200;
  document.getElementById('stockConfigQty').value = qtyVal;

  // Show profile
  document.getElementById('stockProductDetailContainer').style.display = 'flex';
  
  // Trigger preview text
  updateIntakePreviewText();
}
window.loadStockProductDetails = loadStockProductDetails;

function updateIntakePreviewText() {
  if (!selectedStockProduct) return;
  const qty = parseFloat(document.getElementById('stockAddQty').value) || 0;
  const unit = document.getElementById('stockAddUnitType').value;
  const boxSize = parseFloat(selectedStockProduct.boxSize) || 12;
  const palletSize = parseFloat(selectedStockProduct.palletSize) || 200;

  const previewEl = document.getElementById('stockIntakePreview');
  if (!previewEl) return;

  if (qty <= 0) {
    previewEl.innerText = '* Ingrese cantidad para ver equivalencia.';
    return;
  }

  if (unit === 'pieces') {
    previewEl.innerText = `* Se agregarán ${qty} unidades directas a inventario.`;
  } else if (unit === 'boxes') {
    const total = qty * boxSize;
    previewEl.innerText = `* Equivalencia: ${qty} cajas × ${boxSize} unid. = +${total} unidades.`;
  } else if (unit === 'pallets') {
    const total = qty * palletSize;
    previewEl.innerText = `* Equivalencia: ${qty} pallets × ${palletSize} unid. = +${total} unidades.`;
  }
}
window.updateIntakePreviewText = updateIntakePreviewText;

// Setup live preview on quantity input typing
document.addEventListener('DOMContentLoaded', () => {
  const addQtyInput = document.getElementById('stockAddQty');
  if (addQtyInput) {
    addQtyInput.addEventListener('input', updateIntakePreviewText);
  }
});

async function submitStockIntake() {
  if (!selectedStockProduct) {
    showToast('⚠️ No product selected', 'error');
    return;
  }
  
  const qty = parseFloat(document.getElementById('stockAddQty').value) || 0;
  if (qty <= 0) {
    showToast('⚠️ Ingrese una cantidad válida mayor a 0', 'warning');
    return;
  }

  const unitType = document.getElementById('stockAddUnitType').value;

  try {
    const res = await fetch(`${SERVER_URL}/api/admin/products/${selectedStockProduct.id}/add-stock`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quantity: qty, unitType })
    });

    if (res.ok) {
      showToast('📥 Entrada registrada con éxito', 'success');
      
      // Reload products cache
      await loadProducts();
      
      // Refresh current product details from loaded array
      const updated = products.find(p => p.id === selectedStockProduct.id);
      if (updated) {
        loadStockProductDetails(updated);
      }
      
      // Refresh general levels table
      loadManagerStockTable();
    } else {
      showToast('Error al registrar entrada de stock', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Error de conexión', 'error');
  }
}
window.submitStockIntake = submitStockIntake;

async function submitStockConfig() {
  if (!selectedStockProduct) {
    showToast('⚠️ No product selected', 'error');
    return;
  }

  const trackStock = document.getElementById('stockConfigTrack').checked;
  const boxSize = parseFloat(document.getElementById('stockConfigBoxSize').value) || 12;
  const palletSize = parseFloat(document.getElementById('stockConfigPalletSize').value) || 200;
  const stockQuantity = parseFloat(document.getElementById('stockConfigQty').value) || 0;

  try {
    const res = await fetch(`${SERVER_URL}/api/admin/products/${selectedStockProduct.id}/stock-config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ trackStock, boxSize, palletSize, stockQuantity })
    });

    if (res.ok) {
      showToast('⚙️ Configuración de stock guardada', 'success');
      
      // Reload products cache
      await loadProducts();
      
      // Refresh current product details from loaded array
      const updated = products.find(p => p.id === selectedStockProduct.id);
      if (updated) {
        loadStockProductDetails(updated);
      }
      
      // Refresh general levels table
      loadManagerStockTable();
    } else {
      showToast('Error al guardar configuración de stock', 'error');
    }
  } catch (err) {
    console.error(err);
    showToast('Error de conexión', 'error');
  }
}
window.submitStockConfig = submitStockConfig;

function loadManagerStockTable() {
  const tbody = document.getElementById('managerStockTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  // Filter only products that have stock tracking active
  const trackedProds = products.filter(p => p.trackStock);
  
  if (trackedProds.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-secondary); padding: 40px 0;">No hay productos bajo control de stock actualmente.</td></tr>`;
    return;
  }

  // Sort tracked products by name
  trackedProds.sort((a, b) => a.name.localeCompare(b.name));

  trackedProds.forEach(p => {
    const qty = parseFloat(p.stockQuantity) || 0;
    
    // Choose color depending on quantity
    let qtyColor = 'var(--success-color)'; // Green (> 10)
    if (qty <= 0) {
      qtyColor = 'var(--danger-color)'; // Red (Agotado)
    } else if (qty < 10) {
      qtyColor = 'var(--warning-color)'; // Orange (< 10)
    }

    const tr = document.createElement('tr');
    tr.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    tr.style.cursor = 'pointer';
    tr.addEventListener('click', () => {
      loadStockProductDetails(p);
      // Update dropdown and search bar
      const select = document.getElementById('stockDropdownSearch');
      if (select) select.value = p.id;
      document.getElementById('stockBarSearchInput').value = p.barcode || '';
    });

    tr.innerHTML = `
      <td style="padding: 6px 10px; font-weight: bold; color: #fff;">${p.name}</td>
      <td style="padding: 6px 10px; color: var(--text-secondary);">${p.barcode || 'N/A'}</td>
      <td style="padding: 6px 10px; color: var(--text-secondary); text-transform: capitalize;">${p.category}</td>
      <td style="padding: 6px 10px; text-align: right; font-weight: bold; color: ${qtyColor}; font-size: 12px;">${qty.toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
}
window.loadManagerStockTable = loadManagerStockTable;

// --- DYNAMIC DEPARTMENT & PRODUCT SALES REPORT SYSTEM ---
window.onReportDepartmentChange = function() {
  const dept = document.getElementById('reportDepartmentSelect').value;
  const container = document.getElementById('reportProductCheckboxContainer');
  const resultsDiv = document.getElementById('departmentProductReportResults');
  
  if (dept === 'all') {
    container.innerHTML = '<div style="font-size: 10px; color: var(--text-secondary); padding: 4px; text-align: center;">All products included</div>';
    resultsDiv.style.display = 'none';
    return;
  }
  
  // Filter products matching this department
  const deptProducts = products.filter(p => {
    const cat = (p.category || '').toLowerCase();
    const name = (p.name || '').toLowerCase();
    
    switch (dept) {
      case 'bakery':
        return cat === 'panaderia' || cat === 'pan' || name.includes('pan') || name.includes('bolillo');
      case 'dessert':
        return cat === 'postres' || cat === 'postre' || cat === 's cake' || cat === 'dessert slice' || name.includes('dessert') || name.includes('gelatina') || name.includes('flan');
      case 'cakes_stock':
        return (cat === 'pastel' || cat === 'cake' || name.includes('pastel') || name.includes('cake')) && !p.isCustomCake;
      case 'drinks':
        return cat === 'bebidas' || cat === 'drinks' || name.includes('soda') || name.includes('jugo') || name.includes('water') || name.includes('agua') || name.includes('coffee') || name.includes('licuado');
      case 'store':
        return cat === 'tienda' || cat === 'store' || cat === 'mercancia';
      case 'restaurant':
        return cat === 'restaurante' || cat === 'cocina' || cat === 'food' || cat === 'comida';
      case 'custom_cake':
        return p.isCustomCake || cat === 'custom_cake';
      case 'wedding':
        return cat === 'wedding' || name.includes('wedding') || name.includes('evento') || name.includes('event');
      case 'bar':
        return cat === 'bar' || cat === 'alcohol' || cat === 'licor' || cat === 'botella' || name.includes('don julio') || name.includes('hennessy') || name.includes('tito') || name.includes('vodka') || name.includes('tequila') || name.includes('cerveza') || name.includes('trago') || name.includes('shot');
      default:
        return false;
    }
  });

  if (deptProducts.length === 0) {
    container.innerHTML = '<div style="font-size: 10px; color: var(--text-secondary); padding: 4px; text-align: center;">No products in catalog</div>';
    resultsDiv.style.display = 'none';
    return;
  }

  // Render checkbox list
  let html = `
    <div style="display: flex; align-items: center; gap: 4px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 4px; margin-bottom: 4px;">
      <input type="checkbox" id="reportSelectAllProducts" checked onchange="toggleAllReportProducts(this)">
      <label for="reportSelectAllProducts" style="font-size: 10px; font-weight: bold; color: #fff; cursor: pointer;">All (${deptProducts.length} items)</label>
    </div>
  `;

  deptProducts.forEach(p => {
    html += `
      <div style="display: flex; align-items: center; gap: 4px; margin-bottom: 2px;">
        <input type="checkbox" class="report-prod-cb" value="${p.name}" data-price="${p.price}" id="cb_rep_${p.id}" checked onchange="calculateDeptProductSales()">
        <label for="cb_rep_${p.id}" style="font-size: 9px; color: var(--text-secondary); cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 160px;" title="${p.name} - $${p.price}">${p.name} ($${p.price})</label>
      </div>
    `;
  });

  container.innerHTML = html;
  
  // Automatically trigger calculation
  calculateDeptProductSales();
};

window.toggleAllReportProducts = function(masterCb) {
  document.querySelectorAll('.report-prod-cb').forEach(cb => {
    cb.checked = masterCb.checked;
  });
  calculateDeptProductSales();
};

window.calculateDeptProductSales = function() {
  const dept = document.getElementById('reportDepartmentSelect').value;
  const resultsDiv = document.getElementById('departmentProductReportResults');
  
  if (dept === 'all' || !window.lastFilteredOrders) {
    resultsDiv.style.display = 'none';
    return;
  }

  // Get checked product names
  const checkedProds = new Set();
  document.querySelectorAll('.report-prod-cb:checked').forEach(cb => {
    checkedProds.add(cb.value.toLowerCase());
  });

  if (checkedProds.size === 0) {
    resultsDiv.innerHTML = '<div style="color:var(--text-secondary); font-size:10px; padding: 4px;">Select at least one product...</div>';
    resultsDiv.style.display = 'block';
    return;
  }

  // Count sales in lastFilteredOrders
  const sales = {};
  let totalQty = 0;
  let totalRev = 0;

  window.lastFilteredOrders.forEach(o => {
    if (o.status === 'void' || o.status === 'refunded') return;
    o.items.forEach(item => {
      const name = item.name.toLowerCase();
      if (checkedProds.has(name)) {
        if (!sales[item.name]) {
          sales[item.name] = { qty: 0, subtotal: 0 };
        }
        sales[item.name].qty += item.quantity;
        sales[item.name].subtotal += item.price * item.quantity;
        totalQty += item.quantity;
        totalRev += item.price * item.quantity;
      }
    });
  });

  const sortedProducts = Object.keys(sales).sort((a, b) => sales[b].subtotal - sales[a].subtotal);

  let html = `
    <div style="font-weight: bold; border-bottom: 1px solid var(--border-color); padding-bottom: 4px; margin-bottom: 6px; color: var(--accent-color); display: flex; justify-content: space-between;">
      <span>Department Sales Summary</span>
      <span style="color:#fff;">Net: $${totalRev.toFixed(2)}</span>
    </div>
    <table style="width: 100%; border-collapse: collapse; font-size: 10px; text-align: left; color:#fff;">
      <thead>
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.05); color: var(--text-secondary); font-weight: bold;">
          <th style="padding: 2px;">Product</th>
          <th style="padding: 2px; text-align: center;">Qty</th>
          <th style="padding: 2px; text-align: right;">Total</th>
        </tr>
      </thead>
      <tbody>
  `;

  if (sortedProducts.length === 0) {
    html += `
      <tr>
        <td colspan="3" style="text-align: center; padding: 6px; color: var(--text-secondary);">No sales recorded for selected products</td>
      </tr>
    `;
  } else {
    sortedProducts.forEach(name => {
      const item = sales[name];
      html += `
        <tr style="border-bottom: 1px solid rgba(255,255,255,0.03);">
          <td style="padding: 2px;"><strong>${name}</strong></td>
          <td style="padding: 2px; text-align: center;">${item.qty}</td>
          <td style="padding: 2px; text-align: right; font-weight: bold;">$${item.subtotal.toFixed(2)}</td>
        </tr>
      `;
    });
    html += `
      <tr style="border-top: 1px solid var(--border-color); font-weight: bold; color: var(--success-color);">
        <td style="padding: 4px 2px;">TOTAL</td>
        <td style="padding: 4px 2px; text-align: center;">${totalQty}</td>
        <td style="padding: 4px 2px; text-align: right;">$${totalRev.toFixed(2)}</td>
      </tr>
    `;
  }

  html += `
      </tbody>
    </table>
  `;

  resultsDiv.innerHTML = html;
  resultsDiv.style.display = 'block';
};

window.renderReportCharts = function(filtered) {
  const container = document.getElementById('managerReportCharts');
  if (!container) return;

  // Filter out voids and refunds for sales charts
  const salesOrders = filtered.filter(o => o.status !== 'void' && o.status !== 'refunded');

  if (salesOrders.length === 0) {
    container.innerHTML = `
      <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; background: rgba(0,0,0,0.1); text-align: center; color: var(--text-secondary); font-size: 11px;">
        📉 No hay suficientes datos de ventas en este rango para mostrar gráficos.
      </div>
    `;
    return;
  }

  // 1. Group sales by hour
  const hourlySales = {};
  for (let h = 8; h <= 22; h++) {
    hourlySales[h] = 0;
  }

  salesOrders.forEach(o => {
    const hr = new Date(o.dateCreated).getHours();
    if (hourlySales[hr] !== undefined) {
      hourlySales[hr] += o.total;
    } else {
      hourlySales[hr] = o.total;
    }
  });

  const maxHourVal = Math.max(...Object.values(hourlySales), 1);

  let hourlyBarsHtml = '';
  Object.keys(hourlySales).sort((a,b) => parseInt(a) - parseInt(b)).forEach(hrKey => {
    const total = hourlySales[hrKey];
    const percentage = (total / maxHourVal) * 100;
    // Scale height (max height = 80px, min = 2px if there are sales)
    const barHeight = total > 0 ? Math.max(Math.round((percentage / 100) * 80), 3) : 0;
    const hourLabel = parseInt(hrKey) > 12 ? (parseInt(hrKey) - 12) + ' PM' : hrKey + ' AM';
    const barColor = total > 0 ? 'var(--accent-color)' : 'rgba(255,255,255,0.02)';

    hourlyBarsHtml += `
      <div style="display: flex; flex-direction: column; align-items: center; flex: 1; min-width: 25px;">
        <div style="font-size: 8px; color: ${total > 0 ? 'var(--success-color)' : 'var(--text-secondary)'}; margin-bottom: 2px; font-weight: bold;">${total > 0 ? '$' + total.toFixed(0) : ''}</div>
        <div style="width: 14px; height: 80px; background: rgba(255,255,255,0.02); display: flex; align-items: flex-end; border-radius: 3px; overflow: hidden; border: 1px solid rgba(255,255,255,0.03);">
          <div style="width: 100%; height: ${barHeight}px; background: ${barColor}; border-radius: 2px;" title="${hourLabel}: $${total.toFixed(2)}"></div>
        </div>
        <div style="font-size: 7px; color: var(--text-secondary); margin-top: 4px; white-space: nowrap;">${hourLabel}</div>
      </div>
    `;
  });

  // 2. Calculate product sales quantities
  const productQuantities = {};
  salesOrders.forEach(o => {
    o.items.forEach(item => {
      if (!productQuantities[item.name]) {
        productQuantities[item.name] = 0;
      }
      productQuantities[item.name] += item.quantity;
    });
  });

  // Sort products
  const sortedProds = Object.keys(productQuantities).map(name => ({
    name: name,
    qty: productQuantities[name]
  })).sort((a, b) => b.qty - a.qty);

  const topProducts = sortedProds.slice(0, 5);
  const leastProducts = sortedProds.filter(p => p.qty > 0).slice(-5).reverse();

  const maxQtyVal = sortedProds.length > 0 ? sortedProds[0].qty : 1;

  let topProdsHtml = '';
  topProducts.forEach(p => {
    const pct = Math.round((p.qty / maxQtyVal) * 100);
    topProdsHtml += `
      <div style="margin-bottom: 8px;">
        <div style="display: flex; justify-content: space-between; font-size: 9px; margin-bottom: 2px;">
          <span style="color: #fff; font-weight: bold; text-overflow: ellipsis; white-space: nowrap; overflow: hidden; max-width: 70%;" title="${p.name}">${p.name}</span>
          <span style="color: var(--success-color); font-weight: bold;">${p.qty} sold</span>
        </div>
        <div style="width: 100%; height: 6px; background: rgba(255,255,255,0.03); border-radius: 3px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
          <div style="width: ${pct}%; height: 100%; background: linear-gradient(90deg, #30d158, #34c759); border-radius: 3px;"></div>
        </div>
      </div>
    `;
  });

  let leastProdsHtml = '';
  leastProducts.forEach(p => {
    const pct = Math.round((p.qty / maxQtyVal) * 100);
    leastProdsHtml += `
      <div style="margin-bottom: 8px;">
        <div style="display: flex; justify-content: space-between; font-size: 9px; margin-bottom: 2px;">
          <span style="color: #fff; font-weight: bold; text-overflow: ellipsis; white-space: nowrap; overflow: hidden; max-width: 70%;" title="${p.name}">${p.name}</span>
          <span style="color: var(--danger-color); font-weight: bold;">${p.qty} sold</span>
        </div>
        <div style="width: 100%; height: 6px; background: rgba(255,255,255,0.03); border-radius: 3px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05);">
          <div style="width: ${pct}%; height: 100%; background: linear-gradient(90deg, #ff3b30, #ff453a); border-radius: 3px;"></div>
        </div>
      </div>
    `;
  });

  container.innerHTML = `
    <!-- Hourly Timeline Graph Card -->
    <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 12px; background: rgba(0,0,0,0.2); width: 100%;">
      <div style="font-weight: bold; font-size: 11px; color: var(--accent-color); margin-bottom: 8px; text-align: left; display: flex; align-items: center; gap: 4px;">📈 Business Peak Hours Timeline (Ventas por Hora)</div>
      <div style="display: flex; justify-content: space-between; align-items: flex-end; padding: 8px 4px; overflow-x: auto; gap: 4px;">
        ${hourlyBarsHtml}
      </div>
    </div>

    <!-- Top & Least Selling Products Grid -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; width: 100%;">
      <!-- Top Sellers -->
      <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 10px; background: rgba(0,0,0,0.2);">
        <div style="font-weight: bold; font-size: 10px; color: var(--success-color); margin-bottom: 8px; text-align: left;">🔥 Top-Selling Items (Más Vendidos)</div>
        ${topProdsHtml || '<div style="color:var(--text-secondary); font-size:9px; text-align:center;">No data available</div>'}
      </div>
      <!-- Least Sellers -->
      <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 10px; background: rgba(0,0,0,0.2);">
        <div style="font-weight: bold; font-size: 10px; color: var(--danger-color); margin-bottom: 8px; text-align: left;">❄️ Least-Selling Items (Menos Vendidos)</div>
        ${leastProdsHtml || '<div style="color:var(--text-secondary); font-size:9px; text-align:center;">No data available</div>'}
      </div>
    </div>
  `;
};

let screenMediaRecorder = null;
let screenStream = null;

async function initScreenRecording() {
  try {
    if (!posSettings || posSettings.recordEnabled !== true) {
      if (screenMediaRecorder && screenMediaRecorder.state !== 'inactive') {
        screenMediaRecorder.stop();
        screenMediaRecorder = null;
      }
      if (screenStream) {
        screenStream.getTracks().forEach(t => t.stop());
        screenStream = null;
      }
      return;
    }

    if (!window.electronAPI || !window.electronAPI.getPrimaryScreenSourceId) {
      console.warn("[SCREEN RECORDING] Screen recording only works inside Electron.");
      return;
    }

    if (screenMediaRecorder && screenMediaRecorder.state === 'recording') {
      return;
    }

    console.log("[SCREEN RECORDING] Starting screen recording...");
    const sourceId = await window.electronAPI.getPrimaryScreenSourceId();
    if (!sourceId) {
      console.error("[SCREEN RECORDING] Could not get screen source ID.");
      return;
    }

    const quality = posSettings.recordQuality || 'medium';
    let frameRate = 15;
    let bitRate = 400000;
    
    if (quality === 'low') {
      frameRate = 10;
      bitRate = 150000;
    } else if (quality === 'high') {
      frameRate = 30;
      bitRate = 1000000;
    }

    screenStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        mandatory: {
          chromeMediaSource: 'desktop',
          chromeMediaSourceId: sourceId,
          minWidth: 1024,
          maxWidth: 1280,
          minHeight: 640,
          maxHeight: 800,
          minFrameRate: frameRate,
          maxFrameRate: frameRate
        }
      }
    });

    screenMediaRecorder = new MediaRecorder(screenStream, {
      mimeType: 'video/webm; codecs=vp9',
      videoBitsPerSecond: bitRate
    });

    screenMediaRecorder.ondataavailable = async (e) => {
      if (e.data && e.data.size > 0) {
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const base64 = reader.result.split(',')[1];
            const res = await fetch(`${SERVER_URL}/api/recordings/upload`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ base64Data: base64 })
            });
            if (!res.ok) {
              const data = await res.json();
              if (data.error === 'DRIVE_DISCONNECTED') {
                const overlay = document.getElementById('storageDriveBlockOverlay');
                if (overlay) overlay.style.display = 'flex';
              }
            } else {
              const overlay = document.getElementById('storageDriveBlockOverlay');
              if (overlay) overlay.style.display = 'none';
            }
          } catch (uploadErr) {
            console.error('[SCREEN RECORDING] Upload failed:', uploadErr.message);
          }
        };
        reader.readAsDataURL(e.data);
      }
    };

    screenMediaRecorder.start(10000);
    console.log("[SCREEN RECORDING] Active under VP9 quality:", quality);

  } catch (err) {
    console.error("[SCREEN RECORDING] Initialization failed:", err.message);
  }
}

// Bind Caller ID popup actions and simulated call triggers
document.addEventListener('DOMContentLoaded', () => {
  const btnDismiss = document.getElementById('btnDismissCallerId');
  if (btnDismiss) {
    btnDismiss.addEventListener('click', () => {
      document.getElementById('callerIdPopup').style.display = 'none';
      if (window.callerIdTimeout) clearTimeout(window.callerIdTimeout);
      window.activeIncomingCaller = null;
    });
  }

  const btnLink = document.getElementById('btnLinkCallerIdToOrder');
  if (btnLink) {
    btnLink.addEventListener('click', () => {
      if (!window.activeIncomingCaller) return;
      const caller = window.activeIncomingCaller;
      
      currentLoyaltyClient = {
        name: caller.name,
        phone: caller.phone,
        points: caller.points || 0,
        type: caller.isRegistered ? 'individual' : 'custom',
        address: caller.address || ''
      };
      
      if (deliveryType === 'comer') {
        tabTableNumber = 'Customer: ' + caller.name;
        tabClientCount = 1;
        activeTabClientSeat = 1;
      }
      
      setLoyaltyClientUI();
      document.getElementById('callerIdPopup').style.display = 'none';
      if (window.callerIdTimeout) clearTimeout(window.callerIdTimeout);
      window.activeIncomingCaller = null;
      
      showToast(posSettings && posSettings.language === 'es' ? `¡Llamada de ${caller.name} vinculada!` : `Call from ${caller.name} linked!`, 'success');
    });
  }

  const btnSim = document.getElementById('btnSimulateCall');
  if (btnSim) {
    btnSim.addEventListener('click', async () => {
      try {
        const isEs = posSettings && posSettings.language === 'es';
        const mockPhone = '3138418480';
        const mockName = isEs ? 'Juanita Pérez' : 'Juanita Perez';
        
        await fetch(`${SERVER_URL}/api/caller-id/event`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: mockPhone, name: mockName })
        });
      } catch (err) {
        console.error("Simulation error:", err);
      }
    });
  }
});






// --- OPTIONAL EBT (SNAP) & WIC MODULE CONTROLLER ---
function toggleEbtWicSetting(checked) {
  localStorage.setItem('imp_enable_ebt_wic', checked ? 'true' : 'false');
  updateEbtWicVisibility();
  const isEs = (typeof posSettings !== "undefined" && posSettings && posSettings.language === "es"); showToast(checked ? (isEs ? "Módulo EBT/WIC activado (Visible en Cobro)" : "EBT/WIC Module enabled (Visible in Checkout)") : (isEs ? "Módulo EBT/WIC desactivado" : "EBT/WIC Module disabled"), "info");
}
window.toggleEbtWicSetting = toggleEbtWicSetting;

function updateEbtWicVisibility() {
  // Enabled by default so merchants can immediately see and use EBT & WIC tender keys
  const isEnabled = localStorage.getItem('imp_enable_ebt_wic') !== 'false';
  const container = document.getElementById('checkoutEbtPayContainer');
  const chk = document.getElementById('chkEnableEbtWic');
  if (chk) chk.checked = isEnabled;
  if (container) {
    container.style.display = isEnabled ? 'flex' : 'none';
  }
}
window.updateEbtWicVisibility = updateEbtWicVisibility;

// Attach click handlers to EBT / WIC buttons
document.addEventListener('DOMContentLoaded', () => {
  updateEbtWicVisibility();
  
  const btnEbt = document.getElementById('btnPayEbt');
  if (btnEbt) {
    btnEbt.onclick = () => {
      processCheckout('ebt');
    };
  }
  const btnWic = document.getElementById('btnPayWic');
  if (btnWic) {
    btnWic.onclick = () => {
      processCheckout('wic');
    };
  }
});


// --- LINK DEVICES & STATIONS MODAL SYSTEM ---
window.openLinkDevicesModal = async function() {
  const modal = document.getElementById('modalLinkDevices');
  if (!modal) return;
  modal.style.display = 'flex';

  let baseHost = window.location.hostname;
  if (baseHost === 'localhost' || baseHost === '127.0.0.1' || !baseHost) {
    try {
      const res = await fetch(`${SERVER_URL}/api/local-ip`);
      if (res.ok) {
        const data = await res.json();
        if (data.ip && data.ip !== '127.0.0.1') {
          baseHost = data.ip;
        }
      }
    } catch(e) {
      console.warn("Could not fetch local IP for link modal", e);
    }
  }

  const port = window.location.port ? `:${window.location.port}` : ':3000';
  const protocol = window.location.protocol === 'https:' ? 'https:' : 'http:';
  const baseUrl = `${protocol}//${baseHost}${port}`;

  const stations = [
    { qrId: 'qrDevWaiters', urlId: 'urlDevWaiters', path: '/ordena.html' },
    { qrId: 'qrDevKitchen', urlId: 'urlDevKitchen', path: '/cocina.html' },
    { qrId: 'qrDevBar', urlId: 'urlDevBar', path: '/kds_bar.html' },
    { qrId: 'qrDevRunner', urlId: 'urlDevRunner', path: '/runner.html' },
    { qrId: 'qrDevHostess', urlId: 'urlDevHostess', path: '/hostess.html' },
    { qrId: 'qrDevLobby', urlId: 'urlDevLobby', path: '/espera.html' },
    { qrId: 'qrDevReports', urlId: 'urlDevReports', path: '/reports.html' }
  ];

  stations.forEach(st => {
    const fullUrl = `${baseUrl}${st.path}`;
    const urlEl = document.getElementById(st.urlId);
    if (urlEl) urlEl.innerText = fullUrl;

    const qrEl = document.getElementById(st.qrId);
    if (qrEl) {
      qrEl.innerHTML = '';
      try {
        new QRCode(qrEl, {
          text: fullUrl,
          width: 104,
          height: 104,
          correctLevel: QRCode.CorrectLevel.M
        });
        const img = qrEl.querySelector('img');
        if (img) img.style.margin = '0 auto';
      } catch(err) {
        console.error("Error drawing station QR for " + st.qrId, err);
      }
    }
  });
};

window.closeLinkDevicesModal = function() {
  const modal = document.getElementById('modalLinkDevices');
  if (modal) modal.style.display = 'none';
};

window.copyStationUrl = function(urlElemId) {
  const el = document.getElementById(urlElemId);
  if (!el) return;
  const text = el.innerText || el.textContent;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      const isEs = (typeof posSettings !== 'undefined' && posSettings && posSettings.language === 'es');
      showToast(isEs ? "¡Enlace copiado al portapapeles!" : "Link copied to clipboard!", "success");
    }).catch(() => {
      fallbackCopyText(text);
    });
  } else {
    fallbackCopyText(text);
  }
};

function fallbackCopyText(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  try {
    document.execCommand('copy');
    const isEs = (typeof posSettings !== 'undefined' && posSettings && posSettings.language === 'es');
    showToast(isEs ? "¡Enlace copiado al portapapeles!" : "Link copied to clipboard!", "success");
  } catch(err) {}
  document.body.removeChild(textarea);
}


// --- USB DIGITAL WEIGHT SCALE MODULE ---
let currentScaleWeight = 0.00;
let currentScaleTare = 0.00;
let currentScaleUnit = 'lb';

function toggleWeightScaleSetting(enabled) {
  const btnWeigh = document.getElementById('btnCartWeighItem');
  if (btnWeigh) btnWeigh.style.display = enabled ? 'flex' : 'none';
}

async function testWeightScaleConnection() {
  const port = (document.getElementById('adminWeightScalePort') && document.getElementById('adminWeightScalePort').value) || 'COM4';
  const unit = (document.getElementById('adminWeightScaleUnit') && document.getElementById('adminWeightScaleUnit').value) || 'lb';
  const isEs = posSettings && posSettings.language === 'es';
  showToast(isEs ? `Probando báscula en ${port}...` : `Testing scale on ${port}...`, 'info');
  try {
    const res = await fetch(`${SERVER_URL}/api/scale/read?port=${encodeURIComponent(port)}&unit=${encodeURIComponent(unit)}`);
    const data = await res.json();
    if (data.success) {
      showToast(isEs ? `✅ Báscula conectada en ${port}: ${data.weight} ${data.unit}` : `✅ Scale connected on ${port}: ${data.weight} ${data.unit}`, 'success');
    } else {
      showToast(isEs ? `⚠️ Respuesta: ${data.message || 'Sin señal'}` : `⚠️ Response: ${data.message || 'No signal'}`, 'warning');
    }
  } catch (err) {
    showToast(`Error: ${err.message}`, 'error');
  }
}

function openWeightScaleModal(preselectedProduct = null) {
  const modal = document.getElementById('modalWeightScale');
  if (!modal) return;

  const unitSelect = document.getElementById('adminWeightScaleUnit');
  currentScaleUnit = (posSettings && posSettings.weightScaleUnit) || (unitSelect ? unitSelect.value : 'lb') || 'lb';
  const unitDisp = document.getElementById('lblScaleUnitDisplay');
  if (unitDisp) unitDisp.innerText = currentScaleUnit;

  const port = (posSettings && posSettings.weightScalePort) || 'COM4';
  const portInfo = document.getElementById('lblScalePortInfo');
  if (portInfo) portInfo.innerText = `Scale Port: ${port} (${currentScaleUnit.toUpperCase()})`;

  const prodSelect = document.getElementById('scaleProductSelect');
  if (prodSelect) {
    prodSelect.innerHTML = '';
    const isEs = posSettings && posSettings.language === 'es';

    if (!products || products.length === 0) {
      prodSelect.innerHTML = `<option value="">${isEs ? '-- No hay productos cargados --' : '-- No products loaded --'}</option>`;
    } else {
      const sorted = [...products].sort((a, b) => (a.name || '').localeCompare(b.name || ''));
      sorted.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.id;
        opt.dataset.price = p.price;
        opt.dataset.name = p.name;
        opt.dataset.taxable = p.isTaxable !== false;
        opt.innerText = `${p.name} - $${p.price.toFixed(2)} / ${currentScaleUnit}`;
        if (preselectedProduct && preselectedProduct.id === p.id) {
          opt.selected = true;
        }
        prodSelect.appendChild(opt);
      });
    }
  }

  currentScaleWeight = 0.00;
  const liveWt = document.getElementById('lblScaleLiveWeight');
  if (liveWt) liveWt.innerText = '0.00';
  const manInp = document.getElementById('inputManualScaleWeight');
  if (manInp) manInp.value = '';
  
  onScaleProductChange();
  modal.style.display = 'flex';
  triggerReadWeightScale();
}

function closeWeightScaleModal() {
  const modal = document.getElementById('modalWeightScale');
  if (modal) modal.style.display = 'none';
}

async function triggerReadWeightScale() {
  const port = (posSettings && posSettings.weightScalePort) || 'COM4';
  try {
    const res = await fetch(`${SERVER_URL}/api/scale/read?port=${encodeURIComponent(port)}&unit=${encodeURIComponent(currentScaleUnit)}`);
    const data = await res.json();
    if (data.success && data.weight !== undefined) {
      currentScaleWeight = Math.max(0, parseFloat((parseFloat(data.weight) - currentScaleTare).toFixed(2)));
      const liveWt = document.getElementById('lblScaleLiveWeight');
      if (liveWt) liveWt.innerText = currentScaleWeight.toFixed(2);
      const stab = document.getElementById('lblScaleStability');
      if (stab) stab.innerText = data.stable ? 'STABLE' : 'MOTION';
      recalculateScaleTotal();
    }
  } catch (err) {
    console.warn("Scale read fallback:", err);
  }
}

async function tareWeightScale() {
  const isEs = posSettings && posSettings.language === 'es';
  currentScaleTare = parseFloat((currentScaleWeight + currentScaleTare).toFixed(2));
  const tareVal = document.getElementById('lblScaleTareVal');
  if (tareVal) tareVal.innerText = currentScaleTare.toFixed(2);
  currentScaleWeight = 0.00;
  const liveWt = document.getElementById('lblScaleLiveWeight');
  if (liveWt) liveWt.innerText = '0.00';
  recalculateScaleTotal();
  showToast(isEs ? 'Báscula tarada a 0.00' : 'Scale tared to 0.00', 'info');
  try {
    await fetch(`${SERVER_URL}/api/scale/tare`, { method: 'POST' });
  } catch (e) {}
}

function zeroWeightScale() {
  currentScaleTare = 0.00;
  currentScaleWeight = 0.00;
  const tareVal = document.getElementById('lblScaleTareVal');
  if (tareVal) tareVal.innerText = '0.00';
  const liveWt = document.getElementById('lblScaleLiveWeight');
  if (liveWt) liveWt.innerText = '0.00';
  const manInp = document.getElementById('inputManualScaleWeight');
  if (manInp) manInp.value = '';
  recalculateScaleTotal();
}

function onScaleProductChange() {
  const prodSelect = document.getElementById('scaleProductSelect');
  if (!prodSelect || !prodSelect.selectedOptions || prodSelect.selectedOptions.length === 0) return;
  const opt = prodSelect.selectedOptions[0];
  const price = parseFloat(opt.dataset.price) || 0;
  const unitPriceLbl = document.getElementById('lblScaleUnitPrice');
  if (unitPriceLbl) unitPriceLbl.innerText = `$${price.toFixed(2)} / ${currentScaleUnit}`;
  recalculateScaleTotal();
}

function onManualScaleWeightInput() {
  const inp = document.getElementById('inputManualScaleWeight');
  if (!inp) return;
  const val = parseFloat(inp.value);
  if (!isNaN(val) && val >= 0) {
    currentScaleWeight = val;
    const liveWt = document.getElementById('lblScaleLiveWeight');
    if (liveWt) liveWt.innerText = val.toFixed(2);
    recalculateScaleTotal();
  }
}

function recalculateScaleTotal() {
  const prodSelect = document.getElementById('scaleProductSelect');
  if (!prodSelect || !prodSelect.selectedOptions || prodSelect.selectedOptions.length === 0) return;
  const opt = prodSelect.selectedOptions[0];
  const price = parseFloat(opt.dataset.price) || 0;
  const total = currentScaleWeight * price;
  const totalLbl = document.getElementById('lblScaleComputedTotal');
  if (totalLbl) totalLbl.innerText = `$${total.toFixed(2)}`;
}

function confirmScaleItemToCart() {
  const prodSelect = document.getElementById('scaleProductSelect');
  const isEs = posSettings && posSettings.language === 'es';
  if (!prodSelect || !prodSelect.selectedOptions || prodSelect.selectedOptions.length === 0) {
    showToast(isEs ? 'Seleccione un producto primero' : 'Select a product first', 'warning');
    return;
  }
  const opt = prodSelect.selectedOptions[0];
  const prodId = opt.value;
  const prodName = opt.dataset.name;
  const pricePerUnit = parseFloat(opt.dataset.price) || 0;

  if (currentScaleWeight <= 0) {
    showToast(isEs ? '⚠️ Coloque el producto en la báscula o ingrese peso manual' : '⚠️ Place item on scale or enter manual weight', 'warning');
    return;
  }

  const calculatedPrice = parseFloat((currentScaleWeight * pricePerUnit).toFixed(2));
  const weighedItem = {
    id: `scale_${prodId}_${Date.now()}`,
    name: `${prodName} (${currentScaleWeight.toFixed(2)} ${currentScaleUnit} @ $${pricePerUnit.toFixed(2)}/${currentScaleUnit})`,
    price: calculatedPrice,
    quantity: 1,
    unitWeight: currentScaleWeight,
    unitPrice: pricePerUnit,
    unit: currentScaleUnit,
    isCustomCake: false,
    isTaxable: opt.dataset.taxable === 'true',
    clientSeat: activeTabClientSeat || null
  };

  cart.push(weighedItem);
  updateCartUI();
  closeWeightScaleModal();
  showToast(isEs ? `${prodName} agregado ($${calculatedPrice.toFixed(2)})` : `${prodName} added ($${calculatedPrice.toFixed(2)})`, 'success');
}

// =========================================================
// CLOUD AUTO-UPDATER & SYSTEM PATCH MANAGER (OTA)
// =========================================================
let currentSystemVersion = '1.0.0';
let latestAvailableUpdate = null;

async function checkSystemUpdate(manual = false) {
  const icon = document.getElementById('updateStatusIcon');
  const text = document.getElementById('updateStatusText');
  const details = document.getElementById('updateDetailsBox');
  const verBadge = document.getElementById('lblCurrentSystemVersion');
  const isEs = (typeof posSettings !== 'undefined') && posSettings.language === 'es';

  if (manual && text) {
    text.innerText = isEs ? '🔍 Consultando la nube por actualizaciones...' : '🔍 Checking cloud for updates...';
    // icon clean
  }

  try {
    const res = await fetch(`${SERVER_URL}/api/system/check-update`);
    if (!res.ok) throw new Error('No se pudo contactar al servidor');
    const data = await res.json();
    
    currentSystemVersion = data.currentVersion || '1.0.0';
    if (verBadge) verBadge.innerText = `Impossible POS v${currentSystemVersion}`;

    if (data.hasUpdate && data.latestVersion) {
      latestAvailableUpdate = data;
      // icon clean
      if (text) {
        text.innerText = isEs 
          ? `¡Nueva versión v${data.latestVersion} disponible!` 
          : `New version v${data.latestVersion} available!`;
        text.style.color = '#30d158';
      }
      if (details) {
        details.style.display = 'block';
        details.innerHTML = `
          <div style="font-weight: bold; color: #fff; margin-bottom: 4px;">${isEs ? 'Notas de la Versión:' : 'Release Notes:'}</div>
          <div style="background: rgba(0,0,0,0.25); padding: 8px; border-radius: 6px; margin-bottom: 8px; color: #ccc;">
            ${data.releaseNotes || (isEs ? 'Mejoras de rendimiento y estabilidad.' : 'Performance & stability improvements.')}
          </div>
          <button type="button" class="btn-modal primary" onclick="applySystemUpdate()" style="width: 100%; margin: 0; padding: 10px; font-weight: bold; font-size: 12px; background-color: var(--success-color); color: #000; border-radius: 6px; cursor: pointer;">
            ⬇️ ${isEs ? `Actualizar a v${data.latestVersion} Ahora` : `Update to v${data.latestVersion} Now`}
          </button>
        `;
      }
      if (manual) {
        showToast(isEs ? `¡Nueva versión v${data.latestVersion} disponible!` : `New version v${data.latestVersion} available!`, 'success');
      }
      const btnHeaderUpdate = document.getElementById('btnHeaderUpdateAvailable');
      if (btnHeaderUpdate) {
        btnHeaderUpdate.style.display = 'inline-flex';
        btnHeaderUpdate.innerText = isEs ? `Actualizar a v${data.latestVersion}` : `Update to v${data.latestVersion}`;
        btnHeaderUpdate.onclick = () => promptApplySystemUpdate();
      }

      // Safe notification once per session (never forcefully close or loop)
      const notifyKey = `notified_update_${data.latestVersion}`;
      if (!manual && !sessionStorage.getItem(notifyKey)) {
        sessionStorage.setItem(notifyKey, 'true');
        showToast(isEs 
          ? `Nueva versión v${data.latestVersion} disponible. Puede actualizarla en Opciones.` 
          : `New version v${data.latestVersion} available. You can update in Settings.`, 'info');
      }
    } else {
      latestAvailableUpdate = null;
      const btnHeaderUpdate = document.getElementById('btnHeaderUpdateAvailable');
      if (btnHeaderUpdate) btnHeaderUpdate.style.display = 'none';
      // icon clean
      if (text) {
        text.innerText = isEs 
          ? `El sistema está actualizado a la versión más reciente (v${currentSystemVersion}).` 
          : `System is up to date (v${currentSystemVersion}).`;
        text.style.color = '#fff';
      }
      if (details) details.style.display = 'none';
      if (manual) {
        showToast(isEs ? '✓ El sistema está actualizado' : '✓ System is up to date', 'info');
      }
    }
  } catch (err) {
    if (manual) {
      if (icon) icon.innerText = '⚠️';
      if (text) text.innerText = isEs ? 'Error al consultar actualizaciones' : 'Error checking for updates';
      showToast(isEs ? 'No se pudo conectar al servidor de actualizaciones' : 'Could not connect to update server', 'warning');
    }
  }
}
window.checkSystemUpdate = checkSystemUpdate;

function promptApplySystemUpdate() {
  if (!latestAvailableUpdate) return;
  const isEs = (typeof posSettings !== 'undefined') && posSettings.language === 'es';
  const v = latestAvailableUpdate.latestVersion || '1.1.9';
  const confirmMsg = isEs 
    ? `¿Desea instalar la actualización v${v} ahora?\n\nEl sistema descargará e instalará el parche en disco. Al terminar, podrá reiniciar el sistema cuando le sea conveniente.` 
    : `Install update v${v} now?\n\nThe system will download and apply the patch to disk. You can restart when convenient.`;
  if (confirm(confirmMsg)) {
    applySystemUpdate();
  }
}
window.promptApplySystemUpdate = promptApplySystemUpdate;

async function applySystemUpdate() {
  if (window.updateInProgress) return;
  window.updateInProgress = true;
  const isEs = (typeof posSettings !== 'undefined') && posSettings.language === 'es';
  const text = document.getElementById('updateStatusText');
  const details = document.getElementById('updateDetailsBox');
  const icon = document.getElementById('updateStatusIcon');

  if (text) {
    text.innerText = isEs 
      ? 'Descargando e instalando parche de actualización... (Por favor no cierre el sistema)' 
      : 'Downloading & applying update patch... (Please do not close)';
    text.style.color = '#ff9f0a';
  }
  if (details) details.style.display = 'none';

  showToast(isEs ? 'Iniciando descarga de actualización...' : 'Starting update download...', 'info');

  try {
    const res = await fetch(`${SERVER_URL}/api/system/apply-update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updateData: latestAvailableUpdate })
    });
    const result = await res.json();
    if (result.success) {
      if (text) {
        text.innerText = isEs 
          ? `¡Actualización a v${result.newVersion || ''} instalada con éxito!` 
          : `Update to v${result.newVersion || ''} installed successfully!`;
        text.style.color = '#30d158';
      }
      showToast(isEs 
        ? `¡Actualización v${result.newVersion || ''} instalada con éxito! Reinicie el programa o la computadora para completar los cambios.` 
        : `Update v${result.newVersion || ''} installed successfully! Restart the app or computer to apply changes.`, 'success');
      
      const btnHeaderUpdate = document.getElementById('btnHeaderUpdateAvailable');
      if (btnHeaderUpdate) {
        btnHeaderUpdate.innerText = isEs ? `v${result.newVersion} Lista (Reiniciar)` : `v${result.newVersion} Ready (Restart)`;
        btnHeaderUpdate.onclick = () => {
          if (confirm(isEs ? '¿Desea recargar la aplicación ahora?' : 'Reload the application now?')) {
            window.location.reload();
          }
        };
      }
    } else {
      throw new Error(result.error || 'Error al aplicar actualización');
    }
  } catch (err) {
    if (text) {
      text.innerText = `Error: ${err.message}`;
      text.style.color = 'var(--danger-color)';
    }
    showToast(`Error: ${err.message}`, 'danger');
  } finally {
    window.updateInProgress = false;
  }
}
window.applySystemUpdate = applySystemUpdate;

async function toggleAutoUpdateSetting(enabled) {
  try {
    await fetch(`${SERVER_URL}/api/admin/settings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ autoUpdateEnabled: enabled })
    });
    const isEs = (typeof posSettings !== 'undefined') && posSettings.language === 'es';
    showToast(isEs ? 'Preferencia de actualizaciones guardada' : 'Update preferences saved', 'info');
  } catch(e) {}
}
window.toggleAutoUpdateSetting = toggleAutoUpdateSetting;

// Background polling for OTA updates (every 6 hours)
setInterval(() => {
  if (typeof posSettings !== 'undefined' && posSettings.autoUpdateEnabled !== false) {
    checkSystemUpdate(false);
  }
}, 6 * 60 * 60 * 1000);

// Check updates on load once settings are ready
setTimeout(() => {
  if (typeof posSettings !== 'undefined' && posSettings.autoUpdateEnabled !== false) {
    checkSystemUpdate(false);
  }
}, 10000);

// =========================================================
// NETWORK TOPOLOGY, STATION CROQUIS & MULTI-DEVICE BILLING
// =========================================================

window.currentTopology = {
  cashiers: 1,
  barStations: 0,
  waitressStations: 0,
  kitchenKDS: 1,
  runnerKDS: 0,
  mobileSunmis: 0
};
window.currentTopologyData = null;

async function loadNetworkTopology() {
  try {
    const res = await fetch(`${SERVER_URL}/api/system/network-topology`);
    if (!res.ok) return;
    const data = await res.json();
    window.currentTopologyData = data;
    if (data.topology) {
      window.currentTopology = data.topology;
    }

    // Update IP badge
    const ipBadge = document.getElementById('lblServerNetworkIPBadge');
    if (ipBadge && data.serverUrl) {
      ipBadge.innerText = data.serverUrl;
    }

    // Update counters in UI
    const setCt = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.innerText = val !== undefined ? val : 0;
    };
    setCt('counterCashiers', window.currentTopology.cashiers || 1);
    setCt('counterBarStations', window.currentTopology.barStations || 0);
    setCt('counterWaitressStations', window.currentTopology.waitressStations || 0);
    setCt('counterKitchenKDS', window.currentTopology.kitchenKDS || 1);
    setCt('counterMobileSunmis', window.currentTopology.mobileSunmis || 0);

    // Render nodes croquis
    renderNetworkTopologyMap(data);

    // Update billing display
    if (data.billing) {
      updateBillingDisplay(data.billing);
    }
  } catch (err) {
    console.error('Error loading network topology:', err);
  }
}
window.loadNetworkTopology = loadNetworkTopology;
window.refreshNetworkTopology = loadNetworkTopology;

let topologyDebounceTimer = null;
function adjustTopologyCounter(type, delta) {
  if (!window.currentTopology) window.currentTopology = {};
  let currentVal = parseInt(window.currentTopology[type]) || 0;
  let newVal = currentVal + delta;

  // Limits
  if (type === 'cashiers') newVal = Math.max(1, Math.min(8, newVal));
  else if (type === 'barStations') newVal = Math.max(0, Math.min(4, newVal));
  else if (type === 'waitressStations') newVal = Math.max(0, Math.min(8, newVal));
  else if (type === 'kitchenKDS') newVal = Math.max(0, Math.min(4, newVal));
  else if (type === 'runnerKDS') newVal = Math.max(0, Math.min(2, newVal));
  else if (type === 'mobileSunmis') newVal = Math.max(0, Math.min(12, newVal));

  window.currentTopology[type] = newVal;

  // Update UI counter immediately
  const idMap = {
    cashiers: 'counterCashiers',
    barStations: 'counterBarStations',
    waitressStations: 'counterWaitressStations',
    kitchenKDS: 'counterKitchenKDS',
    mobileSunmis: 'counterMobileSunmis'
  };
  const cEl = document.getElementById(idMap[type]);
  if (cEl) cEl.innerText = newVal;

  // Recalculate billing instantly
  const windowsCount = (window.currentTopology.cashiers || 1) + (window.currentTopology.barStations || 0) + (window.currentTopology.waitressStations || 0);
  const windowsTotal = windowsCount * 85.0;
  const barHubActive = (window.currentTopology.barStations || 0) > 0;
  const barHubTotal = barHubActive ? 100.0 : 0.0;
  const sunmiCount = window.currentTopology.mobileSunmis || 0;
  const extraSunmis = Math.max(0, sunmiCount - 1);
  const sunmiTotal = extraSunmis * 20.0;
  const grandTotal = windowsTotal + barHubTotal + sunmiTotal;

  updateBillingDisplay({
    windowsCount,
    windowsTotal,
    barHubActive,
    barHubTotal,
    sunmiCount,
    sunmiTotal,
    grandTotal
  });

  // Debounce save to server
  clearTimeout(topologyDebounceTimer);
  topologyDebounceTimer = setTimeout(async () => {
    try {
      await fetch(`${SERVER_URL}/api/system/network-topology`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topology: window.currentTopology })
      });
      loadNetworkTopology();
    } catch (e) {}
  }, 400);
}
window.adjustTopologyCounter = adjustTopologyCounter;

function renderNetworkTopologyMap(data) {
  const container = document.getElementById('topologyMapNodesContainer');
  const btnQR = document.getElementById('btnOpenSunmiQRModal');
  if (!container) return;

  if (btnQR) {
    btnQR.style.display = (window.currentTopology.mobileSunmis > 0) ? 'flex' : 'none';
  }

  const stations = (data && data.stations) ? data.stations : [];
  if (stations.length === 0) {
    container.innerHTML = '<div style="color: var(--text-secondary); font-size: 11px; padding: 10px;">No stations configured. Click + above to add stations.</div>';
    return;
  }

  let html = '';
  stations.forEach(s => {
    const isConn = s.connected;
    const borderCol = isConn ? '#30d158' : 'rgba(255,255,255,0.12)';
    const bgCol = isConn ? 'rgba(48,209,88,0.06)' : 'rgba(0,0,0,0.3)';
    const statusText = isConn 
      ? (s.isPrimary ? '🟢 Active (Main Server)' : `🟢 Connected (${s.ip || 'LAN'})`)
      : '⚪ Waiting for device... / Esperando equipo...';

    html += `
      <div style="background: ${bgCol}; border: 1px solid ${borderCol}; border-radius: 8px; padding: 10px; display: flex; flex-direction: column; gap: 6px; position: relative;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <div style="display: flex; align-items: center; gap: 6px;">
            <span style="font-size: 20px;">${s.emoji || '💻'}</span>
            <div>
              <strong style="font-size: 12px; color: #fff; display: block;">${s.name}</strong>
              <span style="font-size: 10px; color: var(--text-secondary); text-transform: uppercase;">${s.role}</span>
            </div>
          </div>
          ${s.type === 'sunmi' ? `<span style="font-size: 9px; padding: 2px 6px; border-radius: 4px; background: rgba(48,209,88,0.2); color: #30d158; font-weight: bold;">Mobile QR</span>` : ''}
        </div>

        <div style="margin-top: 4px; padding-top: 6px; border-top: 1px solid rgba(255,255,255,0.05); font-size: 10.5px; color: ${isConn ? '#30d158' : 'var(--text-secondary)'}; display: flex; align-items: center; justify-content: space-between;">
          <span>${statusText}</span>
          ${(s.type === 'sunmi' && s.qrUrl) ? `<button type="button" onclick="openSunmiSingleQR('${s.name}', '${s.qrUrl}')" style="background: none; border: 1px solid #30d158; color: #30d158; border-radius: 4px; font-size: 9px; padding: 2px 6px; cursor: pointer;">📷 Scan QR</button>` : ''}
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

function updateBillingDisplay(billing) {
  if (!billing) return;
  const setTxt = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.innerText = val;
  };

  setTxt('lblBillWindowsCount', `• ${billing.windowsCount || 1}x Windows Terminal ($85/ea):`);
  setTxt('lblBillWindowsTotal', `$${(billing.windowsTotal || 85).toFixed(2)}`);

  const rowBar = document.getElementById('rowBillBarHub');
  if (rowBar) {
    rowBar.style.display = billing.barHubActive ? 'flex' : 'none';
  }
  setTxt('lblBillBarHubTotal', `$${(billing.barHubTotal || 0).toFixed(2)}`);

  const rowSunmi = document.getElementById('rowBillSunmi');
  const count = billing.sunmiCount || 0;
  if (rowSunmi) {
    rowSunmi.style.display = count > 0 ? 'flex' : 'none';
  }
  setTxt('lblBillSunmiCount', `• ${count}x Mobile Sunmi (1st Free + $20/ea):`);
  setTxt('lblBillSunmiTotal', `$${(billing.sunmiTotal || 0).toFixed(2)}`);

  setTxt('lblBillGrandTotal', `$${(billing.grandTotal || 85).toFixed(2)}`);
}

function openSunmiQRCardsModal() {
  const modal = document.getElementById('modalSunmiQRCards');
  const grid = document.getElementById('sunmiQRCardsGrid');
  if (!modal || !grid) return;

  const stations = (window.currentTopologyData && window.currentTopologyData.stations) 
    ? window.currentTopologyData.stations.filter(s => s.type === 'sunmi')
    : [];

  if (stations.length === 0) {
    grid.innerHTML = '<div style="color: #fff; font-size: 12px;">No mobile devices configured yet. Add Sunmi devices in the counters above.</div>';
  } else {
    let html = '';
    stations.forEach((s, idx) => {
      const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(s.qrUrl)}`;
      html += `
        <div style="background: rgba(0,0,0,0.4); border: 1px solid rgba(48,209,88,0.4); border-radius: 8px; padding: 14px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 8px;">
          <div style="font-size: 13px; font-weight: bold; color: #fff;">📱 Sunmi #${idx + 1}</div>
          <span style="font-size: 10px; color: var(--text-secondary);">Waitress / Mesas</span>
          <div style="background: #fff; padding: 6px; border-radius: 8px; display: inline-block;">
            <img src="${qrApiUrl}" alt="QR Sunmi" style="width: 150px; height: 150px; display: block;" onerror="this.src='https://chart.googleapis.com/chart?cht=qr&chs=150x150&chl=${encodeURIComponent(s.qrUrl)}'">
          </div>
          <div style="font-family: monospace; font-size: 9px; color: #30d158; word-break: break-all; max-width: 170px;">${s.qrUrl}</div>
          <span style="font-size: 9.5px; color: var(--text-secondary);">Open camera & scan / Abre la cámara y escanea</span>
        </div>
      `;
    });
    grid.innerHTML = html;
  }

  modal.style.display = 'flex';
}
window.openSunmiQRCardsModal = openSunmiQRCardsModal;

function openSunmiSingleQR(name, url) {
  openSunmiQRCardsModal();
}
window.openSunmiSingleQR = openSunmiSingleQR;

function closeSunmiQRModal() {
  const modal = document.getElementById('modalSunmiQRCards');
  if (modal) modal.style.display = 'none';
}
window.closeSunmiQRModal = closeSunmiQRModal;

// Auto-Claim Station Logic for Secondary PCs
async function checkClaimStationOnStartup() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramStation = urlParams.get('station');
  if (paramStation) {
    localStorage.setItem('impossible_pos_station_id', paramStation);
    return;
  }

  const assignedStation = localStorage.getItem('impossible_pos_station_id');
  const isLocalhost = (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

  if (assignedStation || isLocalhost) {
    if (assignedStation) {
      try {
        fetch(`${SERVER_URL}/api/system/station-ping`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stationId: assignedStation })
        });
      } catch(e) {}
    }
    return;
  }

  try {
    const res = await fetch(`${SERVER_URL}/api/system/network-topology`);
    if (!res.ok) return;
    const data = await res.json();
    const unclaimed = (data.stations || []).filter(s => !s.isPrimary && !s.connected && s.type !== 'sunmi');

    if (unclaimed.length === 0) return;

    const modal = document.getElementById('modalClaimStation');
    const container = document.getElementById('claimStationButtonsContainer');
    if (!modal || !container) return;

    let html = '';
    unclaimed.forEach(s => {
      html += `
        <button type="button" onclick="claimStationSlot('${s.id}', '${s.name}', '${s.role}')" class="btn-modal" style="width: 100%; margin: 0; padding: 12px; font-size: 13px; font-weight: bold; background: rgba(10,132,255,0.15); border: 1.5px solid #0a84ff; color: #fff; border-radius: 8px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
          <span>${s.emoji}</span> <span>${s.name}</span>
        </button>
      `;
    });

    container.innerHTML = html;
    modal.style.display = 'flex';
  } catch (err) {
    console.warn('[CLAIM STATION] Could not check unclaimed stations:', err);
  }
}

async function claimStationSlot(stationId, stationName, role) {
  try {
    localStorage.setItem('impossible_pos_station_id', stationId);
    await fetch(`${SERVER_URL}/api/system/claim-station`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stationId: stationId,
        deviceName: stationName,
        stationRole: role
      })
    });

    const modal = document.getElementById('modalClaimStation');
    if (modal) modal.style.display = 'none';

    showToast(`✅ Assigned as: ${stationName}!`, 'success');
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  } catch(e) {
    showToast('Error claiming station: ' + e.message, 'danger');
  }
}
window.claimStationSlot = claimStationSlot;

window.addEventListener('load', () => {
  setTimeout(checkClaimStationOnStartup, 1500);
});



// ==========================================
// MANAGER / OWNER PIN MANAGEMENT
// ==========================================
function openChangeManagerPinModal() {
  const modal = document.getElementById('modalChangeManagerPin');
  if (!modal) return;
  const cur = document.getElementById('inputChangePinCurrent');
  const nw = document.getElementById('inputChangePinNew');
  const conf = document.getElementById('inputChangePinConfirm');
  if (cur) cur.value = '';
  if (nw) nw.value = '';
  if (conf) conf.value = '';
  modal.style.display = 'flex';
  setTimeout(() => { if (cur) cur.focus(); }, 100);
}
window.openChangeManagerPinModal = openChangeManagerPinModal;

function closeChangeManagerPinModal() {
  const modal = document.getElementById('modalChangeManagerPin');
  if (modal) modal.style.display = 'none';
}
window.closeChangeManagerPinModal = closeChangeManagerPinModal;

async function submitChangeManagerPin() {
  const isEs = (typeof posSettings !== 'undefined') && posSettings.language === 'es';
  const cur = document.getElementById('inputChangePinCurrent') ? document.getElementById('inputChangePinCurrent').value.trim() : '';
  const nw = document.getElementById('inputChangePinNew') ? document.getElementById('inputChangePinNew').value.trim() : '';
  const conf = document.getElementById('inputChangePinConfirm') ? document.getElementById('inputChangePinConfirm').value.trim() : '';

  if (!cur) {
    showToast(isEs ? 'Por favor ingresa tu PIN actual' : 'Please enter your current PIN', 'error');
    return;
  }
  if (!nw || nw.length !== 4 || !/^\d{4}$/.test(nw)) {
    showToast(isEs ? 'El nuevo PIN debe tener exactamente 4 números' : 'New PIN must be exactly 4 digits', 'error');
    return;
  }
  if (nw !== conf) {
    showToast(isEs ? 'La confirmación del nuevo PIN no coincide' : 'New PIN confirmation does not match', 'error');
    return;
  }

  try {
    const res = await fetch(`${SERVER_URL}/api/employees/change-manager-pin`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ currentPin: cur, newPin: nw })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      closeChangeManagerPinModal();
      showToast(isEs ? '✅ ¡PIN de Gerente actualizado con éxito!' : '✅ Manager PIN updated successfully!', 'success');
      if (typeof loadEmployeesList === 'function') {
        loadEmployeesList();
      }
    } else {
      showToast(data.error || (isEs ? 'Error al actualizar el PIN' : 'Failed to update PIN'), 'error');
    }
  } catch(err) {
    showToast(isEs ? 'Error de conexión con el servidor' : 'Server connection error', 'error');
  }
}
window.submitChangeManagerPin = submitChangeManagerPin;

// --- CLOUD SYNC HEADER CONTROLLER ---
async function updateCloudSyncStatus() {
  try {
    const res = await fetch(`${SERVER_URL}/api/cloud-sync/status`);
    if (res.ok) {
      const data = await res.json();
      const dot = document.getElementById('cloudSyncDot');
      const lbl = document.getElementById('lblCloudSyncStatus');
      const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');

      if (dot && lbl) {
        if (data.isOnline) {
          dot.style.backgroundColor = '#30d158';
          dot.style.boxShadow = '0 0 6px rgba(48,209,88,0.8)';
          lbl.innerText = data.pendingCount > 0 
            ? (isEs ? `☁️ Nube (${data.pendingCount})` : `☁️ Cloud (${data.pendingCount})`)
            : (isEs ? '☁️ Nube' : '☁️ Cloud');
        } else {
          dot.style.backgroundColor = '#8e8e93';
          dot.style.boxShadow = 'none';
          lbl.innerText = data.pendingCount > 0 
            ? (isEs ? `☁️ Offline (${data.pendingCount})` : `☁️ Offline (${data.pendingCount})`)
            : (isEs ? 'Offline' : 'Offline');
        }
      }
    }
  } catch (e) {}
}

async function triggerManualCloudSync() {
  const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');
  showToast(isEs ? 'Syncing with Cloud Owner Portal...' : '☁️ Syncing with Cloud Owner Portal...', 'info');
  try {
    const res = await fetch(`${SERVER_URL}/api/cloud-sync/flush`, { method: 'POST' });
    const data = await res.json();
    showToast(isEs ? 'Cloud sync completed' : 'Cloud sync completed', 'success');
    updateCloudSyncStatus();
  } catch (e) {
    showToast(isEs ? 'Modo sin conexión. Los datos están guardados localmente.' : 'Offline mode. Data safely queued locally.', 'warning');
  }
}
window.triggerManualCloudSync = triggerManualCloudSync;
window.updateCloudSyncStatus = updateCloudSyncStatus;

setInterval(updateCloudSyncStatus, 20000);
setTimeout(updateCloudSyncStatus, 2500);


function openOwnerPortalInBrowser() {
  const url = 'https://impossiblepos.com/portal.html';
  fetch('/api/system/open-portal', { method: 'POST' }).catch(() => {});
  try {
    window.open(url, '_blank');
  } catch (e) {}
}
window.openOwnerPortalInBrowser = openOwnerPortalInBrowser;

function openCloudSyncModal() {
  const modal = document.getElementById('modalCloudPortal');
  const settings = (typeof posSettings !== 'undefined' && posSettings) ? posSettings : {};
  const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');
  const licKey = (settings.licenseKey || '').trim().toUpperCase() || (isEs ? 'SIN LICENCIA REGISTRADA' : 'NO LICENSE REGISTERED');
  const licValEl = document.getElementById('txtModalCloudLicVal');
  if (licValEl) licValEl.innerText = licKey;
  
  const connValEl = document.getElementById('txtModalCloudConnVal');
  const badgeEl = document.getElementById('modalCloudStatusBadge');
  
  if (connValEl && badgeEl) {
    if (navigator.onLine) {
      connValEl.innerText = isEs ? 'En Línea - Listo para Sincronizar' : 'Online - Ready to Sync';
      connValEl.style.color = '#30d158';
      badgeEl.innerText = isEs ? 'CONECTADO' : 'CONNECTED';
      badgeEl.style.color = '#30d158';
      badgeEl.style.borderColor = 'rgba(48,209,88,0.3)';
      badgeEl.style.background = 'rgba(48,209,88,0.15)';
    } else {
      connValEl.innerText = isEs ? 'Sin Conexión - Ventas en Cola Local' : 'Offline - Sales Queued Locally';
      connValEl.style.color = '#ff9f0a';
      badgeEl.innerText = isEs ? 'OFFLINE' : 'OFFLINE';
      badgeEl.style.color = '#ff9f0a';
      badgeEl.style.borderColor = 'rgba(255,159,10,0.3)';
      badgeEl.style.background = 'rgba(255,159,10,0.15)';
    }
  }
  modal.style.display = 'flex';
}
window.openCloudSyncModal = openCloudSyncModal;


// Cloud Menu Backup & Restore Logic
async function triggerCloudMenuBackup() {
  const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');
  showToast(isEs ? 'Subiendo catálogo a la nube...' : 'Uploading menu to cloud...', 'info');
  try {
    const res = await fetch('/api/cloud/backup-catalog', { method: 'POST' });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to backup catalog');
    }
    showToast(isEs ? 'Respaldo del menú guardado en la nube' : 'Menu backup saved to cloud successfully', 'success');
  } catch (err) {
    showToast((isEs ? 'Error al respaldar en la nube: ' : 'Cloud backup error: ') + err.message, 'danger');
  }
}
window.triggerCloudMenuBackup = triggerCloudMenuBackup;

function openCloudRestoreModal() {
  const modal = document.getElementById('modalCloudRestoreMenu');
  if (!modal) return;
  const settings = (typeof posSettings !== 'undefined' && posSettings) ? posSettings : {};
  const licKey = settings.licenseKey || '';
  const licInput = document.getElementById('inputRestoreLicenseKey');
  if (licInput && licKey) licInput.value = licKey;
  modal.style.display = 'flex';
}
window.openCloudRestoreModal = openCloudRestoreModal;

async function executeCloudMenuRestore() {
  const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');
  const email = (document.getElementById('inputRestoreEmail') ? document.getElementById('inputRestoreEmail').value : '').trim();
  const password = document.getElementById('inputRestorePassword') ? document.getElementById('inputRestorePassword').value : '';
  let licenseKey = (document.getElementById('inputRestoreLicenseKey') ? document.getElementById('inputRestoreLicenseKey').value : '').trim().toUpperCase();

  const statusEl = document.getElementById('txtRestoreModalStatus');
  if (statusEl) {
    statusEl.style.display = 'block';
    statusEl.style.color = '#30d158';
    statusEl.innerText = isEs ? 'Conectando con la nube de Impossible POS...' : 'Connecting to Impossible POS cloud...';
  }

  if (!email && !licenseKey) {
    const msg = isEs ? 'Ingresa tu correo y contraseña, o tu clave de licencia' : 'Please enter your email and password, or license key';
    if (statusEl) { statusEl.style.color = '#ff4d4f'; statusEl.innerText = msg; }
    showToast(msg, 'warning');
    return;
  }

  const btn = document.getElementById('btnExecuteRestore');
  if (btn) btn.disabled = true;

  try {
    let catalogData = null;

    // Step 1: Direct fetch from browser to Render Cloud (Bypasses Node TLS restrictions)
    try {
      const renderRes = await fetch('https://impossible-pos-licenses.onrender.com/api/cloud/catalog/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, licenseKey })
      });
      if (renderRes.ok) {
        const text = await renderRes.text();
        try {
          const d = JSON.parse(text);
          if (d && d.success && d.products) {
            catalogData = d;
          }
        } catch (pe) {
          console.warn('[CLOUD RESTORE] Failed to parse Render response JSON');
        }
      }
    } catch (browserErr) {
      console.warn('[CLOUD RESTORE] Direct fetch error:', browserErr.message);
    }

    // Step 2: If direct fetch didn't obtain catalog, try local server endpoint
    if (!catalogData) {
      if (statusEl) statusEl.innerText = isEs ? 'Consultando servidor de licencias...' : 'Querying license server...';
      const localRes = await fetch('/api/cloud/restore-catalog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, licenseKey })
      });
      const localText = await localRes.text();
      let localResult = null;
      try {
        localResult = JSON.parse(localText);
      } catch (e) {
        throw new Error(isEs ? 'El servidor local devolvió una respuesta no válida' : 'Local server returned non-JSON response');
      }
      if (!localRes.ok || !localResult.success) {
        throw new Error(localResult.error || (isEs ? 'Error al restaurar catálogo' : 'Failed to restore menu'));
      }
      catalogData = localResult;
    }

    // Step 3: Save catalogData into local database!
    if (catalogData && catalogData.products && !catalogData.alreadyImported) {
      if (statusEl) statusEl.innerText = isEs ? 'Guardando menú en la base de datos...' : 'Saving menu to database...';
      let saved = false;

      // Method A: Dedicated batch import route
      try {
        const impRes = await fetch('/api/cloud/import-catalog', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(catalogData)
        });
        if (impRes.ok) {
          const impText = await impRes.text();
          try {
            const ir = JSON.parse(impText);
            if (ir.success) saved = true;
          } catch(e) {}
        }
      } catch(e) {}

      // Method B: Universal fallback using legacy core POS endpoints
      if (!saved) {
        if (catalogData.licenseKey || catalogData.businessName) {
          await fetch('/api/admin/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey: catalogData.licenseKey, businessName: catalogData.businessName })
          }).catch(() => {});
        }
        if (catalogData.categories && Array.isArray(catalogData.categories)) {
          for (const cat of catalogData.categories) {
            await fetch('/api/departments', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(cat)
            }).catch(() => {});
          }
        }
        if (catalogData.modifierGroups && Array.isArray(catalogData.modifierGroups)) {
          for (const grp of catalogData.modifierGroups) {
            await fetch('/api/admin/modifier-groups', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(grp)
            }).catch(() => {});
          }
        }
        if (catalogData.products && Array.isArray(catalogData.products)) {
          await fetch('/api/admin/products/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(catalogData.products)
          }).catch(() => {});
        }
      }
    }

    const count = catalogData.products ? catalogData.products.length : (catalogData.productCount || 0);
    const successMsg = isEs ? `¡Éxito! Menú descargado (${count} productos)` : `Success! Menu restored (${count} products)`;
    if (statusEl) {
      statusEl.style.color = '#30d158';
      statusEl.innerText = successMsg;
    }
    showToast(successMsg, 'success');

    setTimeout(() => {
      const modal = document.getElementById('modalCloudRestoreMenu');
      if (modal) modal.style.display = 'none';
      if (statusEl) statusEl.style.display = 'none';
    }, 1500);

    if (typeof loadProducts === 'function') loadProducts();
    if (typeof loadCategories === 'function') loadCategories();
  } catch (err) {
    const errMsg = (isEs ? 'Error al restaurar: ' : 'Restore failed: ') + err.message;
    if (statusEl) { statusEl.style.color = '#ff4d4f'; statusEl.innerText = errMsg; }
    showToast(errMsg, 'danger');
  } finally {
    if (btn) btn.disabled = false;
  }
}
window.executeCloudMenuRestore = executeCloudMenuRestore;


async function executeQuickManagerRestore() {
  const isEs = (typeof currentLang !== 'undefined' && currentLang === 'es');
  const pinInput = document.getElementById('inputRestoreManagerPin');
  const managerPin = (pinInput ? pinInput.value : '').trim();

  if (!managerPin) {
    showToast(isEs ? 'Ingresa el PIN de Manager o Master' : 'Please enter Manager or Master PIN', 'warning');
    return;
  }

  showToast(isEs ? 'Verificando autorización y descargando menú...' : 'Verifying authorization & downloading menu...', 'info');
  const btn = document.getElementById('btnQuickManagerRestore');
  if (btn) btn.disabled = true;

  try {
    const res = await fetch('/api/cloud/restore-catalog', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ managerPin })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error === 'INVALID_MANAGER_PIN' 
        ? (isEs ? 'PIN de Manager incorrecto' : 'Invalid Manager PIN') 
        : (data.error || 'Failed to restore menu'));
    }

    document.getElementById('modalCloudRestoreMenu').style.display = 'none';
    if (pinInput) pinInput.value = '';
    showToast(isEs ? `Menú restaurado con éxito (${data.productCount} productos)` : `Menu restored successfully (${data.productCount} items)`, 'success');

    if (typeof loadProducts === 'function') loadProducts();
    if (typeof loadCategories === 'function') loadCategories();
  } catch (err) {
    showToast((isEs ? 'Error al restaurar: ' : 'Restore failed: ') + err.message, 'danger');
  } finally {
    if (btn) btn.disabled = false;
  }
}
window.executeQuickManagerRestore = executeQuickManagerRestore;
