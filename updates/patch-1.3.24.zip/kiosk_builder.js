const path = require('path');
const fs = require('fs');

const STATIONS_CONFIG = {
  kitchen: {
    id: 'kitchen',
    name_en: 'Kitchen KDS',
    name_es: 'Cocina KDS',
    fileName_en: '1_INSTALL_KITCHEN_KDS.bat',
    fileName_es: '1_INSTALAR_COCINA_KDS.bat',
    shortcut_en: 'Impossible POS - Kitchen KDS.lnk',
    shortcut_es: 'Impossible POS - Cocina KDS.lnk',
    icon: 'kitchen.ico',
    url: '/cocina.html',
    desc_en: 'Main Kitchen Display (KDS)',
    desc_es: 'Pantalla de Cocina (KDS)'
  },
  bakery: {
    id: 'bakery',
    name_en: 'Special Orders KDS (Bakery)',
    name_es: 'Cocina Pedidos Especiales (Pasteleria)',
    fileName_en: '2_INSTALL_BAKERY_SPECIAL_ORDERS.bat',
    fileName_es: '2_INSTALAR_PASTELERIA_KDS.bat',
    shortcut_en: 'Impossible POS - Special Orders KDS.lnk',
    shortcut_es: 'Impossible POS - Cocina Pasteleria.lnk',
    icon: 'cake_kds.ico',
    url: '/cocina.html?station=bakery',
    desc_en: 'Special Orders Display',
    desc_es: 'Pantalla de Pedidos Especiales'
  },
  bar: {
    id: 'bar',
    name_en: 'Bar KDS (Beverages)',
    name_es: 'Bar KDS (Bebidas)',
    fileName_en: '3_INSTALL_BAR_KDS.bat',
    fileName_es: '3_INSTALAR_BAR_KDS.bat',
    shortcut_en: 'Impossible POS - Bar Hub.lnk',
    shortcut_es: 'Impossible POS - Bar Hub.lnk',
    icon: 'bar.ico',
    url: '/kds_bar.html',
    desc_en: 'Bar and Drinks Display',
    desc_es: 'Pantalla de Barra y Bebidas'
  },
  photo: {
    id: 'photo',
    name_en: 'Photo Hub (Photos)',
    name_es: 'Photo Hub (Fotos)',
    fileName_en: '4_INSTALL_PHOTO_HUB.bat',
    fileName_es: '4_INSTALAR_PHOTO_HUB.bat',
    shortcut_en: 'Impossible POS - Photo Hub.lnk',
    shortcut_es: 'Impossible POS - Photo Hub.lnk',
    icon: 'photo_hub.ico',
    url: '/photos.html',
    desc_en: 'Customer Photos Viewer',
    desc_es: 'Visor de Fotos'
  },
  lobby_tv: {
    id: 'lobby_tv',
    name_en: 'Lobby TV (Queue)',
    name_es: 'Lobby TV (Turnos)',
    fileName_en: '5_INSTALL_LOBBY_TV.bat',
    fileName_es: '5_INSTALAR_LOBBY_TV.bat',
    shortcut_en: 'Impossible POS - Lobby TV.lnk',
    shortcut_es: 'Impossible POS - Lobby TV.lnk',
    icon: 'lobby_tv.ico',
    url: '/espera.html',
    desc_en: 'Customer Queue Display',
    desc_es: 'Pantalla de Turnos'
  },
  runner: {
    id: 'runner',
    name_en: 'Runner (Dispatch)',
    name_es: 'Runner (Despacho)',
    fileName_en: '6_INSTALL_RUNNER.bat',
    fileName_es: '6_INSTALAR_RUNNER.bat',
    shortcut_en: 'Impossible POS - Runner Dispatch.lnk',
    shortcut_es: 'Impossible POS - Runner Despacho.lnk',
    icon: 'runner.ico',
    url: '/runner.html',
    desc_en: 'Order Expediter Display',
    desc_es: 'Pantalla de Despacho'
  },
  hostess: {
    id: 'hostess',
    name_en: 'Hostess (Front Desk)',
    name_es: 'Hostess (Recepcion)',
    fileName_en: '7_INSTALL_HOSTESS.bat',
    fileName_es: '7_INSTALAR_HOSTESS.bat',
    shortcut_en: 'Impossible POS - Hostess.lnk',
    shortcut_es: 'Impossible POS - Hostess.lnk',
    icon: 'hostess.ico',
    url: '/hostess.html',
    desc_en: 'Hostess Tables Display',
    desc_es: 'Pantalla de Mesas y Recepcion'
  },
  secondary: {
    id: 'secondary',
    name_en: 'Secondary Register (POS 2)',
    name_es: 'Caja Secundaria (POS 2)',
    fileName_en: '8_INSTALL_SECONDARY_REGISTER.bat',
    fileName_es: '8_INSTALAR_CAJA_SECUNDARIA.bat',
    shortcut_en: 'Impossible POS - Secondary POS.lnk',
    shortcut_es: 'Impossible POS - Caja Secundaria.lnk',
    icon: 'pos.ico',
    url: '/caja_v14.html?station=2',
    desc_en: 'Secondary Checkout Terminal',
    desc_es: 'Terminal de Cobro Secundaria'
  }
};

function generateStationLauncherBat(st, serverIp) {
  return `@echo off\r
setlocal EnableDelayedExpansion\r
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"\r
set "SERVER_IP=${serverIp}"\r
if exist "%APP_DIR%\\server_ip.txt" set /p SERVER_IP=<"%APP_DIR%\\server_ip.txt"\r
if "%SERVER_IP%"=="" set "SERVER_IP=${serverIp}"\r
\r
:: Plug and Play: Auto-discover server if not responding\r
set "AUTO_IP="\r
if exist "%APP_DIR%\\discover_server.ps1" (\r
    for /f "usebackq delims=" %%i in (\`powershell -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%\\discover_server.ps1" -LastKnownIp "%SERVER_IP%"\`) do (\r
        if not "%%i"=="" set "AUTO_IP=%%i"\r
    )\r
)\r
if not "!AUTO_IP!"=="" (\r
    set "SERVER_IP=!AUTO_IP!"\r
    echo !AUTO_IP!>"%APP_DIR%\\server_ip.txt"\r
)\r
\r
set "BROWSER_EXE="\r
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"\r
if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"\r
if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"\r
\r
if "%BROWSER_EXE%"=="" (\r
    start "http://%SERVER_IP%:3000${st.url}"\r
    exit\r
)\r
\r
start "" "%BROWSER_EXE%" --app="http://%SERVER_IP%:3000${st.url}" --kiosk --no-first-run\r
exit\r
`;
}

function generateSingleStationInstaller(st, serverIp, lang) {
  const isEs = lang === 'es';
  const title = isEs ? `Instalar ${st.name_es} - Impossible POS` : `Install ${st.name_en} - Impossible POS`;
  const shortcutName = isEs ? st.shortcut_es : st.shortcut_en;
  const desc = isEs ? st.desc_es : st.desc_en;
  const step1 = isEs ? '[1/3] Configurando icono oficial...' : '[1/3] Setting up official icon...';
  const step2 = isEs ? '[2/3] Localizando navegador (Chrome o Edge)...' : '[2/3] Locating browser (Chrome or Edge)...';
  const step3 = isEs ? '[3/3] Creando acceso directo en el escritorio y auto-arranque...' : '[3/3] Creating Desktop shortcut and auto-start...';
  const errBrowser = isEs ? 'ERROR: No se encontro Google Chrome ni Microsoft Edge en esta computadora.' : 'ERROR: Neither Google Chrome nor Microsoft Edge was found on this computer.';
  const successMsg = isEs ? `EXITO: ${st.name_es} configurada con exito en esta computadora.` : `SUCCESS: ${st.name_en} configured successfully on this computer.`;

  return `@echo off\r
setlocal EnableDelayedExpansion\r
title ${title}\r
color 0B\r
\r
echo ======================================================================\r
echo   IMPOSSIBLE POS - KIOSK SHORTCUT INSTALLER\r
echo   Station: ${isEs ? st.name_es : st.name_en}\r
echo ======================================================================\r
echo.\r
\r
set "SERVER_IP=${serverIp}"\r
if exist "%~dp0server_ip.txt" set /p SERVER_IP=<"%~dp0server_ip.txt"\r
if "%SERVER_IP%"=="" set "SERVER_IP=${serverIp}"\r
\r
set "SHORTCUT_NAME=${shortcutName}"\r
set "ICON_NAME=${st.icon}"\r
set "APP_DIR=%LOCALAPPDATA%\\ImpossiblePOS"\r
set "ICON_DEST=%APP_DIR%\\Icons\\%ICON_NAME%"\r
set "LAUNCH_BAT=%APP_DIR%\\launch_${st.id}.bat"\r
\r
if not exist "%APP_DIR%\\Icons" mkdir "%APP_DIR%\\Icons"\r
if exist "%~dp0Icons\\%ICON_NAME%" copy /Y "%~dp0Icons\\%ICON_NAME%" "%ICON_DEST%" >nul\r
if exist "%~dp0discover_server.ps1" copy /Y "%~dp0discover_server.ps1" "%APP_DIR%\\discover_server.ps1" >nul\r
if exist "%~dp0launch_${st.id}.bat" copy /Y "%~dp0launch_${st.id}.bat" "%LAUNCH_BAT%" >nul\r
echo %SERVER_IP%>"%APP_DIR%\\server_ip.txt"\r
\r
echo ${step1}\r
if not exist "%ICON_DEST%" (\r
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/icons/%ICON_NAME%', '%ICON_DEST%')" >nul 2>&1\r
    if not exist "%ICON_DEST%" (\r
        curl -s -o "%ICON_DEST%" "http://%SERVER_IP%:3000/icons/%ICON_NAME%" >nul 2>&1\r
    )\r
)\r
\r
if not exist "%APP_DIR%\\discover_server.ps1" (\r
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('http://%SERVER_IP%:3000/kiosco/discover_server.ps1', '%APP_DIR%\\discover_server.ps1')" >nul 2>&1\r
)\r
\r
echo ${step2}\r
set "BROWSER_EXE="\r
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (\r
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"\r
) else if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (\r
    set "BROWSER_EXE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"\r
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"\r
) else if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"\r
) else if exist "%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe" (\r
    set "BROWSER_EXE=%LocalAppData%\\Google\\Chrome\\Application\\chrome.exe"\r
)\r
\r
if "%BROWSER_EXE%"=="" (\r
    echo ${errBrowser}\r
    pause\r
    exit /b 1\r
)\r
\r
:: Si no existe launch_bat, generarlo con auto-discovery integrado\r
if not exist "%LAUNCH_BAT%" (\r
    echo @echo off > "%LAUNCH_BAT%"\r
    echo set "APP_DIR=%%LOCALAPPDATA%%\\ImpossiblePOS" >> "%LAUNCH_BAT%"\r
    echo set "SERVER_IP=${serverIp}" >> "%LAUNCH_BAT%"\r
    echo if exist "%%APP_DIR%%\\server_ip.txt" set /p SERVER_IP=^<"%%APP_DIR%%\\server_ip.txt" >> "%LAUNCH_BAT%"\r
    echo if exist "%%APP_DIR%%\\discover_server.ps1" for /f "usebackq delims=" %%%%i in (`powershell -NoProfile -ExecutionPolicy Bypass -File "%%APP_DIR%%\\discover_server.ps1" -LastKnownIp "%%SERVER_IP%%"`^) do if not "%%%%i"=="" set "SERVER_IP=%%%%i" >> "%LAUNCH_BAT%"\r
    echo start "" "%BROWSER_EXE%" --app="http://%%SERVER_IP%%:3000${st.url}" --kiosk --no-first-run >> "%LAUNCH_BAT%"\r
    echo exit >> "%LAUNCH_BAT%"\r
)\r
\r
echo ${step3}\r
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $desktop = $ws.SpecialFolders('Desktop'); $shortcut = $ws.CreateShortcut($desktop + '\\%SHORTCUT_NAME%'); $shortcut.TargetPath = '%LAUNCH_BAT%'; $shortcut.WorkingDirectory = '%APP_DIR%'; $shortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $shortcut.IconLocation = '%ICON_DEST%,0' }; $shortcut.Description = '${desc}'; $shortcut.Save(); $startup = $ws.SpecialFolders('Startup'); $sShortcut = $ws.CreateShortcut($startup + '\\%SHORTCUT_NAME%'); $sShortcut.TargetPath = '%LAUNCH_BAT%'; $sShortcut.WorkingDirectory = '%APP_DIR%'; $sShortcut.WindowStyle = 7; if (Test-Path '%ICON_DEST%') { $sShortcut.IconLocation = '%ICON_DEST%,0' }; $sShortcut.Save();"\r
\r
echo.\r
echo ======================================================================\r
echo   ${successMsg}\r
echo   - Desktop Shortcut: "%SHORTCUT_NAME%"\r
echo   - URL: http://%SERVER_IP%:3000${st.url}\r
echo ======================================================================\r
echo.\r
start "" "%LAUNCH_BAT%"\r
timeout /t 2 >nul\r
exit\r
`;
}

module.exports = {
  STATIONS_CONFIG,
  generateSingleStationInstaller,
  generateStationLauncherBat
};
